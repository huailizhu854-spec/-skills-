# AGI Skills · Dual16 Agent Harness

> **2 Controllers + 16 Workers · Evidence-first orchestration, evaluation & replay**
>
> 中文开源项目：以可复现的本地评测、严格任务归属和失败即阻断为基础，探索多 Agent 的任务编排。不是官方 OpenAI/Anthropic 产品。

## 核心理念

常见的“多 Agent”演示会把多个角色提示词当成多个真正的执行体。本项目坚持区分：**角色定义 ≠ 独立模型会话；本地测试进程 ≠ 真实 AI Agent；测试通过 ≠ 实际宿主已部署。**

- **Dual16 固定拓扑**：2 个 Controller，每个管理 8 个 Worker；任务目标冻结、职责不重复、文件单一 Owner、跨团队复核、独立验收。
- **Agent Harness**：可运行的离线测试、失败注入、对比、重放（Replay）和报告工具。
- **按证据发布**：缺少权限、真实宿主回执或预算证明就 `BLOCKED / NOT_EXECUTED`，不靠“模拟成功”冒充实际能力。
- **本地优先**：离线演示无需任何付费 API；真实模型使用需要用户自己配置并先核实供应商收费政策。

## 仓库结构

| 目录 | 内容 |
|---|---|
| [`agi-harness/`](agi-harness/) | Python Harness + Eval Harness，离线用例、模型连接门控与 Replay，当前 `1.0.0rc1` 候选 |
| [`agi-super-power/`](agi-super-power/) | AGI-Super-Power `3.4.0-rc.7` 源码、Dual16 协议、Bridge 与本地示例 |
| [`integrations/`](integrations/) | MCP 连接样例（必须自行替换项目地址，不含密钥） |
| [`SECURITY.md`](SECURITY.md) | 安全边界、敏感配置与真实模型限制 |

## 3 分钟上手｜无需 API Key

要求 **Python 3.12+**。从仓库下载 `AGI-Skills-Source.zip` 并解压，在解压后的根目录进入 `agi-harness`：

```bash
cd agi-harness
python -m agi_harness doctor
python scripts/verify_v1.py --out runs/my-first-check
```

> `runs/my-first-check` 必须是**尚不存在**的目录。如果只想看运行方法，先阅读 `agi-harness/README.md`。`doctor` 和离线验证不会调用付费模型。

验证 `AGI-Super-Power` Dual16 原生工作流的离线夹具：

```bash
cd ../agi-super-power
python -B scripts/validate_dual16.py --out ../dual16-check-new
```

这里使用的是本地确定性测试进程，不是 18 个真实模型。不要把离线通过截图表述为模型实机成绩。

## 真实能力状态（阅读前必看）

| 项目 | 状态 |
|---|---|
| 双主控＋16 Worker 合同、职责映射 | 源码实现／离线可验证 |
| Harness `145` 项原版回归 | 历史离线记录：`145/145 PASS`；以你自己本机重跑为准 |
| 原生宿主创建 18 个独立真实模型会话 | **NOT_EXECUTED / 未通过实机验收** |
| 接入真实模型完成完整外部调用 | **NOT_EXECUTED；需用户自己配置授权与预算** |
| 全自动无人值守生产部署 | **未声明** |

本仓库属于研究、实验及工程迭代的**候选版本**，不是现成的商用自主 Agent 平台。新增结果必须标清真实环境、调用数量、测试性质及证据文件。

## 自己连接模型

请阅读 [`agi-harness/configs/model.env.example`](agi-harness/configs/model.env.example)。配置模型 URL、模型名称、允许的主机和自己的凭据时，**只在本机环境变量或 Secret Manager 存储密钥**，切勿提交真实 `.env` 到 GitHub。若没有供应商强制零付费上限，保持外部调用禁用。

## 使用与贡献

欢迎复现离线测试、提出 bug、提交 PR。反馈请附最小复现、Python/Node 版本、对应命令、预期与实际输出。**不要附密钥、客户数据或私有日志。**

本仓库自有代码按 `MIT` 发布；如带有第三方材料，仍分别遵循其原许可证和 `agi-super-power/THIRD_PARTY_NOTICES.md`。开源不构成各 AI 厂商的授权或官方支持。

---

**English:** AGI Skills is a reproducible Dual16 orchestration & evaluation workbench (2 controllers + 16 workers), with offline fixtures, independent grading and replay. Native 18-session LLM validation has **not** been completed. Explore the code, run the tests, and contribute evidence-backed improvements.
