# 将 AGI Skills 发布到 GitHub / Publish guide

目标仓库： https://github.com/huailizhu854-spec/-skills- ，已有公开 `main` 分支。

**发布方式**：本次使用网页上传完整源码 ZIP，并附仓库首页说明、MIT 许可证和安全说明。ZIP 保留全部项目目录，下载解压后即可阅读代码和运行离线检查。连接器写入请求仍返回 `403 Resource not accessible by integration`。仓库根目录是源码分发入口，不能描述为已展开全部源码；线上是否发布成功须以实际提交为准。

## Windows 最快捷路径

1. 安装 Git for Windows，确保 `git --version` 有输出；确认对目标仓库有写入权限且 Git Credential Manager 完成登录。
2. 解压本 ZIP，右击 `publish-to-github.ps1` 或在该目录 PowerShell 执行 `powershell -ExecutionPolicy Bypass -File .\publish-to-github.ps1`（需要你自己审核脚本后执行）。
3. 脚本会克隆现有仓库，复制已清理源码，展示变更列表；只有你明确输入 `PUBLISH`，才会提交推送 `main`。
4. 打开上述仓库，确认 `agi-harness/`、`agi-super-power/`、`README.md` 和 `LICENSE` 都可见后，再将网址和真实截图分享到 X。

## 如果要通过 ChatGPT GitHub 连接器自动上传

需要在 GitHub/ChatGPT 连接管理中使目标仓库获得 GitHub `Contents: Read and write` 权限。重新授权之后，还需要实际再次调用并核对提交成功；单纯显示“连接成功”不代表具备推送权限。

## GitHub 仓库建议 Topics

`agent-harness` `multi-agent` `agents` `skills` `python` `evaluation` `dual16` `replay`

本次发布的 ZIP 可下载、解压后浏览；并非在 GitHub 文件树中逐个展示源码。后续可以使用上面的 Git 路径上传展开后的目录。真实模型调用和完整回归不属于本次发布，包内测试报告为历史记录。
