# Engineering constraints

Preserve fixed production Dual16. Do not silently substitute fewer workers. Fixtures, HTTP fixtures, real model calls and synthetic policy outcomes must remain separate populations. Never remove failing tests or change a frozen benchmark to improve results. Version benchmark/grader changes. Oracle files are evaluator inputs only, never model prompts. No secrets or .env files in shared archives.

All reports must come from completed commands. Do not recycle legacy test totals as new coverage. Do not execute untrusted model-produced Python; this pilot uses a finite AST interpreter. No cloud changes, paid inference, API key creation or external publication without explicit authorization. Persist dispatch intent before calls and never replay an uncertain transport blindly.
