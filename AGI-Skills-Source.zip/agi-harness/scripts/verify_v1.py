"""Offline engineering verification, never evidence of real-model quality."""
from __future__ import annotations
import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from agi_harness import __version__
from agi_harness.ablation import VARIANTS, replay_injection_study
from agi_harness.benchmark import verify_benchmark, GRADER_VERSION
from agi_harness.campaign import controlled_ablation_comparison
from agi_harness.common import need, read, write
from agi_harness.evaluation import evaluate
from agi_harness.providers import FixtureProvider
from agi_harness.runtime import run, protocol_fingerprint
from agi_harness.security import scan


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    out = args.out.resolve()
    need(not out.exists(), 'VERIFY.OUTPUT_ALREADY_EXISTS')
    out.mkdir(parents=True)
    cmd = [sys.executable, str(ROOT/'scripts/verify_all.py'), '--out', str(out/'core')]
    with (out/'core-verification.log').open('w', encoding='utf-8') as f:
        proc = subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, timeout=180)
    need(proc.returncode == 0, 'REGRESSION.CORE_FAILED')
    core = read(out/'core/ACCEPTANCE.json')
    evaluations = []
    for variant in VARIANTS:
        dest = out/'ablation-fixtures'/variant
        run(FixtureProvider(), dest, ['dual16'], 3, 7, False,
            max_requests=40, concurrency=2, ablation=variant, experimental_ablation=True)
        profile = []
        start = time.perf_counter_ns()
        ev = evaluate(dest, profile=profile)
        write(dest/'evaluation.json', ev)
        write(out/'grader-profiles'/(variant+'.json'), {
            'population':'FIXTURE_ONLY', 'elapsed_ms':(time.perf_counter_ns()-start)/1e6,
            'per_episode':profile, 'excluded_from_replay_result':True})
        need(len(ev['rows']) == 18 and all(r['verified_success'] for r in ev['rows']),
             'REGRESSION.ABLATION_FIXTURE_FAILED')
        need(evaluate(dest) == ev, 'REPLAY.ABLATION_MISMATCH')
        evaluations.append(ev)
    paired = controlled_ablation_comparison(evaluations)
    paired['claim_boundary'] = 'OFFLINE FIXTURES; not a real-model ablation study or efficacy estimate.'
    write(out/'offline-ablation-comparison.json', paired)
    injections = replay_injection_study()
    write(out/'guard-component-injections.json', injections)
    security = scan(ROOT)
    write(out/'source-security-scan.json', security)
    need(security['status']=='PASS', 'SECURITY.STATIC_SCAN_FAILED')
    result = {
        'version':__version__, 'engineering_gate':'PASS', 'release_gate':'BLOCKED',
        'protocol_hash':protocol_fingerprint(), 'benchmark_hash':verify_benchmark(),
        'grader_version':GRADER_VERSION, 'unit_tests':core['new_unit_tests'],
        'legacy_eval':core['legacy_case_tests'], 'legacy_bridge':core['legacy_bridge_tests'],
        'legacy_reliability_cases':core['legacy_reliability_cases'], 'matrix':core['matrix'],
        'offline_ablation':{'arms':len(evaluations), 'episodes':sum(len(e['rows']) for e in evaluations),
            'fixture_calls':sum(r['calls_attempted'] for e in evaluations for r in e['rows']),
            'replay_equal':True, 'real_model_calls':0},
        'fault_episodes':len(core['fault_runs']), 'component_injections':injections,
        'security':security, 'real_model_calls':0,
        'not_executed':['Real provider probe','Six-task real pilot','54 real episodes',
                        'Real-model ablation','Real-data router training','LLM weight training'],
        'notice':'Local HTTP unit tests are fixture_http; no supplied/connected model provider was called.'}
    write(out/'VERIFICATION.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
