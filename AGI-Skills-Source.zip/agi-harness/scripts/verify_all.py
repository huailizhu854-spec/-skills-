"""Offline release verification. Never loads an API key or calls a model provider."""
from __future__ import annotations
import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from agi_harness import __version__
from agi_harness.common import read,write,parse,digest,file_map,need,HarnessError
from agi_harness.runtime import run
from agi_harness.providers import FixtureProvider,FAULTS
from agi_harness.evaluation import evaluate
from agi_harness.metrics import compare
from agi_harness.reporting import render,html_report
from agi_harness.rl_lab import experiment


def execute(cmd,cwd,out):
    p=subprocess.run(cmd,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',timeout=120)
    out.write_text(p.stdout,encoding='utf-8')
    if p.returncode:raise RuntimeError(f'TEST_FAILED: {out.name}')
    return p.stdout


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    need(not a.out.exists(),'VERIFY.OUTPUT_ALREADY_EXISTS');a.out.mkdir(parents=True)
    unitlog=execute([sys.executable,'-m','unittest','discover','-s','tests','-v'],ROOT,a.out/'new-tests.log')
    import re
    legacy=ROOT/'legacy/case-study'
    legacy_log=execute([sys.executable,'-m','unittest','discover','-s','tests','-v'],legacy,a.out/'legacy-eval.log')
    legacy_count=int(re.search(r'Ran (\d+) tests',legacy_log).group(1))
    node=shutil.which('node');node_status='NOT_EXECUTED_NODE_MISSING'
    if node:
        bridge=ROOT/'legacy/bridge-rc7';tests=sorted(str(p.relative_to(bridge)) for p in (bridge/'tests').glob('*.test.mjs'))
        node_log=execute([node,'--test',*tests],bridge,a.out/'legacy-bridge.log')
        n=int(re.search(r'# tests (\d+)',node_log).group(1));passed=int(re.search(r'# pass (\d+)',node_log).group(1))
        need(n==passed,'REGRESSION.BRIDGE_NOT_ALL_PASSED');node_status=f'{passed}/{n} PASS'
    # Run the legacy 30 cases as historical regression, not as the live grader.
    execute([sys.executable,'eval/run_eval.py','--benchmark','benchmark/harness_benchmark_v1.jsonl',
        '--traces','fixtures/traces','--out',str((a.out/'legacy-30.json').resolve())],legacy,a.out/'legacy-30.log')
    matrix=a.out/'smoke-matrix'
    run(FixtureProvider(),matrix,['single','dual8','dual16'],3,7,True)
    evaluation=evaluate(matrix);write(matrix/'evaluation.json',evaluation)
    need(len(evaluation['rows'])==54 and all(r['verified_success'] for r in evaluation['rows']),'REGRESSION.MATRIX_FAILED')
    need(read(a.out/'legacy-30.json')['summary']['benchmark_expectation_accuracy']==1,'REGRESSION.LEGACY_EXPECTATION_FAILED')
    replay=evaluate(matrix);need(replay==evaluation,'REPLAY.MISMATCH')
    paired=compare([evaluation]);write(a.out/'comparison.json',paired)
    text=render(paired);(a.out/'comparison.md').write_text(text,encoding='utf-8');(a.out/'comparison.html').write_text(html_report(text),encoding='utf-8')
    faults=[]
    for fault in FAULTS:
        if fault=='none':continue
        target=a.out/'fault-runs'/fault
        run(FixtureProvider(fault),target,only=['tb001_csv_summary'])
        ev=evaluate(target);write(target/'evaluation.json',ev);row=ev['rows'][0]
        expected=fault=='repair_once'
        need(row['verified_success']==expected,'REGRESSION.UNEXPECTED_FAULT_RESULT')
        faults.append({'fault':fault,'expected_verified':expected,'actual_verified':row['verified_success'],
                      'failures':row['failures'],'extra_attempts':row['extra_attempts'], 'calls_attempted':row['calls_attempted']})
    write(a.out/'fault-summary.json',faults)
    rl=experiment([7,17,27],300);write(a.out/'rl-lab.json',rl)
    import re
    test_count=int(re.search(r'Ran (\d+) tests',unitlog).group(1))
    summary={'release':'agi-harness-'+__version__, 'release_gate':'BLOCKED_REAL_DATA_REQUIRED','new_unit_tests':{'total':test_count,'passed':test_count},
             'legacy_case_tests':f'{legacy_count}/{legacy_count} PASS','legacy_bridge_tests':node_status,
             'legacy_reliability_cases':read(a.out/'legacy-30.json')['summary'],
             'matrix':{'episodes':len(evaluation['rows']),'all_expected_fixture_success':all(r['verified_success'] for r in evaluation['rows']),
                       'repeat_count_per_task_architecture':3,'task_count':6,'architectures':['single','dual8','dual16'],
                       'replay_equal':replay==evaluation,'model_calls':sum(r['real_model_calls'] for r in evaluation['rows']),
                       'fixture_calls':sum(r['calls_attempted'] for r in evaluation['rows'])},
             'fault_runs':faults,'rl':{'label':rl['label'],'human_feedback':False,'llm_weight_training':False,
                  'train_tasks':len(rl['train_task_ids']),'test_tasks':len(rl['test_task_ids']),
                  'reward_model':rl['reward_model'],'seeds':[{'seed':r['seed'],'uniform_test':r['uniform_test'],
                  'learned_test':r['learned_test']} for r in rl['results']]},
             'not_executed':['real-model software benchmark','native ChatGPT subagents','Windows/macOS host acceptance',
                             'LLM-weight RLHF/GRPO','cloud deployment changes','provider billing verification']}
    write(a.out/'ACCEPTANCE.json',summary)
    print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
