#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
out="runs/demo-$(date +%Y%m%d-%H%M%S)"
python3 -m agi_harness run --out "$out" --architectures single dual8 dual16 --experimental-baselines --repetitions 3
python3 -m agi_harness eval "$out"
python3 -m agi_harness replay "$out"
python3 -m agi_harness compare "$out" --out "$out/comparison.json"
python3 -m agi_harness report "$out" --out "$out/report.md"
