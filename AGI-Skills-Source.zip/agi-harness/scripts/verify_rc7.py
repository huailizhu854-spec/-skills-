"""Run unchanged adjacent rc.7 tests in bounded module/class partitions."""
from __future__ import annotations
import argparse
import concurrent.futures
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--start',type=int,default=0)
    ap.add_argument('--end',type=int)
    ap.add_argument('--workers',type=int,default=8)
    args=ap.parse_args()
    sibling=ROOT.parent/'agi-super-power'
    plan=json.loads((ROOT/'scripts/rc7-regression-plan.json').read_text())
    args.out.mkdir(parents=True,exist_ok=True)
    def execute(g):
        name=g['module']+('.'+g['class'] if 'class' in g else '')
        dest=args.out/(name+'.json')
        if dest.exists():
            raise RuntimeError('Refusing to overwrite existing result: '+name)
        cmd=[sys.executable,'-m','unittest']
        cmd+=([name,'-v'] if 'class' in g else ['discover','-s','tests','-p',g['module']+'.py','-v'])
        env=dict(os.environ);env['PYTHONPATH']=str(sibling/'tests')
        start=time.perf_counter()
        with (args.out/(name+'.log')).open('w',encoding='utf-8') as f:
            try:
                p=subprocess.run(cmd,cwd=sibling,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
                code=p.returncode
            except subprocess.TimeoutExpired:
                code='TIMEOUT'
        text=(args.out/(name+'.log')).read_text()
        m=re.search(r'Ran (\d+) tests?',text)
        item={**g,'exit_code':code,'observed_tests':int(m.group(1)) if m else None,
              'skips':len(re.findall(r' \.\.\. skipped ',text)),
              'seconds':round(time.perf_counter()-start,3)}
        item['pass']=code==0 and item['observed_tests']==g['tests']
        dest.write_text(json.dumps(item,indent=2)+'\n')
        return item
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        items=list(pool.map(execute,plan['groups'][args.start:args.end]))
    for item in items: print(json.dumps(item))
    all_items=[]
    for g in plan['groups']:
        name=g['module']+('.'+g['class'] if 'class' in g else '')
        p=args.out/(name+'.json')
        if p.exists():all_items.append(json.loads(p.read_text()))
    if len(all_items)==len(plan['groups']):
        total=sum(x['observed_tests'] or 0 for x in all_items)
        skipped=sum(x['skips'] for x in all_items)
        result={'status':'PASS_WITH_PLATFORM_EXCLUSIONS' if all(x['pass'] for x in all_items) and total==plan['expected_tests'] else 'FAIL',
                'total':total,'passed':total-skipped,'skipped':skipped,'groups':all_items,
                'test_sources_modified':False,'skipped_is_not_passed':True}
        (args.out/'SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n')
    return 0 if all(x['pass'] for x in items) else 1
if __name__=='__main__':raise SystemExit(main())
