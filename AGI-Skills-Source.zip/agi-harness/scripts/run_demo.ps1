$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$out = "runs/demo-" + (Get-Date -Format "yyyyMMdd-HHmmss")
python -m agi_harness run --out $out --architectures single dual8 dual16 --experimental-baselines --repetitions 3
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -m agi_harness eval $out
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -m agi_harness replay $out
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -m agi_harness compare $out --out "$out/comparison.json"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -m agi_harness report $out --out "$out/report.md"
exit $LASTEXITCODE
