# Agent Harness + Eval Harness 技术案例 · 实测报告

日期：2026-09-28

## 1. 案例定位

本案例在现有 Dual16 rc.7 Agent Runtime 之上新增独立 Eval Harness。目标是把“多 Agent 可以跑”升级为“多 Agent 的行为可以固定测量、失败可以分类、结果可以复放、版本可以回归、策略可以优化”。

原 rc.7 已经具备隔离上下文、供应商 response ID、回执哈希、双主控、交叉审核、重试预算和 fail-closed 状态；真实模型供应商仍未配置，因此本案例没有把 fixture 测试写成真实模型成绩。

## 2. 新增结构

- `benchmark/harness_benchmark_v1.jsonl`：30 个冻结 Harness episode。
- `benchmark/live_task_benchmark_v1.jsonl`：6 个冻结小型真实任务规格，public workspace 与 oracle/grader 分离。
- `eval/failure_taxonomy.yaml`：22 个本轮实际覆盖的 failure code，属于 10 个 failure family。
- `eval/grader.py`：确定性自动 grader。
- `eval/replay.py`：离线 replay / mutation 检查。
- `eval/metrics.py`：成功、失败检测、成本、延迟、返工、replay 指标。
- `rl/reward_model.py`：Bradley-Terry pairwise preference reward model。
- `rl/grpo_router.py`：GRPO-style 离散 orchestration routing policy 实验。
- `rl/hf_grpo_lora_optional.py`：真正 Transformer + LoRA/GRPO 的可选接口草图，明确 NOT_EXECUTED。
- `docs/JOB_MAPPING.md`：与 Agent Infra / Evals / Reliability / Post-training 岗位语义的映射。

## 3. Harness Benchmark 实测

- 总 case：30
- clean case：8
- 注入 failure case：22
- benchmark expectation accuracy：100%
- clean verified success：100%
- failure detection recall：100%
- taxonomy codes exercised：22
- replay consistency：100%
- injected false-success catch：100%

fixture clean case 的成本和延迟只用于验证指标管线：mean cost = $0.0095，p50 = 860ms，p95 = 1112ms。**这些不是线上模型性能。**

## 4. Live Task Benchmark Grader Smoke

- 固定任务：6
- untouched baseline 被 grader 拒绝：6/6
- oracle 被 grader 接受：6/6
- 模型/Agent 实际执行：NOT_EXECUTED

这证明的是 grader 可用性，不是 Agent 任务成功率。接入真实 provider 后，应只把 `public/` workspace 暴露给 Agent，把 `oracle/` 留在 Eval Harness 外部。

## 5. Replay 对抗检查

从 clean trace 复制后分别进行三种 mutation：

- receipt hash tamper → `EVIDENCE.HASH_MISMATCH`
- reviewer swap → `VERIFY.WRONG_REVIEWER`
- cost overrun → `COST.BUDGET_EXCEEDED`

三次 replay 均保持输入 trace 不被 grader 修改。

## 6. 小型 RLHF / GRPO 实验

Preference 数据共 240 对，由冻结 rubric 对同一 synthetic routing benchmark 的策略成对比较生成。Bradley-Terry reward model 在这批**同分布、规则生成** preference 上 pairwise accuracy = 100%。这只验证 preference→reward plumbing，不代表真实人工偏好泛化能力。

GRPO-style routing policy 使用 group size = 4、steps = 500、seed = 7。在冻结 synthetic test split 上：

- uniform policy expected verified success：71.25%
- trained policy expected verified success：98.10%
- mean cost norm：0.613 → 0.652
- mean latency norm：0.670 → 0.697
- learned policy mass：`dual8=0.303`, `dual16=0.621`

这是**orchestration policy 的小型 GRPO-style 实验，不是 LLM 权重训练**。真正 LoRA/GRPO extension 仍为 NOT_EXECUTED。

## 7. 回归

- case-study unittest：5/5 PASS。
- rc.7 Node bridge test：44/44 PASS。
- 本轮未修改 rc.7 runtime 核心源码，因此没有把历史 793 项 Python 回归重复计作本轮新增覆盖；完整历史回归证据仍保留在原 rc.7 报告中。

## 8. 适合岗位展示的核心叙事

1. 先做了 Agent Runtime，而不是停在 prompt orchestration。
2. 然后把 success 从“Agent 自己说完成”改成独立 grader 的 verified success。
3. 用 frozen benchmark + taxonomy 把 failure 变成可回归资产。
4. 用 replay + receipt/hash 把线上问题变成可复现实验。
5. 把 cost/latency 纳入 reward，而不是只优化准确率。
6. 最后用 preference reward + GRPO-style routing 验证 post-training / policy optimization 思路。

## 9. 未证明边界

- 真实模型 live task benchmark：NOT_EXECUTED。
- ChatGPT 原生 16 子 Agent：NOT_EXECUTED。
- LLM 权重级 GRPO/LoRA：NOT_EXECUTED。
- synthetic RL 指标不等于生产环境提升。
- fixture 成本/延迟不等于供应商真实成本/延迟。
