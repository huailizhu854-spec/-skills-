from __future__ import annotations
import argparse, json, math
from pathlib import Path

FEATURES=['verified_success','first_pass','neg_cost_norm','neg_latency_norm','neg_violation']

def dot(w,x): return sum(a*b for a,b in zip(w,x))
def feature_vector(d):
    return [float(d.get('verified_success',0)),float(d.get('first_pass',0)),-float(d.get('cost_norm',0)),-float(d.get('latency_norm',0)),-float(d.get('violation',0))]
def vec(d): return feature_vector(d)

def train(rows,epochs=800,lr=.08,l2=.005):
    w=[0.0]*len(FEATURES)
    for _ in range(epochs):
        grad=[0.0]*len(w)
        for r in rows:
            xa,xb=vec(r['chosen']),vec(r['rejected']); d=[a-b for a,b in zip(xa,xb)]
            z=max(-30,min(30,dot(w,d))); p=1/(1+math.exp(-z))
            for i in range(len(w)): grad[i]+=(1-p)*d[i]
        for i in range(len(w)):
            grad[i]=grad[i]/max(1,len(rows))-l2*w[i]
            w[i]+=lr*grad[i]
    correct=0
    for r in rows:
        if dot(w,vec(r['chosen']))>dot(w,vec(r['rejected'])): correct+=1
    return {'features':FEATURES,'weights':w,'train_pairwise_accuracy':correct/max(1,len(rows)),'pairs':len(rows),'method':'Bradley-Terry logistic preference model; offline toy experiment'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--preferences',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
    rows=[json.loads(x) for x in Path(args.preferences).read_text().splitlines() if x.strip()]
    result=train(rows);Path(args.out).write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
