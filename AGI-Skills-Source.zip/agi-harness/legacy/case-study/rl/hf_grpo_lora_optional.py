"""OPTIONAL / NOT_EXECUTED.

Sketch for connecting the same benchmark reward to an open-weight transformer via LoRA + GRPO.
This file intentionally does not auto-install packages or download a model.

Expected stack (pin versions before a real experiment): transformers, trl, peft, datasets, torch.
Use an explicitly selected open-weight model that fits available hardware/licensing constraints.
"""
NOT_EXECUTED = True

def reward_function(completions, **kwargs):
    """Convert completions into harness rewards.

    A real implementation should parse a structured orchestration plan and call the frozen
    Eval Harness. Never reward chain-of-thought text; reward only externally checkable fields.
    """
    raise NotImplementedError("NOT_EXECUTED: connect to frozen eval harness before training")

# Pseudocode only:
# from trl import GRPOConfig, GRPOTrainer
# from peft import LoraConfig
# trainer = GRPOTrainer(model=..., reward_funcs=[reward_function], args=GRPOConfig(...), peft_config=LoraConfig(...))
# trainer.train()
