from __future__ import annotations
import argparse, json, math, random
from pathlib import Path
from reward_model import FEATURES, feature_vector

STRATEGIES=['single','dual8','dual16','dual16_strict']

def softmax(xs):
    m=max(xs);e=[math.exp(x-m) for x in xs];s=sum(e);return [v/s for v in e]

def sample(probs,rng):
    r=rng.random();c=0
    for i,p in enumerate(probs):
        c+=p
        if r<=c:return i
    return len(probs)-1

def outcome(case,strategy):
    # Frozen synthetic environment for reward-plumbing demonstration only.
    c=case['complexity']; risk=case['risk']; tools=case['tool_failure_risk']; artifacts=case['artifact_count']
    idx=STRATEGIES.index(strategy)
    capacity=[.42,.66,.82,.86][idx]
    overhead=[.10,.25,.42,.55][idx]
    verification=[.15,.45,.62,.82][idx]
    success_score=capacity + .18*verification*risk - .09*max(0,c-capacity*1.2) - .08*tools
    verified_success=1.0 if success_score>=case['success_threshold'] else 0.0
    first_pass=1.0 if success_score>=case['success_threshold']+.06 else 0.0
    cost_norm=min(1.5,overhead+.035*artifacts+.12*c)
    latency_norm=min(1.5,overhead*.75+.06*artifacts+.10*c)
    violation=1.0 if strategy=='single' and risk>.72 else 0.0
    return {'verified_success':verified_success,'first_pass':first_pass,'cost_norm':cost_norm,'latency_norm':latency_norm,'violation':violation}

def score(features,rm): return sum(v*w for v,w in zip(feature_vector(features),rm['weights']))

def evaluate(cases,logits,rm):
    probs=softmax(logits); total=0; succ=0; cost=0; lat=0
    for case in cases:
        for prob,strategy in zip(probs,STRATEGIES):
            f=outcome(case,strategy); total+=prob*score(f,rm);succ+=prob*f['verified_success'];cost+=prob*f['cost_norm'];lat+=prob*f['latency_norm']
    n=len(cases);return {'policy_probs':dict(zip(STRATEGIES,probs)),'mean_reward':total/n,'verified_success_rate':succ/n,'mean_cost_norm':cost/n,'mean_latency_norm':lat/n}

def train(cases,rm,seed=7,steps=500,group=4,lr=.045,beta=.015):
    rng=random.Random(seed); logits=[0.0]*4; baseline=evaluate(cases,logits,rm)
    train_cases=[c for c in cases if c['split']=='train']; test_cases=[c for c in cases if c['split']=='test']
    for _ in range(steps):
        case=rng.choice(train_cases); probs=softmax(logits); samples=[]
        for _g in range(group):
            a=sample(probs,rng); f=outcome(case,STRATEGIES[a]); samples.append((a,score(f,rm)))
        mean=sum(r for _,r in samples)/len(samples); sd=(sum((r-mean)**2 for _,r in samples)/len(samples)+1e-8)**.5
        grad=[0.0]*4
        for a,r in samples:
            adv=(r-mean)/sd
            for i in range(4): grad[i]+=adv*((1 if i==a else 0)-probs[i])
        for i in range(4):
            # light entropy/anchor pressure toward the initial uniform policy
            grad[i]/=group; grad[i]-=beta*(probs[i]-.25); logits[i]+=lr*grad[i]
    return {'method':'GRPO-style categorical routing policy; offline synthetic environment, not LLM weight training','seed':seed,'steps':steps,'group_size':group,
      'baseline_all':baseline,'trained_train':evaluate(train_cases,logits,rm),'trained_test':evaluate(test_cases,logits,rm),'logits':dict(zip(STRATEGIES,logits))}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--benchmark',required=True);ap.add_argument('--reward-model',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
    cases=[json.loads(x) for x in Path(args.benchmark).read_text().splitlines() if x.strip()];rm=json.loads(Path(args.reward_model).read_text());result=train(cases,rm)
    Path(args.out).write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
