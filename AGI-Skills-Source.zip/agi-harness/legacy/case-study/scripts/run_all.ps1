$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
python eval/run_eval.py --benchmark benchmark/harness_benchmark_v1.jsonl --traces fixtures/traces --out reports/eval_baseline.json
python eval/task_benchmark_smoke.py
python rl/reward_model.py --preferences rl/preferences_v1.jsonl --out reports/reward_model.json
python rl/grpo_router.py --benchmark benchmark/routing_benchmark_v1.jsonl --reward-model reports/reward_model.json --out reports/grpo_router.json
python -m unittest discover -s tests -v
