# Dual16 Agent Harness + Eval Harness · Technical Case

This directory turns the existing AGI-Super-Power Dual16 runtime into a portfolio-ready **Agent Harness + Eval Harness** case study.

The goal is not to claim that more agents are automatically better. The goal is to make agent execution **measurable, replayable, falsifiable, and optimizable**.

## What this case demonstrates

- Agent harness: fixed topology, task manifests, isolation, receipts, ownership, bounded retries, cross-review, independent gates.
- Eval harness: frozen benchmark, deterministic graders, failure taxonomy, offline replay, metrics aggregation, regression gates.
- Observability: success/failure, first-pass rate, false-success rate, cost, latency, replay consistency, verifier catch rate.
- Post-training experiment: preference-derived reward model + GRPO-style policy optimization over orchestration strategies.
- Optional LLM extension: a clearly marked `NOT_EXECUTED` LoRA/GRPO scaffold for an open-weight model.

## Evidence boundary

The existing rc.7 bridge has deterministic fixture evidence and deployment tests, but its real model provider is not configured. Therefore this case separates:

1. **Harness correctness benchmark** — executable offline now.
2. **Live agent task benchmark** — requires a configured provider and must report actual model receipts.
3. **Offline RL experiment** — executable now; it optimizes an orchestration policy, not LLM weights.
4. **LLM GRPO/LoRA extension** — scaffold only, not executed in this delivery.

## Quick start

```bash
cd case-study
python eval/run_eval.py --benchmark benchmark/harness_benchmark_v1.jsonl --traces fixtures/traces --out reports/eval_baseline.json
python eval/replay.py --trace fixtures/traces/hb_001_clean.json
python rl/reward_model.py --preferences rl/preferences_v1.jsonl --out reports/reward_model.json
python rl/grpo_router.py --benchmark benchmark/routing_benchmark_v1.jsonl --reward-model reports/reward_model.json --out reports/grpo_router.json
python -m unittest discover -s tests -v
```

Or run all:

```bash
bash scripts/run_all.sh
```

## Interview framing

> I built a multi-agent execution runtime, then stopped treating demos as evidence. I added a frozen benchmark, failure taxonomy, deterministic and model-assisted grading boundaries, replayable traces, cost/latency metrics, and a small preference + GRPO optimization loop for orchestration policy. The system distinguishes logical context IDs, provider response IDs, and native-host execution evidence, so it does not report simulated parallelism as real agent execution.

## Live task benchmark

`benchmark/live_task_benchmark_v1.jsonl` freezes six small deterministic tasks. `eval/task_benchmark_smoke.py` proves the graders reject the untouched baseline and accept the oracle. **No model run is claimed.** When a provider is configured, the Agent Harness can be adapted to copy only each task's `public/` workspace to an agent and keep `oracle/` grader material out of the agent context.
