# Job-description mapping

| Common JD phrase | Evidence in this case |
|---|---|
| Build agent infrastructure / orchestration | Dual16 runtime, state machine, receipts, bounded retries, controller-worker topology |
| Build evals / benchmarks | Frozen JSONL benchmark + expected failure labels |
| Design automated graders | Deterministic trace grader with explicit evidence and false-success detection |
| Build replay / debugging infrastructure | Canonical offline replay + mutation checks |
| Observability / reliability metrics | success, false success, cost, latency, recovery, replay consistency |
| Failure analysis | Versioned failure taxonomy with primary/secondary codes |
| Optimize agent policies | Preference reward model + GRPO-style routing optimization |
| Post-training familiarity | Optional LoRA/GRPO transformer scaffold with strict NOT_EXECUTED label |
| Production rigor | fail-closed semantics, idempotency, receipt hashes, provider/session identity separation |

## Resume bullet draft

- Built a 2-controller/16-worker agent execution harness with explicit artifact ownership, cross-team verification, bounded retries, persisted dispatch intent, and fail-closed handling of uncertain remote execution.
- Built a frozen eval harness with deterministic graders, failure taxonomy, offline replay, regression gates, and success/cost/latency metrics; separated logical context IDs from provider/native execution evidence to prevent false-success claims.
- Implemented a small preference-learning + GRPO-style routing experiment that optimizes orchestration strategy against verified-success, cost, latency, and violation penalties, with held-out evaluation.
