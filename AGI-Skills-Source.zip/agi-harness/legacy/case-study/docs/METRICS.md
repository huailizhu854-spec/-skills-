# Metrics contract

## Primary

- `verified_success_rate`: passes independent deterministic checks.
- `false_success_rate`: executor declared success but grader rejected the episode.
- `failure_detection_recall`: expected primary failure correctly identified on frozen failure cases.
- `cost_per_verified_success_usd`: total measured cost divided by verified successes.
- `latency_p50_ms`, `latency_p95_ms`: end-to-end episode latency distribution.

## Secondary

- `first_pass_success_rate`
- `rework_rate`
- `verifier_catch_rate`
- `replay_consistency_rate`

## Reporting rule

A metric is reported only for the population actually measured. Fixture latency/cost must never be presented as live-provider performance. Live benchmark reports must include provider/model/version, benchmark hash, run timestamp, and receipt count.
