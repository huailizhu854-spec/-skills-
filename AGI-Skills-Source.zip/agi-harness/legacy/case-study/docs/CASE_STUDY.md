# Case Study: From Multi-Agent Demo to Measurable Agent Infrastructure

## Problem

A multi-agent system can look impressive while hiding three problems: fake delegation, unverifiable success, and unbounded cost. The original Dual16 work already enforced ownership, receipts, bounded retries, cross-team review, and fail-closed behavior. The next step is to evaluate the system as infrastructure rather than as a demo.

## Design decision

The project is split into an **Agent Harness** and an **Eval Harness**.

The Agent Harness executes a task and emits evidence. The Eval Harness treats that run as an immutable episode and independently decides whether the run passed. This avoids circular evaluation where the executor grades itself.

## Benchmark strategy

Two frozen benchmark families are used:

- `harness_benchmark_v1.jsonl`: deterministic trace cases covering success and known failure modes. This tests the harness, taxonomy, grader, replay, and metrics plumbing.
- `routing_benchmark_v1.jsonl`: frozen synthetic orchestration scenarios used by the small RL experiment. These scenarios are not claimed to represent production distributions.

A future `live_task_benchmark_v1` should contain real software/research tasks with hidden tests and source artifacts. Live model runs must pin provider/model/version and record raw receipts.

## Failure taxonomy

Failures are classified into planning, delegation, execution, evidence, verification, recovery, infrastructure, artifact, cost, and latency families. Every benchmark failure has an expected primary code. The grader may emit secondary codes, but primary-code accuracy is tracked separately.

## Replay

Replay is offline and side-effect free. It canonicalizes the trace, recomputes hashes, re-runs the grader, and compares the result to the original. Counterfactual mutation can be performed on copied traces to test whether the grader catches tampering.

## Metrics

The headline metric is **verified success rate**, not raw completion rate. Additional metrics include first-pass success, false-success rate, failure detection recall, verifier catch rate, rework rate, cost per verified success, p50/p95 latency, and replay consistency.

## RL experiment

The executed RL experiment is deliberately small. A Bradley-Terry-style preference reward model is fit from pairwise strategy preferences. A categorical routing policy is then optimized with a GRPO-style group-relative advantage update over four orchestration strategies.

This demonstrates the reward plumbing and evaluation loop without pretending that an LLM was post-trained. `rl/hf_grpo_lora_optional.py` shows how the same reward signal could be connected to a transformer + LoRA/GRPO stack, but it is explicitly `NOT_EXECUTED` here.
