# Architecture

```text
                         +----------------------+
                         |   Frozen Benchmark   |
                         +----------+-----------+
                                    |
                                    v
+----------------+       +----------+-----------+       +-------------------+
| Provider /     |<----->|      Agent Harness   |------>| Artifact / Trace  |
| Fixture Adapter|       | plan/run/retry/gate  |       | Ledger            |
+----------------+       +----------+-----------+       +---------+---------+
                                    |                             |
                                    v                             v
                         +----------+-----------+       +---------+---------+
                         |       Eval Harness   |<------| Offline Replay    |
                         | graders + taxonomy   |       | hash + mutation   |
                         +----------+-----------+       +-------------------+
                                    |
                                    v
                         +----------+-----------+
                         | Metrics / Regression |
                         +----------+-----------+
                                    |
                                    v
                         +----------+-----------+
                         | Reward + GRPO Policy |
                         +----------------------+
```

## Agent Harness responsibilities

The existing rc.7 runtime remains the execution substrate. It owns orchestration state and evidence collection. The Eval Harness does **not** alter execution results after the fact.

Important invariants:

- 2 controller roles and 16 worker roles are distinguishable.
- Application context IDs are not provider response IDs.
- Provider response IDs are not native host session IDs.
- Dispatch intent is persisted before outbound inference.
- Uncertain remote execution is blocked instead of blindly retried.
- Artifact ownership and opposite-team review are explicit.
- Success requires evidence, not a worker's self-report.

## Eval Harness responsibilities

The Eval Harness consumes immutable benchmark cases plus traces and produces:

- pass/fail result
- primary and secondary failure taxonomy codes
- evidence list
- metric vector
- canonical replay hash
- regression-compatible JSON

Deterministic graders are authoritative for properties that can be mechanically checked. LLM-as-judge is intentionally not required for the frozen harness benchmark; if added to live task benchmarks, it must be one signal rather than the sole gate.
