import json, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'eval'))
from grader import grade_dict, canonical_hash

class EvalHarnessTests(unittest.TestCase):
    def cases(self):
        return [json.loads(x) for x in (ROOT/'benchmark/harness_benchmark_v1.jsonl').read_text().splitlines() if x.strip()]
    def test_frozen_benchmark_primary_codes(self):
        for c in self.cases():
            t=json.loads((ROOT/'fixtures/traces'/c['trace']).read_text())
            g=grade_dict(t)
            self.assertEqual(g['primary_failure'],c['expected_primary_failure'],c['id'])
    def test_replay_is_immutable(self):
        c=self.cases()[0];t=json.loads((ROOT/'fixtures/traces'/c['trace']).read_text());h=canonical_hash(t);grade_dict(t);self.assertEqual(h,canonical_hash(t))
    def test_mutation_caught(self):
        c=self.cases()[0];t=json.loads((ROOT/'fixtures/traces'/c['trace']).read_text());t['execution']['receipts'][0]['recomputed_sha256']='tampered';self.assertEqual(grade_dict(t)['primary_failure'],'EVIDENCE.HASH_MISMATCH')
    def test_benchmark_manifest_hashes(self):
        import hashlib
        m=json.loads((ROOT/'benchmark/frozen_manifest.json').read_text())
        for rel,meta in m['files'].items():self.assertEqual(hashlib.sha256((ROOT/rel).read_bytes()).hexdigest(),meta['sha256'])

    def test_live_task_oracles(self):
        import shutil, tempfile
        from task_grader import grade
        tasks=[json.loads(x) for x in (ROOT/'benchmark/live_task_benchmark_v1.jsonl').read_text().splitlines() if x.strip()]
        for case in tasks:
            td=ROOT/'benchmark'/case['task_dir']
            with tempfile.TemporaryDirectory() as tmp:
                ws=Path(tmp)/'workspace';shutil.copytree(td/'public',ws)
                sol=td/'oracle'/'solution'
                if sol.exists():
                    for p in sol.rglob('*'):
                        if p.is_file():
                            dest=ws/p.relative_to(sol);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
                else:
                    expected=json.loads((td/'oracle'/'expected.json').read_text());(ws/'output.json').write_text(json.dumps(expected,indent=2),encoding='utf-8')
                self.assertTrue(grade(ws,td)['passed'],case['id'])

if __name__=='__main__':unittest.main()
