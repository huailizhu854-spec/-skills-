from __future__ import annotations
import argparse, copy, json
from pathlib import Path
from grader import grade_dict, canonical_hash


def replay(trace):
    before=canonical_hash(trace)
    grade=grade_dict(copy.deepcopy(trace))
    after=canonical_hash(trace)
    return {'trace_hash_before':before,'trace_hash_after':after,'trace_immutable':before==after,'grade':grade}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--trace',required=True); ap.add_argument('--mutate',choices=['hash','reviewer','cost'])
    args=ap.parse_args(); trace=json.loads(Path(args.trace).read_text(encoding='utf-8'))
    if args.mutate=='hash' and trace.get('execution',{}).get('receipts'):
        trace['execution']['receipts'][0]['recomputed_sha256']='tampered'
    elif args.mutate=='reviewer' and trace.get('verification',{}).get('reviews'):
        trace['verification']['reviews'][0]['reviewer']='control-a' if trace['verification']['reviews'][0]['reviewer']=='control-b' else 'control-b'
    elif args.mutate=='cost':
        trace.setdefault('metrics',{})['cost_usd']=999
    print(json.dumps(replay(trace),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
