from __future__ import annotations
import argparse, importlib.util, json, subprocess, sys
from pathlib import Path


def exact_json(workspace: Path, task_dir: Path, spec: dict):
    out=workspace/spec['output_file']
    if not out.exists(): return {'passed':False,'reason':'MISSING_OUTPUT'}
    try: actual=json.loads(out.read_text(encoding='utf-8'))
    except Exception: return {'passed':False,'reason':'INVALID_JSON'}
    expected=json.loads((task_dir/'oracle'/spec['expected_file']).read_text(encoding='utf-8'))
    return {'passed':actual==expected,'reason':None if actual==expected else 'JSON_MISMATCH'}


def python_unittest(workspace: Path, task_dir: Path, spec: dict):
    test_file=task_dir/'oracle'/spec['test_file']
    cmd=[sys.executable,str(test_file),str(workspace)]
    p=subprocess.run(cmd,text=True,capture_output=True,timeout=10)
    return {'passed':p.returncode==0,'reason':None if p.returncode==0 else 'UNIT_TEST_FAILED','stdout':p.stdout[-4000:],'stderr':p.stderr[-4000:]}


def grade(workspace: Path, task_dir: Path):
    spec=json.loads((task_dir/'grader.json').read_text())
    if spec['type']=='exact_json': return exact_json(workspace,task_dir,spec)
    if spec['type']=='python_unittest': return python_unittest(workspace,task_dir,spec)
    raise ValueError('UNKNOWN_GRADER')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workspace',required=True);ap.add_argument('--task-dir',required=True);args=ap.parse_args()
    print(json.dumps(grade(Path(args.workspace),Path(args.task_dir)),indent=2))
if __name__=='__main__':main()
