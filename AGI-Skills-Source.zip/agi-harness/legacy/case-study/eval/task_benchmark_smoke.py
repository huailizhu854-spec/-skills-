from __future__ import annotations
import json, shutil, tempfile
from pathlib import Path
from task_grader import grade
ROOT=Path(__file__).resolve().parents[1]

def main():
    tasks=[json.loads(x) for x in (ROOT/'benchmark/live_task_benchmark_v1.jsonl').read_text().splitlines() if x.strip()]
    rows=[]
    for case in tasks:
        td=ROOT/'benchmark'/case['task_dir']
        with tempfile.TemporaryDirectory() as tmp:
            ws=Path(tmp)/'workspace';shutil.copytree(td/'public',ws)
            baseline=grade(ws,td)
            sol=td/'oracle'/'solution'
            if sol.exists():
                for p in sol.rglob('*'):
                    if p.is_file():
                        dest=ws/p.relative_to(sol);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
            else:
                expected=json.loads((td/'oracle'/'expected.json').read_text());(ws/'output.json').write_text(json.dumps(expected,indent=2),encoding='utf-8')
            oracle=grade(ws,td)
            rows.append({'id':case['id'],'baseline_passed':baseline['passed'],'oracle_passed':oracle['passed']})
    out={'cases':len(rows),'baseline_failures':sum(not r['baseline_passed'] for r in rows),'oracle_passes':sum(r['oracle_passed'] for r in rows),'rows':rows,
         'execution_boundary':'grader smoke only; no model/agent executed these tasks'}
    (ROOT/'reports/task_benchmark_smoke.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
    if out['oracle_passes']!=len(rows) or out['baseline_failures']!=len(rows): raise SystemExit(2)
if __name__=='__main__':main()
