from __future__ import annotations
import math, statistics


def percentile(values, p):
    if not values:
        return None
    xs=sorted(values)
    if len(xs)==1:
        return xs[0]
    k=(len(xs)-1)*p
    f=math.floor(k); c=math.ceil(k)
    if f==c: return xs[int(k)]
    return xs[f]*(c-k)+xs[c]*(k-f)


def aggregate(rows):
    n=len(rows)
    clean=[r for r in rows if r['expected_primary_failure'] is None]
    failed=[r for r in rows if r['expected_primary_failure'] is not None]
    clean_pass=sum(1 for r in clean if r['grade']['passed'])
    expected_match=sum(1 for r in rows if r['grade']['primary_failure']==r['expected_primary_failure'])
    detected=sum(1 for r in failed if r['grade']['primary_failure']==r['expected_primary_failure'])
    first_pass=sum(1 for r in clean if r['grade']['passed'] and r['trace'].get('execution',{}).get('attempts_max',1)<=1)
    declared_success_failures=sum(1 for r in failed if r['trace'].get('verification',{}).get('declared_success'))
    caught_false_success=sum(1 for r in failed if r['trace'].get('verification',{}).get('declared_success') and not r['grade']['passed'])
    verifier_opps=sum(1 for r in rows if r['trace'].get('verification',{}).get('declared_success') and r['trace'].get('verification',{}).get('independent_checks_passed') is False)
    verifier_catches=sum(1 for r in rows if r['grade']['primary_failure']=='VERIFY.FALSE_SUCCESS')
    costs=[float(r['trace'].get('metrics',{}).get('cost_usd',0)) for r in clean]
    lat=[float(r['trace'].get('metrics',{}).get('latency_ms',0)) for r in clean]
    replay=[bool(r.get('replay_consistent',True)) for r in rows]
    reworks=sum(1 for r in clean if r['trace'].get('execution',{}).get('attempts_max',1)>1)
    return {
      'cases_total': n,
      'clean_cases': len(clean),
      'injected_failure_cases': len(failed),
      'benchmark_expectation_accuracy': expected_match/n if n else 0,
      'clean_verified_success_rate': clean_pass/len(clean) if clean else None,
      'clean_first_pass_success_rate': first_pass/len(clean) if clean else None,
      'failure_detection_recall': detected/len(failed) if failed else None,
      'failure_taxonomy_codes_exercised': len({r['expected_primary_failure'] for r in failed}),
      'injected_false_success_catch_rate': caught_false_success/declared_success_failures if declared_success_failures else None,
      'verifier_catch_rate': verifier_catches/verifier_opps if verifier_opps else None,
      'clean_rework_rate': reworks/len(clean) if clean else None,
      'fixture_mean_cost_usd_clean_cases': statistics.mean(costs) if costs else None,
      'fixture_latency_p50_ms_clean_cases': percentile(lat,0.50),
      'fixture_latency_p95_ms_clean_cases': percentile(lat,0.95),
      'replay_consistency_rate': sum(replay)/len(replay) if replay else None,
      'population_note': 'Failure cases are intentionally injected; do not interpret all-case pass fraction or fixture cost/latency as live model performance.'
    }
