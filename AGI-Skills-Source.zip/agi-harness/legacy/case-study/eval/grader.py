from __future__ import annotations
import hashlib, json
from dataclasses import dataclass, asdict
from typing import Any

@dataclass
class Grade:
    passed: bool
    primary_failure: str | None
    secondary_failures: list[str]
    evidence: list[str]
    canonical_hash: str


def canonical_hash(trace: dict[str, Any]) -> str:
    blob = json.dumps(trace, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(blob).hexdigest()


def _add(failures: list[str], evidence: list[str], code: str, why: str) -> None:
    if code not in failures:
        failures.append(code)
    evidence.append(f"{code}: {why}")


def grade_trace(trace: dict[str, Any]) -> Grade:
    failures: list[str] = []
    evidence: list[str] = []
    plan = trace.get("plan", {})
    execution = trace.get("execution", {})
    verification = trace.get("verification", {})
    metrics = trace.get("metrics", {})

    roles = plan.get("roles", [])
    responsibilities = [r.get("responsibility") for r in roles]
    if len([x for x in responsibilities if x]) != len(set(x for x in responsibilities if x)):
        _add(failures, evidence, "PLAN.DUPLICATE_RESPONSIBILITY", "duplicate non-empty responsibility")

    owners: dict[str, str] = {}
    for role in roles:
        for artifact in role.get("owns", []):
            if artifact in owners and owners[artifact] != role.get("slot"):
                _add(failures, evidence, "PLAN.OWNERSHIP_CONFLICT", f"{artifact} owned by {owners[artifact]} and {role.get('slot')}")
            owners[artifact] = role.get("slot")
        for dep in role.get("depends_on", []):
            if dep not in {r.get("slot") for r in roles}:
                _add(failures, evidence, "PLAN.MISSING_DEPENDENCY", f"unknown dependency {dep}")

    sessions = execution.get("sessions", {})
    for slot in execution.get("required_slots", []):
        if not sessions.get(slot):
            _add(failures, evidence, "DELEGATION.MISSING_SESSION", f"missing session for {slot}")

    for d in execution.get("dispatches", []):
        slot, controller = d.get("slot", ""), d.get("controller")
        if slot.startswith("w"):
            expected = "control-a" if int(slot[1:]) <= 8 else "control-b"
            if controller != expected:
                _add(failures, evidence, "DELEGATION.WRONG_CONTROLLER", f"{slot} dispatched by {controller}, expected {expected}")

    receipts = execution.get("receipts", [])
    ids = [r.get("provider_response_id") for r in receipts if r.get("provider_response_id")]
    if len(ids) != len(set(ids)):
        _add(failures, evidence, "EXEC.DUPLICATE_PROVIDER_RESPONSE", "duplicate provider_response_id")
    for r in receipts:
        if r.get("uncertain"):
            _add(failures, evidence, "EXEC.TIMEOUT_UNCERTAIN", f"uncertain execution in {r.get('slot')}")
        if r.get("valid_output") is False:
            _add(failures, evidence, "EXEC.INVALID_OUTPUT", f"invalid output in {r.get('slot')}")
        if not r.get("provider_response_id"):
            _add(failures, evidence, "EVIDENCE.MISSING_RECEIPT", f"missing response id for {r.get('slot')}")
        if r.get("content_sha256") and r.get("recomputed_sha256") and r["content_sha256"] != r["recomputed_sha256"]:
            _add(failures, evidence, "EVIDENCE.HASH_MISMATCH", f"receipt hash mismatch for {r.get('slot')}")
        if r.get("nonce") and r.get("expected_nonce") and r["nonce"] != r["expected_nonce"]:
            _add(failures, evidence, "EVIDENCE.STALE_NONCE", f"stale nonce for {r.get('slot')}")

    for review in verification.get("reviews", []):
        slot = review.get("slot", "")
        expected = "control-b" if slot.startswith("w") and int(slot[1:]) <= 8 else "control-a"
        if review.get("reviewer") != expected:
            _add(failures, evidence, "VERIFY.WRONG_REVIEWER", f"{slot} reviewed by {review.get('reviewer')}")
        if review.get("output_sha256") != review.get("current_output_sha256"):
            _add(failures, evidence, "VERIFY.STALE_HASH", f"stale review hash for {slot}")

    if verification.get("declared_success") and verification.get("independent_checks_passed") is False:
        _add(failures, evidence, "VERIFY.FALSE_SUCCESS", "executor declared success while independent checks failed")

    if execution.get("attempts_max", 0) > execution.get("retry_budget", 2):
        _add(failures, evidence, "RECOVERY.RETRY_BUDGET_EXCEEDED", "attempts exceed retry budget")
    if execution.get("replayed_uncertain_call"):
        _add(failures, evidence, "RECOVERY.REPLAYED_UNCERTAIN_CALL", "uncertain call was replayed")
    if execution.get("lease_lost"):
        _add(failures, evidence, "INFRA.LEASE_LOST", "job lease lost")
    if execution.get("provider_fingerprint_changed"):
        _add(failures, evidence, "INFRA.CONFIG_DRIFT", "provider fingerprint changed")

    for artifact in trace.get("artifacts", []):
        if artifact.get("required") and not artifact.get("exists"):
            _add(failures, evidence, "ARTIFACT.MISSING", artifact.get("path", "required artifact missing"))
        owner = artifact.get("owner")
        writer = artifact.get("writer")
        if owner and writer and owner != writer:
            _add(failures, evidence, "ARTIFACT.OUTSIDE_OWNERSHIP", f"{artifact.get('path')} written by {writer}, owner {owner}")

    if metrics.get("cost_usd", 0) > metrics.get("budget_usd", float("inf")):
        _add(failures, evidence, "COST.BUDGET_EXCEEDED", f"cost={metrics.get('cost_usd')} budget={metrics.get('budget_usd')}")
    if metrics.get("latency_ms", 0) > metrics.get("slo_ms", float("inf")):
        _add(failures, evidence, "LATENCY.SLO_BREACH", f"latency={metrics.get('latency_ms')} slo={metrics.get('slo_ms')}")

    primary = failures[0] if failures else None
    return Grade(not failures, primary, failures[1:], evidence, canonical_hash(trace))


def grade_dict(trace: dict[str, Any]) -> dict[str, Any]:
    return asdict(grade_trace(trace))
