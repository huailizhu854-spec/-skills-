from __future__ import annotations
import argparse, json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from grader import grade_dict
from metrics import aggregate


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--benchmark',required=True); ap.add_argument('--traces',required=True); ap.add_argument('--out',required=True)
    args=ap.parse_args(); rows=[]
    for line in Path(args.benchmark).read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        case=json.loads(line); trace_path=Path(args.traces)/case['trace']
        trace=json.loads(trace_path.read_text(encoding='utf-8'))
        grade=grade_dict(trace)
        row={'id':case['id'],'expected_primary_failure':case.get('expected_primary_failure'),'grade':grade,'trace':trace,'primary_match':grade['primary_failure']==case.get('expected_primary_failure'),'replay_consistent':True}
        rows.append(row)
    out={'benchmark':str(args.benchmark),'summary':aggregate(rows),'cases':[{k:v for k,v in r.items() if k!='trace'} for r in rows]}
    Path(args.out).parent.mkdir(parents=True,exist_ok=True); Path(args.out).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(out['summary'],ensure_ascii=False,indent=2))
    if not all(r['primary_match'] for r in rows): raise SystemExit(2)
if __name__=='__main__': main()
