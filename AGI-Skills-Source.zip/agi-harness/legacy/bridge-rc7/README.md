# AGI Agent Team 3.4.0-rc.7 · External Host Bridge

**本轮交付范围：固定的 2 主控＋16 Worker「你好」真实性验收桥。不是通用自主开发平台，也不是 ChatGPT 内部原生子 Agent 接口。** 原 rc.6 原生宿主模块保留；新外部路线使用自己的 Supabase 账本，不和原生 SQLite 账本混为同一任务的两个真相源。

## 已有实现与当前实际状态

已实现真实 HTTP 模型适配器、18 个隔离应用上下文、两个模型主控派单、16 路 Worker HTTP 请求、对侧主控复核、代码级独立验收、持久状态、幂等、租约、取消与证据导出。主控的派单/审核必须来自实际模型返回的合法决策，运行时不能自填。

本轮线上 MCP 与数据库已部署。**模型供应商尚未配置，真实模型调用验收为 NOT_EXECUTED。** `reports/fixture-demo.json` 的问候全部来自明确标注的本地 HTTP 测试夹具，不是真实模型。请阅读本轮实测报告，不要把历史报告或 topology PASS 当成当前原生/模型验收。

## 正常流程与请求数量

```text
start_dual16 → 18 个应用管理的独立上下文，尚未推理
advance #1 → Controller A / B 各做一次真实模型调用，分别决定派单 8 人
advance #2 → w01–w16 各用自己的上下文调用模型，保存原始回复
advance #3 → A 审 w09–w16，B 审 w01–w08，回到各自主控原上下文
collect → 代码重新核验完整证据，合格后返回 16 条原文
```

无返工的一轮为 **20 次模型请求、18 个上下文**，不是 18 次请求。Worker 错误时只重跑原责任人并用对侧主控复核，每人最多 2 次尝试，整个任务最多 64 次请求。HTTP 并发请求不等于供应商 GPU 同时执行推理；应用生成的 context_id 不等于 provider_response_id，也不能证明创建了 ChatGPT 原生会话。

这是**显式分阶段、可续跑**的执行方式。每次调用 `advance_dual16` 执行一个阶段；没有常驻后台消费者、cron、无人值守自动续跑或 OAuth 授权服务器。CLI 可在前台自动推进完整问候流程。Supabase 后台任务仍受执行时限约束，故本版不靠一条悬挂请求等待整个长任务。

## 已部署 MCP

```text
https://YOUR_SUPABASE_PROJECT_ID.supabase.co/functions/v1/agi-agent-team-rc7/mcp
```

健康检查为同一路径末尾改 `/healthz`。旧 v3.2、rc.6 端点保持不变；现有个人插件不会因新端点部署而自动换地址。本轮并未证明各聊天产品的完整 UI 接入兼容性。

## 八个工具

| 工具 | 实际行为 |
|---|---|
| runtime_info | 返回实现边界与配置就绪状态，不调用模型 |
| dual16_self_test | 计算拓扑检查，不是模型自测 |
| start_dual16 | 鉴权后创建固定问候任务；同一 owner＋幂等键返回同一任务 |
| advance_dual16 | 执行一个实际模型阶段，保存意图与回执 |
| get_dual16_status | 只读状态，不暗中推进任务 |
| collect_dual16_results | 复核证据后取回 16 句原始问候 |
| cancel_dual16 | 阻止后续阶段，不声称已取消供应商在途请求 |
| export_dual16_evidence | 鉴权导出本任务原始回执与上下文，含敏感对话内容 |

本轮没有添加“只生成 UUID 就宣称 spawn 成功”的接口。不能把这份桥用于任意代码修改、文件写入或联网研究：本版只接受固定问候探针，不接受任意 goal。

## 先配置模型，不要把密钥发进普通聊天

在 Supabase 本项目的 Edge Function Secrets 中配置 `model.env.example` 列出的变量。供应商需提供兼容 `/chat/completions` 的接口，返回 `id` 与 `choices[0].message.content`，并能按要求输出 JSON。BASE_URL 只填 API 前缀，不要把 `/chat/completions` 重复拼上。

启用前核实：模型确实可用、模型名正确、可处理结构化指令、并发和限流条件、服务条款、数据传输范围，以及供应商是否真正提供零支出硬上限。**开源权重不代表托管推理免费；`hard-cap-zero` 只是操作方的确认，不会替供应商拦截收费。** 本版不自动切换付费模型、不自动购买额度、不提高并发配额。

只有上述条件满足后，才把：

```text
AGI_ENABLE_EXTERNAL_INFERENCE=true
AGI_MODEL_TRANSPORT_AUTHORIZED=true
AGI_MODEL_BILLING_MODE=hard-cap-zero
```

写入服务端秘密配置。配置不足时 `start_dual16` 返回 `BLOCKED_CONFIG`，不创建任务，也不发模型请求。云端代码不能通过 `localhost` 连接你电脑的 Ollama；本地模型需另行部署本机 runner，不在本轮云端交付的范围内。

## 桥接访问凭据与模型密钥分离

服务对外关闭 Supabase 网关 JWT 验证，但实现自己的访问凭据验证。公开部分只有初始化、工具列表、健康、运行状态与拓扑；所有任务动作需要专用 `agi_...` 桥接凭据。数据库只保存 SHA-256 摘要，不保存明文。

优先用 `Authorization: Bearer <专用桥接凭据>`。本轮另附的**私有连接配置文件**只含此桥接凭据，不含模型 API key 或 service_role key；不得转发，不能放入公共仓库或通用 Skill ZIP。

缺少自定义请求头支持的客户端，可在受保护工具参数 `bridge_key` 中提供这个专用、可撤销的桥接凭据，但它会进入客户端/模型工具调用上下文，应审慎使用。**不得把供应商 API key 或 Supabase service_role key 填进去。** 这是工具级凭据，不是 OAuth。本轮仅验证 HTTP MCP 协议与本地鉴权流程，云端携带凭据的请求测试被工具安全检查阻止，未伪记为通过。

## 使用 CLI 运行完整探针

要求 Node.js 22+，不需要 npm 安装。将另附私有文件保存为本目录 `client.env`：

```bash
node --env-file=client.env scripts/probe.mjs --check
node --env-file=client.env scripts/probe.mjs --run
# 已有一个 READY 任务时，按其真实 job_id 续跑：
node --env-file=client.env scripts/probe.mjs --resume <job_id>
```

`--check` 不推理；`--run` 是显式的外部推理请求。遇到不确定执行、429、5xx、非法回执或超时，程序停止，不偷偷重放或切换供应商。改动供应商/模型会让旧任务阻塞，需要新的任务轮次。

## 验证边界

每名 Worker 需返回绑定 slot 与本轮 nonce 的“你好”JSON；每名主控需返回绑定本轮 nonce 的组内派单/对侧审核；审核需对应输出哈希。独立代码验证层不另开第 19 个模型。它能验证这些确定性合同，**不能因此证明任意复杂任务的事实正确性**。

证据包含原始响应、供应商响应 ID、应用 context ID、时间、usage（供应商提供时）、请求意图及输出哈希。哈希只能检测记录是否改变，不能证明供应商身份；`provider_identity_attested` 与 `simultaneous_model_inference_proven` 保持 false。

## 安全与恢复

新任务：每 owner 每 24 小时最多 10 个，活跃未过期记录最多 40 个，单记录最大约 1.8 MB。请求体、模型响应与 HTTP 时间均有限制。模型地址仅来自服务端配置，客户端不可替换；字面本地地址与非 HTTPS 地址被拒绝。这不是完整的 DNS 重绑定防护或第三方安全审计。

请求意图先写入数据库，再向供应商发请求；若进程中断后发现未决意图，进入 `BLOCKED_UNCERTAIN`，不声称 exactly-once，也不盲目重试。取消结果为 `CANCELLED_REMOTE_UNCONFIRMED`，供应商在途推理可能仍结束。

任务记录逻辑保留 7 天：到期后接口不可读取；过期记录在后续创建同类记录时清理，**没有额外定时物理删除作业**。桥接凭据本轮有效期 90 天，可提前撤销；通用 RPC 创建的新凭据记录默认 365 天，生产运维应自行设定更短过期时间。

## 本地测试与重新部署

```bash
node --test tests/*.test.mjs
node scripts/fixture-demo.mjs
```

两者不调用真实模型。重新部署时使用 `src/index.mjs` 作入口，上传 `core.mjs`、`handler.mjs`、`store.mjs`；它们使用相对依赖且不需要第三方包。数据库初始结构见 `database/schema.sql`。使用 CLI 前先核对当前官方 `--help`，不要把示例路径当成你电脑的路径。

详细设计、已知限制与本轮可复现证据见 `docs/ACCEPTANCE.md` 和 `reports/`。
