import {readLimited} from './core.mjs';
/** Only the Edge Function receives the Supabase service-role key. Never expose it to clients. */
export class RemoteStore {
  constructor(url,key,fetcher=fetch){this.url=url;this.key=key;this.fetcher=fetcher;}
  async rpc(op,collection,key='',value={},revision=0,lease=''){
    if(!this.url||!this.key)throw new Error('STORAGE_NOT_CONFIGURED');
    const r=await this.fetcher(this.url+'/rest/v1/rpc/agi_rc7_store',{
      method:'POST',redirect:'error',signal:AbortSignal.timeout(8000),
      headers:{'content-type':'application/json','apikey':this.key,'authorization':'Bearer '+this.key},
      body:JSON.stringify({p_op:op,p_collection:collection,p_key:key,p_value:value,p_revision:revision,p_lease:lease})});
    const text=await readLimited(r,1900000);
    if(!r.ok){let code='STORAGE_ERROR';try{const m=JSON.parse(text).message;
      if(['INVALID_COLLECTION','STORAGE_QUOTA','DAILY_JOB_LIMIT','NOT_FOUND','BUSY','JOB_STOPPED','LEASE_LOST','REVISION_CONFLICT'].includes(m))code=m;}catch{}
      throw new Error(code);}
    return JSON.parse(text);
  }
  get(c,k){return this.rpc('get',c,k);}
  create(c,k,v){return this.rpc('create',c,k,v);}
  acquire(k,l){return this.rpc('acquire','jobs',k,{},0,l);}
  checkpoint(k,v,r,l){return this.rpc('checkpoint','jobs',k,v,r,l);}
  release(k,l){return this.rpc('release','jobs',k,{},0,l);}
  cancel(k){return this.rpc('cancel','jobs',k);}
}
