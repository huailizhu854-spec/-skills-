import {HttpProvider,configuration} from './core.mjs';
import {RemoteStore} from './store.mjs';
import {createHandler} from './handler.mjs';
const env=Deno.env.toObject();
const store=new RemoteStore(env.SUPABASE_URL,env.SUPABASE_SERVICE_ROLE_KEY);
const provider=new HttpProvider(configuration(env));
Deno.serve(createHandler(store,provider));
