import {Runtime,VERSION,WORKERS,CONTROLLERS,assigned,sha,readLimited,requireThat} from './core.mjs';
const keyProp={type:'string',description:'Dedicated bridge access token. Prefer Authorization: Bearer instead. Never put a model API key here.'};
const jobProp={type:'string',pattern:'^[a-f0-9-]{36}$',description:'Job ID returned by start_dual16.'};
const schema=properties=>({type:'object',properties,additionalProperties:false});
export const TOOLS=[
  {name:'runtime_info',description:'Show live configuration readiness and implementation boundaries. Does not call a model.',inputSchema:schema({})},
  {name:'dual16_self_test',description:'Compute topology checks only; not evidence of model execution.',inputSchema:schema({})},
  {name:'start_dual16',description:'Create exactly 2 controller + 16 worker isolated contexts for an authenticated fixed greeting probe. No paid fallback. No model call yet.',inputSchema:{...schema({bridge_key:keyProp,idempotency_key:{type:'string',minLength:8,maxLength:100}}),required:['idempotency_key']}},
  {name:'advance_dual16',description:'Execute one real external-model phase: controller dispatch, up to 16 worker greetings, or opposite-team review. Preserve receipts; no hidden retries. Call again only when status is READY.',inputSchema:{...schema({bridge_key:keyProp,job_id:jobProp}),required:['job_id']}},
  {name:'get_dual16_status',description:'Read persisted status only. Does not advance or run models.',inputSchema:{...schema({bridge_key:keyProp,job_id:jobProp}),required:['job_id']}},
  {name:'collect_dual16_results',description:'Independently check stored receipt hashes and greeting contracts, then return all 16 original replies only if complete.',inputSchema:{...schema({bridge_key:keyProp,job_id:jobProp}),required:['job_id']}},
  {name:'cancel_dual16',description:'Stop future phases. In-flight remote inference may still finish; provider cancellation is not guaranteed.',inputSchema:{...schema({bridge_key:keyProp,job_id:jobProp}),required:['job_id']}},
  {name:'export_dual16_evidence',description:'Read raw model receipts and context transcripts for this job. Sensitive: only export intentionally; stored for 7 days.',inputSchema:{...schema({bridge_key:keyProp,job_id:jobProp}),required:['job_id']}}
].map(x=>({...x,annotations:{readOnlyHint:!['start_dual16','advance_dual16','cancel_dual16'].includes(x.name),destructiveHint:false,idempotentHint:x.name!=='advance_dual16',openWorldHint:x.name==='advance_dual16'}}));
function json(body,status=200,headers={}){return new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store',...headers}});}
export function createHandler(store,provider,{allowedOrigins=['https://chatgpt.com','https://chat.openai.com'],prefix='/agi-agent-team-rc7'}={}){
  const runtime=new Runtime(store,provider);
  const authenticate=async(req,args)=>{
    const bearer=req.headers.get('authorization');
    const token=bearer?.startsWith('Bearer ')?bearer.slice(7):args.bridge_key;
    requireThat(typeof token==='string'&&/^agi_[A-Za-z0-9_-]{40,120}$/.test(token),'AUTH_REQUIRED');
    const r=await store.get('tokens',await sha(token));
    requireThat(r?.value?.enabled===true&&typeof r.value.owner==='string','AUTH_REQUIRED');return r.value.owner;
  };
  return async req=>{
    const url=new URL(req.url),path=url.pathname;
    const origin=req.headers.get('origin');
    if(origin&&!allowedOrigins.includes(origin))return json({error:'ORIGIN_REJECTED'},403);
    if(path===prefix+'/healthz'){
      if(req.method!=='GET')return json({error:'METHOD_NOT_ALLOWED'},405);
      return json({ok:true,version:VERSION,scope:'greeting_acceptance_only',tools:TOOLS.length,configuration:provider.readiness(),native_chatgpt_agents:0});
    }
    if(path!==prefix+'/mcp')return json({error:'NOT_FOUND'},404);
    if(req.method==='GET'||req.method==='DELETE')return json({error:'SSE_NOT_SUPPORTED_USE_POST'},405,{'allow':'POST'});
    if(req.method!=='POST')return json({error:'METHOD_NOT_ALLOWED'},405);
    const accept=req.headers.get('accept')??'';
    if(!accept.includes('application/json')||!accept.includes('text/event-stream'))return json({error:'ACCEPT_MUST_INCLUDE_JSON_AND_SSE'},406);
    if(!(req.headers.get('content-type')??'').toLowerCase().startsWith('application/json'))return json({error:'CONTENT_TYPE_REQUIRED'},415);
    const version=req.headers.get('mcp-protocol-version');
    if(version&&!['2025-03-26','2025-06-18','2025-11-25'].includes(version))return json({error:'UNSUPPORTED_PROTOCOL'},400);
    let body;
    try{body=JSON.parse(await readLimited(req,20000));}catch{return json({jsonrpc:'2.0',id:null,error:{code:-32700,message:'Invalid JSON or body too large'}},400);}
    if(!body||Array.isArray(body)||body.jsonrpc!=='2.0'||typeof body.method!=='string')return json({jsonrpc:'2.0',id:null,error:{code:-32600,message:'Invalid request'}},400);
    if(!('id'in body)){
      if(!body.method.startsWith('notifications/'))return json({error:'MISSING_REQUEST_ID'},400);
      return new Response(null,{status:202});
    }
    const response=result=>json({jsonrpc:'2.0',id:body.id,result});
    const error=(code,message)=>json({jsonrpc:'2.0',id:body.id,error:{code,message}});
    if(body.method==='initialize')return response({protocolVersion:['2025-03-26','2025-06-18','2025-11-25'].includes(body.params?.protocolVersion)?body.params.protocolVersion:'2025-11-25',
      capabilities:{tools:{listChanged:false}},serverInfo:{name:'AGI-Agent-Team-External-Bridge',version:VERSION},
      instructions:'Authenticated fixed greeting probe only. 18 local context IDs are not model execution. start_dual16 then advance while READY; collect only when COMPLETED. Never invent replies. Missing model configuration is a hard stop.'});
    if(body.method==='ping')return response({});
    if(body.method==='tools/list')return response({tools:TOOLS});
    if(body.method!=='tools/call')return error(-32601,'Method not found');
    const tool=TOOLS.find(x=>x.name===body.params?.name);
    if(!tool)return error(-32602,'Unknown tool');
    const args=body.params.arguments??{};
    try{
      requireThat(args&&typeof args==='object'&&!Array.isArray(args),'INVALID_ARGUMENTS');
      requireThat(Object.keys(args).every(k=>k in tool.inputSchema.properties),'UNKNOWN_ARGUMENT');
      for(const k of tool.inputSchema.required??[])requireThat(typeof args[k]==='string','MISSING_ARGUMENT:'+k);
      let result;
      if(tool.name==='runtime_info')result=runtime.info();
      else if(tool.name==='dual16_self_test')result={status:WORKERS.length===16&&new Set(WORKERS).size===16&&CONTROLLERS.every(c=>assigned(c).length===8)?'TOPOLOGY_PASS':'FAIL',native_model_sessions_spawned:0,model_execution:'NOT_EXECUTED',version:VERSION};
      else {
        const owner=await authenticate(req,args);
        if(tool.name==='start_dual16')result=await runtime.start(owner,args.idempotency_key);
        else if(tool.name==='advance_dual16')result=await runtime.advance(args.job_id,owner);
        else if(tool.name==='get_dual16_status')result=await runtime.status(args.job_id,owner);
        else if(tool.name==='collect_dual16_results')result=await runtime.collect(args.job_id,owner);
        else if(tool.name==='cancel_dual16')result=await runtime.cancel(args.job_id,owner);
        else {const r=await runtime.own(args.job_id,owner);result={...r.value,owner:undefined};}
      }
      return response({content:[{type:'text',text:JSON.stringify(result)}],isError:false});
    }catch(e){
      // Never return provider secrets, request headers or storage error bodies.
      const message=/^[A-Z][A-Z0-9_: -]{0,150}$/.test(e.message)?e.message:'REQUEST_FAILED';
      return response({content:[{type:'text',text:JSON.stringify({error:message})}],isError:true});
    }
  };
}
