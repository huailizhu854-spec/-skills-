-- Cloud job store. Run as a Supabase migration; runtime RPC is service_role-only.
create schema if not exists agi_rc7;
revoke all on schema agi_rc7 from public, anon, authenticated;
grant usage on schema agi_rc7 to service_role;
create table if not exists agi_rc7.documents (
 collection text not null check (collection in ('jobs','tokens')),
 key text not null check (length(key) between 1 and 200),
 value jsonb not null check (octet_length(value::text) <= 1800000),
 revision integer not null default 1, expires_at timestamptz not null,
 lease_token text, lease_until timestamptz,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 primary key (collection,key)
);
alter table agi_rc7.documents enable row level security;
revoke all on agi_rc7.documents from public, anon, authenticated;
grant select,insert,update,delete on agi_rc7.documents to service_role;
create index if not exists agi_rc7_expiry on agi_rc7.documents(expires_at);
create or replace function public.agi_rc7_store(
 p_op text, p_collection text, p_key text default '', p_value jsonb default '{}'::jsonb,
 p_revision integer default 0, p_lease text default ''
) returns jsonb language plpgsql security invoker set search_path='' as $$
declare r agi_rc7.documents%rowtype; n integer;
begin
 if p_collection not in ('jobs','tokens') then raise exception 'INVALID_COLLECTION'; end if;
 if p_op='get' then
  select * into r from agi_rc7.documents where collection=p_collection and key=p_key and expires_at>now();
  if not found then return 'null'::jsonb; end if;
 elsif p_op='create' then
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('agi_rc7:'||p_collection,0));
  select * into r from agi_rc7.documents where collection=p_collection and key=p_key for update;
  if found and r.expires_at>now() then return jsonb_build_object('existing',true,'key',r.key,'value',r.value,'revision',r.revision); end if;
  delete from agi_rc7.documents where collection=p_collection and expires_at<=now();
  select count(*) into n from agi_rc7.documents where collection=p_collection;
  if n >= (case when p_collection='jobs' then 40 else 100 end) then raise exception 'STORAGE_QUOTA'; end if;
  if p_collection='jobs' then
   select count(*) into n from agi_rc7.documents where collection='jobs' and created_at>now()-interval '24 hours' and value->>'owner'=p_value->>'owner';
   if n>=10 then raise exception 'DAILY_JOB_LIMIT'; end if;
  end if;
  insert into agi_rc7.documents(collection,key,value,expires_at) values(p_collection,p_key,p_value,now()+(case when p_collection='jobs' then interval '7 days' else interval '365 days' end)) returning * into r;
 elsif p_op='acquire' and p_collection='jobs' then
  select * into r from agi_rc7.documents where collection='jobs' and key=p_key and expires_at>now() for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if r.lease_until>now() then raise exception 'BUSY'; end if;
  if r.value->>'status' not in ('READY','RUNNING') then raise exception 'JOB_STOPPED'; end if;
  update agi_rc7.documents set lease_token=p_lease,lease_until=now()+interval '110 seconds',updated_at=now() where collection='jobs' and key=p_key returning * into r;
 elsif p_op='checkpoint' and p_collection='jobs' then
  select * into r from agi_rc7.documents where collection='jobs' and key=p_key and expires_at>now() for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if r.lease_token is distinct from p_lease or r.lease_until<=now() then raise exception 'LEASE_LOST'; end if;
  if r.revision<>p_revision then raise exception 'REVISION_CONFLICT'; end if;
  if r.value->>'status' not in ('READY','RUNNING') then raise exception 'JOB_STOPPED'; end if;
  update agi_rc7.documents set value=p_value,revision=revision+1,updated_at=now() where collection='jobs' and key=p_key returning * into r;
 elsif p_op='release' and p_collection='jobs' then
  update agi_rc7.documents set lease_token=null,lease_until=null where collection='jobs' and key=p_key and lease_token=p_lease returning * into r;
  if not found then return 'null'::jsonb; end if;
 elsif p_op='cancel' and p_collection='jobs' then
  select * into r from agi_rc7.documents where collection='jobs' and key=p_key and expires_at>now() for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if r.value->>'status'='COMPLETED' then return jsonb_build_object('key',r.key,'value',r.value,'revision',r.revision); end if;
  update agi_rc7.documents set value=jsonb_set(value,'{status}','"CANCELLED_REMOTE_UNCONFIRMED"'::jsonb),revision=revision+1,updated_at=now() where collection='jobs' and key=p_key returning * into r;
 else raise exception 'INVALID_OPERATION';
 end if;
 return jsonb_build_object('key',r.key,'value',r.value,'revision',r.revision,'lease_token',r.lease_token,'lease_until',r.lease_until);
end $$;
revoke all on function public.agi_rc7_store(text,text,text,jsonb,integer,text) from public,anon,authenticated;
grant execute on function public.agi_rc7_store(text,text,text,jsonb,integer,text) to service_role;
