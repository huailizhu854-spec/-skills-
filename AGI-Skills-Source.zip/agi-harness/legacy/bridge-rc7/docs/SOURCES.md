# 实施时核对的技术资料

- Supabase Edge Function limits: https://supabase.com/docs/guides/functions/limits
- Supabase background tasks: https://supabase.com/docs/guides/functions/background-tasks
- Supabase HTTP database extension: https://supabase.com/docs/guides/database/extensions/http
- PostgreSQL HTTP primary documentation: https://github.com/pramsey/pgsql-http
- MCP Streamable HTTP specification: https://modelcontextprotocol.io/specification/2025-11-25/basic/transports
- Ollama compatible API reference (not deployed/used in this cloud test): https://docs.ollama.com/api/openai-compatibility

核对日期：2026-09-27。Supabase changelog.md 索引本轮获取失败，未声称已检查其全部变更。线上项目证据来自已连接的Supabase工具，不来自公开网页推测。上面资料说明协议与部署条件，不构成本项目真实模型执行证据。
