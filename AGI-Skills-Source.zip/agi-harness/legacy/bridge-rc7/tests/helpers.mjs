import {copy,requireThat,id,configuration,HttpProvider} from '../src/core.mjs';
import http from 'node:http';
export class MemoryStore {
 constructor(){this.data=new Map();}
 async get(c,k){const r=this.data.get(c+':'+k);return r&&r.expiry>Date.now()?copy(r):null;}
 async create(c,k,v){const old=await this.get(c,k);if(old)return {...old,existing:true};
  const rows=[...this.data.entries()].filter(([key,r])=>key.startsWith(c+':')&&r.expiry>Date.now()).map(([,r])=>r);
  requireThat(rows.length<(c==='jobs'?40:100),'STORAGE_QUOTA');
  if(c==='jobs')requireThat(rows.filter(r=>r.value.owner===v.owner&&r.created>Date.now()-86400000).length<10,'DAILY_JOB_LIMIT');
  const r={key:k,value:copy(v),revision:1,created:Date.now(),expiry:Date.now()+86400000*(c==='jobs'?7:365),lease_token:null,lease_until:null};
  this.data.set(c+':'+k,r);return copy(r);
 }
 async acquire(k,l){const r=this.data.get('jobs:'+k);requireThat(r,'NOT_FOUND');requireThat(!r.lease_until||r.lease_until<Date.now(),'BUSY');requireThat(['READY','RUNNING'].includes(r.value.status),'JOB_STOPPED');r.lease_token=l;r.lease_until=Date.now()+110000;return copy(r);}
 async checkpoint(k,v,rev,l){const r=this.data.get('jobs:'+k);requireThat(r,'NOT_FOUND');requireThat(r.lease_token===l&&r.lease_until>Date.now(),'LEASE_LOST');requireThat(r.revision===rev,'REVISION_CONFLICT');requireThat(['READY','RUNNING'].includes(r.value.status),'JOB_STOPPED');r.value=copy(v);r.revision++;return copy(r);}
 async release(k,l){const r=this.data.get('jobs:'+k);if(r?.lease_token===l){r.lease_token=null;r.lease_until=null;return copy(r);}return null;}
 async cancel(k){const r=this.data.get('jobs:'+k);requireThat(r,'NOT_FOUND');if(r.value.status!=='COMPLETED'){r.value.status='CANCELLED_REMOTE_UNCONFIRMED';r.revision++;}return copy(r);}
}
export async function mockHTTP(options={}) {
 const seen=[];let active=0,peak=0;const waiting=[];
 const server=http.createServer(async(req,res)=>{
  active++;peak=Math.max(peak,active);
  let text='';for await(const b of req)text+=b;const body=JSON.parse(text),packet=JSON.parse(body.messages.at(-1).content);
  seen.push({packet,body});const occurrence=seen.filter(x=>x.packet.slot===packet.slot&&x.packet.phase===packet.phase).length;
  try{
   if(options.barrier && packet.phase==='greeting' && seen.filter(x=>x.packet.phase==='greeting').length<=16) {
    await new Promise(resolve=>{waiting.push(resolve);if(waiting.length===16)for(const done of waiting)done();});
   }
   if(options.delay)await new Promise(r=>setTimeout(r,options.delay));
   if(options.httpError&&packet.slot===options.errorSlot){res.writeHead(options.httpError);res.end('fixture error');return;}
   let result;
   if(packet.phase==='dispatch')result={controller:packet.slot,nonce:packet.nonce,decisions:packet.assigned_workers.map(slot=>({slot,action:'dispatch',reason:'Ready for the connectivity test.'}))};
   else if(packet.phase==='greeting')result={slot:packet.slot,nonce:packet.nonce,greeting:'你好'};
   else result={controller:packet.slot,nonce:packet.nonce,decisions:packet.worker_evidence.map(w=>({slot:w.slot,action:w.independent_checks_ok?'accept':'rework',output_sha256:w.output_sha256,reason:'Checked the supplied output and integrity result.'}))};
   if(options.mutate)result=options.mutate(result,packet,occurrence)??result;
   const payload={id:options.fixedId??'fixture-'+id(),model:'fixture-not-a-model',choices:[{message:{role:'assistant',content:JSON.stringify(result)}}],usage:{total_tokens:1}};
   if(options.noId)delete payload.id;
   res.writeHead(200,{'content-type':'application/json','x-request-id':id()});res.end(JSON.stringify(payload));
  }finally{active--;}
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const baseURL=`http://127.0.0.1:${server.address().port}/v1`;
 const config=configuration({AGI_MODEL_BASE_URL:baseURL,AGI_MODEL_NAME:'fixture-not-a-model',AGI_MODEL_ALLOWED_HOST:'127.0.0.1',
  AGI_ENABLE_EXTERNAL_INFERENCE:'true',AGI_MODEL_TRANSPORT_AUTHORIZED:'true',AGI_MODEL_BILLING_MODE:'hard-cap-zero'},{local:true});
 if(options.timeout)config.timeoutMs=options.timeout;
 const provider=new HttpProvider(config);provider.kind='fixture';
 return {provider,seen,get peak(){return peak;},close:async()=>{server.closeAllConnections();await new Promise(r=>server.close(r));}};
}
