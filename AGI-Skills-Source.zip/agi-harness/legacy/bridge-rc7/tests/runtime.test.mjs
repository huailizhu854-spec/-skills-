import test from 'node:test';
import assert from 'node:assert/strict';
import {Runtime,configuration,sha,WORKERS} from '../src/core.mjs';
import {MemoryStore,mockHTTP} from './helpers.mjs';
import {createHandler} from '../src/handler.mjs';
async function rig(t,opts={}){const mock=await mockHTTP(opts);t.after(()=>mock.close());const store=new MemoryStore();return {mock,store,rt:new Runtime(store,mock.provider)};}
async function run(rt,key='test-job-0001'){let r=await rt.start('owner',key);for(let i=0;i<8&&r.status==='READY';i++)r=await rt.advance(r.job_id,'owner');return r;}
const token='agi_'+('x'.repeat(48));
function req(name,args={},headers={}){return new Request('https://example.test/agi-agent-team-rc7/mcp',{method:'POST',headers:{'content-type':'application/json',accept:'application/json, text/event-stream',...headers},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name,arguments:args}})});}

test('20 actual loopback HTTP calls, 18 isolated contexts, 2x8 dispatch, opposite reviews',async t=>{
 const {mock,rt,store}=await rig(t,{delay:8,barrier:true});const r=await run(rt);assert.equal(r.status,'COMPLETED');
 const out=await rt.collect(r.job_id,'owner');assert.equal(out.greetings.length,16);assert.equal(out.provider_calls,20);assert.equal(out.execution_kind,'fixture');
 assert.equal(out.native_chatgpt_agents,0);assert.equal(out.simultaneous_model_inference_proven,false);assert.equal(out.controllers_with_model_responses,2);
 assert.equal(mock.seen.length,20);assert.equal(mock.peak,16); // request overlap, NOT inference parallelism
 const j=(await store.get('jobs',r.job_id)).value;assert.equal(new Set(Object.values(j.sessions).map(x=>x.context_id)).size,18);
 assert.ok(mock.seen.filter(x=>x.packet.phase==='greeting').every(x=>x.body.messages.length===2));
 assert.equal(j.sessions['control-a'].messages.length,5);assert.equal(j.sessions.w01.messages.length,3);
 for(const s of WORKERS)assert.equal(j.worker_records[s].parsed.greeting,'你好');
});
test('missing provider config blocks before allocating or calling models',async()=>{const store=new MemoryStore();const rt=new Runtime(store,{kind:'external_model_api',readiness:()=>({ready:false,missing:['AGI_MODEL_NAME']})});assert.equal((await rt.start('x','abcdefgh')).status,'BLOCKED_CONFIG');assert.equal(store.data.size,0);});
test('idempotency returns same contexts and job; no extra call',async t=>{const {rt,store,mock}=await rig(t);const a=await rt.start('owner','same-key-123');const ctx=(await store.get('jobs',a.job_id)).value.sessions.w01.context_id;const b=await rt.start('owner','same-key-123');assert.equal(a.job_id,b.job_id);assert.equal(ctx,(await store.get('jobs',b.job_id)).value.sessions.w01.context_id);assert.equal(mock.seen.length,0);});
test('idempotency is owner scoped',async t=>{const {rt}=await rig(t);const a=await rt.start('a','same-key-123'),b=await rt.start('b','same-key-123');assert.notEqual(a.job_id,b.job_id);await assert.rejects(rt.status(a.job_id,'b'),/NOT_FOUND/);});
test('no hidden calls in status or incomplete collect',async t=>{const {rt,mock}=await rig(t);const a=await rt.start('owner','status-key1');await rt.status(a.job_id,'owner');const c=await rt.collect(a.job_id,'owner');assert.deepEqual(c.greetings,[]);assert.equal(mock.seen.length,0);});
test('concurrent advance has one lease and no duplicate inference',async t=>{const {rt,mock}=await rig(t,{delay:35});const a=await rt.start('owner','concurrency');const p=rt.advance(a.job_id,'owner');await new Promise(r=>setTimeout(r,5));await assert.rejects(rt.advance(a.job_id,'owner'),/BUSY/);await p;assert.equal(mock.seen.length,2);});
test('unknown old in-flight dispatch blocks without replay',async t=>{const {rt,store,mock}=await rig(t);const a=await rt.start('owner','stale-run-1');store.data.get('jobs:'+a.job_id).value.inflight=[{slot:'w01'}];const r=await rt.advance(a.job_id,'owner');assert.equal(r.status,'BLOCKED_UNCERTAIN');assert.equal(mock.seen.length,0);});
test('wrong controller group is rejected',async t=>{const {rt}=await rig(t,{mutate:(o,p)=>{if(p.phase==='dispatch'&&p.slot==='control-a')o.decisions[0].slot='w09';return o;}});const r=await run(rt);assert.equal(r.status,'BLOCKED_CONTRACT');assert.ok(r.errors.includes('CONTROLLER_SCOPE_VIOLATION'));});
test('duplicate controller worker IDs are rejected',async t=>{const {rt}=await rig(t,{mutate:(o,p)=>{if(p.phase==='dispatch')o.decisions[1].slot=o.decisions[0].slot;return o;}});assert.equal((await run(rt)).status,'BLOCKED_CONTRACT');});
test('stale controller nonce is rejected',async t=>{const {rt}=await rig(t,{mutate:(o,p)=>{if(p.phase==='dispatch')o.nonce='old';return o;}});assert.ok((await run(rt)).errors.includes('CONTROLLER_NONCE_MISMATCH'));});
test('one incorrect worker reworks only that worker with original context',async t=>{const {rt,mock,store}=await rig(t,{mutate:(o,p,n)=>{if(p.phase==='greeting'&&p.slot==='w07'&&n===1)o.greeting='wrong';return o;}});const r=await run(rt);assert.equal(r.status,'COMPLETED');assert.equal(mock.seen.length,22);assert.equal(mock.seen.filter(x=>x.packet.slot==='w07'&&x.packet.phase==='greeting').length,2);assert.equal(mock.seen.filter(x=>x.packet.slot==='w06').length,1);const j=(await store.get('jobs',r.job_id)).value;assert.equal(j.sessions.w07.messages.length,5);assert.equal((await rt.collect(r.job_id,'owner')).verified,true);});
test('repeated bad greeting stops at worker attempt cap',async t=>{const {rt,mock}=await rig(t,{mutate:(o,p)=>{if(p.phase==='greeting'&&p.slot==='w01')o.greeting='bad';return o;}});const r=await run(rt);assert.equal(r.status,'BLOCKED_CONTRACT');assert.ok(r.errors.includes('WORKER_ATTEMPT_LIMIT'));assert.equal(mock.seen.filter(x=>x.packet.slot==='w01').length,2);});
test('controller false approval cannot bypass independent worker checks',async t=>{const {rt}=await rig(t,{mutate:(o,p)=>{if(p.phase==='greeting'&&p.slot==='w01')o.nonce='old';if(p.phase==='review')o.decisions.forEach(d=>d.action='accept');return o;}});const r=await run(rt);assert.equal(r.status,'BLOCKED_CONTRACT');assert.ok(r.errors.includes('INDEPENDENT_GATE_REJECTED'));assert.equal((await rt.collect(r.job_id,'owner')).greetings.length,0);});
test('stale review hash rejected',async t=>{const {rt}=await rig(t,{mutate:(o,p)=>{if(p.phase==='review')o.decisions[0].output_sha256='old';return o;}});assert.ok((await run(rt)).errors.includes('STALE_REVIEW_HASH'));});
test('duplicate provider completion IDs never pass',async t=>{const {rt}=await rig(t,{fixedId:'fixture-reused-id'});const r=await run(rt);assert.equal(r.status,'BLOCKED_PROVIDER');assert.ok(r.errors.includes('DUPLICATE_PROVIDER_RESPONSE_ID'));});
test('missing provider completion ID never accepted',async t=>{const {rt}=await rig(t,{noId:true});assert.equal((await run(rt)).status,'BLOCKED_PROVIDER');});
test('429 stops without automatic retry or paid fallback',async t=>{const {rt,mock}=await rig(t,{httpError:429,errorSlot:'control-a'});const r=await run(rt);assert.equal(r.status,'BLOCKED_PROVIDER');assert.equal(mock.seen.length,2);});
test('provider 500 considered uncertain and not replayed',async t=>{const {rt,mock}=await rig(t,{httpError:500,errorSlot:'control-a'});const r=await run(rt);assert.equal(r.status,'BLOCKED_UNCERTAIN');await rt.advance(r.job_id,'owner');assert.equal(mock.seen.length,2);});
test('timeout does not imply provider cancellation',async t=>{const {rt}=await rig(t,{timeout:5,delay:40});const r=await run(rt);assert.equal(r.status,'BLOCKED_UNCERTAIN');});
test('cancel prevents future dispatch and does not claim remote termination',async t=>{const {rt,mock}=await rig(t);const a=await rt.start('owner','cancel-key1');const c=await rt.cancel(a.job_id,'owner');assert.equal(c.status,'CANCELLED_REMOTE_UNCONFIRMED');await rt.advance(a.job_id,'owner');assert.equal(mock.seen.length,0);});
test('concurrent cancellation cannot be overwritten by late phase result',async t=>{const {rt}=await rig(t,{delay:30});const a=await rt.start('owner','cancel-key2');const p=rt.advance(a.job_id,'owner');await new Promise(r=>setTimeout(r,10));await rt.cancel(a.job_id,'owner');await p;assert.equal((await rt.status(a.job_id,'owner')).status,'CANCELLED_REMOTE_UNCONFIRMED');});
test('tampered raw receipt blocked on collection',async t=>{const {rt,store}=await rig(t);const r=await run(rt);store.data.get('jobs:'+r.job_id).value.receipts[0].raw_response+=' ';await assert.rejects(rt.collect(r.job_id,'owner'),/RECEIPT_HASH_MISMATCH/);});
test('deleted opposite-team review blocked on collection',async t=>{const {rt,store}=await rig(t);const r=await run(rt);store.data.get('jobs:'+r.job_id).value.reviews=[];await assert.rejects(rt.collect(r.job_id,'owner'),/CROSS_REVIEW_MISSING/);});
test('deleted context identity uniqueness blocked',async t=>{const {rt,store}=await rig(t);const r=await run(rt);const j=store.data.get('jobs:'+r.job_id).value;j.sessions.w02.context_id=j.sessions.w01.context_id;await assert.rejects(rt.collect(r.job_id,'owner'),/CONTEXT_COLLISION/);});
test('zero billing and explicit egress are required',()=>{const c=configuration({AGI_MODEL_BASE_URL:'https://test.example/v1',AGI_MODEL_NAME:'q',AGI_MODEL_API_KEY:'test',AGI_MODEL_ALLOWED_HOST:'test.example'});assert.equal(c.ready,false);assert.ok(c.missing.includes('AGI_MODEL_BILLING_MODE=hard-cap-zero'));});
test('cloud refuses HTTP and private IP model endpoints',()=>{for(const host of ['127.0.0.1','169.254.169.254','[::1]']){assert.equal(configuration({AGI_MODEL_BASE_URL:'http://'+host+'/v1',AGI_MODEL_NAME:'x',AGI_MODEL_ALLOWED_HOST:host}).ready,false);}});
test('provider URL rejects credentials, query and host mismatch',()=>{for(const url of ['https://user:pass@api.example/v1','https://api.example/v1?key=x','https://evil.example/v1'])assert.equal(configuration({AGI_MODEL_BASE_URL:url,AGI_MODEL_ALLOWED_HOST:'api.example'}).ready,false);});
test('daily job quota stops new allocations',async t=>{const {rt}=await rig(t);for(let i=0;i<10;i++)await rt.start('owner','quota-key-'+i);await assert.rejects(rt.start('owner','quota-key-11'),/DAILY_JOB_LIMIT/);});
test('MCP initialization, tools and notification work without exposing jobs',async t=>{const {store,mock}=await rig(t);const handler=createHandler(store,mock.provider);const base={method:'POST',headers:{'content-type':'application/json',accept:'application/json, text/event-stream'}};
 for(const method of ['initialize','tools/list','ping']){const r=await handler(new Request('https://x/agi-agent-team-rc7/mcp',{...base,body:JSON.stringify({jsonrpc:'2.0',id:1,method})}));assert.equal(r.status,200);assert.ok((await r.json()).result);}
 const r=await handler(new Request('https://x/agi-agent-team-rc7/mcp',{...base,body:JSON.stringify({jsonrpc:'2.0',method:'notifications/initialized'})}));assert.equal(r.status,202);});
test('MCP no key and wrong key cannot start jobs',async t=>{const {store,mock}=await rig(t);const h=createHandler(store,mock.provider);for(const args of [{idempotency_key:'auth-key-1'},{idempotency_key:'auth-key-1',bridge_key:token}]){const r=await(await h(req('start_dual16',args))).json();assert.equal(r.result.isError,true);assert.match(r.result.content[0].text,/AUTH_REQUIRED/);}assert.equal(store.data.size,0);});
test('MCP bearer authentication works, never returned in result',async t=>{const {store,mock}=await rig(t);await store.create('tokens',await sha(token),{owner:'owner',enabled:true});const h=createHandler(store,mock.provider);const raw=await(await h(req('start_dual16',{idempotency_key:'auth-key-2'},{authorization:'Bearer '+token}))).text();assert.equal(raw.includes(token),false);assert.equal(JSON.parse(raw).result.isError,false);});
test('MCP tool-scoped bridge key works for headerless clients',async t=>{const {store,mock}=await rig(t);await store.create('tokens',await sha(token),{owner:'owner',enabled:true});const h=createHandler(store,mock.provider);const r=await(await h(req('start_dual16',{idempotency_key:'auth-key-3',bridge_key:token}))).json();assert.equal(r.result.isError,false);});
test('MCP client cannot replace model endpoint or bypass billing mode',async t=>{const {store,mock}=await rig(t);const h=createHandler(store,mock.provider);const r=await(await h(req('start_dual16',{idempotency_key:'auth-key-4',model:'paid',baseURL:'https://evil.example'}))).json();assert.equal(r.result.isError,true);assert.match(r.result.content[0].text,/UNKNOWN_ARGUMENT/);});
test('MCP rejects wrong browser Origin',async t=>{const {store,mock}=await rig(t);assert.equal((await createHandler(store,mock.provider)(req('runtime_info',{}, {origin:'https://evil.example'}))).status,403);});
test('MCP rejects unsupported protocol',async t=>{const {store,mock}=await rig(t);assert.equal((await createHandler(store,mock.provider)(req('runtime_info',{}, {'mcp-protocol-version':'invalid'}))).status,400);});
test('MCP refuses unsupported GET event stream',async t=>{const {store,mock}=await rig(t);assert.equal((await createHandler(store,mock.provider)(new Request('https://x/agi-agent-team-rc7/mcp'))).status,405);});
test('MCP self test explicitly says no model execution',async t=>{const {store,mock}=await rig(t);const r=await(await createHandler(store,mock.provider)(req('dual16_self_test'))).json();const out=JSON.parse(r.result.content[0].text);assert.equal(out.model_execution,'NOT_EXECUTED');assert.equal(out.native_model_sessions_spawned,0);assert.equal(mock.seen.length,0);});

test('configuration errors never echo a malformed secret-bearing provider URL',()=>{
 const c=configuration({AGI_MODEL_BASE_URL:'secret-do-not-echo@example.invalid::bad'});
 assert.ok(c.missing.includes('INVALID_PROVIDER_URL'));assert.equal(JSON.stringify(c.missing).includes('secret-do-not-echo'),false);
});
test('changing provider after job creation stops before any model call',async t=>{
 const {rt,mock}=await rig(t);const j=await rt.start('owner','provider-change');mock.provider.config.model='changed';
 const r=await rt.advance(j.job_id,'owner');assert.equal(r.status,'BLOCKED_CONFIG');assert.ok(r.errors.includes('PROVIDER_CHANGED'));assert.equal(mock.seen.length,0);
});
test('tampered parsed worker text cannot replace the raw model reply',async t=>{
 const {rt,store}=await rig(t);const j=await run(rt);store.data.get('jobs:'+j.job_id).value.worker_records.w01.parsed.greeting='invented';
 await assert.rejects(rt.collect(j.job_id,'owner'),/WORKER_CONTENT_MISMATCH/);
});
test('a review referencing a worker receipt is not independent review evidence',async t=>{
 const {rt,store}=await rig(t);const j=await run(rt);const v=store.data.get('jobs:'+j.job_id).value;
 v.reviews[0].receipt_id=v.worker_records[v.reviews[0].slot].provider_response_id;
 await assert.rejects(rt.collect(j.job_id,'owner'),/REVIEW_RECEIPT_MISMATCH/);
});
test('revoked bridge token fails even when the token has not expired',async t=>{
 const {store,mock}=await rig(t);await store.create('tokens',await sha(token),{owner:'owner',enabled:false});
 const r=await(await createHandler(store,mock.provider)(req('start_dual16',{idempotency_key:'revoked-token'},{authorization:'Bearer '+token}))).json();
 assert.equal(r.result.isError,true);assert.match(r.result.content[0].text,/AUTH_REQUIRED/);assert.equal(mock.seen.length,0);
});
test('oversized remote receipt blocks as uncertain without retry',async t=>{
 const {rt,mock}=await rig(t,{mutate:(o,p)=>p.phase==='dispatch'?{...o,padding:'x'.repeat(130000)}:o});
 const r=await run(rt);assert.equal(r.status,'BLOCKED_UNCERTAIN');assert.equal(mock.seen.length,2);
});
test('raw export requires correct owner just like result collection',async t=>{
 const {rt,store,mock}=await rig(t);const j=await rt.start('owner','export-owner');
 await store.create('tokens',await sha(token),{owner:'different-owner',enabled:true});
 const r=await(await createHandler(store,mock.provider)(req('export_dual16_evidence',{job_id:j.job_id},{authorization:'Bearer '+token}))).json();
 assert.equal(r.result.isError,true);assert.match(r.result.content[0].text,/NOT_FOUND/);
});
