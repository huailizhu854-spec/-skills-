#!/usr/bin/env node
/** Explicit bounded client; never retries an ambiguous external-model dispatch. Node >=22. */
import {randomUUID} from 'node:crypto';
import {readLimited} from '../src/core.mjs';
const argv=process.argv.slice(2);
if(argv.includes('--help')){
 console.log(`Usage (run from bridge-rc7):
  node --env-file=client.env scripts/probe.mjs --check
  node --env-file=client.env scripts/probe.mjs --run
  node --env-file=client.env scripts/probe.mjs --resume JOB_ID

--check performs no inference; --run explicitly requests the complete greeting probe.
Set AGI_MCP_URL and AGI_BRIDGE_KEY in client.env. Model keys stay in Supabase Secrets.
Never retry an uncertain provider dispatch blindly. This client does not prove native ChatGPT agents.`);
 process.exit(0);
}
const endpoint=process.env.AGI_MCP_URL;
const key=process.env.AGI_BRIDGE_KEY;
let rpcId=0;
async function rpc(method,params,authenticated=false){
 const url=new URL(endpoint??'');
 if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash)throw new Error('Set a valid HTTPS AGI_MCP_URL without credentials or query parameters.');
 if(authenticated&&!/^agi_[A-Za-z0-9_-]{40,120}$/.test(key??''))throw new Error('Set the dedicated AGI_BRIDGE_KEY in client.env. Do not use a model API key.');
 const response=await fetch(url,{method:'POST',redirect:'error',signal:AbortSignal.timeout(105000),
  headers:{'content-type':'application/json',accept:'application/json, text/event-stream','mcp-protocol-version':'2025-11-25',...(authenticated?{authorization:'Bearer '+key}:{})},
  body:JSON.stringify({jsonrpc:'2.0',id:++rpcId,method,params})});
 if(!response.ok)throw new Error('HTTP_'+response.status);
 const data=JSON.parse(await readLimited(response,1900000));
 if(data.error)throw new Error('MCP_PROTOCOL_ERROR');
 return data.result;
}
async function tool(name,args={},authenticated=true){
 const result=await rpc('tools/call',{name,arguments:args},authenticated);
 const data=JSON.parse(result.content[0].text);
 if(result.isError)throw new Error(data.error??'MCP_TOOL_ERROR');return data;
}
try{
 await rpc('initialize',{protocolVersion:'2025-11-25',capabilities:{},clientInfo:{name:'dual16-rc7-probe',version:'3.4.0-rc.7'}});
 const info=await tool('runtime_info',{},false);
 console.log(JSON.stringify(info,null,2));
 if(!argv.includes('--run')&&!argv.includes('--resume'))process.exit(0);
 if(!info.provider.ready)throw new Error('BLOCKED_CONFIG: configure the operator-approved zero-spend model provider first.');
 let state;
 if(argv.includes('--resume')){
  const job=argv[argv.indexOf('--resume')+1];state=await tool('get_dual16_status',{job_id:job});
 }else state=await tool('start_dual16',{idempotency_key:'cli-'+randomUUID()});
 for(let phase=0;phase<8&&state.status==='READY';phase++){
  console.log(JSON.stringify({job_id:state.job_id,phase:state.phase,status:state.status}));
  state=await tool('advance_dual16',{job_id:state.job_id});
 }
 console.log(JSON.stringify(state,null,2));
 if(state.status!=='COMPLETED')throw new Error('JOB_NOT_COMPLETE: preserve the job_id and inspect its state; no automatic replay.');
 const result=await tool('collect_dual16_results',{job_id:state.job_id});
 if(!result.verified||result.execution_kind!=='external_model_api'||result.greetings.length!==16)throw new Error('ACCEPTANCE_NOT_MET');
 for(const reply of result.greetings)console.log(`${reply.slot}: ${reply.text} [provider_response_id=${reply.provider_response_id}]`);
 console.log('18 app-managed contexts; 16 collected worker replies. Native ChatGPT sessions and provider-side simultaneous inference are NOT claimed.');
}catch(e){console.error(e.message);process.exitCode=1;}
