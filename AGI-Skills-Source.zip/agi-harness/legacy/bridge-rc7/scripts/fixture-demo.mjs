#!/usr/bin/env node
/** Offline HTTP protocol fixture ONLY. Not a real model or native-agent acceptance test. */
import {writeFile,mkdir} from 'node:fs/promises';
import {Runtime} from '../src/core.mjs';
import {MemoryStore,mockHTTP} from '../tests/helpers.mjs';
const mock=await mockHTTP({barrier:true});
const store=new MemoryStore(),rt=new Runtime(store,mock.provider),transitions=[];
try{
 let s=await rt.start('fixture-demo','fixture-demo-unique');transitions.push(s);
 for(let i=0;i<8&&s.status==='READY';i++){s=await rt.advance(s.job_id,'fixture-demo');transitions.push(s);}
 const result=await rt.collect(s.job_id,'fixture-demo');
 if(s.status!=='COMPLETED'||result.greetings.length!==16)throw new Error('Fixture flow incomplete.');
 const report={test_kind:'offline_http_fixture',real_model_calls:0,native_agent_calls:0,
  peak_overlapping_http_requests:mock.peak,actual_loopback_http_requests:mock.seen.length,
  simultaneous_model_inference_proven:false,transitions,result,
  ledger:(await store.get('jobs',s.job_id)).value};
 const out=new URL('../reports/fixture-demo.json',import.meta.url);await mkdir(new URL('../reports/',import.meta.url),{recursive:true});
 await writeFile(out,JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({test_kind:report.test_kind,status:s.status,contexts:result.contexts_prepared,
  loopback_requests:mock.seen.length,peak_http_overlap:mock.peak,greetings:result.greetings.length,real_model_calls:0}));
}finally{await mock.close();}
