from __future__ import annotations
import copy
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stdout, redirect_stderr
from pathlib import Path
from unittest.mock import patch

from agi_harness.common import ROOT, HarnessError, canonical, parse, read, write, digest, file_map, sha_bytes
from agi_harness.contracts import roster, group, opposite, decode
from agi_harness.benchmark import tasks, public_input, grade_artifact, output_name, verify_benchmark, json_equal, BENCHMARK
from agi_harness.providers import FixtureProvider, HTTPProvider
from agi_harness.runtime import run, EpisodeRunner
from agi_harness.evaluation import evaluate, grade_episode, verify_seal
from agi_harness.metrics import compare, aggregate, quantile
from agi_harness.safe_expr import Predicate
from agi_harness.cli import main
from agi_harness.rl_lab import experiment, feature, train_policy, probs

class ContractsTests(unittest.TestCase):
    def test_dual16_exact_roster(self):
        r=roster('dual16');self.assertEqual(len(r['controllers'])+len(r['workers']),18)
        self.assertEqual([len(group(r,c)) for c in r['controllers']],[8,8])
        self.assertEqual(len(set(r['responsibilities'].values())),16)
    def test_dual8_is_two_by_four(self):
        r=roster('dual8');self.assertEqual([len(group(r,c)) for c in r['controllers']],[4,4])
    def test_single_is_one_context(self):
        r=roster('single');self.assertEqual(r['controllers'],[]);self.assertEqual(r['workers'],['w01'])
    def test_unknown_architecture_blocks(self):
        with self.assertRaises(HarnessError):roster('dual32')
    def test_duplicate_json_keys_rejected(self):
        with self.assertRaises(HarnessError):parse('{"x":1,"x":2}')
    def test_nonfinite_json_rejected(self):
        for text in ['NaN','Infinity','-Infinity']:
            with self.subTest(text=text),self.assertRaises(HarnessError):parse(text)
    def test_exponent_overflow_rejected(self):
        for text in ['1e309','-1e309','{"value":1e9999}']:
            with self.subTest(text=text),self.assertRaises(HarnessError):parse(text)
    def test_large_sealed_evidence_read_with_explicit_limit(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'trace.json';write(p,{'text':'x'*2_000_100})
            self.assertEqual(len(read(p)['text']),2_000_100)
            with self.assertRaises(HarnessError):parse(p.read_text())
    def test_boolean_not_numeric(self):
        self.assertFalse(json_equal(True,1));self.assertFalse(json_equal({'v':True},{'v':1}))
    def test_numeric_equivalence(self):self.assertTrue(json_equal({'v':10},{'v':10.0}))
    def test_no_json_file_path_escape(self):
        result=grade_artifact('tb001_csv_summary',{'../output.json':'{}'})
        self.assertFalse(result['passed'])
    def test_freeze_detects_content_drift(self):
        with tempfile.TemporaryDirectory() as t:
            b=Path(t)/'b';shutil.copytree(BENCHMARK,b)
            (b/'tasks/tb001_csv_summary/public/input.csv').write_text('tamper')
            with self.assertRaises(HarnessError):verify_benchmark(b)
    def test_frozen_benchmark_verifies(self):self.assertEqual(len(verify_benchmark()),64)

class SafeGraderTests(unittest.TestCase):
    def test_all_six_public_fixture_solutions(self):
        for t in tasks():
            with self.subTest(task=t['id']):
                data=FixtureProvider.solve(t['id'],public_input(t))
                self.assertTrue(grade_artifact(t['id'],{output_name(t['id']):data})['passed'])
    def test_untouched_inputs_all_rejected(self):
        for t in tasks():
            public=public_input(t);name=output_name(t['id'])
            with self.subTest(task=t['id']):self.assertFalse(grade_artifact(t['id'],{name:public[name]} if name in public else {})['passed'])
    def test_imports_never_execute(self):
        source='import os\nos.system("false")\ndef should_retry(status, uncertain, attempts, max_attempts=2): return True'
        self.assertEqual(grade_artifact('tb005_retry_safety',{'retry.py':source})['code'],'GRADER.UNSUPPORTED_PROGRAM')
    def test_calls_never_execute(self):
        src='def within_budget(cost_usd, latency_ms, max_cost_usd, max_latency_ms): return __import__("os").getcwd()'
        self.assertFalse(grade_artifact('tb006_budget_gate',{'budget.py':src})['passed'])
    def test_dynamic_annotation_rejected(self):
        src='def within_budget(cost_usd: print("NO"), latency_ms, max_cost_usd, max_latency_ms): return True'
        self.assertFalse(grade_artifact('tb006_budget_gate',{'budget.py':src})['passed'])
    def test_signature_changes_rejected(self):
        src='def should_retry(status, uncertain, attempts, max_attempts=3): return False'
        self.assertEqual(grade_artifact('tb005_retry_safety',{'retry.py':src})['code'],'GRADER.SIGNATURE_CHANGED')
    def test_original_oracles_work_without_exec(self):
        for task in ('tb005_retry_safety','tb006_budget_gate'):
            name=output_name(task);src=(BENCHMARK/'tasks'/task/'oracle/solution'/name).read_text()
            self.assertTrue(grade_artifact(task,{name:src})['passed'])
    def test_loops_rejected(self):
        src='def should_retry(status, uncertain, attempts, max_attempts=2):\n while True: pass'
        self.assertFalse(grade_artifact('tb005_retry_safety',{'retry.py':src})['passed'])
    def test_all_true_is_not_passing(self):
        src='def within_budget(cost_usd, latency_ms, max_cost_usd, max_latency_ms): return True'
        self.assertGreater(grade_artifact('tb006_budget_gate',{'budget.py':src})['failed_checks'],0)
    def test_and_returns_operand_not_bool(self):
        src='def within_budget(cost_usd, latency_ms, max_cost_usd, max_latency_ms): return (cost_usd <= max_cost_usd and latency_ms <= max_latency_ms and 1) or False'
        self.assertFalse(grade_artifact('tb006_budget_gate',{'budget.py':src})['passed'])
    def test_strict_json_nan_rejected(self):
        self.assertFalse(grade_artifact('tb001_csv_summary',{'output.json':'{"rows":NaN}'})['passed'])

class RuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.path=Path(cls.tmp.name)/'matrix'
        cls.provider=FixtureProvider()
        run(cls.provider,cls.path,['single','dual8','dual16'],1,experimental=True)
        cls.evaluation=evaluate(cls.path)
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def test_all_architectures_all_tasks(self):
        self.assertEqual(len(self.evaluation['rows']),18)
        self.assertTrue(all(r['verified_success'] for r in self.evaluation['rows']))
    def test_actual_request_counts(self):
        for r in self.evaluation['rows']:
            self.assertEqual(r['calls_attempted'],{'single':1,'dual8':12,'dual16':20}[r['architecture']])
    def test_full_context_counts(self):
        for r in self.evaluation['rows']:
            self.assertEqual(r['validated_contexts'],{'single':1,'dual8':10,'dual16':18}[r['architecture']])
    def test_fixture_does_not_claim_model_or_cost(self):
        for r in self.evaluation['rows']:
            self.assertEqual(r['real_model_calls'],0);self.assertIsNone(r['estimated_cost_usd']);self.assertIsNone(r['input_tokens'])
    def test_replay_no_network_and_identical(self):
        with patch('urllib.request.OpenerDirector.open',side_effect=AssertionError('network')):
            second=evaluate(self.path)
        self.assertEqual(second,self.evaluation)
    def test_grading_does_not_modify_raw_artifacts(self):
        before=file_map(self.path);evaluate(self.path);self.assertEqual(file_map(self.path),before)
    def test_empty_trace_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);write(d/'trace.json',{})
            c=read(self.path/'run.json');unit=c['plan'][0]
            result=grade_episode(d,c,unit)
            self.assertFalse(result['verified_success']);self.assertIn('EVIDENCE.EMPTY_OR_INVALID_TRACE',result['failures'])
    def test_tampered_raw_bytes_fail_seal(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'x';shutil.copytree(self.path,d)
            ep=next((d/'episodes').iterdir());t=read(ep/'trace.json');t['calls'][0]['raw_response']='{}';write(ep/'trace.json',t)
            with self.assertRaises(HarnessError):evaluate(d)
    def test_resealed_bad_raw_hash_still_fails_grader(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'x';shutil.copytree(self.path,d)
            c=read(d/'run.json');unit=c['plan'][0];ep=d/'episodes'/unit['episode_id'];t=read(ep/'trace.json')
            t['calls'][0]['raw_response']='{}';write(ep/'trace.json',t)
            result=grade_episode(ep,c,unit)
            self.assertFalse(result['verified_success'])
    def test_unexpected_artifact_fails_seal(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'x';shutil.copytree(self.path,d)
            (next((d/'episodes').iterdir())/'artifacts/extra').write_text('NO')
            with self.assertRaises(HarnessError):evaluate(d)
    def test_same_output_directory_never_reexecutes(self):
        with self.assertRaises(HarnessError):run(FixtureProvider(),self.path)
    def test_baseline_requires_explicit_opt_in(self):
        with tempfile.TemporaryDirectory() as td,self.assertRaises(HarnessError):run(FixtureProvider(),Path(td)/'x',['single'])
    def test_oracle_not_in_agent_input(self):
        for ep in (self.path/'episodes').iterdir():
            for c in read(ep/'trace.json')['calls']:
                self.assertFalse(any('oracle' in k for k in c['request']['public_files']))
                self.assertNotIn('test_retry.py',canonical(c['request']))
    def test_request_budget_stops_dispatch(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'x';run(FixtureProvider(),d,only=['tb001_csv_summary'],max_requests=2)
            row=evaluate(d)['rows'][0]
            self.assertFalse(row['verified_success']);self.assertEqual(row['calls_attempted'],2)
    def test_missing_model_config_is_preflight_not_success(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'x'
            with self.assertRaises(HarnessError):run(HTTPProvider(env={}),d)
            self.assertFalse(d.exists())
    def test_journal_intent_before_receipt(self):
        for ep in (self.path/'episodes').iterdir():
            seen=set()
            for line in (ep/'events.jsonl').read_text().splitlines():
                e=parse(line)
                if e['kind']=='DISPATCH_INTENT':seen.add(e['payload']['request_id'])
                if e['kind']=='RESPONSE':self.assertIn(e['payload']['request_id'],seen)
    def test_artifact_symlink_blocks(self):
        if os.name=='nt':self.skipTest('requires symlink permission')
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'x';shutil.copytree(self.path,d)
            ep=next((d/'episodes').iterdir());p=next((ep/'artifacts').iterdir());p.unlink();p.symlink_to('/etc/hostname')
            with self.assertRaises(HarnessError):evaluate(d)

class FailureTests(unittest.TestCase):
    def probe(self,fault):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'run';run(FixtureProvider(fault),d,only=['tb001_csv_summary'])
            e=evaluate(d);c=read(d/'run.json');t=read(d/'episodes'/c['plan'][0]['episode_id']/'trace.json')
            return e['rows'][0],t
    def test_stale_nonce(self):
        row,t=self.probe('stale_nonce');self.assertFalse(row['verified_success']);self.assertIn('EVIDENCE.STALE_NONCE',row['failures'])
    def test_wrong_review_hash(self):
        row,t=self.probe('bad_hash_review');self.assertFalse(row['verified_success']);self.assertIn('VERIFY.STALE_HASH',row['failures'])
    def test_wrong_group(self):
        row,t=self.probe('wrong_group');self.assertFalse(row['verified_success']);self.assertIn('DELEGATION.WRONG_CONTROLLER',row['failures'])
    def test_false_success_is_caught_by_task_grader(self):
        row,t=self.probe('incorrect_output');self.assertFalse(row['verified_success']);self.assertTrue(row['false_success']);self.assertIn('TASK.INCORRECT_OUTPUT',row['failures'])
    def test_ownership_escape(self):
        row,t=self.probe('ownership_escape');self.assertFalse(row['verified_success']);self.assertIn('ARTIFACT.OUTSIDE_OWNERSHIP',row['failures'])
    def test_duplicate_id(self):
        row,t=self.probe('duplicate_id');self.assertFalse(row['verified_success']);self.assertIn('EXEC.DUPLICATE_PROVIDER_RESPONSE',row['failures'])
    def test_timeout_never_blindly_retries(self):
        row,t=self.probe('timeout_uncertain');self.assertFalse(row['verified_success'])
        self.assertEqual(sum(c['request']['slot']=='w01' for c in t['calls']),1)
    def test_local_repair_same_context_only_one_worker(self):
        row,t=self.probe('repair_once');self.assertTrue(row['verified_success']);self.assertFalse(row['first_pass_success'])
        self.assertEqual(row['calls_attempted'],21)
        calls=[c for c in t['calls'] if c['request']['slot']=='w07']
        self.assertEqual(len(calls),2);self.assertEqual(len({c['context_id'] for c in calls}),1)
        self.assertEqual(row['extra_attempts'],1)
    def test_empty_receipt_not_success(self):
        row,t=self.probe('empty_receipt');self.assertFalse(row['verified_success'])

class MetricsTests(unittest.TestCase):
    def row(self,ok=True,cost=None,lat=10,arch='single',task='t',rep=0):
        return dict(architecture=arch,task_id=task,repetition=rep,seed=7,execution_kind='external_model_api',
                    verified_success=ok,first_pass_success=ok,declared_success=True,false_success=not ok,
                    extra_attempts=0,latency_ms=lat,estimated_cost_usd=cost,real_model_calls=1,calls_attempted=1,failures=[])
    def test_failed_cost_included(self):
        m=aggregate([self.row(True,.2),self.row(False,.3)])['single'];self.assertEqual(m['estimated_cost_per_verified_success_usd'],.5)
    def test_unknown_cost_stays_null(self):
        m=aggregate([self.row(True,.2),self.row(False,None)])['single'];self.assertIsNone(m['estimated_total_cost_usd']);self.assertEqual(m['cost_coverage'],.5)
    def test_zero_success_ratio_is_null(self):
        self.assertIsNone(aggregate([self.row(False,.3)])['single']['estimated_cost_per_verified_success_usd'])
    def test_latency_includes_failures(self):
        m=aggregate([self.row(True,lat=10),self.row(False,lat=100)])['single'];self.assertEqual(m['latency_p50_ms'],55)
    def test_percentile_definition(self):self.assertEqual(quantile([0,100],.95),95)
    def test_compatible_comparison_and_small_cluster_warning(self):
        base={k:'same' for k in ['benchmark_id','benchmark_hash','grader_version','protocol_hash','execution_kind','provider','limits','rate_card']}
        base['rows']=[self.row(arch='single'),self.row(arch='dual16')]
        c=compare([base]);self.assertEqual(c['paired_differences']['dual16']['success_rate_difference'],0)
    def test_mixed_execution_rejected(self):
        base={k:'same' for k in ['benchmark_id','benchmark_hash','grader_version','protocol_hash','execution_kind','provider','limits','rate_card']};base['rows']=[self.row()]
        b=copy.deepcopy(base);b['execution_kind']='fixture'
        with self.assertRaises(HarnessError):compare([base,b])
    def test_unpaired_population_rejected(self):
        base={k:'same' for k in ['benchmark_id','benchmark_hash','grader_version','protocol_hash','execution_kind','provider','limits','rate_card']};base['rows']=[self.row(),self.row(arch='dual16',task='other')]
        with self.assertRaises(HarnessError):compare([base])
    def test_duplicate_runs_rejected(self):
        base={k:'same' for k in ['benchmark_id','benchmark_hash','grader_version','protocol_hash','execution_kind','provider','limits','rate_card']};base['rows']=[self.row()]
        with self.assertRaises(HarnessError):compare([base,base])

class RLTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.result=experiment([7],steps=60)
    def test_no_human_feedback_or_llm_claims(self):
        self.assertFalse(self.result['is_human_feedback']);self.assertFalse(self.result['is_llm_weight_training'])
    def test_split_disjoint_by_task(self):
        self.assertFalse(set(self.result['train_task_ids']) & set(self.result['test_task_ids']))
    def test_same_heldout_population(self):
        r=self.result['results'][0];self.assertEqual(r['uniform_test']['tasks'],r['learned_test']['tasks'])
    def test_conditioned_policy_not_one_global_vector(self):
        ps=list(self.result['results'][0]['test_case_probabilities'].values())
        self.assertTrue(any(p!=ps[0] for p in ps[1:]))
    def test_production_dual16_unchanged(self):self.assertFalse(self.result['production_routing_changed'])
    def test_seed_reproduces_policy(self):
        self.assertEqual(experiment([7],steps=60)['results'][0],self.result['results'][0])

class CLITests(unittest.TestCase):
    def test_core_five_commands(self):
        with tempfile.TemporaryDirectory() as td,redirect_stdout(io.StringIO()),redirect_stderr(io.StringIO()):
            d=Path(td)/'run';out=Path(td)/'compare.json';report=Path(td)/'report.md'
            self.assertEqual(main(['run','--out',str(d),'--tasks','tb001_csv_summary']),0)
            self.assertEqual(main(['eval',str(d)]),0)
            self.assertEqual(main(['replay',str(d)]),0)
            self.assertEqual(main(['compare',str(d),'--out',str(out)]),0)
            self.assertEqual(main(['report',str(d),'--out',str(report)]),0)
            self.assertTrue(report.with_suffix('.html').is_file())
    def test_bad_live_preflight_exit_code(self):
        with tempfile.TemporaryDirectory() as td,redirect_stdout(io.StringIO()),redirect_stderr(io.StringIO()):
            self.assertEqual(main(['run','--provider','http','--out',str(Path(td)/'x')]),2)
    def test_eval_failure_exit_code(self):
        with tempfile.TemporaryDirectory() as td,redirect_stdout(io.StringIO()),redirect_stderr(io.StringIO()):
            d=Path(td)/'x';main(['run','--out',str(d),'--fault','incorrect_output','--tasks','tb001_csv_summary'])
            self.assertEqual(main(['eval',str(d)]),1)

if __name__=='__main__':unittest.main()
