from __future__ import annotations
import json
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from agi_harness.providers import HTTPProvider,FixtureProvider
from agi_harness.common import HarnessError,parse,canonical,read
from agi_harness.runtime import run
from agi_harness.evaluation import evaluate

class HTTPFixtureAdapter(HTTPProvider):
    kind='fixture_http'  # Keep transport simulation out of real model metrics.

class LocalHandler(BaseHTTPRequestHandler):
    def log_message(self,*a):pass
    def do_POST(self):
        payload=parse(self.rfile.read(int(self.headers['Content-Length'])).decode())
        packet=parse(payload['messages'][-1]['content'])
        code=self.server.reply_code
        if code==302:
            self.send_response(302);self.send_header('Location','http://127.0.0.1:9/not-allowed');self.end_headers();return
        if code!=200:
            self.send_response(code);self.end_headers();self.wfile.write(b'secret-upstream-error-do-not-leak');return
        reply=FixtureProvider().invoke(packet,[])['raw']
        b=parse(reply);b['usage']={'prompt_tokens':100,'completion_tokens':20}
        data=canonical(b).encode()
        self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)

class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),LocalHandler);cls.server.reply_code=200
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()
    def setUp(self):self.server.reply_code=200
    def adapter(self,**overrides):
        env={'AGI_MODEL_BASE_URL':f'http://127.0.0.1:{self.server.server_port}/v1','AGI_MODEL_NAME':'local-fixture-not-model',
             'AGI_MODEL_ALLOWED_HOST':'127.0.0.1','AGI_TRANSPORT_AUTHORIZED':'true','AGI_ZERO_COST_CONFIRMED':'true'}
        env.update(overrides)
        return HTTPFixtureAdapter(allow_live=True,allow_local=True,env=env)
    def packet(self):
        return {'slot':'w01','phase':'implement','task_id':'tb001_csv_summary','nonce':'test-nonce','request_id':'test-request',
                'output_name':'output.json','public_files':{'input.csv':'id,amount\na,10\nb,15\nc,5\n'},'attempt':1}
    def test_preflight_no_model_calls(self):self.assertEqual(self.adapter().preflight()['model_calls'],0)
    def test_real_http_fixture_pipeline(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'r';run(self.adapter(),d,only=['tb001_csv_summary'])
            e=evaluate(d);self.assertTrue(e['rows'][0]['verified_success']);self.assertEqual(e['rows'][0]['calls_attempted'],20)
            self.assertEqual(e['execution_kind'],'fixture_http');self.assertEqual(e['rows'][0]['real_model_calls'],0)
    def test_api_key_not_saved(self):
        secret='local-fixture-private-placeholder-not-real'
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'r';run(self.adapter(AGI_MODEL_API_KEY=secret),d,only=['tb001_csv_summary'])
            for p in d.rglob('*'):
                if p.is_file():self.assertNotIn(secret,p.read_text())
    def test_429_is_not_hidden_retry(self):
        self.server.reply_code=429
        with self.assertRaisesRegex(HarnessError,'PROVIDER.HTTP_429'):self.adapter().invoke(self.packet(),[])
    def test_5xx_is_uncertain(self):
        self.server.reply_code=503
        with self.assertRaisesRegex(HarnessError,'EXEC.TIMEOUT_UNCERTAIN'):self.adapter().invoke(self.packet(),[])
    def test_upstream_error_body_not_leaked(self):
        self.server.reply_code=401
        try:self.adapter().invoke(self.packet(),[])
        except HarnessError as e:self.assertNotIn('secret',str(e))
    def test_redirect_rejected(self):
        self.server.reply_code=302
        with self.assertRaisesRegex(HarnessError,'PROVIDER.REDIRECT_REJECTED'):self.adapter().invoke(self.packet(),[])
    def test_host_allowlist_enforced(self):
        with self.assertRaisesRegex(HarnessError,'CONFIG.HOST_NOT_ALLOWED'):self.adapter(AGI_MODEL_ALLOWED_HOST='other.example').preflight()
    def test_query_secrets_rejected(self):
        with self.assertRaisesRegex(HarnessError,'CONFIG.INVALID_URL'):self.adapter(AGI_MODEL_BASE_URL='http://127.0.0.1/v1?key=bad').preflight()
    def test_free_cost_confirmation_not_assumed(self):
        with self.assertRaisesRegex(HarnessError,'CONFIG.ZERO_COST_NOT_CONFIRMED'):self.adapter(AGI_ZERO_COST_CONFIRMED='false').preflight()
    def test_transport_permission_not_assumed(self):
        with self.assertRaisesRegex(HarnessError,'CONFIG.TRANSPORT_NOT_AUTHORIZED'):self.adapter(AGI_TRANSPORT_AUTHORIZED='false').preflight()
    def test_native_delegation_not_exposed(self):self.assertFalse(hasattr(self.adapter(),'spawn_native_agent'))

if __name__=='__main__':unittest.main()
