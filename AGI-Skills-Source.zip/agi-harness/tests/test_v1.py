from __future__ import annotations
import asyncio
import contextlib
import copy
import io
import json
import os
import tempfile
import threading
import unittest
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from agi_harness.ablation import controls_for, validate_controls, replay_injection_study, VARIANTS
from agi_harness.benchmark import tasks, verify_benchmark
from agi_harness.campaign import validate_probe, validate_population, controlled_ablation_comparison, run_stage
from agi_harness.cli import main
from agi_harness.common import HarnessError, canonical, parse, read
from agi_harness.evaluation import evaluate
from agi_harness.live_provider import Provider, StrictHTTPProvider, configuration_status, usage_fields
from agi_harness.live_router import experiment as routing_experiment
from agi_harness.metrics import aggregate, compare
from agi_harness.providers import FixtureProvider
from agi_harness.runtime import run
from agi_harness.security import scan
from agi_harness.statistics import distribution, wilson95
from agi_harness.telemetry import observe_trace


class HTTPFixture(StrictHTTPProvider):
    kind = "fixture_http"


class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_POST(self):
        payload=parse(self.rfile.read(int(self.headers["Content-Length"])).decode())
        self.server.calls+=1
        self.server.payloads.append(payload)
        if self.server.mode=="429":
            self.send_response(429);self.end_headers();self.wfile.write(b'{"error":"fixture rate limit"}');return
        if self.server.mode=="503":
            self.send_response(503);self.end_headers();self.wfile.write(b'{"error":"fixture unavailable"}');return
        if self.server.mode=="redirect":
            self.send_response(302);self.send_header("Location","http://127.0.0.1:9/forbidden");self.end_headers();return
        last=payload["messages"][-1]["content"]
        if last=="AGI_HEALTH_OK":
            body={"id":"http-fixture-"+str(uuid.uuid4()),"choices":[{"message":{"content":"AGI_HEALTH_OK"}}]}
        else:
            request=parse(last)
            body=parse(FixtureProvider().invoke(request,[])["raw"])
        body["model"]="wrong-fixture-model" if self.server.mode=="wrong_model" else payload["model"]
        body["choices"][0]["finish_reason"]="length" if self.server.mode=="length" else "stop"
        if self.server.mode!="no_usage":body["usage"]={"prompt_tokens":100,"completion_tokens":20,"total_tokens":120}
        if self.server.mode=="echo_secret":body["choices"][0]["message"]["content"]=self.server.secret
        data=canonical(body).encode()
        self.send_response(200);self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(data)));self.send_header("x-request-id","fixture-header-request")
        self.end_headers();self.wfile.write(data)


class LiveTransportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(("127.0.0.1",0),Handler)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()
    def setUp(self):
        self.server.mode="ok";self.server.calls=0;self.server.payloads=[];self.server.secret="unit-fixture-private-placeholder"
    def adapter(self,**overrides):
        env={"AGI_MODEL_BASE_URL":f"http://127.0.0.1:{self.server.server_port}/v1","AGI_MODEL_ALLOWED_HOST":"127.0.0.1",
             "AGI_MODEL_NAME":"approved-fixture-model","AGI_TRANSPORT_AUTHORIZED":"true","AGI_ZERO_COST_CONFIRMED":"true"}
        env.update(overrides)
        return HTTPFixture(allow_live=True,allow_local=True,env=env)
    def packet(self):
        return {"slot":"w01","phase":"implement","task_id":"tb001_csv_summary","nonce":"fixture-nonce",
                "request_id":"fixture-request","attempt":1,"output_name":"output.json",
                "public_files":{"input.csv":"id,amount\na,10\nb,15\nc,5\n"}}
    def test_async_contract_is_structural(self):self.assertIsInstance(self.adapter(),Provider)
    def test_health_is_actual_loopback_http_not_live_model(self):
        p=self.adapter();record=asyncio.run(p.health());self.assertEqual(record["status"],"PASS")
        self.assertEqual(record["execution_kind"],"fixture_http");self.assertEqual(record["real_model_calls"],0)
        self.assertEqual(self.server.calls,1)
    def test_generate_requires_health_before_send(self):
        with self.assertRaisesRegex(HarnessError,"HEALTH_REQUIRED"):asyncio.run(self.adapter().generate(self.packet(),[]))
        self.assertEqual(self.server.calls,0)
    def test_model_info_adds_no_call(self):
        p=self.adapter();p.health_sync();info=asyncio.run(p.model_info())
        self.assertEqual(info["observed_model"],p.model);self.assertEqual(self.server.calls,1)
    def test_wrong_health_model_blocks(self):
        self.server.mode="wrong_model";self.assertEqual(self.adapter().health_sync()["code"],"PROVIDER.MODEL_MISMATCH")
    def test_incomplete_health_finish_blocks(self):
        self.server.mode="length";self.assertEqual(self.adapter().health_sync()["code"],"PROVIDER.INCOMPLETE_FINISH")
    def test_missing_usage_unknown_not_zero(self):
        self.server.mode="no_usage";r=self.adapter().health_sync()
        self.assertEqual(r["status"],"PASS");self.assertIsNone(r["raw_evidence"]["telemetry"]["input_tokens"])
    def test_all_telemetry_fields_present(self):
        p=self.adapter();p.health_sync();reply=asyncio.run(p.generate(self.packet(),[]));t=reply["telemetry"]
        for field in ("request_id","provider_response_id","model","start_time","end_time","latency_ms","usage",
                      "input_tokens","output_tokens","finish_reason","http_status","retry_count","wire_request_sha256"):
            self.assertIn(field,t)
        self.assertEqual(t["http_status"],200);self.assertEqual(t["input_tokens"],100)
    def test_429_recorded_without_retry(self):
        p=self.adapter();p.health_sync();self.server.mode="429";before=self.server.calls
        r=p.invoke(self.packet(),[]);self.assertEqual(r["error_code"],"PROVIDER.HTTP_429")
        self.assertEqual(r["telemetry"]["http_status"],429);self.assertEqual(self.server.calls-before,1)
    def test_503_retains_latency_and_uncertainty(self):
        p=self.adapter();p.health_sync();self.server.mode="503";r=p.invoke(self.packet(),[])
        self.assertEqual(r["error_code"],"EXEC.TIMEOUT_UNCERTAIN");self.assertGreaterEqual(r["elapsed_ms"],0)
    def test_redirect_never_followed(self):
        self.server.mode="redirect";r=self.adapter().health_sync()
        self.assertEqual(r["code"],"PROVIDER.REDIRECT_REJECTED");self.assertEqual(self.server.calls,1)
    def test_key_echo_redacted_and_rejected(self):
        self.server.mode="echo_secret";p=self.adapter(AGI_MODEL_API_KEY=self.server.secret);r=p.health_sync()
        self.assertEqual(r["code"],"SECURITY.SECRET_ECHO");self.assertNotIn(self.server.secret,canonical(r))
    def test_secret_in_malformed_base_not_logged(self):
        secret=self.server.secret;p=self.adapter(AGI_MODEL_API_KEY=secret,AGI_MODEL_BASE_URL="https://"+secret+"@127.0.0.1/v1?key="+secret)
        self.assertNotIn(secret,canonical(p.health_sync()));self.assertEqual(self.server.calls,0)
    def test_config_drift_after_health_blocks(self):
        p=self.adapter();p.health_sync();p.model="unapproved"
        with self.assertRaisesRegex(HarnessError,"PROVIDER_DRIFT"):p.invoke(self.packet(),[])
        self.assertEqual(self.server.calls,1)
    def test_payload_sampling_explicit_and_frozen(self):
        p=self.adapter(AGI_MODEL_SEED="7",AGI_MODEL_TEMPERATURE="0.3");p.health_sync();p.invoke(self.packet(),[])
        self.assertEqual(self.server.payloads[-1]["seed"],7);self.assertEqual(self.server.payloads[-1]["temperature"],.3)
        self.assertEqual(p.metadata()["sampling_seed_honored"],"NOT_VERIFIED")
    def test_loopback_full_dual16_and_independent_replay(self):
        p=self.adapter();p.health_sync()
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"run";run(p,path,only=["tb001_csv_summary"])
            e=evaluate(path);self.assertTrue(e["rows"][0]["verified_success"])
            self.assertEqual(self.server.calls,21);self.assertEqual(e["rows"][0]["real_model_calls"],0)
            with patch.object(StrictHTTPProvider,"_send",side_effect=AssertionError("no replay network")):
                self.assertEqual(e,evaluate(path))
    def test_mid_run_wrong_model_is_independent_failure(self):
        p=self.adapter();p.health_sync();self.server.mode="wrong_model"
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"run";run(p,path,only=["tb001_csv_summary"]);e=evaluate(path)
            self.assertFalse(e["rows"][0]["verified_success"])
            self.assertIn("PROVIDER.MODEL_MISMATCH",e["rows"][0]["failures"])
    def test_no_secret_in_sealed_evidence(self):
        p=self.adapter(AGI_MODEL_API_KEY=self.server.secret);p.health_sync()
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"run";run(p,path,only=["tb001_csv_summary"])
            for f in path.rglob("*"):
                if f.is_file():self.assertNotIn(self.server.secret,f.read_text())


class WriteAttemptFixture(FixtureProvider):
    def invoke(self,request,history):
        response=super().invoke(request,history)
        if request["slot"]=="w02" and request["phase"]=="inspect":
            body=parse(response["raw"]);wrapper=parse(body["choices"][0]["message"]["content"])
            wrapper["result"]["files"]={"output.json":"{}"}
            body["choices"][0]["message"]["content"]=canonical(wrapper)
            response["raw"]=canonical(body)
        return response


class OperationalGuardTests(unittest.TestCase):
    def run_one(self,variant="full",provider=None):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        path=Path(tmp.name)/"run"
        run(provider or FixtureProvider(),path,only=["tb001_csv_summary"],ablation=variant,experimental_ablation=variant!="full")
        return path,evaluate(path)
    def test_production_controls_all_on(self):self.assertTrue(all(controls_for()[k] for k in ("cross_review","artifact_ownership","independent_grader","replay_protection")))
    def test_ablation_optin_required(self):
        with self.assertRaisesRegex(HarnessError,"EXPLICIT_OPT_IN"):controls_for("no_grader")
    def test_multiple_ablation_variables_blocked(self):
        c=controls_for("no_grader",experimental=True);c["cross_review"]=False
        with self.assertRaises(HarnessError):validate_controls(c)
    def test_cross_review_removed_but_sixteen_workers_remain(self):
        p,e=self.run_one("no_cross_review");self.assertTrue(e["rows"][0]["verified_success"])
        self.assertEqual(e["rows"][0]["calls_attempted"],18)
        t=read(next((p/"episodes").iterdir())/"trace.json")
        self.assertEqual(len({c["request"]["slot"] for c in t["calls"] if c["request"]["slot"].startswith("w")}),16)
    def test_runtime_grader_ablation_does_not_disable_shadow(self):
        _,e=self.run_one("no_grader",FixtureProvider("incorrect_output"));row=e["rows"][0]
        self.assertFalse(row["verified_success"]);self.assertTrue(row["operational_success"])
        self.assertTrue(row["false_success"]);self.assertTrue(row["shadow_grader_enabled"])
    def test_full_runtime_does_not_release_false_pass(self):
        _,e=self.run_one(provider=FixtureProvider("incorrect_output"));self.assertFalse(e["rows"][0]["operational_success"])
    def test_ownership_guard_blocks_actual_fixture_write_attempt(self):
        path,e=self.run_one(provider=WriteAttemptFixture());row=e["rows"][0]
        self.assertFalse(row["verified_success"]);self.assertTrue(row["artifact_conflict"])
        artifact=next((path/"episodes").iterdir())/"artifacts/output.json"
        self.assertNotEqual(artifact.read_text(),"{}")
    def test_ownership_ablated_allows_write_but_shadow_rejects(self):
        path,e=self.run_one("no_ownership",WriteAttemptFixture());row=e["rows"][0]
        self.assertFalse(row["verified_success"]);self.assertGreater(row["artifact_conflict_attempts"],0)
        artifact=next((path/"episodes").iterdir())/"artifacts/output.json"
        self.assertEqual(artifact.read_text(),"{}")
    def test_replay_ablation_cannot_fool_shadow_grader(self):
        _,e=self.run_one("no_replay_guard",FixtureProvider("stale_nonce"));row=e["rows"][0]
        self.assertFalse(row["verified_success"]);self.assertTrue(row["operational_accepted_before_shadow"])
        self.assertIn("EVIDENCE.STALE_NONCE",row["failures"])
    def test_uncertain_call_not_resent_even_under_ablation(self):
        path,e=self.run_one("no_replay_guard",FixtureProvider("timeout_uncertain"))
        t=read(next((path/"episodes").iterdir())/"trace.json")
        self.assertEqual(sum(c["request"]["slot"]=="w01" for c in t["calls"]),1)
    def test_ten_guard_component_injections(self):
        r=replay_injection_study();self.assertTrue(r["passed"]);self.assertEqual(len(r["rows"]),10)
        self.assertEqual(sum(not x["accepted"] for x in r["rows"] if x["guard_enabled"]),5)
    def test_probe_gate_rejects_fixture(self):
        path,_=self.run_one()
        with self.assertRaisesRegex(HarnessError,"FIXTURE_IS_NOT_LIVE"):validate_probe(path)
    def test_probe_identity_has_sixteen_workers_and_four_controller_responses(self):
        path,_=self.run_one();gate=validate_probe(path,require_live=False)
        self.assertEqual(gate["worker_responses"],16);self.assertEqual(gate["controller_responses"],4)
    def test_probe_does_not_cherry_pick_correct_answers(self):
        path,_=self.run_one(provider=FixtureProvider("incorrect_output"));gate=validate_probe(path,require_live=False)
        self.assertEqual(gate["status"],"PASS");self.assertEqual(gate["independent_grader"],"FAIL")
    def test_probe_duplicate_ids_block_even_with_operational_guard_disabled(self):
        path,_=self.run_one("no_replay_guard",FixtureProvider("duplicate_id"))
        with self.assertRaises(HarnessError):validate_probe(path,require_live=False)
    def test_all_five_ablation_arms_pair(self):
        evaluations=[self.run_one(v)[1] for v in VARIANTS]
        result=controlled_ablation_comparison(evaluations)
        self.assertEqual(len(result["rows"]),5);self.assertEqual(result["population"],"fixture")
    def test_standard_compare_rejects_ablation_mix(self):
        _,full=self.run_one();_,other=self.run_one("no_grader")
        with self.assertRaisesRegex(HarnessError,"INCOMPATIBLE_CONTROLS"):compare([full,other])
    def test_probe_run_is_not_a_six_task_pilot(self):
        path,_=self.run_one()
        with self.assertRaisesRegex(HarnessError,"POPULATION_INCOMPLETE"):validate_population(path,"pilot",require_live=False)
    def test_unique_run_and_episode_identity(self):
        path,e=self.run_one();cfg=read(path/"run.json");t=read(next((path/"episodes").iterdir())/"trace.json")
        self.assertEqual(t["identity"]["cohort_run_id"],cfg["run_id"])
        self.assertNotEqual(t["identity"]["run_id"],cfg["run_id"])
        self.assertTrue(t["identity"]["episode_uuid"]);self.assertTrue(t["start_time"]);self.assertTrue(t["end_time"])
    def test_replay_resolves_episode_run_id_locally(self):
        from agi_harness.replay import resolve
        path,ev=self.run_one();run_id=ev["rows"][0]["run_id"]
        resolved,selected=resolve(Path(run_id),path.parent)
        self.assertEqual(resolved,path);self.assertEqual(selected,run_id)
        output=io.StringIO()
        with contextlib.redirect_stdout(output):
            self.assertEqual(main(["replay",run_id,"--runs-root",str(path.parent)]),0)
        self.assertEqual(json.loads(output.getvalue())["replayed"],1)
    def test_grader_profiling_does_not_change_replay_result(self):
        path,ev=self.run_one();profile=[]
        self.assertEqual(evaluate(path,profile=profile),ev)
        self.assertEqual(len(profile),1);self.assertGreaterEqual(profile[0]["grader_latency_ms"],0)
    def test_interrupted_future_episodes_keep_unique_run_ids(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"run"
            run(FixtureProvider("timeout_uncertain"),path)
            cfg=read(path/"run.json");ev=evaluate(path)
            self.assertEqual(len({u["run_id"] for u in cfg["plan"]}),6)
            self.assertEqual(len({r["run_id"] for r in ev["rows"]}),6)
            self.assertEqual(sum(r["failures"]==["EXEC.NOT_COMPLETED"] for r in ev["rows"]),5)
    def test_episode_uuid_is_in_pre_dispatch_plan(self):
        path,ev=self.run_one()
        self.assertEqual(read(path/"run.json")["plan"][0]["run_id"],ev["rows"][0]["run_id"])
    def test_frozen_benchmark_digest_unchanged(self):
        self.assertEqual(verify_benchmark(),"15effcdf4484993a3f04b7e3c80f6268adaf2b108f42b1e022bb3278f3c66f80")


class MetricsAndRoutingTests(unittest.TestCase):
    def test_unknown_usage_is_not_zero(self):
        self.assertEqual(usage_fields({})["token_usage_status"],"unknown");self.assertIsNone(usage_fields({})["total_tokens"])
    def test_inconsistent_provider_total_marked_unknown(self):
        self.assertEqual(usage_fields({"usage":{"prompt_tokens":1,"completion_tokens":2,"total_tokens":100}})["token_usage_status"],"unknown")
    def test_boolean_token_counts_rejected(self):
        self.assertEqual(usage_fields({"usage":{"prompt_tokens":True,"completion_tokens":2}})["token_usage_status"],"unknown")
    def test_failure_call_latency_included_and_missing_disclosed(self):
        d=distribution([1,100,None]);self.assertEqual(d["n"],2);self.assertEqual(d["missing"],1)
        self.assertEqual(d["mean"],50.5);self.assertGreater(d["p95"],90)
    def test_success_ci_not_point_estimate(self):
        ci=wilson95(18,18);self.assertLess(ci[0],1);self.assertGreater(ci[0],.8);self.assertAlmostEqual(ci[1],1)
    def test_empty_success_ci_null(self):self.assertIsNone(wilson95(0,0))
    def test_full_trace_usage_not_truncated_by_protocol_failure(self):
        # Explicit in-memory metering fixture; never a stored live experiment.
        calls=[]
        for i in range(3):
            calls.append({"request":{"slot":"w01"},"raw_response":canonical({"id":str(i),"usage":{"prompt_tokens":10,"completion_tokens":2}}),"elapsed_ms":i+1,"telemetry":{}})
        r=observe_trace({"execution_kind":"external_model_api","calls":calls,"unit_test_fixture":True})
        self.assertEqual(r["input_tokens"],30);self.assertEqual(r["output_tokens"],6);self.assertIsNone(r["provider_cost_usd"])
    def test_full_trace_retry_count_does_not_depend_on_grade_stop(self):
        calls=[{"request":{"slot":"w01","phase":"implement"},"raw_response":None} for _ in range(2)]
        observed=observe_trace({"calls":calls,"execution_kind":"fixture"})
        self.assertEqual(observed["extra_attempts"],1)
    def test_live_router_rejects_fixture_population(self):
        with self.assertRaisesRegex(HarnessError,"REAL_DATA_REQUIRED"):routing_experiment({"execution_kind":"fixture"})
    def mock_envelope(self):
        rows=[]
        for t in tasks():
            for i,a in enumerate(("single","dual8","dual16")):
                for rep in range(3):
                    rows.append({"task_id":t["id"],"architecture":a,"repetition":rep,"seed":7+rep*10,
                        "verified_success":i>0,"first_pass_success":i>0,"false_success":i==0,"extra_attempts":0,
                        "artifact_conflict":False,"latency_ms":100*(i+1),"total_tokens":100*(i+1),"observed_model_responses":1})
        return {"execution_kind":"external_model_api","controls":{"variant":"full"},"rows":rows,
                "source_seal_sha256":"UNIT_TEST_MOCK_NOT_LIVE_EVIDENCE","unit_test_fixture":True}
    def test_router_math_with_explicit_in_memory_mock(self):
        r=routing_experiment(self.mock_envelope());self.assertEqual(len(r["baselines"]),5)
        self.assertEqual(r["dual16_strict"],"MASKED_NO_LIVE_ACTION_DATA");self.assertFalse(r["production_routing_changed"])
    def test_router_splits_disjoint_by_task(self):
        r=routing_experiment(self.mock_envelope());parts=[set(r[k]) for k in ("train_task_ids","validation_task_ids","held_out_test_task_ids")]
        self.assertFalse(parts[0]&parts[1] or parts[0]&parts[2] or parts[1]&parts[2])
        self.assertEqual([len(p) for p in parts],[3,1,2])
    def test_heldout_labels_cannot_change_fit(self):
        envelope=self.mock_envelope();a=routing_experiment(envelope)
        for row in envelope["rows"]:
            if row["task_id"] in a["held_out_test_task_ids"]:
                row["verified_success"]=not row["verified_success"];row["total_tokens"]*=100
        b=routing_experiment(envelope)
        self.assertEqual(a["weights"],b["weights"]);self.assertEqual(a["selected_ridge"],b["selected_ridge"])
    def test_missing_real_cost_proxy_blocks_router(self):
        e=self.mock_envelope();e["rows"][0]["total_tokens"]=None
        with self.assertRaisesRegex(HarnessError,"MEASURED_TOKEN_AND_LATENCY_REQUIRED"):routing_experiment(e)


class ConfigurationAndSecurityTests(unittest.TestCase):
    def test_empty_env_lists_missing_without_secret_values(self):
        r=configuration_status({});self.assertEqual(r["status"],"BLOCKED_CONFIG");self.assertEqual(len(r["missing_environment_variables"]),4)
    def test_live_doctor_fails_closed_without_network(self):
        with patch.dict(os.environ,{},clear=True),patch.object(StrictHTTPProvider,"_send",side_effect=AssertionError("no network")),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(main(["doctor","--live","--allow-live"]),2)
    def test_live_stage_no_secret_creates_only_blocker_evidence(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/"campaign";p=StrictHTTPProvider(allow_live=True,env={})
            with patch.object(p,"_send",side_effect=AssertionError("no network")):
                r=run_stage(p,root,"probe",request_ceiling=21)
            self.assertEqual(r["status"],"BLOCKED");self.assertEqual(r["real_runs_admitted"],0)
            self.assertFalse(list(root.rglob("run.json")));self.assertFalse((root/"campaign.json").exists())
    def test_pilot_cannot_skip_probe(self):
        with tempfile.TemporaryDirectory() as td:
            r=run_stage(StrictHTTPProvider(allow_live=True,env={}),Path(td)/"c","pilot",request_ceiling=121)
            self.assertEqual(r["code"],"GATE.PREVIOUS_STAGE_REQUIRED")
    def test_too_small_explicit_request_ceiling_blocks(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaisesRegex(HarnessError,"REQUEST_CEILING_REQUIRED"):
                run_stage(StrictHTTPProvider(env={}),Path(td)/"c","probe",request_ceiling=20)
    def test_raw_http_run_cannot_bypass_campaign(self):
        with tempfile.TemporaryDirectory() as td,contextlib.redirect_stderr(io.StringIO()):
            code=main(["run","--provider","http","--out",str(Path(td)/"x")])
            self.assertEqual(code,2)
    def test_env_secret_scan_does_not_print_value(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/".env").write_text("unit-test-placeholder")
            r=scan(root);self.assertEqual(r["status"],"FAIL");self.assertNotIn("unit-test-placeholder",canonical(r))
    def test_example_env_permitted(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/".env.example").write_text("AGI_MODEL_API_KEY=\n")
            self.assertEqual(scan(root)["status"],"PASS")
    def test_literal_configured_secret_scan(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/"log.txt").write_text("dummy-literal-private-value")
            self.assertEqual(scan(root,["dummy-literal-private-value"])["status"],"FAIL")
    def test_dynamic_python_not_allowed_in_active_grader(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);d=root/"agi_harness";d.mkdir();(d/"unsafe.py").write_text("eval('1+1')\n")
            self.assertEqual(scan(root)["status"],"FAIL")

if __name__=="__main__":unittest.main()
