---
name: agi-harness
description: Execute the evidence-first Dual16 benchmark with strict live-provider admission, independent grading, offline replay and explicit evidence populations.
---

Read README.md and docs/LIMITATIONS.md before running. Production is fixed at two controllers and sixteen workers; baselines and ablations are experimental only. This skill does not create native host subagent permissions.

Use `python -m agi_harness doctor` offline first. Only `live --stage probe|pilot|benchmark|ablation` may admit an external provider; require a user-approved exact provider/model/allowlist, local secret and verified supplier zero-spend cap. Never solicit a key in chat or send one to logs. No fallback and no blind uncertain transport retry.

Preserve all attempts, raw receipts, trace hashes, benchmark and grader versions. Compare only compatible paired cohorts. Replay by directory or episode UUID uses zero model calls and regrades current evidence, not cached success. The outer shadow evaluator stays enabled in all ablations, including no_grader.

Label fixture, fixture_http, external_model_api, component injection and synthetic-only policy results separately. A missing live provider means RELEASE=BLOCKED, not a simulated successful release. `rl --live-campaign` requires completed real benchmark and ablation; the default `rl` remains synthetic-only. Never claim model-weight training or native provider sessions without evidence.
