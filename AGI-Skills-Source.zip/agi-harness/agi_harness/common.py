from __future__ import annotations
import hashlib
import json
import math
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent

class HarnessError(Exception):
    """An actionable, non-secret failure code."""
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)

def need(condition: bool, code: str) -> None:
    if not condition:
        raise HarnessError(code)

def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)

def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()

def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def _pairs(pairs):
    obj = {}
    for key, value in pairs:
        need(key not in obj, "FORMAT.DUPLICATE_JSON_KEY")
        obj[key] = value
    return obj

def parse(text: str, *, max_chars: int = 2_000_000) -> Any:
    need(len(text) <= max_chars, "FORMAT.OVERSIZE")
    def invalid(_):
        raise HarnessError("FORMAT.NONFINITE")
    def finite_float(token):
        value = float(token)
        need(math.isfinite(value), "FORMAT.NONFINITE")
        return value
    try:
        return json.loads(text, object_pairs_hook=_pairs, parse_constant=invalid, parse_float=finite_float)
    except (ValueError, RecursionError) as exc:
        raise HarnessError("FORMAT.INVALID_JSON") from exc

def read(path: Path) -> Any:
    need(not path.is_symlink() and path.is_file(), "EVIDENCE.FILE_MISSING_OR_LINK")
    need(path.stat().st_size <= 30_000_000, "FORMAT.OVERSIZE")
    return parse(path.read_text(encoding="utf-8"), max_chars=30_000_000)

def write(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    # Caller creates a private run directory. Never write through a supplied symlink.
    need(not path.is_symlink() and not tmp.is_symlink(), "ARTIFACT.SYMLINK")
    with tmp.open("w", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)

def file_map(root: Path) -> dict[str, str]:
    result = {}
    for path in sorted(root.rglob("*")):
        need(not path.is_symlink(), "ARTIFACT.SYMLINK")
        if path.is_file() and "__pycache__" not in path.parts:
            result[path.relative_to(root).as_posix()] = sha_bytes(path.read_bytes())
    return result

def finite_nonnegative(value: Any) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and value >= 0
