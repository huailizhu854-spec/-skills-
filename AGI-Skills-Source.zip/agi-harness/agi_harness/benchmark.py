from __future__ import annotations
from pathlib import Path
from .common import ROOT, read, parse, file_map, need, digest, HarnessError
from .safe_expr import grade_predicate

BENCHMARK = ROOT / "benchmarks/software-smoke-v1.1"
BENCHMARK_ID = "software-smoke-v1.1"
GRADER_VERSION = "strict-receipts-and-task-v3"

def verify_benchmark(root: Path = BENCHMARK) -> str:
    manifest = read(root / "MANIFEST.json")
    actual = file_map(root)
    actual.pop("MANIFEST.json", None)
    need(manifest["files"] == actual, "BENCHMARK.HASH_MISMATCH")
    return digest(manifest)

def tasks():
    return [parse(s) for s in (BENCHMARK / "tasks.jsonl").read_text(encoding="utf-8").splitlines() if s.strip()]

def task_by_id(task_id):
    found = [t for t in tasks() if t["id"] == task_id]
    need(len(found) == 1, "BENCHMARK.UNKNOWN_TASK")
    return found[0]

def public_input(task: dict) -> dict[str, str]:
    d = BENCHMARK / task["task_dir"] / "public"
    return {p.name: p.read_text(encoding="utf-8") for p in sorted(d.iterdir()) if p.is_file()}

def output_name(task_id: str) -> str:
    if task_id.startswith("tb005"): return "retry.py"
    if task_id.startswith("tb006"): return "budget.py"
    return "output.json"

def json_equal(a, b):
    if type(a) is bool or type(b) is bool:
        return type(a) is type(b) and a == b
    if type(a) in (int, float) and type(b) in (int, float):
        return a == b
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return set(a) == set(b) and all(json_equal(a[k], b[k]) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(json_equal(x,y) for x,y in zip(a,b))
    return a == b


def grade_artifact(task_id: str, files: dict[str, str]) -> dict:
    task = task_by_id(task_id)
    try:
        name = output_name(task_id)
        need(isinstance(files, dict) and set(files) == {name}, "ARTIFACT.MISSING_OR_UNEXPECTED")
        need(isinstance(files[name], str), "FORMAT.INVALID_ARTIFACT")
        if name.endswith(".py"):
            return grade_predicate(task_id, files[name])
        actual = parse(files[name])
        expected = read(BENCHMARK / task["task_dir"] / "oracle/expected.json")
        # Preserve numeric equality (10 == 10.0), but never True == 1.
        passed = json_equal(actual, expected)
        return {"passed": passed, "checks": 1, "failed_checks": int(not passed),
                "code": None if passed else "TASK.INCORRECT_OUTPUT", "grader": "exact-json-v2"}
    except HarnessError as e:
        return {"passed": False, "checks": 0, "code": e.code, "grader": GRADER_VERSION}
