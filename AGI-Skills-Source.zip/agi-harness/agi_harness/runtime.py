from __future__ import annotations
import copy
import json
import os
import platform
import random
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from . import __version__
from .common import ROOT, canonical, digest, sha_bytes, read, write, file_map, need, HarnessError
from .benchmark import BENCHMARK_ID, GRADER_VERSION, verify_benchmark, tasks, public_input, output_name
from .contracts import roster, group, opposite, decode
from .ablation import controls_for, validate_controls, operational_decode
from .live_provider import utc_now

class Journal:
    def __init__(self, path: Path):
        self.path, self.head, self.seq = path, "0" * 64, 0
    def add(self, kind: str, payload: dict):
        e = {"seq": self.seq, "prev": self.head, "kind": kind, "payload": payload}
        e["hash"] = digest(e)
        with self.path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(canonical(e) + "\n"); f.flush(); os.fsync(f.fileno())
        self.seq += 1; self.head = e["hash"]


def protocol_fingerprint() -> str:
    # One protocol fingerprint for all architectures, including prompts, grader and provider code.
    items = {"agi_harness/" + p.name: sha_bytes(p.read_bytes()) for p in sorted((ROOT/"agi_harness").glob("*.py"))}
    items["prompts/system.txt"] = sha_bytes((ROOT/"prompts/system.txt").read_bytes())
    return digest(items)

class EpisodeRunner:
    def __init__(self, provider, task, architecture: str, path: Path, seed: int, limits: dict, controls=None, identity=None):
        self.provider, self.task, self.arch, self.path, self.seed, self.limits = provider, task, architecture, path, seed, limits
        self.controls = validate_controls(controls or controls_for())
        self.identity = identity or {}
        self.r = roster(architecture)
        self.path.mkdir(parents=True, exist_ok=False)
        (self.path/"artifacts").mkdir()
        self.journal = Journal(self.path/"events.jsonl")
        slots = self.r["controllers"] + self.r["workers"]
        self.histories = {slot: [] for slot in slots}
        self.nonces = set()
        self.latest, self.attempts, self.ids = {}, {}, set()
        self.begin = time.perf_counter_ns()
        self.trace = {"schema_version": 1, "task_id": task["id"], "architecture": architecture,
            "seed": seed, "execution_kind": provider.kind, "status": "RUNNING", "error": None,
            "context_ids": {s: str(uuid.uuid4()) for s in slots}, "calls": [], "diagnostics": [],
            "public_files": public_input(task), "limits": limits,
            "artifact_sha256": {}, "latency_ms": None, "journal_head": None,
            "controls": self.controls, "identity": self.identity, "artifact_events": [],
            "start_time": utc_now(), "end_time": None}
        self.journal.add("START", {"task_id": task["id"], "architecture": architecture, "execution_kind": provider.kind})
        self.save()
    def save(self):
        self.trace["journal_head"] = self.journal.head
        write(self.path/"trace.json", self.trace)
    def elapsed(self): return (time.perf_counter_ns()-self.begin)/1e6
    def packet(self, slot, phase, **extra):
        p = {"slot": slot, "phase": phase, "task_id": self.task["id"], "nonce": str(uuid.uuid4()),
             "request_id": str(uuid.uuid4()), "attempt": self.attempts.get((slot, phase), 0)+1,
             "public_files": self.trace["public_files"], "output_name": output_name(self.task["id"]),
             "required_wrapper": {"slot": slot, "nonce": "echo the request nonce", "result": "phase-specific object"}}
        p.update(extra)
        return p
    def batch(self, packets: list[dict]):
        pending = packets
        while pending:
            need(self.elapsed() <= self.limits["deadline_ms"], "LATENCY.SLO_BREACH")
            need(len(self.trace["calls"]) + len(pending) <= self.limits["max_requests"], "BUDGET.REQUEST_LIMIT")
            for p in pending:
                key = (p["slot"], p["phase"])
                self.attempts[key] = self.attempts.get(key, 0) + 1
                p["attempt"] = self.attempts[key]
                need(p["attempt"] <= self.limits["max_attempts"], "RECOVERY.RETRY_BUDGET_EXCEEDED")
                need(p["nonce"] not in self.nonces, "EVIDENCE.STALE_NONCE")
                self.nonces.add(p["nonce"])
                self.journal.add("DISPATCH_INTENT", {"request_id": p["request_id"], "slot": p["slot"],
                    "request_hash": digest(p), "context_id": self.trace["context_ids"][p["slot"]]})
            self.save()  # durable intent precedes provider calls
            def invoke(p):
                started, clock = utc_now(), time.perf_counter_ns()
                try:
                    reply = self.provider.invoke(p, copy.deepcopy(self.histories[p["slot"]]))
                    reply.setdefault("telemetry", {"request_id": p["request_id"], "start_time": started,
                        "end_time": utc_now(), "latency_ms": (time.perf_counter_ns()-clock)/1e6,
                        "http_status": None, "retry_count": p["attempt"]-1})
                    return reply, reply.get("error_code")
                except HarnessError as e:
                    return {"raw": None, "transport": self.provider.kind,
                        "elapsed_ms": (time.perf_counter_ns()-clock)/1e6,
                        "telemetry": {"request_id": p["request_id"], "start_time": started,
                        "end_time": utc_now(), "http_status": None, "retry_count": p["attempt"]-1}}, e.code
                except Exception:
                    return {"raw": None, "transport": self.provider.kind,
                        "elapsed_ms": (time.perf_counter_ns()-clock)/1e6,
                        "telemetry": {"request_id": p["request_id"], "start_time": started,
                        "end_time": utc_now(), "http_status": None, "retry_count": p["attempt"]-1}}, "PROVIDER.UNEXPECTED_FAILURE"
            with ThreadPoolExecutor(max_workers=min(self.limits["concurrency"], len(pending))) as pool:
                replies = list(pool.map(invoke, pending))
            retry, fatal = [], []
            for p, (reply, error) in zip(pending, replies):
                call = {"request": p, "request_hash": digest(p), "context_id": self.trace["context_ids"][p["slot"]],
                        "raw_response": None, "raw_sha256": None, "transport": self.provider.kind,
                        "elapsed_ms": None, "error": error, "valid_contract": False}
                if reply is not None:
                    call.update(raw_response=reply["raw"], raw_sha256=sha_bytes(reply["raw"].encode()) if reply["raw"] is not None else None,
                                transport=reply["transport"], elapsed_ms=reply["elapsed_ms"], telemetry=reply.get("telemetry"))
                    try:
                        need(not error, error or "PROVIDER.UNEXPECTED_FAILURE")
                        need(reply["raw"] is not None, "EVIDENCE.MISSING_RECEIPT")
                        body, result = operational_decode(p, reply["raw"], self.controls)
                        if self.provider.kind == "external_model_api" or getattr(self.provider, "requires_health_gate", False):
                            need(body.get("model") == self.provider.model, "PROVIDER.MODEL_MISMATCH")
                            need(body["choices"][0].get("finish_reason") == "stop", "PROVIDER.INCOMPLETE_FINISH")
                            need(reply.get("telemetry", {}).get("http_status") == 200, "PROVIDER.INVALID_HTTP_STATUS")
                        if self.controls["replay_protection"]:
                            need(body["id"] not in self.ids, "EXEC.DUPLICATE_PROVIDER_RESPONSE")
                        self.ids.add(body["id"])
                        call["valid_contract"] = True
                        self.latest[(p["slot"], p["phase"])] = {"result": result, "hash": digest(result), "response_id": body["id"]}
                    except HarnessError as e:
                        call["error"] = e.code
                    # Preserve raw response in the context only if it has readable model content.
                    try:
                        from .common import parse
                        content = parse(reply["raw"])["choices"][0]["message"]["content"]
                        if isinstance(content, str):
                            self.histories[p["slot"]] += [{"role":"user","content":canonical(p)}, {"role":"assistant","content":content}]
                    except (HarnessError, TypeError, KeyError, IndexError):
                        pass
                self.trace["calls"].append(call)
                self.journal.add("RESPONSE" if reply is not None and reply.get("raw") is not None else "TRANSPORT_ERROR", {
                    "request_id": p["request_id"], "call_hash": digest(call), "error": call["error"]})
                if call["error"]:
                    self.trace["diagnostics"].append({"slot":p["slot"],"code":call["error"]})
                    recoverable = call["error"] in ("EVIDENCE.STALE_NONCE", "EXEC.INVALID_OUTPUT", "FORMAT.INVALID_JSON")
                    if recoverable and p["attempt"] < self.limits["max_attempts"]:
                        nxt = copy.deepcopy(p); nxt.update(nonce=str(uuid.uuid4()), request_id=str(uuid.uuid4()),
                            repair_instruction="Your previous reply violated " + call["error"] + ". Reuse your assigned responsibility. Return the exact wrapper with the NEW nonce.")
                        retry.append(nxt)
                    else:
                        fatal.append(call["error"])
            self.save()
            if fatal: raise HarnessError(fatal[0])
            pending = retry
    def write_artifact(self, slot: str, name: str, content: str):
        # File confinement is never ablated, even when logical ownership is disabled.
        need(name == output_name(self.task["id"]) and isinstance(content, str) and len(content) <= 16000,
             "ARTIFACT.OUTSIDE_OWNERSHIP")
        conflict = slot != "w01"
        accepted = not conflict or not self.controls["artifact_ownership"]
        self.trace["artifact_events"].append({"slot": slot, "path": name, "owner": "w01",
            "conflict": conflict, "accepted": accepted, "overwrite": name in self.trace["artifact_sha256"],
            "sha256": sha_bytes(content.encode())})
        need(accepted, "ARTIFACT.OUTSIDE_OWNERSHIP")
        (self.path/"artifacts"/name).write_text(content, encoding="utf-8", newline="\n")
        self.trace["artifact_sha256"][name] = sha_bytes(content.encode())

    def execute(self) -> dict:
        try:
            r = self.r
            if r["controllers"]:
                self.batch([self.packet(c, "plan", assigned_workers=group(r,c),
                    responsibilities={w:r["responsibilities"][w] for w in group(r,c)},
                    output_contract={"assignments": [{"slot":w,"work_key":"contract-"+w,"instruction":"a bounded assignment"} for w in group(r,c)]})
                    for c in r["controllers"]])
                instructions = {a["slot"]:a["instruction"] for c in r["controllers"] for a in self.latest[(c,"plan")]["result"]["assignments"]}
            else: instructions = {"w01":r["responsibilities"]["w01"]}
            self.batch([self.packet("w01", "implement", responsibility=r["responsibilities"]["w01"],
                controller=r["owner"]["w01"], assignment=instructions["w01"],
                output_contract={"files":{output_name(self.task["id"]):"full UTF-8 file content"},"claimed_success":True})])
            implementation = self.latest[("w01","implement")]["result"]
            for name, content in implementation["files"].items():
                self.write_artifact("w01", name, content)
            if len(r["workers"]) > 1:
                self.batch([self.packet(w, "inspect", controller=r["owner"][w], responsibility=r["responsibilities"][w],
                    assignment=instructions[w], candidate=implementation["files"],
                    output_contract={"analysis":"reason only about your assigned aspect; disclose non-applicability", "passed":True})
                    for w in r["workers"] if w != "w01"])
                for w in r["workers"][1:]:
                    proposed = self.latest[(w,"inspect")]["result"].get("files", {})
                    need(isinstance(proposed, dict), "ARTIFACT.INVALID_WRITE")
                    for name, content in proposed.items():
                        self.write_artifact(w, name, content)
                def evidence(c):
                    return {w:{"sha256":self.latest[(w,"implement" if w=="w01" else "inspect")]["hash"],
                               "output":self.latest[(w,"implement" if w=="w01" else "inspect")]["result"]}
                            for w in group(r, opposite(c))}
                if self.controls["cross_review"]:
                    self.batch([self.packet(c,"review",review_evidence=evidence(c),
                        output_contract={"decisions":[{"slot":w,"output_sha256":e["sha256"],"decision":"accept or block"} for w,e in evidence(c).items()]}) for c in r["controllers"]])
                    for c in r["controllers"]:
                        need(all(d["decision"]=="accept" for d in self.latest[(c,"review")]["result"]["decisions"]), "VERIFY.REVIEW_REJECTED")
                for w in r["workers"][1:]:
                    need(self.latest[(w,"inspect")]["result"]["passed"], "VERIFY.WORKER_REJECTED")
            self.trace["status"] = "EXECUTED_UNGRADED"
        except HarnessError as e:
            self.trace["status"], self.trace["error"] = "BLOCKED", e.code
        except KeyboardInterrupt:
            self.trace["status"], self.trace["error"] = "BLOCKED", "EXEC.INTERRUPTED_UNCERTAIN"
        self.trace["latency_ms"] = self.elapsed()
        self.trace["end_time"] = utc_now()
        self.journal.add("END", {"status":self.trace["status"], "error":self.trace["error"], "calls":len(self.trace["calls"])})
        self.save()
        return self.trace


def run(provider, out: Path, architectures=None, repetitions=1, seed=7, experimental=False, only=None,
        max_requests=64, concurrency=16, deadline_ms=180000, rate_card=None,
        ablation="full", experimental_ablation=False) -> Path:
    need(provider.kind in ("fixture", "fixture_http", "external_model_api"), "CONFIG.UNKNOWN_EXECUTION_KIND")
    architectures = architectures or ["dual16"]
    need(len(set(architectures)) == len(architectures) and 1 <= len(architectures) <= 3, "PLAN.ARCHITECTURES")
    for arch in architectures: roster(arch)
    need(experimental or architectures==["dual16"], "PLAN.BASELINE_OPT_IN_REQUIRED")
    need(1 <= repetitions <= 10 and 1 <= concurrency <= 16 and 1 <= max_requests <= 128 and 1 <= deadline_ms <= 600000, "CONFIG.LIMITS")
    need(not out.exists(), "RUN.ALREADY_EXISTS_NO_REPLAY")
    benchmark_hash = verify_benchmark()
    provider.preflight()  # never emit a fake run when no provider is configured
    controls = controls_for(ablation, experimental=experimental_ablation)
    need(ablation == "full" or architectures == ["dual16"], "ABLATION.DUAL16_ONLY")
    if getattr(provider, "requires_health_gate", False):
        provider.require_health()
    if provider.kind == "external_model_api":
        need(getattr(provider, "requires_health_gate", False), "PROVIDER.STRICT_ADAPTER_REQUIRED")
        admission = getattr(provider, "campaign_admission", None)
        need(isinstance(admission, dict), "GATE.USE_LIVE_CAMPAIGN_COMMAND")
        need(admission.get("architecture_set") == architectures and admission.get("repetitions") == repetitions
             and admission.get("ablation") == ablation and admission.get("tasks") == only,
             "GATE.CAMPAIGN_SCOPE_MISMATCH")
    selected = [t for t in tasks() if only is None or t["id"] in only]
    need(bool(selected) and (only is None or len(selected)==len(set(only))), "BENCHMARK.UNKNOWN_TASK")
    plan = [{"task_id":t["id"],"architecture":arch,"repetition":rep,"seed":seed+rep*10,
             "episode_id":f'{t["id"]}--{arch}--{rep}', "run_id":str(uuid.uuid4())} for t in selected for arch in architectures for rep in range(repetitions)]
    random.Random(seed).shuffle(plan)
    if rate_card is not None:
        from .common import finite_nonnegative
        need(all(finite_nonnegative(rate_card.get(k)) for k in ("input_per_million_usd","output_per_million_usd"))
             and isinstance(rate_card.get("as_of"),str), "CONFIG.INVALID_RATE_CARD")
    out.mkdir(parents=True)
    run_id = str(uuid.uuid4())
    code_version = protocol_fingerprint()
    config = {"schema_version":1,"harness_version":__version__,"benchmark_id":BENCHMARK_ID,
        "benchmark_hash":benchmark_hash,"grader_version":GRADER_VERSION,"protocol_hash":protocol_fingerprint(),
        "provider":provider.metadata(),"execution_kind":provider.kind,"architectures":architectures,
        "experimental_baselines":experimental,"repetitions":repetitions,"seed":seed,
        "limits":{"max_requests":max_requests,"max_attempts":2,"concurrency":concurrency,"deadline_ms":deadline_ms},
        "rate_card":rate_card,"plan":plan,"python":platform.python_version(),
        "run_id":run_id,"created_at":utc_now(),"code_version":code_version,"controls":controls,
        "provider_health":getattr(provider,"health_record",None),"evaluator_version":"receipt-evaluator-v3",
        "seed_note":"Seed fixes scheduling/order; API model stochasticity is not controlled by this seed.",
        "autonomous_resume":"NOT_IMPLEMENTED; interrupted inference is never automatically replayed"}
    write(out/"run.json",config)
    lookup={t["id"]:t for t in selected}
    for unit in plan:
        episode_run_id=unit["run_id"]
        ep=EpisodeRunner(provider,lookup[unit["task_id"]],unit["architecture"],out/"episodes"/unit["episode_id"],unit["seed"],config["limits"], controls,
            identity={"run_id":episode_run_id,"cohort_run_id":run_id,"episode_uuid":episode_run_id,"benchmark_version":BENCHMARK_ID,
                "task_id":unit["task_id"],"architecture":unit["architecture"],"provider":provider.metadata(),
                "model":provider.metadata()["model"],"seed":unit["seed"],"attempt":unit["repetition"]+1,
                "code_version":code_version,"grader_version":GRADER_VERSION,"timestamp":utc_now()})
        trace=ep.execute()
        if trace["error"] in ("EXEC.INTERRUPTED_UNCERTAIN","EXEC.TIMEOUT_UNCERTAIN") or (
            provider.kind=="external_model_api" and str(trace["error"]).startswith(("PROVIDER.","CONFIG.","BUDGET.STAGE_"))):
            break
    write(out/"seal.json",{"schema":1,"files":file_map(out),"notice":"Local integrity seal, NOT a publisher signature or provider attestation."})
    return out
