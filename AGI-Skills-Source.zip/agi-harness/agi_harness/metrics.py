from __future__ import annotations
import math
import random
from collections import defaultdict, Counter
from .common import need, finite_nonnegative
from .statistics import distribution, wilson95


def quantile(xs,p):
    if not xs:return None
    xs=sorted(xs);pos=(len(xs)-1)*p;i=int(pos);j=min(i+1,len(xs)-1)
    return xs[i]+(xs[j]-xs[i])*(pos-i)


def aggregate(rows):
    buckets=defaultdict(list)
    for r in rows:buckets[r["architecture"]].append(r)
    out={}
    for arch,rs in sorted(buckets.items()):
        n=len(rs);success=sum(r["verified_success"] for r in rs);claims=sum(r["declared_success"] for r in rs)
        latency=[r["latency_ms"] for r in rs if finite_nonnegative(r["latency_ms"])]
        costs=[r["estimated_cost_usd"] for r in rs if r["estimated_cost_usd"] is not None]
        fail=Counter(code for r in rs for code in r["failures"])
        out[arch]={"scheduled_episodes":n,"unique_tasks":len({r["task_id"] for r in rs}),
            "verified_successes":success,"verified_success_rate":success/n,
            "first_pass_success_rate":sum(r["first_pass_success"] for r in rs)/n,
            "success_count_total":[success,n],"verified_success_wilson_95":wilson95(success,n),
            "statistical_power":"low statistical power; repeats share only a small number of task clusters",
            "ci_note":"Descriptive episode-level Wilson interval, not an iid claim; use task-cluster comparison for differences",
            "latency_distribution_ms":distribution([r["latency_ms"] for r in rs]),
            "provider_cost_usd":None,"cost_per_episode":None,"cost_per_verified_success":None,
            "grader_reject_rate":sum(not r["verified_success"] for r in rs)/n,
            "false_pass_caught":sum(r["false_success"] for r in rs),
            "recovery_success_rate":(sum(r["verified_success"] and r["extra_attempts"]>0 for r in rs)/
                sum(r["extra_attempts"]>0 for r in rs)) if any(r["extra_attempts"]>0 for r in rs) else None,
            "artifact_conflict_rate":sum(r.get("artifact_conflict",False) for r in rs)/n,
            "artifact_conflict_attempts":sum(r.get("artifact_conflict_attempts",0) for r in rs),
            "input_tokens":sum(r["input_tokens"] for r in rs) if all(r.get("input_tokens") is not None for r in rs) else None,
            "output_tokens":sum(r["output_tokens"] for r in rs) if all(r.get("output_tokens") is not None for r in rs) else None,
            "false_success_rate_all_runs":sum(r["false_success"] for r in rs)/n,
            "false_success_rate_given_claim":sum(r["false_success"] for r in rs)/claims if claims else None,
            "rework_rate":sum(r["extra_attempts"]>0 for r in rs)/n,
            "estimated_total_cost_usd":sum(costs) if len(costs)==n else None,
            "estimated_cost_per_episode_usd":sum(costs)/n if len(costs)==n else None,
            "estimated_cost_distribution_usd":distribution([r["estimated_cost_usd"] for r in rs]),
            "total_tokens":sum(r["total_tokens"] for r in rs) if all(r.get("total_tokens") is not None for r in rs) else None,
            "known_cost_lower_bound_usd":sum(costs) if costs else None,
            "cost_coverage":len(costs)/n,
            "estimated_cost_per_verified_success_usd":sum(costs)/success if len(costs)==n and success else None,
            "latency_p50_ms":quantile(latency,.5),"latency_p95_ms":quantile(latency,.95),"latency_coverage":len(latency)/n,
            "calls_attempted":sum(r["calls_attempted"] for r in rs),
            "real_model_calls":sum(r["real_model_calls"] for r in rs),"failure_counts":dict(fail),
            "population":"FIXTURE plumbing only" if rs[0]["execution_kind"]!="external_model_api" else "external model benchmark"}
    return out


def compare(evaluations, bootstrap_samples=2000):
    need(bool(evaluations),"COMPARE.EMPTY")
    reference=evaluations[0]
    fields=["benchmark_id","benchmark_hash","grader_version","protocol_hash","execution_kind","provider","limits","rate_card"]
    for e in evaluations:
        need(e.get("controls")==reference.get("controls"),"COMPARE.INCOMPATIBLE_CONTROLS")
        need({r["task_id"] for r in e["rows"]}=={r["task_id"] for r in reference["rows"]},"COMPARE.INCOMPATIBLE_TASK_SET")
        for k in fields:need(e[k]==reference[k],"COMPARE.INCOMPATIBLE_"+k.upper())
    all_rows=[];seen=set()
    for e in evaluations:
        for row in e["rows"]:
            key=(row["task_id"],row["architecture"],row["repetition"],row["seed"])
            need(key not in seen,"COMPARE.DUPLICATE_EPISODE");seen.add(key);all_rows.append(row)
    by_arch=defaultdict(dict)
    for row in all_rows:by_arch[row["architecture"]][(row["task_id"],row["repetition"],row["seed"])]=row
    keys=[set(v) for v in by_arch.values()]
    need(all(k==keys[0] for k in keys),"COMPARE.UNPAIRED_POPULATION")
    arches=sorted(by_arch);baseline="single" if "single" in arches else arches[0]
    task_ids=sorted({k[0] for k in keys[0]})
    deltas={}
    for arch in arches:
        if arch==baseline:continue
        task_means=[]
        for task_id in task_ids:
            ks=[k for k in keys[0] if k[0]==task_id]
            task_means.append(sum(int(by_arch[arch][k]["verified_success"])-int(by_arch[baseline][k]["verified_success"]) for k in ks)/len(ks))
        rng=random.Random(1337)
        samples=[sum(rng.choice(task_means) for _ in task_means)/len(task_means) for _ in range(bootstrap_samples)]
        deltas[arch]={"against":baseline,"success_rate_difference":sum(task_means)/len(task_means),
            "task_cluster_bootstrap_95":[quantile(samples,.025),quantile(samples,.975)],
            "unique_task_clusters":len(task_ids),"warning":"Only a small smoke sample; repeated seeds are not independent tasks."}
    return {"execution_kind":reference["execution_kind"],"benchmark_id":reference["benchmark_id"],
        "metrics":aggregate(all_rows),"paired_differences":deltas,"architecture_order":arches,
        "claim_boundary":"No production advantage can be inferred from fixture results." if reference["execution_kind"]!="external_model_api" else "Descriptive paired pilot, not proof of universal superiority."}
