"""Evidence-revalidated sequential live campaign. No success-file based admission."""
from __future__ import annotations
import copy
import random
import time
import uuid
from pathlib import Path
from .common import ROOT, HarnessError, digest, need, parse, read, write
from .benchmark import BENCHMARK_ID, GRADER_VERSION, tasks, verify_benchmark
from .runtime import run, protocol_fingerprint
from .evaluation import evaluate
from .live_provider import StrictHTTPProvider, utc_now
from .ablation import VARIANTS

STAGES = ("probe", "pilot", "benchmark", "ablation")
PREVIOUS = {"probe": None, "pilot": "probe", "benchmark": "pilot", "ablation": "benchmark"}


def nominal_calls(stage):
    return {"probe": 20, "pilot": 120, "benchmark": 594, "ablation": 1764}[stage]


def _receipts(path):
    config = read(path / "run.json")
    all_records = []
    for unit in config["plan"]:
        trace_path = path/"episodes"/unit["episode_id"]/"trace.json"
        if not trace_path.exists(): continue
        trace = read(trace_path)
        for call in trace["calls"]:
            try:
                body = parse(call["raw_response"])
                rid = body.get("id")
                if isinstance(rid, str) and rid:
                    all_records.append({"id": rid, "slot": call["request"]["slot"],
                        "phase": call["request"]["phase"], "valid": call["valid_contract"] and not call["error"],
                        "model": body.get("model"), "episode_id": unit["episode_id"]})
            except (HarnessError, TypeError, AttributeError): pass
    return all_records


def validate_probe(path: Path, *, require_live=True) -> dict:
    ev = evaluate(path)
    need(not require_live or ev["execution_kind"] == "external_model_api", "GATE.FIXTURE_IS_NOT_LIVE")
    need(len(ev["rows"]) == 1 and ev["rows"][0]["architecture"] == "dual16", "GATE.PROBE_SHAPE")
    records = _receipts(path)
    good = [r for r in records if r["valid"]]
    workers = [r for r in good if r["slot"].startswith("w")]
    need({r["slot"] for r in workers} == {f"w{i:02d}" for i in range(1,17)}, "GATE.WORKERS_INCOMPLETE")
    need(len(workers) == len({r["id"] for r in workers}) == 16, "GATE.WORKER_IDS_NOT_UNIQUE")
    need(len({r["id"] for r in records}) == len(records), "GATE.DUPLICATE_PROVIDER_RESPONSE")
    controllers = [r for r in good if r["slot"].startswith("control-")]
    need({(r["slot"],r["phase"]) for r in controllers} == {
         (slot,phase) for slot in ("control-a","control-b") for phase in ("plan","review")}, "GATE.CONTROLLER_REVIEW_INCOMPLETE")
    # A wrong task answer remains valuable data, not an excuse to keep sampling until PASS.
    structural = [c for c in ev["rows"][0]["failures"] if not c.startswith("TASK.") and c != "VERIFY.FALSE_SUCCESS"]
    need(not structural, "GATE.PROBE_PROTOCOL_FAILED")
    return {"status":"PASS", "population":ev["execution_kind"], "workers_requested":16,
            "workers_responded":16,"unique_worker_response_ids":16,"controllers":2,
            "controller_responses":len(controllers),"worker_responses":len(workers),
            "cross_review_completed":True,"independent_grader": "PASS" if ev["rows"][0]["verified_success"] else "FAIL",
            "task_quality_is_not_probe_admission_criterion":True, "source_seal_sha256":ev["source_seal_sha256"]}


def validate_population(path: Path, stage: str, *, require_live=True):
    if stage == "probe": return validate_probe(path, require_live=require_live)
    need(stage in ("pilot","benchmark"), "GATE.UNKNOWN_POPULATION")
    ev = evaluate(path)
    need(not require_live or ev["execution_kind"] == "external_model_api", "GATE.FIXTURE_IS_NOT_LIVE")
    config = read(path/"run.json")
    expected_arches = {"dual16"} if stage == "pilot" else {"single","dual8","dual16"}
    reps = 1 if stage == "pilot" else 3
    expected = {(task["id"],arch,rep) for task in tasks() for arch in expected_arches for rep in range(reps)}
    actual = {(r["task_id"],r["architecture"],r["repetition"]) for r in ev["rows"]}
    need(actual == expected and len(ev["rows"]) == len(expected), "GATE.POPULATION_INCOMPLETE")
    for unit in config["plan"]:
        trace = read(path/"episodes"/unit["episode_id"]/"trace.json")
        need(trace.get("end_time") is not None, "GATE.UNFINISHED_EPISODE")
        need(trace.get("error") not in ("EXEC.INTERRUPTED_UNCERTAIN", "EXEC.TIMEOUT_UNCERTAIN"), "GATE.UNCERTAIN_EPISODE")
        need(not str(trace.get("error", "")).startswith("BUDGET.STAGE_"), "GATE.STAGE_BUDGET_EXHAUSTED")
        need(any(isinstance(c.get("raw_response"),str) and '"id"' in c["raw_response"] for c in trace["calls"]), "GATE.NO_OBSERVED_RESPONSE")
        need(not any(c["error"] and (c["error"].startswith("PROVIDER.") or c["error"].startswith("CONFIG."))
                     for c in trace["calls"]), "GATE.PROVIDER_FAILURE")
    ids = [r["id"] for r in _receipts(path)]
    need(len(ids)==len(set(ids)), "GATE.DUPLICATE_PROVIDER_RESPONSE")
    return {"status":"PASS", "episodes":len(ev["rows"]), "verified_successes":sum(r["verified_success"] for r in ev["rows"]),
            "task_failures_retained":True,"source_seal_sha256":ev["source_seal_sha256"]}


def controlled_ablation_comparison(evaluations):
    need(len(evaluations) == len(VARIANTS), "ABLATION.MISSING_ARM")
    by_name = {e["controls"]["variant"]: e for e in evaluations}
    need(set(by_name) == set(VARIANTS), "ABLATION.MISSING_ARM")
    full = by_name["full"]
    fields = ("benchmark_id","benchmark_hash","grader_version","protocol_hash","provider","limits","rate_card","execution_kind")
    cohort = {(r["task_id"],r["seed"],r["repetition"]) for r in full["rows"]}
    result = []
    for name in VARIANTS:
        ev = by_name[name]
        for field in fields: need(ev[field]==full[field], "ABLATION.INCOMPATIBLE_"+field.upper())
        need({(r["task_id"],r["seed"],r["repetition"]) for r in ev["rows"]} == cohort, "ABLATION.UNPAIRED_COHORT")
        need(all(r["architecture"]=="dual16" for r in ev["rows"]), "ABLATION.DUAL16_ONLY")
        need(sum(ev["controls"][k] != full["controls"][k] for k in ("cross_review","artifact_ownership","independent_grader","replay_protection")) == (0 if name=="full" else 1), "ABLATION.MULTIPLE_VARIABLES_OR_INVALID")
        n=len(ev["rows"])
        result.append({"configuration":name,"episodes":n,**ev["metrics"]["dual16"],
            "operational_success_rate":sum(r.get("operational_success",False) for r in ev["rows"])/n,
            "false_pass_released":sum(r.get("operational_success",False) and not r["verified_success"] for r in ev["rows"]),
            "outer_shadow_grader":"ALWAYS_ENABLED"})
    return {"population":full["execution_kind"],"rows":result,
            "limits":["Tiny single-writer tasks may expose no real ownership conflicts.",
                      "No uncertain network request is resent, even in no_replay_guard.",
                      "Prompt/seed/budget are fixed; removed stages necessarily reduce actual calls.",
                      "Arms run in preregistered randomized blocks, not simultaneous provider inference."]}


def _run_stage_unlocked(provider: StrictHTTPProvider, root: Path, stage: str, *, seed=7, concurrency=2,
              max_requests=40, deadline_ms=180000, rate_card=None, request_ceiling=None):
    need(stage in STAGES, "GATE.UNKNOWN_STAGE")
    need(provider.kind == "external_model_api", "GATE.FIXTURE_IS_NOT_LIVE")
    need(1<=concurrency<=16 and 1<=max_requests<=128, "CONFIG.LIMITS")
    minimum = nominal_calls(stage)
    need(request_ceiling is not None and request_ceiling >= minimum + 1, "BUDGET.STAGE_REQUEST_CEILING_REQUIRED")
    need(not root.is_symlink(), "ARTIFACT.SYMLINK")
    root.mkdir(parents=True,exist_ok=True)
    attempt_id = f"{stage}-{uuid.uuid4()}"
    attempt = root/"attempts"/attempt_id
    attempt.mkdir(parents=True,exist_ok=False)
    snapshot = {"benchmark_id":BENCHMARK_ID,"benchmark_hash":verify_benchmark(),"grader_version":GRADER_VERSION,
        "protocol_hash":protocol_fingerprint(),"provider":provider.metadata(),"seed":seed,
        "limits":{"concurrency":concurrency,"max_requests":max_requests,"deadline_ms":deadline_ms},"rate_card":rate_card}
    order = list(VARIANTS)
    random.Random(seed).shuffle(order)
    intent = {"stage":stage,"attempt_id":attempt_id,"timestamp":utc_now(),"snapshot":snapshot,
              "nominal_agent_calls":minimum,"request_ceiling":request_ceiling,
              "ablation_block_order":order if stage=="ablation" else None}
    write(attempt/"intent.json",intent)
    state_path=root/"campaign.json"
    state=read(state_path) if state_path.exists() else {"snapshot":snapshot,"stages":{},"attempts":[]}
    try:
        need(state["snapshot"]==snapshot,"GATE.CAMPAIGN_CONFIG_DRIFT")
        previous=PREVIOUS[stage]
        if previous:
            need(previous in state["stages"],"GATE.PREVIOUS_STAGE_REQUIRED")
            previous_path=root/state["stages"][previous]["run_path"]
            validate_population(previous_path,previous)
        health=provider.health_sync()
        write(attempt/"health.json",health)
        need(health["status"]=="PASS","GATE.PROVIDER_HEALTH_FAILED")
        # Bound the actual number of HTTP requests, including health, with a locked counter.
        import threading
        lock=threading.Lock();counter={"requests":1};original_send=provider._send
        def bounded_send(*args,**kwargs):
            with lock:
                need(counter["requests"]<request_ceiling,"BUDGET.STAGE_REQUEST_LIMIT")
                counter["requests"]+=1
            return original_send(*args,**kwargs)
        provider._send=bounded_send
        outputs=[]
        try:
            variants=order if stage=="ablation" else ["full"]
            for variant in variants:
                arches=["single","dual8","dual16"] if stage=="benchmark" else ["dual16"]
                reps=3 if stage in ("benchmark","ablation") else 1
                only=[tasks()[0]["id"]] if stage=="probe" else None
                provider.campaign_admission={"architecture_set":arches,"repetitions":reps,"tasks":only,"ablation":variant}
                path=attempt/("run" if stage!="ablation" else variant)
                run(provider,path,arches,reps,seed,stage=="benchmark",only,max_requests,concurrency,deadline_ms,rate_card,
                    ablation=variant,experimental_ablation=stage=="ablation")
                profile=[]
                start=time.perf_counter_ns();ev=evaluate(path,profile=profile);elapsed=(time.perf_counter_ns()-start)/1e6
                write(path/"evaluation.json",ev)
                write(attempt/(variant+"-grader-profile.json"),{"initial_evaluation_wall_clock_ms":elapsed,
                    "episode_count":len(ev["rows"]),"per_episode":profile,
                    "source_seal_sha256":ev["source_seal_sha256"],
                    "excluded_from_deterministic_replay_result":True})
                need(evaluate(path)==ev,"REPLAY.GRADER_DRIFT")
                outputs.append((path,ev))
            if stage=="ablation":
                comparison=controlled_ablation_comparison([e for _,e in outputs])
                write(attempt/"ablation-results.json",comparison)
                # All five arms must contain the complete six-task/three-repeat Dual16 cohort.
                expected={(t["id"],r) for t in tasks() for r in range(3)}
                need(all({(r["task_id"],r["repetition"]) for r in ev["rows"]}==expected for _,ev in outputs),"ABLATION.POPULATION_INCOMPLETE")
                for path,ev in outputs:
                    need(ev["execution_kind"]=="external_model_api","GATE.FIXTURE_IS_NOT_LIVE")
                    for unit in read(path/"run.json")["plan"]:
                        trace=read(path/"episodes"/unit["episode_id"]/"trace.json")
                        need(trace.get("end_time") is not None,"GATE.UNFINISHED_EPISODE")
                        need(trace.get("error") not in ("EXEC.TIMEOUT_UNCERTAIN","EXEC.INTERRUPTED_UNCERTAIN"),"GATE.UNCERTAIN_EPISODE")
                        need(not str(trace.get("error")).startswith(("PROVIDER.","CONFIG.","BUDGET.STAGE_")),"GATE.PROVIDER_FAILURE")
                        need(any(record["episode_id"]==unit["episode_id"] for record in _receipts(path)),"GATE.NO_OBSERVED_RESPONSE")
                all_ids=[record["id"] for path,_ in outputs for record in _receipts(path)]
                need(len(all_ids)==len(set(all_ids)),"GATE.DUPLICATE_PROVIDER_RESPONSE")
                gate={"status":"PASS","episodes":sum(len(e["rows"]) for _,e in outputs),"outer_shadow_grader":"ALWAYS_ENABLED"}
            else: gate=validate_population(outputs[0][0],stage)
        finally:
            provider._send=original_send
            provider.campaign_admission=None
        outcome={"status":"PASS","stage":stage,"attempt_id":attempt_id,"gate":gate,
                 "actual_http_requests":counter["requests"],"model_calls_during_replay":0,
                 "runs":[str(p.relative_to(root)) for p,_ in outputs]}
        write(attempt/"outcome.json",outcome)
        state["stages"][stage]={"attempt_id":attempt_id,"run_path":str(outputs[0][0].relative_to(root)),"outcome":str((attempt/"outcome.json").relative_to(root))}
        state["attempts"].append({"attempt_id":attempt_id,"status":"PASS"})
        write(state_path,state)
        return outcome
    except (HarnessError,OSError,ValueError) as exc:
        code=exc.code if isinstance(exc,HarnessError) else "IO_OR_CONFIG_ERROR"
        outcome={"status":"BLOCKED","stage":stage,"attempt_id":attempt_id,"code":code,
                 "real_runs_admitted":len(list(attempt.rglob("run.json"))),"failed_evidence_retained":True}
        write(attempt/"outcome.json",outcome)
        # An unconfigured first attempt must not freeze an empty provider for future valid runs.
        if state_path.exists():
            state["attempts"].append({"attempt_id":attempt_id,"status":"BLOCKED","code":code})
            write(state_path,state)
        return outcome


def run_stage(provider: StrictHTTPProvider, root: Path, stage: str, **kwargs):
    """Exclusive per-campaign lock; a crashed owner requires manual reconciliation."""
    need(not root.is_symlink(), "ARTIFACT.SYMLINK")
    root.mkdir(parents=True,exist_ok=True)
    lock_path=root/".campaign.lock"
    try:
        with lock_path.open("x",encoding="utf-8") as f:
            f.write(canonical_lock := str(uuid.uuid4()))
            f.flush()
    except FileExistsError:
        raise HarnessError("GATE.CAMPAIGN_LOCKED_RECONCILE_MANUALLY") from None
    try:
        return _run_stage_unlocked(provider,root,stage,**kwargs)
    finally:
        # Never silently clear a replaced lock belonging to another operator.
        if lock_path.is_file() and not lock_path.is_symlink() and lock_path.read_text()==canonical_lock:
            lock_path.unlink()
