"""Synthetic preference modeling + contextual, clipped group-relative policy lab.
Not human-feedback RLHF, not LLM-weight training, never changes production Dual16.
"""
from __future__ import annotations
import math
import random
from pathlib import Path
from .common import ROOT, parse, digest, need

STRATEGIES = ["single","dual8","dual16","dual16_strict"]

def softmax(z):
    m=max(z);a=[math.exp(x-m) for x in z];s=sum(a);return [v/s for v in a]
def feature(c):return [1,c["complexity"],c["risk"],c["tool_failure_risk"],c["artifact_count"]/12]
def outcome(c,s):
    # Preserve v1's frozen synthetic environment, not a fitted model of real agents.
    i=STRATEGIES.index(s);cap=[.42,.66,.82,.86][i];over=[.10,.25,.42,.55][i];ver=[.15,.45,.62,.82][i]
    score=cap+.18*ver*c["risk"]-.09*max(0,c["complexity"]-cap*1.2)-.08*c["tool_failure_risk"]
    return [float(score>=c["success_threshold"]),float(score>=c["success_threshold"]+.06),
            -min(1.5,over+.035*c["artifact_count"]+.12*c["complexity"]),
            -min(1.5,over*.75+.06*c["artifact_count"]+.10*c["complexity"]),
            -float(s=="single" and c["risk"]>.72)]
def fv(x):return [x["verified_success"],x["first_pass"],-x["cost_norm"],-x["latency_norm"],-x["violation"]]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def fit_reward(pairs,epochs=350):
    w=[0.0]*5
    ds=[[a-b for a,b in zip(fv(p["chosen"]),fv(p["rejected"]))] for p in pairs]
    for _ in range(epochs):
        g=[0.0]*5
        for d in ds:
            p=1/(1+math.exp(-max(-30,min(30,dot(w,d)))))
            for j in range(5):g[j]+=(1-p)*d[j]
        w=[v+.08*(x/len(ds)-.005*v) for v,x in zip(w,g)]
    return w
def accuracy(pairs,w):
    return sum(dot(w,fv(p["chosen"]))>dot(w,fv(p["rejected"])) for p in pairs)/len(pairs) if pairs else None

def probs(weights,c):return softmax([dot(w,feature(c)) for w in weights])
def evaluate_policy(cases,weights,reward):
    sums=[0.0]*5;mean_reward=0;mean_probs=[0.0]*4
    for c in cases:
        p=probs(weights,c)
        for i,s in enumerate(STRATEGIES):
            o=outcome(c,s);mean_reward+=p[i]*dot(reward,o);mean_probs[i]+=p[i]
            for j in range(5):sums[j]+=p[i]*o[j]
    n=len(cases)
    return {"tasks":n,"expected_verified_success":sums[0]/n,"expected_first_pass":sums[1]/n,
            "expected_cost_norm":-sums[2]/n,"expected_latency_norm":-sums[3]/n,
            "expected_violation":-sums[4]/n,"reward":mean_reward/n,
            "mean_action_probability":dict(zip(STRATEGIES,[v/n for v in mean_probs]))}

def train_policy(train_cases,reward,seed=7,steps=300,group_size=8):
    rng=random.Random(seed);W=[[0.0]*5 for _ in range(4)];log=[]
    clip=.2;beta=.02;lr=.035
    for step in range(steps):
        c=rng.choice(train_cases);x=feature(c);old=probs(W,c)
        actions=rng.choices(range(4),weights=old,k=group_size)
        rewards=[dot(reward,outcome(c,STRATEGIES[a])) for a in actions]
        mean=sum(rewards)/group_size;std=math.sqrt(sum((v-mean)**2 for v in rewards)/group_size)
        advantages=[(v-mean)/(std+1e-8) for v in rewards]
        for _ in range(3):
            p=probs(W,c);grad=[0.0]*4
            for a,adv in zip(actions,advantages):
                ratio=p[a]/old[a]
                active=not ((adv>0 and ratio>1+clip) or (adv<0 and ratio<1-clip))
                if active:
                    for k in range(4):grad[k]+=adv*ratio*((1.0 if k==a else 0)-p[k])/group_size
            logratio=[math.log(v/.25) for v in p];kl=sum(v*l for v,l in zip(p,logratio))
            for k in range(4):
                grad[k]-=beta*p[k]*(logratio[k]-kl)  # exact categorical KL to the reference
                for j in range(5):W[k][j]+=lr*grad[k]*x[j]
        if step%25==0 or step==steps-1:
            log.append({"step":step,"group_reward_mean":mean,"advantage_std":std,
                        "reference_kl":kl,"entropy":-sum(v*math.log(v) for v in p)})
    return W,log

def experiment(seeds=(7,17,27),steps=300):
    root=ROOT/"legacy/case-study"
    cases=[parse(x) for x in (root/"benchmark/routing_benchmark_v1.jsonl").read_text().splitlines() if x.strip()]
    pairs=[parse(x) for x in (root/"rl/preferences_v1.jsonl").read_text().splitlines() if x.strip()]
    train_cases=[c for c in cases if c["split"]=="train"];test_cases=[c for c in cases if c["split"]=="test"]
    train_ids={c["id"] for c in train_cases};test_ids={c["id"] for c in test_cases}
    need(not train_ids&test_ids and train_ids and test_ids,"RL.SPLIT_LEAKAGE")
    train_pairs=[p for p in pairs if p["case_id"] in train_ids];test_pairs=[p for p in pairs if p["case_id"] in test_ids]
    w=fit_reward(train_pairs);uniform=[[0.0]*5 for _ in range(4)]
    results=[]
    for seed in seeds:
        policy,log=train_policy(train_cases,w,seed,steps)
        results.append({"seed":seed,"weights":policy,"training_log":log,
            "uniform_test":evaluate_policy(test_cases,uniform,w),"learned_test":evaluate_policy(test_cases,policy,w),
            "learned_train":evaluate_policy(train_cases,policy,w),
            "test_case_probabilities":{c["id"]:probs(policy,c) for c in test_cases}})
    return {"label":"SYNTHETIC_ONLY","method":"Bradley-Terry reward + contextual categorical clipped group-relative policy optimization",
        "is_human_feedback":False,"is_llm_weight_training":False,"production_routing_changed":False,
        "limitations":["synthetic environment encodes all outcome assumptions","same task-heldout split for both policies",
                       "GRPO-style discrete-action adaptation, not a TRL LLM GRPO run","no real task advantage demonstrated",
                       "legacy preferences contain no held-out-task pairs; reward-model test accuracy remains null"],
        "dataset_hash":digest({"cases":cases,"pairs":pairs}),"train_task_ids":sorted(train_ids),"test_task_ids":sorted(test_ids),
        "reward_model":{"train_pairs":len(train_pairs),"test_pairs":len(test_pairs),"weights":w,
                        "train_accuracy":accuracy(train_pairs,w),"test_accuracy":accuracy(test_pairs,w)},
        "steps":steps,"group_size":8,"optimization_epochs_per_group":3,"clip":.2,"kl_beta":.02,"seeds":list(seeds),"results":results}
