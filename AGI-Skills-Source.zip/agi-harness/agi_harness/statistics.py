"""Descriptive statistics; failed episodes remain in denominators and latency sets."""
from __future__ import annotations
import math
import statistics as stdstats
from .common import finite_nonnegative


def distribution(values):
    raw = list(values)
    xs = sorted(x for x in raw if finite_nonnegative(x))
    def quantile(p):
        if not xs: return None
        pos = (len(xs)-1)*p
        lo, hi = int(pos), min(int(pos)+1, len(xs)-1)
        return xs[lo] + (xs[hi]-xs[lo])*(pos-lo)
    return {"n": len(xs), "missing": len(raw)-len(xs),
            "mean": stdstats.mean(xs) if xs else None,
            "median": stdstats.median(xs) if xs else None,
            "p50": quantile(.5), "p95": quantile(.95),
            "standard_deviation": stdstats.stdev(xs) if len(xs)>1 else None,
            "min": xs[0] if xs else None, "max": xs[-1] if xs else None}


def wilson95(success, total):
    if total == 0: return None
    z = 1.959963984540054
    p = success / total
    denominator = 1 + z*z/total
    center = (p + z*z/(2*total))/denominator
    radius = z*math.sqrt(p*(1-p)/total + z*z/(4*total*total))/denominator
    return [max(0., center-radius), min(1., center+radius)]
