from __future__ import annotations
from .common import need, parse

ARCHITECTURES = {"single": (0, 1), "dual8": (2, 8), "dual16": (2, 16)}
RESPONSIBILITIES = [
    "Implement the single requested deliverable; you alone own the solution file.",
    "Audit input schema: list field names, value types and mandatory inputs.",
    "Audit output schema: required keys, shapes and return types only.",
    "Audit numeric boundaries: equality and zero boundary handling only.",
    "Audit ordering and tie-breaking determinism only.",
    "Audit duplicate and missing-record behavior only.",
    "Audit explicit forbidden changes and function signature preservation only.",
    "Audit public-input coverage: identify any ignored provided input.",
    "Independently recompute one concrete example from public input only.",
    "Propose a minimal counterexample to the candidate's core predicate only.",
    "Audit unknown/uncertain execution handling; explain non-applicability when absent.",
    "Audit retry stopping boundaries; explain non-applicability when absent.",
    "Audit artifact ownership and unexpected file outputs only.",
    "Audit stated resource budgets and missing measurement caveats only.",
    "Audit whether the candidate contains data or claims absent from public inputs.",
    "Audit final deliverable naming, encoding and syntactic completeness only.",
]

def roster(architecture: str) -> dict:
    need(architecture in ARCHITECTURES, "PLAN.UNKNOWN_ARCHITECTURE")
    c, n = ARCHITECTURES[architecture]
    workers = [f"w{i:02d}" for i in range(1, n + 1)]
    controllers = ["control-a", "control-b"] if c else []
    owners = {w: ("control-a" if i < n // 2 else "control-b") for i, w in enumerate(workers)} if c else {"w01": None}
    return {"controllers": controllers, "workers": workers, "owner": owners,
            "responsibilities": {w: RESPONSIBILITIES[i] for i, w in enumerate(workers)}}

def group(r: dict, controller: str) -> list[str]:
    return [w for w in r["workers"] if r["owner"][w] == controller]

def opposite(controller: str) -> str:
    need(controller in ("control-a", "control-b"), "PLAN.INVALID_CONTROLLER")
    return "control-b" if controller == "control-a" else "control-a"

def decode(request: dict, raw: str) -> tuple[dict, dict]:
    body = parse(raw)
    need(isinstance(body, dict), "EVIDENCE.MISSING_RECEIPT")
    rid = body.get("id")
    need(isinstance(rid, str) and 0 < len(rid) <= 300, "EVIDENCE.MISSING_RECEIPT")
    try:
        text = body["choices"][0]["message"]["content"]
        need(isinstance(text, str), "EXEC.INVALID_OUTPUT")
        obj = parse(text)
    except (KeyError, IndexError, TypeError):
        need(False, "EXEC.INVALID_OUTPUT")
    need(isinstance(obj, dict) and set(obj) == {"slot", "nonce", "result"}, "EXEC.INVALID_OUTPUT")
    need(obj["slot"] == request["slot"], "DELEGATION.WRONG_SLOT")
    need(obj["nonce"] == request["nonce"], "EVIDENCE.STALE_NONCE")
    result = obj["result"]
    need(isinstance(result, dict), "EXEC.INVALID_OUTPUT")
    phase = request["phase"]
    if phase == "plan":
        assignments = result.get("assignments")
        expected = request["assigned_workers"]
        need(isinstance(assignments, list) and len(assignments) == len(expected), "PLAN.INCOMPLETE")
        need(all(isinstance(x, dict) and isinstance(x.get("slot"), str) and isinstance(x.get("work_key"), str) for x in assignments), "PLAN.INVALID_ASSIGNMENT")
        need({x.get("slot") for x in assignments} == set(expected), "DELEGATION.WRONG_CONTROLLER")
        need(len({x.get("work_key") for x in assignments}) == len(expected), "PLAN.DUPLICATE_RESPONSIBILITY")
        for a in assignments:
            need(a.get("work_key") == "contract-" + a["slot"], "PLAN.INVALID_WORK_KEY")
            need(isinstance(a.get("instruction"), str) and 0 < len(a["instruction"]) <= 1500, "PLAN.INVALID_INSTRUCTION")
    elif phase == "implement":
        need(type(result.get("claimed_success")) is bool, "EXEC.INVALID_OUTPUT")
        files = result.get("files")
        need(isinstance(files, dict) and set(files) == {request["output_name"]}, "ARTIFACT.OUTSIDE_OWNERSHIP")
        need(all(isinstance(v, str) and len(v) <= 16000 for v in files.values()), "ARTIFACT.OVERSIZE")
    elif phase == "inspect":
        need(type(result.get("passed")) is bool, "EXEC.INVALID_OUTPUT")
        need(isinstance(result.get("analysis"), str) and 0 < len(result["analysis"]) <= 5000, "EXEC.INVALID_OUTPUT")
    elif phase == "review":
        decisions = result.get("decisions")
        expected = request["review_evidence"]
        need(isinstance(decisions, list) and len(decisions) == len(expected), "VERIFY.MISSING_REVIEW")
        need(all(isinstance(d, dict) and isinstance(d.get("slot"), str) for d in decisions), "VERIFY.INVALID_DECISION")
        need({d.get("slot") for d in decisions} == set(expected), "VERIFY.WRONG_REVIEWER")
        for d in decisions:
            need(d.get("output_sha256") == expected[d["slot"]]["sha256"], "VERIFY.STALE_HASH")
            need(d.get("decision") in ("accept", "block"), "VERIFY.INVALID_DECISION")
    else:
        need(False, "PLAN.UNKNOWN_PHASE")
    return body, result
