from __future__ import annotations
import html
import json
from pathlib import Path
from .common import canonical

def render(result: dict) -> str:
    lines=["# AGI Harness evaluation report", "", f"**Execution class: `{result['execution_kind']}`**", "",
      "Fixture results validate plumbing only; they are not real-model accuracy or inference latency.",
      "", "| Architecture | Scheduled | Verified | First pass | False success | Cost coverage | Estimated cost / verified | p50 ms | p95 ms |",
      "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for arch,m in result["metrics"].items():
        def val(x): return "unknown" if x is None else f"{x:.4f}"
        lines.append(f"| {arch} | {m['scheduled_episodes']} | {m['verified_success_rate']:.1%} | {m['first_pass_success_rate']:.1%} | {m['false_success_rate_all_runs']:.1%} | {m['cost_coverage']:.0%} | {val(m['estimated_cost_per_verified_success_usd'])} | {val(m['latency_p50_ms'])} | {val(m['latency_p95_ms'])} |")
    lines += ["", "## Interpretation boundaries", "", "The denominator includes every scheduled episode after admission. Missing usage is null, not zero. Cost per verified success includes failed attempts. Latency covers the full episode, not only successful model calls. Seed controls run order, not provider determinism. Repeated runs of six tasks do not create 18 independent tasks.","",
              "Raw receipts and a local SHA-256 chain support auditability, not cryptographic proof of model identity. No native ChatGPT subagents are claimed.","", "## Machine-readable result", "", "```json", json.dumps(result.get('paired_differences',{}),indent=2), "```", ""]
    return "\n".join(lines)

def html_report(markdown: str) -> str:
    return '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AGI Harness report</title><style>body{max-width:1100px;margin:40px auto;padding:0 24px;font:16px/1.6 system-ui}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.7 ui-monospace}</style><main><pre>'+html.escape(markdown)+'</pre></main></html>'
