"""Strict opt-in HTTP transport. No provider/model defaults and no transport retry.

The async API is a contract over bounded blocking HTTP calls (asyncio.to_thread),
not a claim of provider sessions, native subagents or concurrent GPU inference.
"""
from __future__ import annotations
import asyncio
import copy
import os
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from typing import Protocol, runtime_checkable
from .common import HarnessError, canonical, digest, finite_nonnegative, need, parse, sha_bytes
from .providers import HTTPProvider, NoRedirect

REQUIRED_ENV = ("AGI_MODEL_BASE_URL", "AGI_MODEL_API_KEY", "AGI_MODEL_NAME", "AGI_MODEL_ALLOWED_HOST")
CONFIRMATIONS = ("AGI_TRANSPORT_AUTHORIZED", "AGI_ZERO_COST_CONFIRMED")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def configuration_status(env=None) -> dict:
    env = os.environ if env is None else env
    missing = [key for key in REQUIRED_ENV if not env.get(key)]
    confirmations = [key for key in CONFIRMATIONS if env.get(key) != "true"]
    return {"status": "READY_FOR_HEALTH_PROBE" if not missing and not confirmations else "BLOCKED_CONFIG",
            "missing_environment_variables": missing, "unconfirmed": confirmations,
            "real_model_calls": 0, "billing_enforcement": "NOT_VERIFIED_BY_HARNESS"}


@runtime_checkable
class Provider(Protocol):
    async def generate(self, request: dict, history: list[dict]) -> dict: ...
    async def health(self) -> dict: ...
    async def model_info(self) -> dict: ...


def usage_fields(body: dict) -> dict:
    usage = body.get("usage")
    valid = (isinstance(usage, dict) and all(type(usage.get(k)) is int and usage[k] >= 0
             for k in ("prompt_tokens", "completion_tokens")))
    if valid and "total_tokens" in usage:
        valid = type(usage["total_tokens"]) is int and usage["total_tokens"] == usage["prompt_tokens"] + usage["completion_tokens"]
    return {"usage": copy.deepcopy(usage) if isinstance(usage, dict) else None,
            "input_tokens": usage["prompt_tokens"] if valid else None,
            "output_tokens": usage["completion_tokens"] if valid else None,
            "total_tokens": usage["prompt_tokens"] + usage["completion_tokens"] if valid else None,
            "token_usage_status": "provider_reported" if valid else "unknown"}


class StrictHTTPProvider(HTTPProvider):
    """Explicitly authorized OpenAI-compatible protocol, not a provider selector."""
    requires_health_gate = True

    def __init__(self, *, allow_live=False, allow_local=False, env=None, timeout=35, max_output_tokens=1800):
        env = os.environ if env is None else env
        super().__init__(allow_live=allow_live, allow_local=allow_local, env=env,
                         timeout=timeout, max_output_tokens=max_output_tokens)
        self.env_status = configuration_status(env)
        try:
            self.temperature = float(env.get("AGI_MODEL_TEMPERATURE", "0.2"))
            self.sampling_seed = int(env["AGI_MODEL_SEED"]) if env.get("AGI_MODEL_SEED") else None
        except (TypeError, ValueError):
            raise HarnessError("CONFIG.INVALID_SAMPLING") from None
        need(finite_nonnegative(self.temperature) and self.temperature < 2, "CONFIG.INVALID_SAMPLING")
        need(self.sampling_seed is None or 0 <= self.sampling_seed < 2**64, "CONFIG.INVALID_SAMPLING")
        # Do not silently inherit a process-wide credential-bearing proxy.
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        self.health_record = None
        self._approved_base, self._approved_model, self._approved_host = self.base, self.model, self.host

    def metadata(self):
        metadata = {**super().metadata(), "adapter_version": "strict-http-v1",
                "temperature": self.temperature, "sampling_seed_requested": self.sampling_seed,
                "sampling_seed_honored": "NOT_VERIFIED", "automatic_transport_retries": 0,
                "proxy_policy": "no_inherited_proxy", "provider_sessions": "NOT_CLAIMED",
                "billing_enforcement": "operator_confirmed_supplier_cap_not_locally_verified"}
        import urllib.parse
        try:
            parsed = urllib.parse.urlsplit(self.base)
            host = parsed.hostname or ""
            authority = ("["+host+"]" if ":" in host else host) + (":"+str(parsed.port) if parsed.port else "")
            metadata["base_url"] = urllib.parse.urlunsplit((parsed.scheme,authority,parsed.path,"",""))
        except ValueError:
            metadata["base_url"] = "[INVALID_URL]"
        return parse(canonical(metadata).replace(self.key,"[REDACTED_SECRET]")) if self.key else metadata

    def preflight(self):
        need((self.base, self.model, self.host) == (self._approved_base, self._approved_model, self._approved_host),
             "CONFIG.PROVIDER_DRIFT")
        need(not any(c in self.model + self.host for c in "\r\n\x00"), "CONFIG.INVALID_ID")
        return super().preflight()

    def _payload(self, messages: list[dict]) -> dict:
        payload = {"model": self.model, "messages": messages, "max_tokens": self.max_output_tokens,
                   "stream": False, "temperature": self.temperature}
        if self.sampling_seed is not None:
            payload["seed"] = self.sampling_seed
        need(len(canonical(payload).encode()) <= 120000, "BUDGET.CONTEXT_TOO_LARGE")
        return payload

    def _send(self, payload: dict, request_id: str, retry_count: int = 0) -> dict:
        self.preflight()
        started_at, start = utc_now(), time.perf_counter_ns()
        need(not self.key or self.key not in canonical(payload), "SECURITY.SECRET_IN_PAYLOAD")
        headers = {"Content-Type": "application/json", "X-Client-Request-Id": request_id}
        if self.key:
            headers["Authorization"] = "Bearer " + self.key
        request = urllib.request.Request(self.base + "/chat/completions", data=canonical(payload).encode(),
                                         headers=headers, method="POST")
        status = None
        raw = None
        error = None
        upstream_request_id = None
        truncated = False
        original_hash = None
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                status = response.status
                upstream_request_id = response.headers.get("x-request-id") or response.headers.get("request-id")
                data = response.read(160001)
                original_hash = sha_bytes(data)
                if len(data) > 160000:
                    truncated, error = True, "PROVIDER.RESPONSE_TOO_LARGE"
                    data = data[:160000]
                raw = data.decode("utf-8", errors="strict")
        except urllib.error.HTTPError as exc:
            status = exc.code
            data = exc.read(160001)
            original_hash = sha_bytes(data)
            truncated = len(data) > 160000
            raw = data[:160000].decode("utf-8", errors="replace")
            upstream_request_id = exc.headers.get("x-request-id") if exc.headers else None
            error = "EXEC.TIMEOUT_UNCERTAIN" if status >= 500 or status == 408 else f"PROVIDER.HTTP_{status}"
            exc.close()
        except HarnessError as exc:
            error = exc.code
        except (OSError, UnicodeError, urllib.error.URLError, TimeoutError):
            error = "EXEC.TIMEOUT_UNCERTAIN"
        elapsed = (time.perf_counter_ns() - start) / 1e6
        redacted = False
        if self.key and raw and self.key in raw:
            raw, redacted, error = raw.replace(self.key, "[REDACTED_SECRET]"), True, "SECURITY.SECRET_ECHO"
        if self.key and upstream_request_id and self.key in upstream_request_id:
            upstream_request_id, redacted, error = "[REDACTED_SECRET]", True, "SECURITY.SECRET_ECHO"
        body = {}
        if raw is not None:
            try:
                parsed = parse(raw)
                if isinstance(parsed, dict):
                    body = parsed
            except HarnessError:
                pass
        choices = body.get("choices")
        choice = choices[0] if isinstance(choices, list) and choices and isinstance(choices[0], dict) else {}
        telemetry = {"request_id": request_id, "provider_response_id": body.get("id"),
            "provider_request_id": upstream_request_id, "requested_model": self.model,
            "model": body.get("model"), "base_url": self.base, "start_time": started_at, "end_time": utc_now(),
            "latency_ms": elapsed, "http_status": status, "retry_count": retry_count,
            "finish_reason": choice.get("finish_reason"), "provider_cost_usd": None,
            "wire_request": payload, "wire_request_sha256": digest(payload),
            "response_redacted": redacted, "response_truncated": truncated,
            "received_bytes_sha256": original_hash, **usage_fields(body)}
        return {"raw": raw, "transport": self.kind, "elapsed_ms": elapsed,
                "error_code": error, "telemetry": telemetry}

    def health_sync(self) -> dict:
        """Exactly one small authorized generation after config checks; never a fake ping."""
        base = {"schema_version": 1, "timestamp": utc_now(), "provider": self.metadata(),
                "execution_kind": self.kind, "model_calls": 0, "real_model_calls": 0,
                "raw_evidence": None, "billing_verified": False}
        try:
            self.preflight()
        except HarnessError as exc:
            self.health_record = {**base, "status": "BLOCKED_CONFIG", "code": exc.code,
                                  "configuration": self.env_status}
            return copy.deepcopy(self.health_record)
        payload = self._payload([{"role": "system", "content": "Reply with exactly AGI_HEALTH_OK."},
                                 {"role": "user", "content": "AGI_HEALTH_OK"}])
        payload["max_tokens"] = 128
        reply = self._send(payload, str(uuid.uuid4()))
        response_seen=isinstance(reply.get("telemetry",{}).get("provider_response_id"),str) and bool(reply["telemetry"]["provider_response_id"])
        base.update(raw_evidence=reply, http_requests_attempted=1, model_calls=int(response_seen),
                    real_model_calls=int(self.kind == "external_model_api" and response_seen))
        try:
            need(not reply["error_code"], reply["error_code"] or "PROVIDER.HEALTH_FAILED")
            body = parse(reply["raw"])
            need(isinstance(body, dict), "PROVIDER.HEALTH_SCHEMA")
            need(isinstance(body.get("id"), str) and bool(body["id"]), "EVIDENCE.MISSING_RECEIPT")
            need(body.get("model") == self.model, "PROVIDER.MODEL_MISMATCH")
            need(reply["telemetry"]["http_status"] == 200, "PROVIDER.HEALTH_STATUS")
            choice = body["choices"][0]
            need(choice.get("finish_reason") == "stop", "PROVIDER.INCOMPLETE_FINISH")
            need(choice["message"]["content"].strip() == "AGI_HEALTH_OK", "PROVIDER.HEALTH_CONTENT")
            self.health_record = {**base, "status": "PASS", "code": None,
                                  "configuration_sha256": digest(self.metadata())}
        except (HarnessError, KeyError, IndexError, TypeError, AttributeError) as exc:
            self.health_record = {**base, "status": "BLOCKED_CONFIG",
                                  "code": exc.code if isinstance(exc, HarnessError) else "PROVIDER.HEALTH_SCHEMA"}
        return copy.deepcopy(self.health_record)

    def require_health(self):
        record = self.health_record
        need(record is not None and record.get("status") == "PASS", "PROVIDER.HEALTH_REQUIRED")
        need(record["configuration_sha256"] == digest(self.metadata()), "CONFIG.PROVIDER_DRIFT")
        need(record["raw_evidence"]["telemetry"]["model"] == self.model, "PROVIDER.MODEL_MISMATCH")

    def invoke(self, request: dict, history: list[dict]) -> dict:
        self.require_health()
        messages = [{"role": "system", "content": self.system}] + history + [
                    {"role": "user", "content": canonical(request)}]
        return self._send(self._payload(messages), request["request_id"], max(0, request.get("attempt", 1) - 1))

    async def generate(self, request: dict, history: list[dict]) -> dict:
        return await asyncio.to_thread(self.invoke, request, history)

    async def health(self) -> dict:
        return await asyncio.to_thread(self.health_sync)

    async def model_info(self) -> dict:
        observed = None
        if self.health_record and self.health_record.get("raw_evidence"):
            observed = self.health_record["raw_evidence"]["telemetry"].get("model")
        return {"expected_model": self.model, "observed_model": observed,
                "base_url": self.base, "source": "health_response" if observed else "configuration_only",
                "provider_attestation": "NOT_AVAILABLE", "additional_model_calls": 0}
