"""Resolve cohort/episode UUIDs locally; replay never performs model calls."""
from __future__ import annotations
from pathlib import Path
from .common import ROOT, read, need


def resolve(reference: Path, runs_root: Path | None = None):
    if reference.is_dir() and (reference/"run.json").is_file():return reference,None
    if reference.is_dir() and (reference/"trace.json").is_file():
        trace=read(reference/"trace.json")
        return reference.parent.parent,trace.get("identity",{}).get("run_id")
    target=str(reference)
    root=runs_root or ROOT/"runs"
    need(root.is_dir(),"REPLAY.RUNS_ROOT_MISSING")
    matches=[]
    configs=list(root.rglob("run.json"))
    need(len(configs)<=10000,"REPLAY.INDEX_LIMIT")
    for path in configs:
        config=read(path)
        if config.get("run_id")==target:matches.append((path.parent,None));continue
        for unit in config.get("plan",[]):
            episode_id=unit.get("episode_id","")
            need(Path(episode_id).name==episode_id and episode_id not in (".","..","") and "\\" not in episode_id,"PLAN.UNSAFE_EPISODE_PATH")
            trace_path=path.parent/"episodes"/episode_id/"trace.json"
            if trace_path.is_file():
                trace=read(trace_path)
                if trace.get("identity",{}).get("run_id")==target:matches.append((path.parent,target))
    need(len(matches)==1,"REPLAY.RUN_ID_NOT_FOUND_OR_AMBIGUOUS")
    return matches[0]
