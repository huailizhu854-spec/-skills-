"""Small measured-data contextual routing experiment; never an LLM weight update."""
from __future__ import annotations
import random
from collections import defaultdict
from .common import need
from .benchmark import task_by_id, public_input

ACTIONS = ("single", "dual8", "dual16")
RIDGES = (.01, .1, 1., 10.)


def task_features(task_id, training_failure_prior):
    task = task_by_id(task_id)
    public = public_input(task)
    task_number = int(task_id[2:5])
    # Preregistered before model outcomes; no oracle access and no held-out label lookup.
    task_type = {1:"csv",2:"dedupe",3:"dag",4:"ownership",5:"retry",6:"budget"}[task_number]
    complexity = {1:1,2:2,3:3,4:2,5:2,6:1}[task_number]
    return {"task_type":task_type,"file_count":len(public),"dependency_depth":2 if task_number==3 else 1,
            "expected_parallelism":1,"risk":2 if task_number in (4,5,6) else 1,
            "complexity":complexity,"historical_failure_rate":training_failure_prior}


def vector(features):
    types=("csv","dedupe","dag","ownership","retry","budget")
    return [1.,features["file_count"]/5,features["dependency_depth"]/5,features["expected_parallelism"]/16,
            features["risk"]/5,features["complexity"]/5,features["historical_failure_rate"],
            *[float(features["task_type"]==kind) for kind in types]]


def solve(matrix, rhs):
    a=[list(row)+[b] for row,b in zip(matrix,rhs)]
    n=len(rhs)
    for col in range(n):
        pivot=max(range(col,n),key=lambda row:abs(a[row][col]))
        need(abs(a[pivot][col])>1e-12,"RL.SINGULAR_FIT")
        a[col],a[pivot]=a[pivot],a[col]
        d=a[col][col];a[col]=[x/d for x in a[col]]
        for row in range(n):
            if row==col:continue
            factor=a[row][col]
            a[row]=[x-factor*y for x,y in zip(a[row],a[col])]
    return [row[-1] for row in a]


def fit(xs,ys,ridge):
    n=len(xs[0])
    return solve([[sum(x[i]*x[j] for x in xs)+(ridge if i==j else 0) for j in range(n)] for i in range(n)],
                 [sum(x[i]*y for x,y in zip(xs,ys)) for i in range(n)])


def experiment(evaluation, *, seed=20260928):
    need(evaluation["execution_kind"]=="external_model_api","RL.REAL_DATA_REQUIRED")
    need(evaluation.get("controls",{}).get("variant")=="full","RL.FULL_BASELINE_REQUIRED")
    rows=evaluation["rows"]
    need(len(rows)==54,"RL.FULL_54_EPISODE_BENCHMARK_REQUIRED")
    task_ids=sorted({r["task_id"] for r in rows})
    need(len(task_ids)==6 and {r["architecture"] for r in rows}==set(ACTIONS),"RL.UNPAIRED_ACTIONS")
    keys={(r["task_id"],r["architecture"],r["repetition"]) for r in rows}
    need(keys=={(t,a,r) for t in task_ids for a in ACTIONS for r in range(3)},"RL.UNPAIRED_ACTIONS")
    need(all(r.get("total_tokens") is not None and r.get("latency_ms") is not None for r in rows),"RL.MEASURED_TOKEN_AND_LATENCY_REQUIRED")
    need(all(r.get("observed_model_responses",0)>0 for r in rows),"RL.UNEXECUTED_EPISODES")
    random.Random(seed).shuffle(task_ids)
    train_ids,val_ids,test_ids=task_ids[:3],task_ids[3:4],task_ids[4:]
    train_rows=[r for r in rows if r["task_id"] in train_ids]
    prior=sum(not r["verified_success"] for r in train_rows)/len(train_rows)
    token_scale=max(1.,sum(r["total_tokens"] for r in train_rows)/len(train_rows))
    latency_scale=max(1.,sum(r["latency_ms"] for r in train_rows)/len(train_rows))
    def utility(r):
        return (2*int(r["verified_success"])+.5*int(r["first_pass_success"])
            -.15*r["total_tokens"]/token_scale-.15*r["latency_ms"]/latency_scale
            -.1*r["extra_attempts"]-2*int(r["false_success"])-.5*int(r.get("artifact_conflict",False)))
    groups=defaultdict(list)
    for row in rows:groups[(row["task_id"],row["architecture"])].append(row)
    means={k:sum(utility(r) for r in rs)/len(rs) for k,rs in groups.items()}
    features={t:task_features(t,prior) for t in task_ids}
    xs={t:vector(features[t]) for t in task_ids}
    def predict(weights,task):
        scores={a:sum(w*x for w,x in zip(weights[a],xs[task])) for a in ACTIONS}
        return max(ACTIONS,key=lambda a:scores[a])
    candidates=[]
    for ridge in RIDGES:
        weights={a:fit([xs[t] for t in train_ids],[means[(t,a)] for t in train_ids],ridge) for a in ACTIONS}
        score=sum(means[(t,predict(weights,t))] for t in val_ids)/len(val_ids)
        candidates.append((score,ridge,weights))
    # Stable selection uses validation only; the held-out test never chooses a ridge or reward.
    score,ridge,weights=max(candidates,key=lambda item:(item[0],-item[1]))
    baselines=[]
    for name in (*["always_"+a for a in ACTIONS],"uniform","learned_router"):
        chosen={t:(predict(weights,t) if name=="learned_router" else name.removeprefix("always_")) for t in test_ids}
        values=[];successes=[];tokens=[];latencies=[]
        for task in test_ids:
            actions=ACTIONS if name=="uniform" else (chosen[task],)
            matched=[r for a in actions for r in groups[(task,a)]]
            values.append(sum(utility(r) for r in matched)/len(matched))
            successes.append(sum(r["verified_success"] for r in matched)/len(matched))
            tokens.append(sum(r["total_tokens"] for r in matched)/len(matched))
            latencies.append(sum(r["latency_ms"] for r in matched)/len(matched))
        baselines.append({"policy":name,"held_out_tasks":len(test_ids),"mean_reward":sum(values)/len(values),
            "verified_success_rate":sum(successes)/len(successes),"mean_tokens":sum(tokens)/len(tokens),
            "mean_latency_ms":sum(latencies)/len(latencies),"provider_cost_usd":None,
            "actions":chosen if name!="uniform" else {t:{a:1/len(ACTIONS) for a in ACTIONS} for t in test_ids}})
    return {"status":"EXECUTED","population":"MEASURED_EXTERNAL_MODEL_DATA","method":"ridge contextual reward model + argmax",
        "train_task_ids":train_ids,"validation_task_ids":val_ids,"held_out_test_task_ids":test_ids,
        "selected_ridge":ridge,"validation_mean_reward":score,"weights":weights,"features":features,
        "normalization_source":"training split only","token_scale":token_scale,"latency_scale":latency_scale,
        "reward_spec":"2*success + .5*firstpass - .15*tokens/train_mean - .15*latency/train_mean - .1*retries -2*false_success -.5*conflict",
        "cost_proxy":"observed token consumption; not USD cost","baselines":baselines,
        "supported_actions":list(ACTIONS),"dual16_strict":"MASKED_NO_LIVE_ACTION_DATA",
        "source_seal_sha256":evaluation["source_seal_sha256"],"production_routing_changed":False,
        "llm_weight_training":"NOT_EXECUTED","statistical_power":"low statistical power: 3 train / 1 validation / 2 test tasks",
        "statement":"This is policy optimization over orchestration actions, not LLM weight-level GRPO."}
