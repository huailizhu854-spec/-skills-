"""Observe every stored call independently of where protocol grading first fails."""
from __future__ import annotations
from collections import Counter
from .common import HarnessError, parse
from .live_provider import usage_fields
from .statistics import distribution


def observe_trace(trace):
    calls = trace.get("calls", [])
    observed, inputs, outputs, all_latency, controller_latency, worker_latency = [], [], [], [], [], []
    usage_missing = 0
    conflicts = 0
    declared = False
    attempts = Counter()
    for call in calls:
        elapsed = call.get("elapsed_ms")
        all_latency.append(elapsed)
        q = call.get("request", {})
        attempts[(q.get("slot"),q.get("phase"))] += 1
        (controller_latency if q.get("slot", "").startswith("control-") else worker_latency).append(elapsed)
        body = {}
        try:
            raw = call.get("raw_response")
            value = parse(raw) if isinstance(raw, str) else {}
            body = value if isinstance(value, dict) else {}
        except HarnessError: pass
        rid = body.get("id")
        if isinstance(rid, str) and rid:
            observed.append(rid)
        usage = usage_fields(body)
        if usage["token_usage_status"] == "provider_reported":
            inputs.append(usage["input_tokens"]); outputs.append(usage["output_tokens"])
        else: usage_missing += 1
        try:
            wrapper = parse(body["choices"][0]["message"]["content"])
            result = wrapper["result"]
            if q.get("phase") == "implement" and q.get("slot") == "w01" and result.get("claimed_success") is True:
                declared = True
            if q.get("phase") == "inspect" and isinstance(result.get("files"), dict):
                conflicts += len(result["files"])
        except (HarnessError, KeyError, IndexError, TypeError, AttributeError): pass
    live = trace.get("execution_kind") == "external_model_api"
    complete = live and bool(calls) and not usage_missing
    return {"observed_response_ids": observed, "observed_model_responses": len(observed) if live else 0,
            "real_model_calls": len(set(observed)) if live else 0, "provider_requests_attempted": len(calls),
            "input_tokens": sum(inputs) if complete else None, "output_tokens": sum(outputs) if complete else None,
            "total_tokens": sum(inputs)+sum(outputs) if complete else None,
            "known_input_tokens": sum(inputs) if inputs and live else None,
            "known_output_tokens": sum(outputs) if outputs and live else None,
            "usage_coverage": len(inputs)/len(calls) if calls else 0,
            "token_usage_status": "provider_reported" if complete else "unknown",
            "provider_cost_usd": None, "billed_cost_usd": None,
            "artifact_conflict_attempts": conflicts, "artifact_conflict": conflicts > 0,
            "declared_success_from_raw": declared, "provider_call_latency_ms": distribution(all_latency),
            "controller_latency_ms": distribution(controller_latency), "worker_latency_ms": distribution(worker_latency),
            "extra_attempts":sum(max(0,n-1) for n in attempts.values()),
            "rework_definition": "completed-response repair attempts only; reviewer veto does not synthesize a repair",
            "http_statuses": [c.get("telemetry", {}).get("http_status") for c in calls]}
