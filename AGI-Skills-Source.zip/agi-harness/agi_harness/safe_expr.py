"""A finite AST interpreter for the TWO predicate benchmark tasks, not Python exec.
No calls, attributes, imports, loops, comprehensions, I/O, dynamic annotations or bytecode.
Unsupported correct Python is rejected as outside this deliberately narrow grammar.
"""
from __future__ import annotations
import ast
import itertools
import operator
from .common import need, HarnessError

OPS = {ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Lt: operator.lt,
       ast.LtE: operator.le, ast.Gt: operator.gt, ast.GtE: operator.ge,
       ast.In: lambda a, b: a in b, ast.NotIn: lambda a, b: a not in b,
       ast.Is: operator.is_, ast.IsNot: operator.is_not}
ALLOWED = (ast.Module, ast.FunctionDef, ast.arguments, ast.arg, ast.Return, ast.If, ast.Expr,
           ast.Constant, ast.Name, ast.Load, ast.BoolOp, ast.And, ast.Or, ast.UnaryOp, ast.Not,
           ast.USub, ast.Compare, ast.Tuple, ast.List, *OPS)

class Predicate:
    def __init__(self, text: str, name: str, args: list[str], defaults: list):
        need(len(text) <= 16000, "GRADER.UNSUPPORTED_PROGRAM")
        try:
            tree = ast.parse(text)
        except (SyntaxError, RecursionError, ValueError):
            raise HarnessError("GRADER.UNSUPPORTED_PROGRAM")
        nodes = list(ast.walk(tree))
        need(len(nodes) <= 180, "GRADER.UNSUPPORTED_PROGRAM")
        need(all(isinstance(n, ALLOWED) for n in nodes), "GRADER.UNSUPPORTED_PROGRAM")
        need(sum(isinstance(n, ast.FunctionDef) for n in nodes) == 1, "GRADER.UNSUPPORTED_PROGRAM")
        need(len(tree.body) == 1 and isinstance(tree.body[0], ast.FunctionDef), "GRADER.UNSUPPORTED_PROGRAM")
        f = tree.body[0]
        need(f.name == name and not f.decorator_list and not f.type_params, "GRADER.SIGNATURE_CHANGED")
        need([a.arg for a in f.args.args] == args and not f.args.posonlyargs and not f.args.kwonlyargs
             and f.args.vararg is None and f.args.kwarg is None, "GRADER.SIGNATURE_CHANGED")
        need(len(f.args.defaults) == len(defaults), "GRADER.SIGNATURE_CHANGED")
        for n, value in zip(f.args.defaults, defaults):
            need(isinstance(n, ast.Constant) and type(n.value) is type(value) and n.value == value, "GRADER.SIGNATURE_CHANGED")
        for n in nodes:
            if isinstance(n, ast.Constant):
                need(type(n.value) in (str, bool, int, float, type(None)), "GRADER.UNSUPPORTED_PROGRAM")
                need(not isinstance(n.value, str) or len(n.value) <= 2000, "GRADER.UNSUPPORTED_PROGRAM")
                if type(n.value) in (int, float):
                    need(-1e12 <= n.value <= 1e12, "GRADER.UNSUPPORTED_PROGRAM")
            if isinstance(n, ast.Name):
                need(n.id in args + ["int", "bool", "float"], "GRADER.UNSUPPORTED_PROGRAM")
            if isinstance(n, ast.Expr):
                need(isinstance(n.value, ast.Constant) and isinstance(n.value.value, str), "GRADER.UNSUPPORTED_PROGRAM")
        self.body, self.args, self.defaults = f.body, args, defaults

    def expr(self, n, env):
        if isinstance(n, ast.Constant): return n.value
        if isinstance(n, ast.Name): return env[n.id]
        if isinstance(n, (ast.Tuple, ast.List)): return tuple(self.expr(x, env) for x in n.elts)
        if isinstance(n, ast.UnaryOp):
            v = self.expr(n.operand, env)
            return not v if isinstance(n.op, ast.Not) else -v
        if isinstance(n, ast.BoolOp):
            value = self.expr(n.values[0], env)
            for child in n.values[1:]:
                if isinstance(n.op, ast.And) and not value: return value
                if isinstance(n.op, ast.Or) and value: return value
                value = self.expr(child, env)
            return value
        if isinstance(n, ast.Compare):
            left = self.expr(n.left, env)
            for op, right_expr in zip(n.ops, n.comparators):
                right = self.expr(right_expr, env)
                if not OPS[type(op)](left, right): return False
                left = right
            return True
        raise HarnessError("GRADER.UNSUPPORTED_PROGRAM")

    def block(self, stmts, env):
        for stmt in stmts:
            if isinstance(stmt, ast.Return): return True, self.expr(stmt.value, env)
            if isinstance(stmt, ast.If):
                done, value = self.block(stmt.body if self.expr(stmt.test, env) else stmt.orelse, env)
                if done: return True, value
            elif not isinstance(stmt, ast.Expr):
                raise HarnessError("GRADER.UNSUPPORTED_PROGRAM")
        return False, None

    def __call__(self, *args):
        provided = list(args)
        while len(provided) < len(self.args):
            provided.append(self.defaults[len(provided) - (len(self.args) - len(self.defaults))])
        try:
            return self.block(self.body, dict(zip(self.args, provided)))[1]
        except (TypeError, KeyError, IndexError):
            raise HarnessError("GRADER.UNSUPPORTED_PROGRAM")

def grade_predicate(task_id: str, content: str) -> dict:
    if task_id.startswith("tb005"):
        fn = Predicate(content, "should_retry", ["status", "uncertain", "attempts", "max_attempts"], [2])
        cases = list(itertools.product([200, 400, 408, 429, 500, 502], [False, True], range(4), range(4)))
        oracle = lambda s, u, a, m: s in (408, 429) and not u and a < m
    else:
        fn = Predicate(content, "within_budget", ["cost_usd", "latency_ms", "max_cost_usd", "max_latency_ms"], [])
        cases = list(itertools.product([0.0, .01, .02, .03], [0, 1000, 2000, 3000], [.0, .02], [0, 2000]))
        oracle = lambda c, l, mc, ml: c <= mc and l <= ml
    failed = sum(fn(*case) is not oracle(*case) for case in cases)
    return {"passed": failed == 0, "checks": len(cases), "failed_checks": failed,
            "code": None if not failed else "TASK.INCORRECT_OUTPUT", "grader": "restricted-ast-predicate-v2"}
