from __future__ import annotations
from collections import Counter
from pathlib import Path
import time
from .common import read, parse, digest, sha_bytes, file_map, need, HarnessError, finite_nonnegative
from .benchmark import verify_benchmark, BENCHMARK_ID, GRADER_VERSION, task_by_id, grade_artifact, public_input, output_name
from .contracts import roster, group, opposite, decode
from .runtime import protocol_fingerprint
from .ablation import controls_for, validate_controls
from .telemetry import observe_trace


def verify_seal(run_dir: Path) -> dict:
    seal = read(run_dir/"seal.json")
    expected = seal.get("files")
    need(isinstance(expected,dict) and "run.json" in expected, "EVIDENCE.SEAL_INVALID")
    need(not (run_dir/"run.json").is_symlink(),"ARTIFACT.SYMLINK")
    actual = {"run.json":sha_bytes((run_dir/"run.json").read_bytes())}
    actual.update({"episodes/"+p:h for p,h in file_map(run_dir/"episodes").items()})
    need(expected == actual, "EVIDENCE.SEAL_MISMATCH")
    return read(run_dir/"run.json")


def check_journal(path: Path, trace: dict):
    head, intents, responses = "0"*64, {}, {}
    lines = path.read_text(encoding="utf-8").splitlines()
    need(bool(lines), "EVIDENCE.JOURNAL_MISSING")
    end = None
    for i,line in enumerate(lines):
        e=parse(line)
        need(e.get("seq")==i and e.get("prev")==head, "EVIDENCE.JOURNAL_CHAIN")
        h=e.pop("hash",None)
        need(digest(e)==h, "EVIDENCE.JOURNAL_CHAIN")
        head=h
        if e["kind"]=="DISPATCH_INTENT":
            p=e["payload"];need(p["request_id"] not in intents,"EVIDENCE.DUPLICATE_REQUEST")
            intents[p["request_id"]]=p
        if e["kind"] in ("RESPONSE","TRANSPORT_ERROR"):
            p=e["payload"]
            need(p["request_id"] in intents and p["request_id"] not in responses,"EVIDENCE.JOURNAL_ORDER")
            responses[p["request_id"]]=p
        if e["kind"]=="END":
            need(i==len(lines)-1,"EVIDENCE.JOURNAL_ORDER");end=e["payload"]
    need(head==trace["journal_head"],"EVIDENCE.JOURNAL_CHAIN")
    need(end and end["status"]==trace["status"] and end["calls"]==len(trace["calls"]),"EVIDENCE.JOURNAL_END")
    need(len(intents)==len(responses)==len(trace["calls"]),"EXEC.UNRESOLVED_INTENT")
    for c in trace["calls"]:
        key=c["request"]["request_id"]
        need(intents[key]["request_hash"]==digest(c["request"]) and responses[key]["call_hash"]==digest(c),"EVIDENCE.JOURNAL_RECEIPT")
        need(intents[key]["slot"]==c["request"]["slot"] and intents[key]["context_id"]==c["context_id"],"DELEGATION.CONTEXT_MISMATCH")


def grade_episode(path: Path, config: dict, unit: dict) -> dict:
    t=read(path/"trace.json")
    failures=[];latest={};ids=set();nonces=set();request_ids=set();counts=Counter();contexts=set()
    observed=observe_trace(t)
    declared=observed["declared_success_from_raw"]
    controls=validate_controls(config.get("controls",controls_for()))
    usage_in=[];usage_out=[];usage_missing=0
    task_grade={"passed":False,"code":"TASK.NOT_GRADED"}
    def add(code):
        if code not in failures: failures.append(code)
    try:
        need(t.get("schema_version")==1 and bool(t.get("calls")),"EVIDENCE.EMPTY_OR_INVALID_TRACE")
        need(t["task_id"]==unit["task_id"] and t["architecture"]==unit["architecture"] and t["seed"]==unit["seed"],"EVIDENCE.UNIT_MISMATCH")
        need(t["execution_kind"]==config["execution_kind"],"EVIDENCE.MIXED_EXECUTION")
        need(t["limits"]==config["limits"],"BUDGET.CONFIG_MISMATCH")
        need(t.get("controls",controls_for())==controls,"ABLATION.CONFIG_MISMATCH")
        if config.get("run_id"):
            need(t.get("identity",{}).get("cohort_run_id")==config["run_id"],"EVIDENCE.RUN_ID_MISMATCH")
            need(t.get("identity",{}).get("run_id")==unit.get("run_id"),"EVIDENCE.EPISODE_RUN_ID_MISMATCH")
        need(t["public_files"]==public_input(task_by_id(t["task_id"])),"EVIDENCE.PUBLIC_INPUT_MISMATCH")
        r=roster(t["architecture"]);slots=r["controllers"]+r["workers"]
        need(set(t["context_ids"])==set(slots) and len(set(t["context_ids"].values()))==len(slots),"DELEGATION.MISSING_OR_SHARED_CONTEXT")
        check_journal(path/"events.jsonl",t)
        need(len(t["calls"])<=t["limits"]["max_requests"],"BUDGET.REQUEST_LIMIT")
        for c in t["calls"]:
            q=c["request"];slot=q["slot"];phase=q["phase"]
            need(slot in slots and q["task_id"]==t["task_id"],"DELEGATION.WRONG_SLOT")
            need(c["context_id"]==t["context_ids"][slot],"DELEGATION.CONTEXT_MISMATCH")
            need(c["transport"]==t["execution_kind"],"EVIDENCE.MIXED_EXECUTION")
            need(q["public_files"]==t["public_files"] and q["output_name"]==output_name(t["task_id"]),"EVIDENCE.INPUT_MISMATCH")
            need(c["request_hash"]==digest(q),"EVIDENCE.PROMPT_HASH_MISMATCH")
            need(q["nonce"] not in nonces and q["request_id"] not in request_ids,"EVIDENCE.DUPLICATE_REQUEST")
            nonces.add(q["nonce"]);request_ids.add(q["request_id"])
            counts[(slot,phase)]+=1
            need(q["attempt"]==counts[(slot,phase)]<=t["limits"]["max_attempts"],"RECOVERY.RETRY_BUDGET_EXCEEDED")
            if phase=="plan":
                need(slot in r["controllers"] and q["assigned_workers"]==group(r,slot),"DELEGATION.WRONG_CONTROLLER")
                need(q["responsibilities"]=={w:r["responsibilities"][w] for w in group(r,slot)},"PLAN.RESPONSIBILITY_MISMATCH")
            elif phase in ("implement","inspect"):
                need(slot in r["workers"] and q["controller"]==r["owner"][slot],"DELEGATION.WRONG_CONTROLLER")
                need(q["responsibility"]==r["responsibilities"][slot],"PLAN.RESPONSIBILITY_MISMATCH")
                if r["controllers"]:
                    plan=latest.get((r["owner"][slot],"plan"))
                    need(plan is not None,"DELEGATION.MISSING_PLAN_RECEIPT")
                    assignment=next(a for a in plan["assignments"] if a["slot"]==slot)
                    need(q["assignment"]==assignment["instruction"],"DELEGATION.ASSIGNMENT_MISMATCH")
                if phase=="implement":need(slot=="w01","ARTIFACT.OUTSIDE_OWNERSHIP")
                else:
                    need(slot!="w01" and ("w01","implement") in latest,"PLAN.DEPENDENCY_UNMET")
                    need(q["candidate"]==latest[("w01","implement")]["files"],"EVIDENCE.STALE_CANDIDATE")
            elif phase=="review":
                need(slot in r["controllers"],"VERIFY.WRONG_REVIEWER")
                expected=group(r,opposite(slot));need(set(q["review_evidence"])==set(expected),"VERIFY.WRONG_REVIEWER")
                for w,e in q["review_evidence"].items():
                    output=latest.get((w,"implement" if w=="w01" else "inspect"))
                    need(output is not None and e=={"sha256":digest(output),"output":output},"VERIFY.STALE_HASH")
            else:need(False,"PLAN.UNKNOWN_PHASE")
            if c["raw_response"] is None:
                need(bool(c["error"]) and not c["valid_contract"],"EVIDENCE.MISSING_RECEIPT")
                add(c["error"]);usage_missing+=1;continue
            raw=c["raw_response"]
            need(sha_bytes(raw.encode())==c["raw_sha256"],"EVIDENCE.HASH_MISMATCH")
            body=parse(raw)
            rid=body.get("id")
            if rid:
                need(rid not in ids,"EXEC.DUPLICATE_PROVIDER_RESPONSE");ids.add(rid)
            if config["provider"].get("adapter_version") == "strict-http-v1":
                telemetry=c.get("telemetry",{})
                if telemetry.get("http_status") != 200 and c.get("error"):
                    add(c["error"])
                    continue
                need(body.get("model")==config["provider"]["model"],"PROVIDER.MODEL_MISMATCH")
                need(telemetry.get("model")==body.get("model"),"EVIDENCE.MODEL_TELEMETRY_MISMATCH")
                need(telemetry.get("request_id")==q["request_id"],"EVIDENCE.REQUEST_ID_MISMATCH")
                need(telemetry.get("base_url")==config["provider"]["base_url"],"CONFIG.PROVIDER_DRIFT")
                need(telemetry.get("provider_response_id")==rid,"EVIDENCE.RESPONSE_ID_MISMATCH")
                need(telemetry.get("wire_request_sha256")==digest(telemetry.get("wire_request")),"EVIDENCE.WIRE_REQUEST_HASH")
                need(telemetry.get("http_status")==200,"PROVIDER.INVALID_HTTP_STATUS")
                need(body["choices"][0].get("finish_reason")=="stop","PROVIDER.INCOMPLETE_FINISH")
            usage=body.get("usage",{})
            if type(usage) is dict and type(usage.get("prompt_tokens")) is int and type(usage.get("completion_tokens")) is int and usage["prompt_tokens"]>=0 and usage["completion_tokens"]>=0:
                usage_in.append(usage["prompt_tokens"]);usage_out.append(usage["completion_tokens"])
            else:usage_missing+=1
            try:
                _,result=decode(q,raw)
            except HarnessError as e:
                if not controls["replay_protection"]:
                    add(e.code)  # independent shadow grading never disables the guard
                else:
                    need(not c["valid_contract"] and c["error"]==e.code,"EVIDENCE.RESULT_FLAG_MISMATCH")
                continue
            need(c["valid_contract"] and c["error"] is None,"EVIDENCE.RESULT_FLAG_MISMATCH")
            latest[(slot,phase)]=result;contexts.add(slot)
            if phase=="implement":declared=result["claimed_success"]
        need(t["status"]=="EXECUTED_UNGRADED" and t["error"] is None,t.get("error") or "EXEC.INCOMPLETE")
        need(contexts==set(slots),"DELEGATION.MISSING_SESSION")
        for c in r["controllers"]:
            need((c,"plan") in latest,"DELEGATION.MISSING_PLAN_RECEIPT")
            if controls["cross_review"]:
                need((c,"review") in latest,"VERIFY.MISSING_REVIEW")
                need(all(d["decision"]=="accept" for d in latest[(c,"review")]["decisions"]),"VERIFY.REVIEW_REJECTED")
            else:
                need((c,"review") not in latest,"ABLATION.UNEXPECTED_REVIEW")
        if observed["artifact_conflict"]:
            add("ARTIFACT.OUTSIDE_OWNERSHIP")
        for w in r["workers"][1:]:
            need(latest.get((w,"inspect"),{}).get("passed") is True,"VERIFY.WORKER_REJECTED")
        solution=latest[("w01","implement")]["files"]
        actual=file_map(path/"artifacts")
        expected={n:sha_bytes(c.encode()) for n,c in solution.items()}
        need(actual==expected==t["artifact_sha256"],"ARTIFACT.HASH_MISMATCH")
        task_grade=grade_artifact(t["task_id"],solution)
        if not task_grade["passed"]:add(task_grade["code"])
        need(finite_nonnegative(t["latency_ms"]),"METRICS.INVALID_LATENCY")
        if t["latency_ms"]>task_by_id(t["task_id"])["latency_slo_ms"]:add("LATENCY.SLO_BREACH")
    except HarnessError as e:add(e.code)
    except (KeyError, TypeError, IndexError, ValueError, StopIteration):add("EVIDENCE.INVALID_SCHEMA")
    live=t.get("execution_kind")=="external_model_api"
    # Metering is an independent full-trace pass, including replies after the first fatal error.
    complete_usage=observed["token_usage_status"]=="provider_reported"
    usage_in=[observed["input_tokens"]] if complete_usage else []
    usage_out=[observed["output_tokens"]] if complete_usage else []
    declared=observed["declared_success_from_raw"]
    try:
        actual_files={p.name:p.read_text(encoding="utf-8") for p in (path/"artifacts").iterdir()
                      if p.is_file() and not p.is_symlink()}
        if actual_files:
            task_grade=grade_artifact(unit["task_id"],actual_files)
            if not task_grade["passed"]:add(task_grade["code"])
    except (OSError, UnicodeError):add("ARTIFACT.UNREADABLE")
    rate=config.get("rate_card")
    cost=None
    if complete_usage and rate:
        cost=(sum(usage_in)*rate["input_per_million_usd"]+sum(usage_out)*rate["output_per_million_usd"])/1_000_000
        if cost>task_by_id(unit["task_id"])["cost_budget_usd"]:add("COST.BUDGET_EXCEEDED")
    if declared and failures:add("VERIFY.FALSE_SUCCESS")
    return {"episode_id":unit["episode_id"],"task_id":unit["task_id"],"architecture":unit["architecture"],
        "repetition":unit["repetition"],"seed":unit["seed"],"execution_kind":t.get("execution_kind"),
        "verified_success":not failures,"task_grade":task_grade,"failures":failures,
        "declared_success":declared,"false_success":declared and bool(failures),
        "first_pass_success":not failures and all(n==1 for n in counts.values()),
        "extra_attempts":sum(max(0,n-1) for n in counts.values()),
        "latency_ms":t.get("latency_ms"),"calls_attempted":len(t.get("calls",[])),
        "validated_contexts":len(contexts),"real_model_calls":len(ids) if live else 0,
        "input_tokens":sum(usage_in) if complete_usage else None,"output_tokens":sum(usage_out) if complete_usage else None,
        "usage_coverage":len(usage_in)/len(t["calls"]) if t.get("calls") else 0,
        "estimated_cost_usd":cost,"billed_cost_usd":None,
        "cost_note":"flat input/output rate-card estimate; missing usage/rate is null, never zero",
        "native_subagents":0,"trace_hash":digest(t),
        **{k:v for k,v in observed.items() if k not in ("observed_response_ids","declared_success_from_raw")},
        "run_id":t.get("identity",{}).get("run_id"),"cohort_run_id":config.get("run_id"),"episode_wall_clock_ms":t.get("latency_ms"),
        "operational_success":(not failures if controls["independent_grader"] else
            t.get("status")=="EXECUTED_UNGRADED" and declared),
        "operational_accepted_before_shadow":t.get("status")=="EXECUTED_UNGRADED" and declared,
        "shadow_grader_enabled":True,"ablation":controls["variant"]}


def evaluate(run_dir: Path, *, profile=None) -> dict:
    config=verify_seal(run_dir)
    need(config["benchmark_id"]==BENCHMARK_ID and config["benchmark_hash"]==verify_benchmark(),"BENCHMARK.VERSION_MISMATCH")
    need(config["grader_version"]==GRADER_VERSION,"GRADER.VERSION_MISMATCH")
    need(config["protocol_hash"]==protocol_fingerprint(),"PROTOCOL.VERSION_MISMATCH")
    if config["execution_kind"]=="external_model_api":
        health=config.get("provider_health")
        need(isinstance(health,dict) and health.get("execution_kind")=="external_model_api","PROVIDER.HEALTH_EVIDENCE_REQUIRED")
        need(health.get("configuration_sha256")==digest(config["provider"]),"CONFIG.PROVIDER_DRIFT")
        evidence=health.get("raw_evidence",{})
        body=parse(evidence.get("raw") or "{}")
        need(isinstance(body,dict),"PROVIDER.HEALTH_SCHEMA")
        need(isinstance(body.get("id"),str) and bool(body["id"]),"EVIDENCE.MISSING_RECEIPT")
        need(body.get("model")==config["provider"]["model"],"PROVIDER.MODEL_MISMATCH")
        need(evidence.get("telemetry",{}).get("http_status")==200 and not evidence.get("error_code"),"PROVIDER.HEALTH_STATUS")
        try:
            need(body["choices"][0]["finish_reason"]=="stop" and body["choices"][0]["message"]["content"].strip()=="AGI_HEALTH_OK","PROVIDER.HEALTH_CONTENT")
        except (KeyError,IndexError,TypeError,AttributeError):
            raise HarnessError("PROVIDER.HEALTH_SCHEMA") from None
    plan=config["plan"]
    need(isinstance(plan,list) and all(isinstance(unit,dict) and isinstance(unit.get("episode_id"),str)
         and Path(unit["episode_id"]).name==unit["episode_id"] and unit["episode_id"] not in (".","..","")
         and "\\" not in unit["episode_id"] for unit in plan),"PLAN.UNSAFE_EPISODE_PATH")
    need(bool(plan) and len({p["episode_id"] for p in plan})==len(plan),"PLAN.EMPTY_OR_DUPLICATE")
    need(all(isinstance(u.get("run_id"),str) and u["run_id"] for u in plan)
         and len({u["run_id"] for u in plan})==len(plan),"EVIDENCE.DUPLICATE_EPISODE_RUN_ID")
    rows=[]
    for unit in plan:
        grade_started=time.perf_counter_ns()
        p=run_dir/"episodes"/unit["episode_id"]
        if not (p/"trace.json").exists():
            rows.append({**unit,"execution_kind":config["execution_kind"],"verified_success":False,
                "cohort_run_id":config.get("run_id"),"failures":["EXEC.NOT_COMPLETED"],"declared_success":False,"false_success":False,
                "first_pass_success":False,"extra_attempts":0,"latency_ms":None,"calls_attempted":0,
                "estimated_cost_usd":None,"real_model_calls":0,"validated_contexts":0})
        else:rows.append(grade_episode(p,config,unit))
        if profile is not None:
            profile.append({"episode_id":unit["episode_id"],"run_id":rows[-1].get("run_id"),
                            "grader_latency_ms":(time.perf_counter_ns()-grade_started)/1e6})
    from .metrics import aggregate
    return {"schema_version":1,"benchmark_id":BENCHMARK_ID,"benchmark_hash":config["benchmark_hash"],
        "grader_version":GRADER_VERSION,"protocol_hash":config["protocol_hash"],"execution_kind":config["execution_kind"],
        "provider":config["provider"],"limits":config["limits"],"rate_card":config["rate_card"],
        "rows":rows,"metrics":aggregate(rows),"source_seal_sha256":digest(read(run_dir/"seal.json")),
        "controls":config.get("controls",controls_for()),"run_id":config.get("run_id")}
