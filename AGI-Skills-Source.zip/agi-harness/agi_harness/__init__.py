"""AGI Agent Harness + Eval Harness: v1.0 release candidate, live-gated."""
__version__ = "1.0.0rc1"
