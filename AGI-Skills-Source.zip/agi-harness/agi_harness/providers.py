from __future__ import annotations
import csv
import io
import json
import os
import socket
import ipaddress
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from .common import canonical, parse, need, HarnessError, finite_nonnegative

FAULTS = ("none", "stale_nonce", "bad_hash_review", "wrong_group", "incorrect_output",
          "ownership_escape", "duplicate_id", "timeout_uncertain", "repair_once", "empty_receipt")

class FixtureProvider:
    """Deterministic public-input solver, NEVER a model. Does not open oracle files."""
    kind = "fixture"
    def __init__(self, fault="none"):
        need(fault in FAULTS, "CONFIG.UNKNOWN_FAULT")
        self.fault = fault
        self.lock = threading.Lock()
        self.active = 0
        self.peak = 0
        self.count = 0
    def metadata(self):
        return {"kind": self.kind, "model": "deterministic-public-solver", "fault": self.fault,
                "cost_source": "not_applicable_fixture", "sampling_seed_honored": False}
    def preflight(self): return {"ready": True, "model_calls": 0}
    def invoke(self, request: dict, history: list[dict]) -> dict:
        with self.lock:
            self.active += 1
            self.count += 1
            self.peak = max(self.peak, self.active)
        start = time.perf_counter_ns()
        try:
            time.sleep(.003)
            if self.fault == "timeout_uncertain" and request["slot"] == "w01":
                raise HarnessError("EXEC.TIMEOUT_UNCERTAIN")
            phase, slot = request["phase"], request["slot"]
            if phase == "plan":
                result = {"assignments": [{"slot": w, "work_key": "contract-" + w,
                          "instruction": request["responsibilities"][w]} for w in request["assigned_workers"]]}
                if self.fault == "wrong_group": result["assignments"][0]["slot"] = "w99"
            elif phase == "implement":
                files = {request["output_name"]: self.solve(request["task_id"], request["public_files"])}
                if self.fault == "incorrect_output": files[request["output_name"]] = "{}"
                if self.fault == "ownership_escape": files = {"../escape.txt": "must be rejected"}
                result = {"files": files, "claimed_success": True}
            elif phase == "inspect":
                result = {"analysis": "FIXTURE plumbing check for " + request["responsibility"], "passed": True}
            else:
                result = {"decisions": [{"slot": w, "output_sha256": e["sha256"], "decision": "accept"}
                                       for w, e in request["review_evidence"].items()]}
                if self.fault == "bad_hash_review": result["decisions"][0]["output_sha256"] = "0" * 64
            nonce = request["nonce"]
            if self.fault == "stale_nonce" and slot == "w01": nonce = "previous-run"
            if self.fault == "repair_once" and slot == "w07" and request["attempt"] == 1: nonce = "previous-attempt"
            content = canonical({"slot": slot, "nonce": nonce, "result": result})
            response_id = "fixture-" + str(uuid.uuid4())
            if self.fault == "duplicate_id": response_id = "fixture-always-the-same"
            body = {"id": response_id, "model": "fixture", "choices": [{"message": {"content": content}}]}
            if self.fault == "empty_receipt": body = {}
            return {"raw": canonical(body), "transport": "fixture", "elapsed_ms": (time.perf_counter_ns()-start)/1e6}
        finally:
            with self.lock: self.active -= 1
    @staticmethod
    def solve(task_id: str, files: dict[str, str]) -> str:
        if task_id.startswith("tb001"):
            rows = list(csv.DictReader(io.StringIO(files["input.csv"])))
            numbers = [int(r["amount"]) for r in rows]
            return canonical({"rows": len(rows), "total_amount": sum(numbers), "mean_amount": sum(numbers)//len(numbers)})
        if task_id.startswith("tb002"):
            best = {}
            for r in parse(files["records.json"]):
                if r["id"] not in best or r["ts"] > best[r["id"]]["ts"]: best[r["id"]] = r
            return canonical([best[k] for k in sorted(best)])
        if task_id.startswith("tb003"):
            g = parse(files["graph.json"])
            left, order = set(g["nodes"]), []
            while left:
                available = sorted(n for n in left if not any(b == n and a in left for a,b in g["edges"]))
                need(bool(available), "FIXTURE.CYCLE")
                order.append(available[0]); left.remove(available[0])
            return canonical(order)
        if task_id.startswith("tb004"):
            owners = {}
            for role in parse(files["plan.json"])["roles"]:
                for path in role["owns"]: owners.setdefault(path, set()).add(role["slot"])
            return canonical([{"path": p, "owners": sorted(v)} for p,v in sorted(owners.items()) if len(v)>1])
        if task_id.startswith("tb005"):
            return 'def should_retry(status: int, uncertain: bool, attempts: int, max_attempts: int = 2) -> bool:\n    return status in (408, 429) and not uncertain and attempts < max_attempts\n'
        return 'def within_budget(cost_usd: float, latency_ms: int, max_cost_usd: float, max_latency_ms: int) -> bool:\n    return cost_usd <= max_cost_usd and latency_ms <= max_latency_ms\n'

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise HarnessError("PROVIDER.REDIRECT_REJECTED")

class HTTPProvider:
    kind = "external_model_api"
    def __init__(self, *, allow_live=False, allow_local=False, env=None, timeout=35, max_output_tokens=1800):
        env = os.environ if env is None else env
        self.base = env.get("AGI_MODEL_BASE_URL", "").rstrip("/")
        self.model = env.get("AGI_MODEL_NAME", "")
        self.key = env.get("AGI_MODEL_API_KEY", "")
        self.host = env.get("AGI_MODEL_ALLOWED_HOST", "")
        self.cost_confirmed = env.get("AGI_ZERO_COST_CONFIRMED") == "true"
        self.authorized = env.get("AGI_TRANSPORT_AUTHORIZED") == "true"
        self.allow_live, self.allow_local = allow_live, allow_local
        self.timeout, self.max_output_tokens = timeout, max_output_tokens
        self.system = (__import__('pathlib').Path(__file__).resolve().parent.parent/"prompts/system.txt").read_text(encoding="utf-8")
        self.opener = urllib.request.build_opener(NoRedirect())
    def metadata(self):
        return {"kind": self.kind, "base_url": self.base, "model": self.model,
                "timeout_seconds": self.timeout, "max_output_tokens": self.max_output_tokens,
                "cost_source": "unknown_until_provider_usage_and_rate_card", "zero_cost_operator_confirmation": self.cost_confirmed,
                "sampling_seed_honored": False}
    def preflight(self):
        need(self.allow_live, "CONFIG.LIVE_NOT_AUTHORIZED")
        need(self.authorized, "CONFIG.TRANSPORT_NOT_AUTHORIZED")
        need(self.cost_confirmed, "CONFIG.ZERO_COST_NOT_CONFIRMED")
        need(bool(self.model) and len(self.model) < 200, "CONFIG.MODEL_MISSING")
        try: u = urllib.parse.urlsplit(self.base)
        except ValueError: raise HarnessError("CONFIG.INVALID_URL")
        need(u.hostname is not None and u.hostname == self.host, "CONFIG.HOST_NOT_ALLOWED")
        need(not u.username and not u.password and not u.query and not u.fragment, "CONFIG.INVALID_URL")
        local = u.hostname in ("localhost", "127.0.0.1", "::1")
        need(u.scheme == "https" or (self.allow_local and local and u.scheme == "http"), "CONFIG.HTTPS_REQUIRED")
        need(local and self.allow_local or bool(self.key), "CONFIG.MODEL_KEY_MISSING")
        need(1 <= self.timeout <= 120 and 128 <= self.max_output_tokens <= 8000, "CONFIG.RESOURCE_LIMIT")
        # User-specified host allowlist; do not permit public-mode access to private network addresses.
        try: addresses = socket.getaddrinfo(u.hostname, u.port or (443 if u.scheme == "https" else 80))
        except OSError: raise HarnessError("CONFIG.DNS_FAILED")
        for a in addresses:
            ip = ipaddress.ip_address(a[4][0])
            need(ip.is_global or (self.allow_local and local and ip.is_loopback), "CONFIG.PRIVATE_ADDRESS")
        return {"ready": True, "model_calls": 0, "billing_verified": False}
    def invoke(self, request: dict, history: list[dict]) -> dict:
        messages = [{"role": "system", "content": self.system}] + history + [{"role": "user", "content": canonical(request)}]
        need(len(canonical(messages).encode("utf-8")) <= 120000, "BUDGET.CONTEXT_TOO_LARGE")
        payload = canonical({"model": self.model, "messages": messages, "max_tokens": self.max_output_tokens, "stream": False}).encode("utf-8")
        headers = {"Content-Type": "application/json", "X-Client-Request-Id": request["request_id"]}
        if self.key: headers["Authorization"] = "Bearer " + self.key
        req = urllib.request.Request(self.base + "/chat/completions", data=payload, headers=headers, method="POST")
        started = time.perf_counter_ns()
        try:
            with self.opener.open(req, timeout=self.timeout) as response:
                raw = response.read(160001)
                need(len(raw) <= 160000, "PROVIDER.RESPONSE_TOO_LARGE")
                text = raw.decode("utf-8")
                return {"raw": text, "transport": self.kind, "elapsed_ms": (time.perf_counter_ns()-started)/1e6}
        except urllib.error.HTTPError as e:
            # Do not copy upstream response bodies or headers into error messages.
            raise HarnessError("EXEC.TIMEOUT_UNCERTAIN" if e.code >= 500 else f"PROVIDER.HTTP_{e.code}")
        except (OSError, UnicodeError, urllib.error.URLError):
            raise HarnessError("EXEC.TIMEOUT_UNCERTAIN")
