"""One-variable operational ablations. The outer evaluator is NEVER removed."""
from __future__ import annotations
import copy
from .common import HarnessError, need, parse, canonical
from .contracts import decode

DEFAULT_CONTROLS = {"cross_review": True, "artifact_ownership": True,
                    "independent_grader": True, "replay_protection": True}
VARIANTS = {"full": None, "no_cross_review": "cross_review",
            "no_ownership": "artifact_ownership", "no_grader": "independent_grader",
            "no_replay_guard": "replay_protection"}


def controls_for(name="full", *, experimental=False) -> dict:
    need(name in VARIANTS, "ABLATION.UNKNOWN_VARIANT")
    need(name == "full" or experimental, "ABLATION.EXPLICIT_OPT_IN_REQUIRED")
    controls = dict(DEFAULT_CONTROLS)
    if VARIANTS[name]:
        controls[VARIANTS[name]] = False
    return {"variant": name, **controls}


def validate_controls(value: dict) -> dict:
    need(value == controls_for(value.get("variant"), experimental=True), "ABLATION.MULTIPLE_VARIABLES_OR_INVALID")
    return value


def operational_decode(request, raw, controls):
    """A disabled nonce guard changes admission only, never persisted raw evidence."""
    if controls["replay_protection"]:
        return decode(request, raw)
    try:
        return decode(request, raw)
    except HarnessError as exc:
        if exc.code != "EVIDENCE.STALE_NONCE":
            raise
        body = parse(raw)
        wrapper = parse(body["choices"][0]["message"]["content"])
        wrapper["nonce"] = request["nonce"]
        patched = copy.deepcopy(body)
        patched["choices"][0]["message"]["content"] = canonical(wrapper)
        _, result = decode(request, canonical(patched))
        return body, result


class ReceiptAdmissionGuard:
    """Pure acceptance state used for guard injection tests; never resends HTTP."""
    def __init__(self, enabled=True):
        self.enabled = enabled
        self.responses, self.receipts, self.uncertain = set(), set(), set()

    def accept(self, *, request_id, response_id, receipt_id, nonce, expected_nonce,
               result_epoch, current_epoch):
        if self.enabled:
            need(request_id not in self.uncertain, "RECOVERY.REPLAYED_UNCERTAIN_CALL")
            need(nonce == expected_nonce, "EVIDENCE.STALE_NONCE")
            need(response_id not in self.responses, "EXEC.DUPLICATE_PROVIDER_RESPONSE")
            need(receipt_id not in self.receipts, "EVIDENCE.REPLAYED_RECEIPT")
            need(result_epoch == current_epoch, "EVIDENCE.OLD_RESULT")
        self.responses.add(response_id)
        self.receipts.add(receipt_id)
        return True


def replay_injection_study():
    scenarios = ("stale_nonce", "duplicate_response", "replayed_receipt", "uncertain_retry", "old_result")
    rows = []
    for enabled in (True, False):
        for scenario in scenarios:
            guard = ReceiptAdmissionGuard(enabled)
            packet = dict(request_id="request-new", response_id="response-new", receipt_id="receipt-new",
                          nonce="current", expected_nonce="current", result_epoch=2, current_epoch=2)
            if scenario == "stale_nonce": packet["nonce"] = "old"
            elif scenario == "duplicate_response": guard.responses.add(packet["response_id"])
            elif scenario == "replayed_receipt": guard.receipts.add(packet["receipt_id"])
            elif scenario == "uncertain_retry": guard.uncertain.add(packet["request_id"])
            else: packet["result_epoch"] = 1
            code = None
            try: accepted = guard.accept(**packet)
            except HarnessError as exc: accepted, code = False, exc.code
            rows.append({"scenario": scenario, "guard_enabled": enabled, "accepted": accepted, "code": code,
                         "expected_accepted": not enabled, "model_calls": 0})
    return {"population": "OFFLINE_GUARD_COMPONENT_INJECTION", "rows": rows,
            "passed": all(r["accepted"] == r["expected_accepted"] for r in rows),
            "real_model_calls": 0,
            "scope": "Receipt admission component only. The live scheduler NEVER blindly resends uncertain HTTP calls."}
