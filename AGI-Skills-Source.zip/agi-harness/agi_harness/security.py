"""Reproducible static checks, not a claim of complete security certification."""
from __future__ import annotations
import ast
import re
from pathlib import Path

PATTERNS = {
    "private_key":r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
    "api_key":r"\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}",
    "aws_access":r"\bAKIA[A-Z0-9]{16}\b",
    "github_token":r"\bgh[pousr]_[A-Za-z0-9]{30,}",
}


def scan(root: Path, known_secrets=()):
    findings=[];checked=0
    for p in sorted(root.rglob("*")):
        if "__pycache__" in p.parts or ".git" in p.parts:continue
        relative=p.relative_to(root).as_posix()
        if p.is_symlink():
            findings.append({"path":relative,"rule":"symlink"});continue
        if not p.is_file():continue
        checked+=1
        if p.name in (".env",".env.local",".env.production") or p.name.endswith(".env"):
            findings.append({"path":relative,"rule":"non_example_environment_file"})
        try:text=p.read_text(encoding="utf-8")
        except (OSError,UnicodeError):continue
        for name,pattern in PATTERNS.items():
            if re.search(pattern,text):findings.append({"path":relative,"rule":name})
        if any(secret and secret in text for secret in known_secrets):
            findings.append({"path":relative,"rule":"configured_secret_literal"})
        if p.suffix==".py" and p.parent.name=="agi_harness":
            for node in ast.walk(ast.parse(text)):
                if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in ("eval","exec"):
                    findings.append({"path":relative,"rule":"dynamic_python_execution","line":node.lineno})
    return {"status":"PASS" if not findings else "FAIL","files_checked":checked,"findings":findings,
            "scope":"credential patterns, exact provided secrets, env filenames, symlinks and dynamic Python calls in active modules",
            "limitations":"Static pattern scan is not a proof that every possible secret encoding or vulnerability is absent."}
