from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from .common import write, read, need, HarnessError
from .runtime import run
from .providers import FixtureProvider, HTTPProvider, FAULTS
from .evaluation import evaluate
from .metrics import compare
from .reporting import render, html_report


def main(argv=None):
    p=argparse.ArgumentParser(prog="agi-harness",description="Evidence-first Dual16 Agent + Eval Harness")
    sub=p.add_subparsers(dest="command",required=True)
    r=sub.add_parser("run",help="run frozen software tasks; fixture by default")
    r.add_argument("--out",type=Path,required=True)
    r.add_argument("--provider",choices=["fixture","http"],default="fixture")
    r.add_argument("--architectures",nargs="+",choices=["single","dual8","dual16"],default=["dual16"])
    r.add_argument("--experimental-baselines",action="store_true")
    r.add_argument("--repetitions",type=int,default=1);r.add_argument("--seed",type=int,default=7)
    r.add_argument("--tasks",nargs="+");r.add_argument("--fault",choices=FAULTS,default="none")
    r.add_argument("--allow-live",action="store_true");r.add_argument("--allow-local",action="store_true")
    r.add_argument("--max-requests",type=int,default=64);r.add_argument("--concurrency",type=int,default=16)
    r.add_argument("--deadline-ms",type=int,default=180000);r.add_argument("--rate-card",type=Path)
    r.add_argument("--ablation",choices=["full","no_cross_review","no_ownership","no_grader","no_replay_guard"],default="full")
    r.add_argument("--experimental-ablation",action="store_true")
    e=sub.add_parser("eval",help="independently grade sealed run without model calls")
    e.add_argument("run_dir",type=Path);e.add_argument("--out",type=Path)
    rp=sub.add_parser("replay",help="offline regrade; never re-execute inference")
    rp.add_argument("run_dir",type=Path);rp.add_argument("--runs-root",type=Path)
    co=sub.add_parser("compare",help="paired metrics with compatibility gates")
    co.add_argument("run_dirs",nargs="+",type=Path);co.add_argument("--out",type=Path,required=True)
    re=sub.add_parser("report",help="generate Markdown and escaped HTML")
    re.add_argument("run_dirs",nargs="+",type=Path);re.add_argument("--out",type=Path,required=True)
    rl=sub.add_parser("rl",help="synthetic-only contextual preference/GRPO-style lab")
    rl.add_argument("--out",type=Path,required=True);rl.add_argument("--seeds",nargs="+",type=int,default=[7,17,27]);rl.add_argument("--steps",type=int,default=300)
    rl.add_argument("--live-campaign",type=Path)
    doctor=sub.add_parser("doctor",help="offline by default; --live explicitly performs one health call")
    doctor.add_argument("--live",action="store_true");doctor.add_argument("--allow-live",action="store_true")
    doctor.add_argument("--allow-local",action="store_true");doctor.add_argument("--out",type=Path)
    live=sub.add_parser("live",help="gated real-provider campaign; no fallback")
    live.add_argument("--stage",choices=["probe","pilot","benchmark","ablation"],required=True)
    live.add_argument("--out",type=Path,required=True);live.add_argument("--allow-live",action="store_true")
    live.add_argument("--allow-local",action="store_true");live.add_argument("--seed",type=int,default=7)
    live.add_argument("--concurrency",type=int,default=2);live.add_argument("--max-requests",type=int,default=40)
    live.add_argument("--deadline-ms",type=int,default=180000);live.add_argument("--request-ceiling",type=int,required=True)
    live.add_argument("--rate-card",type=Path)
    audit=sub.add_parser("audit",help="offline static source and secret scan")
    audit.add_argument("root",type=Path,nargs="?",default=Path.cwd());audit.add_argument("--out",type=Path)
    a=p.parse_args(argv)
    try:
        if a.command=="run":
            need(a.provider=="fixture" or a.fault=="none","CONFIG.LIVE_FAULT_INJECTION_DISABLED")
            need(a.provider!="http","GATE.USE_LIVE_CAMPAIGN_COMMAND")
            provider=FixtureProvider(a.fault) if a.provider=="fixture" else HTTPProvider(allow_live=a.allow_live,allow_local=a.allow_local)
            out=run(provider,a.out,a.architectures,a.repetitions,a.seed,a.experimental_baselines,a.tasks,
                a.max_requests,a.concurrency,a.deadline_ms,read(a.rate_card) if a.rate_card else None,
                ablation=a.ablation,experimental_ablation=a.experimental_ablation)
            result={"run_dir":str(out),"status":"RUN_FINISHED_NEEDS_EVALUATION","execution_kind":provider.kind,"next":"agi-harness eval "+str(out)}
        elif a.command in ("eval","replay"):
            selected_episode=None
            if a.command=="replay":
                from .replay import resolve
                a.run_dir,selected_episode=resolve(a.run_dir,a.runs_root)
            result=evaluate(a.run_dir)
            if a.command=="eval":write(a.out or a.run_dir/"evaluation.json",result)
            else:
                prior=a.run_dir/"evaluation.json"
                same=read(prior)==result if prior.exists() else None
                need(same is not False,"REPLAY.GRADER_DRIFT")
                if selected_episode:
                    from .metrics import aggregate
                    rows=[r for r in result["rows"] if r.get("run_id")==selected_episode]
                    need(len(rows)==1,"REPLAY.EPISODE_ID_MISMATCH")
                    result["rows"],result["metrics"]=rows,aggregate(rows)
                result={"replayed":len(result["rows"]),"model_calls":0,"prior_result_equal":same,"metrics":result["metrics"],
                        "selected_episode_run_id":selected_episode}
        elif a.command in ("compare","report"):
            result=compare([evaluate(d) for d in a.run_dirs])
            if a.command=="compare":write(a.out,result)
            else:
                text=render(result);a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(text,encoding="utf-8")
                a.out.with_suffix(".html").write_text(html_report(text),encoding="utf-8")
        elif a.command=="rl":
            if a.live_campaign:
                from .live_router import experiment
                from .campaign import validate_population,controlled_ablation_comparison
                state=read(a.live_campaign/"campaign.json")
                need("benchmark" in state["stages"] and "ablation" in state["stages"],"RL.LIVE_BENCHMARK_AND_ABLATION_REQUIRED")
                path=a.live_campaign/state["stages"]["benchmark"]["run_path"]
                validate_population(path,"benchmark")
                outcome=read(a.live_campaign/state["stages"]["ablation"]["outcome"])
                controlled_ablation_comparison([evaluate(a.live_campaign/d) for d in outcome["runs"]])
                result=experiment(evaluate(path))
            else:
                from .rl_lab import experiment
                need(1<=a.steps<=5000 and 1<=len(a.seeds)<=10,"RL.CONFIG_LIMIT")
                result=experiment(a.seeds,a.steps)
            need(not a.out.exists(),"RL.OUTPUT_ALREADY_EXISTS");write(a.out,result)
        elif a.command=="live":
            from .live_provider import StrictHTTPProvider
            from .campaign import run_stage
            provider=StrictHTTPProvider(allow_live=a.allow_live,allow_local=a.allow_local)
            result=run_stage(provider,a.out,a.stage,seed=a.seed,concurrency=a.concurrency,max_requests=a.max_requests,
                deadline_ms=a.deadline_ms,rate_card=read(a.rate_card) if a.rate_card else None,request_ceiling=a.request_ceiling)
        elif a.command=="audit":
            from .security import scan
            result=scan(a.root)
            if a.out:write(a.out,result)
        else:
            from .benchmark import verify_benchmark
            from .live_provider import configuration_status,StrictHTTPProvider
            from .runtime import protocol_fingerprint
            result={"benchmark_hash":verify_benchmark(),"python":sys.version.split()[0],"offline_ready":True,
                "protocol_hash":protocol_fingerprint(),"native_delegation":"NOT_IMPLEMENTED",
                "live_provider_status":"NOT_PROBED","model_calls":0,"configuration":configuration_status()}
            if a.live:
                result["health"]=StrictHTTPProvider(allow_live=a.allow_live,allow_local=a.allow_local).health_sync()
                result["live_provider_status"]=result["health"]["status"]
            if a.out:write(a.out,result)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        if a.command=="eval" and any(not x["verified_success"] for x in result["rows"]):return 1
        if a.command=="live" and result.get("status")!="PASS":return 2
        if a.command=="doctor" and a.live and result["live_provider_status"]!="PASS":return 2
        if a.command=="audit" and result["status"]!="PASS":return 1
        return 0
    except HarnessError as e:
        print(json.dumps({"status":"BLOCKED","code":e.code},ensure_ascii=False),file=sys.stderr);return 2
    except (OSError,ValueError) as e:
        print(json.dumps({"status":"BLOCKED","code":"IO_OR_CONFIG_ERROR","detail":type(e).__name__}),file=sys.stderr);return 2

if __name__=="__main__":raise SystemExit(main())
