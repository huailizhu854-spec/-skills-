
def should_retry(status: int, uncertain: bool, attempts: int, max_attempts: int = 2) -> bool:
    if attempts >= max_attempts:
        return False
    if uncertain:
        return False
    return status in (408, 429)
