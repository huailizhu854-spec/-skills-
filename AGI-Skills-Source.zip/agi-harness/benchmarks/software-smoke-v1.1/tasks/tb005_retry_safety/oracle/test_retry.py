import importlib.util, pathlib, sys
ws=pathlib.Path(sys.argv[1]);spec=importlib.util.spec_from_file_location('retry',ws/'retry.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
cases=[((429,False,0),True),((408,False,1),True),((500,True,0),False),((500,False,0),False),((429,False,2),False),((200,False,0),False)]
for args,expected in cases:
    got=m.should_retry(*args)
    if got is not expected: raise SystemExit(f'{args}: expected {expected}, got {got}')
