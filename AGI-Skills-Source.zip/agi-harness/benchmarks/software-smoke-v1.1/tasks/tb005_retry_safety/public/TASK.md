Fix retry.py. Retry only known-safe transient statuses 408/429, never retry uncertain execution, and respect max_attempts. Do not change function signature.
