
def should_retry(status: int, uncertain: bool, attempts: int, max_attempts: int = 2) -> bool:
    # BUG: unsafe retries for uncertain/5xx requests and ignores budget.
    return status >= 400
