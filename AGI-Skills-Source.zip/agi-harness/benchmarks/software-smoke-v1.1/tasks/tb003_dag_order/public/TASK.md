Create output.json containing a valid topological order. When multiple nodes are ready, choose lexicographically smallest first.
