Create output.json. Deduplicate records by id, keeping the record with the lexicographically latest timestamp. Sort output by id.
