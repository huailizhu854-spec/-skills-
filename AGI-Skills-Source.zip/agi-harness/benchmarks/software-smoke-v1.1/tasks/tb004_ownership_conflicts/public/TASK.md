Create output.json as a sorted list of conflicts. Each conflict is {path, owners} and owners is sorted. Include only paths with more than one owner.
