Read input.csv and create output.json with rows, total_amount, and mean_amount. Use exact numeric values.
