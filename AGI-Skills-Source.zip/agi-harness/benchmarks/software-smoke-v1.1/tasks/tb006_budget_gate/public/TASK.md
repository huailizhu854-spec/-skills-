Fix budget.py so a run passes only when BOTH cost and latency budgets are satisfied. Do not change function signature.
