import importlib.util, pathlib, sys
ws=pathlib.Path(sys.argv[1]);spec=importlib.util.spec_from_file_location('budget',ws/'budget.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
cases=[((.01,1000,.02,2000),True),((.03,1000,.02,2000),False),((.01,3000,.02,2000),False),((.03,3000,.02,2000),False)]
for args,expected in cases:
    got=m.within_budget(*args)
    if got is not expected: raise SystemExit(f'{args}: expected {expected}, got {got}')
