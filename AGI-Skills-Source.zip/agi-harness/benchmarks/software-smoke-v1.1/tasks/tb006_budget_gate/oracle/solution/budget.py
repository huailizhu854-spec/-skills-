
def within_budget(cost_usd: float, latency_ms: int, max_cost_usd: float, max_latency_ms: int) -> bool:
    return cost_usd <= max_cost_usd and latency_ms <= max_latency_ms
