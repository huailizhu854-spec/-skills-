# AGI Agent Harness + Eval Harness v1.0 候选工程

**包内版本：`1.0.0rc1` · RELEASE = BLOCKED · 真实模型调用：0**

本包已经完成代码施工与离线回归，不是已经获得真实模型成绩的 v1.0 正式发布版。
冻结的 6 题 `software-smoke-v1.1` 未改；正式默认结构仍为 **2 Controllers + 16 Workers**。
`single` / `dual8` 只能通过实验开关启用；不能因 Provider 能力不足静默减员。

## 本次已实际验证

| 检查 | 结果 | 证据性质 |
|---|---|---|
| Harness 单元与本地 HTTP 合同测试 | 145 / 145 通过 | fixture / fixture_http，不是真实模型 |
| rc.7 Python 兼容回归 | 791 通过，2 项平台跳过，0 失败 | 原始测试未改；Windows 两项不算通过 |
| rc.7 Bridge Node 回归 | 44 / 44 通过 | 本地兼容性 |
| 历史 Eval | 5 / 5；30 / 30 案例符合原预期 | 旧 reliability fixture，非新任务成绩 |
| 三架构离线矩阵 | 54 Episode，594 fixture calls；回放一致 | 六题 × 三架构 × 三次 |
| 五组离线消融 | 90 Episode，1764 fixture calls；回放一致 | 五组 × 六题 × 三次 |
| 故障场景 | 9 / 9 符合预期：8 拒绝、1 修复成功 | 明确注入的故障 |
| Replay Guard 组件注入 | 10 / 10 符合预期 | 开启时拒绝 5 类；关闭时接受 5 类 |
| 实际启动 Provider Probe | BLOCKED_CONFIG，0 外部请求 | 缺少本地授权配置与 Secret |

## 运行位置与环境

解压工作区后进入 `agi-harness` 子目录。新 Harness 需要 Python 3.12+；本次用 Python 3.13.5。
Bridge 验收另需 Node，本次 v22.16.0。新 Harness 无第三方运行时依赖。

```bash
cd agi-harness
python -m agi_harness doctor
python scripts/verify_v1.py --out runs/offline-verify-new
python scripts/verify_rc7.py --out runs/rc7-verify-new
```

每个输出目录必须是新的；不覆盖旧 Run。第一条 `doctor` 仅检查离线状态，不请求模型。
`verify_v1.py` 会调用 145 项测试（其中本地回环 HTTP Server 是测试夹具），不会连接模型供应商。
`verify_rc7.py` 按固定模块/类分组运行相邻 `../agi-super-power`，测试断言不变。

## 真实调用：只有一项外部前置条件

**在实际执行机器上完成用户已批准 Provider 的环境变量与 Secret 注入，并确认供应商端能够强制零付费。**
当前这里没有这些值，不能从聊天产品订阅自动获得 API Key，也没有擅自选择替代模型或付费 Provider。
密钥不要发到聊天、写入 ZIP、Git 或报告。

复制 `configs/model.env.example` 作为字段说明，而不是把真实 `.env` 放进工程。
CLI 不自动读取 dotenv 文件；值须由本地 shell、系统环境或 Secret 管理器提供：

```text
AGI_MODEL_BASE_URL
AGI_MODEL_API_KEY
AGI_MODEL_NAME
AGI_MODEL_ALLOWED_HOST
AGI_TRANSPORT_AUTHORIZED=true
AGI_ZERO_COST_CONFIRMED=true
```

`AGI_ZERO_COST_CONFIRMED` 只是操作者确认，**不会把收费接口变免费**。
必须先在供应商控制台确认免费额度有效、该模型适用、额度耗尽时拒绝而非转为计费。
无法确认就保持 false，程序阻塞。此前选择过的百炼新加坡 / `qwen3.7-flash` 仅作为用户意向记录，
本轮没有验证此模型是否仍可用或免费；代码不硬编码它、不替换模型，也不切换 URL。
精确端点以同一账户/地域控制台为准，包含正确工作空间；参见 `docs/SOURCES.md`。

## 按 Gate 逐段启动，不要一次性执行全部命令

以下是分别执行的命令；只有上一阶段 Gate PASS 才能执行下一条。
每阶段自己进行一次真实健康生成，因此不必额外跑一次 `doctor --live`。
默认并发 2 仅限制在途 HTTP 请求，不改变 16 Worker，也不声称 16 个 GPU 推理同时进行。

```bash
python -m agi_harness live --stage probe --out runs/live-v1 --allow-live --request-ceiling 41
python -m agi_harness live --stage pilot --out runs/live-v1 --allow-live --request-ceiling 241
python -m agi_harness live --stage benchmark --out runs/live-v1 --allow-live --request-ceiling 1189
python -m agi_harness live --stage ablation --out runs/live-v1 --allow-live --request-ceiling 3529
```

这些 ceiling 是包含健康请求与最多一次响应格式修复的**示例硬请求上限**，不是免费额度保证、费用估算或必需花完的预算。
正常无重试时，四阶段分别是 **21、121、595、1765 个 HTTP 请求**（每阶段含 1 个健康请求）。
54 Episode 只指 benchmark，不含 Probe、Pilot 和 90 Episode 消融。
小额度不足时不要运行后续阶段。429、超时/不确定完成的请求不会盲目重发；失败证据保留。

Probe 会检查 16/16 不同 Worker 回复、两名 Controller 各完成规划和交叉审查、全部 receipt 和独立判分。
**Probe 的通信 Gate 可以 PASS 而题目判分 FAIL**：这避免为了凑正确答案不断重抽；任务错误仍保留为失败。
协议、receipt、Worker 数量或模型身份不合格则阻塞。
原来的 `run --provider http` 旁路已禁用，只能走 `live` 阶段闸门。

## Eval / Replay / Compare / Report

`live` 结果输出真实 run 路径。将下面示例路径替换为输出中的路径：

```bash
python -m agi_harness eval runs/live-v1/attempts/ACTUAL_ATTEMPT/run
python -m agi_harness replay ACTUAL_EPISODE_RUN_ID --runs-root runs/live-v1
python -m agi_harness compare runs/live-v1/attempts/ACTUAL_ATTEMPT/run --out runs/comparison-new.json
python -m agi_harness report runs/live-v1/attempts/ACTUAL_ATTEMPT/run --out runs/report-new.md
python -m agi_harness rl --live-campaign runs/live-v1 --out runs/live-router-new.json
```

Replay 使用当前版本重新校验 raw response、journal、artifact、grader；模型调用 0。
不是直接读旧的 `pass=true`。全局 UUID 区分每个 Episode；目录型 cohort Run 另有独立 ID。
Benchmark/Grader/协议指纹不同会拒绝回放或比较；旧证据应配对应代码快照，不伪造兼容。
`rl --live-campaign` 必须已有真实 benchmark 和消融。没有真实数据不会训练；不改变生产路由。

## 交付索引

完整原始日志、请求/回复、seal、故障与中间尝试在单独的 `evidence.zip`。
当前最终结果位于其 `evidence/final/offline-final/`，先前尝试在别的目录，不能叠加成更多独立样本。
`reports/v1.0-rc1/final-report.md` / `.html` 是本轮报告；`reports` 中其它原有文件为 v0.1 历史资料。

- `docs/ARCHITECTURE.md`：真实能力、20 次调用与 18 个上下文的区别。
- `docs/BENCHMARK.md` / `docs/ABLATION.md`：冻结任务、对照与统计边界。
- `docs/FAILURE_ANALYSIS.md`：本轮真实执行的**夹具故障**，没有假装是真实模型失败。
- `docs/RL_EXPERIMENT.md` / `docs/LIMITATIONS.md`：学习算法与未执行项。
- `reports/v1.0-rc1/benchmark-results.json`：真实结果明确为 NOT_EXECUTED，不填 0% 冒充成绩。

基准 digest：`15effcdf4484993a3f04b7e3c80f6268adaf2b108f42b1e022bb3278f3c66f80`。协议指纹：`86cf8ffcaeb8157ae2443861f85c0ed97aa710372da02cb02eab15ac45e0b469`。
