# Failure analysis — 真实模型失败案例：NOT_EXECUTED

本轮没有外部模型 Run，不能提交“3–5 个真实模型失败案例”。下列五例是本轮**实际运行并保留原始证据的故障夹具**，不是模型自然失误。
所有样例任务为 tb001_csv_summary，架构 Dual16。另有 4 个场景一并保留，包含 repair_once 成功修复。

## incorrect_output

Run ID：`a7723c5c-e93b-457c-8183-22c4b4c659fc`。独立结果：FAIL；代码：`TASK.INCORRECT_OUTPUT / VERIFY.FALSE_SUCCESS`。
观察：实现者给出错误产物但仍 claimed_success=true。 原因是明确注入该缺陷，不归因于任何真实模型。
Grader：冻结 oracle 对实际产物判错；自述成功额外映射 VERIFY.FALSE_SUCCESS。 恢复：没有语义自动修复；错误样本保留。 修复/开放问题：独立判分已有效拒绝；真实模型错误率仍未知。
原始证据：`evidence/final/offline-final/core/fault-runs/incorrect_output/episodes/tb001_csv_summary--dual16--0/trace.json`、`events.jsonl`、`evidence/final/offline-final/core/fault-runs/incorrect_output/seal.json`。
该场景记录 20 次 fixture 调用、0 次额外尝试；外部模型调用 0。

## bad_hash_review

Run ID：`1335fe75-52ff-42dc-a17e-ab139582e503`。独立结果：FAIL；代码：`VERIFY.STALE_HASH / VERIFY.FALSE_SUCCESS`。
观察：Controller 引用错误的 Worker 输出哈希。 原因是明确注入该缺陷，不归因于任何真实模型。
Grader：审查证据与实际 Worker 结果不一致，拒绝 stale hash。 恢复：不把不匹配审查当成可信通过。 修复/开放问题：保持输出哈希绑定，禁止复用旧审查。
原始证据：`evidence/final/offline-final/core/fault-runs/bad_hash_review/episodes/tb001_csv_summary--dual16--0/trace.json`、`events.jsonl`、`evidence/final/offline-final/core/fault-runs/bad_hash_review/seal.json`。
该场景记录 20 次 fixture 调用、0 次额外尝试；外部模型调用 0。

## ownership_escape

Run ID：`913d096c-1a9f-4bab-b5c0-98d1673942e9`。独立结果：FAIL；代码：`ARTIFACT.OUTSIDE_OWNERSHIP / VERIFY.FALSE_SUCCESS`。
观察：实现者尝试返回不在允许产物集合中的文件。 原因是明确注入该缺陷，不归因于任何真实模型。
Grader：产物合同/路径所有权检查在写出前拒绝。 恢复：不放宽目录限制来完成运行。 修复/开放问题：严格路径限制从不参与消融；本例不是自然多写入者冲突。
原始证据：`evidence/final/offline-final/core/fault-runs/ownership_escape/episodes/tb001_csv_summary--dual16--0/trace.json`、`events.jsonl`、`evidence/final/offline-final/core/fault-runs/ownership_escape/seal.json`。
该场景记录 3 次 fixture 调用、0 次额外尝试；外部模型调用 0。

## duplicate_id

Run ID：`a3fa3f4b-dab6-4e39-8639-cef76c5ea3af`。独立结果：FAIL；代码：`EXEC.DUPLICATE_PROVIDER_RESPONSE`。
观察：夹具复用已经出现的 Provider response ID。 原因是明确注入该缺陷，不归因于任何真实模型。
Grader：运行时与 evaluator 均检查重复 ID；不是 16 个唯一回复。 恢复：停止当前任务，不静默凑一个新 ID。 修复/开放问题：局部 ID 防重不等价供应商签名证明。
原始证据：`evidence/final/offline-final/core/fault-runs/duplicate_id/episodes/tb001_csv_summary--dual16--0/trace.json`、`events.jsonl`、`evidence/final/offline-final/core/fault-runs/duplicate_id/seal.json`。
该场景记录 2 次 fixture 调用、0 次额外尝试；外部模型调用 0。

## timeout_uncertain

Run ID：`859c266c-544c-46c8-8b82-62f3322dee6d`。独立结果：FAIL；代码：`EXEC.TIMEOUT_UNCERTAIN`。
观察：请求已发出但完成状态未知。 原因是明确注入该缺陷，不归因于任何真实模型。
Grader：留下 dispatch/transport error；标记 EXEC.TIMEOUT_UNCERTAIN。 恢复：不会自动重发；后续计划行保留为未完成。 修复/开放问题：人工核验供应商状态后另起 attempt，不能声称 exactly-once。
原始证据：`evidence/final/offline-final/core/fault-runs/timeout_uncertain/episodes/tb001_csv_summary--dual16--0/trace.json`、`events.jsonl`、`evidence/final/offline-final/core/fault-runs/timeout_uncertain/seal.json`。
该场景记录 3 次 fixture 调用、0 次额外尝试；外部模型调用 0。

## 失败分布与标签

`failure-distribution.csv` 是真实模型分布，当前只有表头、无样本。
`offline-failure-distribution.csv` 是九个夹具场景的多标签分布，同一 Episode 可属于多个 family，比例和可大于 100%。
历史 taxonomy 保留在 docs/history/v0.1；当前新代码/组件扩展以 FAILURE_TAXONOMY.json v1.0.0-rc1 记录，旧 Run 标签不回写。
新增配置/Provider/Gate/消融/安全代码是更具体的工程状态，不把 BLOCKED_CONFIG 当成真实模型 failure mode 频率。
