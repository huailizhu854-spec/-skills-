# Routing / RL experiment

## 两条路径分开

原 `rl_lab.py` 合成实验实际重跑，标记 SYNTHETIC_ONLY：44 个训练任务、16 个测试任务，seed 7/17/27，每 seed 300 步。
这些训练/测试数据与偏好都由合成环境构造，不是用户、真实供应商、生产用户反馈或 LLM 权重更新。
其数值只用于回归算法实现，不作为真实任务性能提升。

新增 `live_router.py` 已实现并通过显式内存 mock 单元测试，但真实训练为 **NOT_EXECUTED**。
它只接受真实完整 54 Episode、完整实际 Token 与延迟，并且 CLI 要求真实消融已完成。
算法是 ridge contextual reward model + argmax，而不是把推理日志喂给模型就叫 GRPO。

## 预注册的真实数据实验

输入包含 task_type、file_count、dependency_depth、expected_parallelism、risk、complexity、historical_failure_rate。
除了公共文件数量，部分复杂度/风险是事先固定的任务元数据代理，不是自动发现的真实项目特征。
历史失败先验与归一化只用训练分区，oracle 不进入模型 Prompt。

按 task ID 分组划分 3 个 train / 1 个 validation / 2 个 held-out test；同一题的三次重复不能跨分区。
ridge 候选为 .01/.1/1/10，validation 选参数，held-out 只报告结果。六题功效很低，不能包装成通用智能路由。

Reward：2×verified success + 0.5×first pass − 0.15×Tokens/train mean − 0.15×latency/train mean − 0.1×retry − 2×false success − 0.5×conflict。
这里的成本惩罚是**实际 Token 代理**，不是美元，缺失 Token 不填零。供应商实际账单目前没有采集接口，美元仍 null。
比较 always single / always dual8 / always dual16 / uniform / learned router；uniform 用均匀策略的经验期望，不制造额外 Run。

Action 中 single/dual8/dual16 可用；`dual16_strict` 因没有单独真实 action 数据被 **MASKED_NO_LIVE_ACTION_DATA**。
不从 Full Dual16 复制奖励伪造第四个 action，也不宣称已经完成四动作学习。新增动作需要另行受控采样。

> This is policy optimization over orchestration actions, not LLM weight-level GRPO.

LoRA、TRL、LLM 权重 GRPO、GPU 训练：NOT_EXECUTED。生产默认仍固定 Dual16，学习结果不会自动改部署。
