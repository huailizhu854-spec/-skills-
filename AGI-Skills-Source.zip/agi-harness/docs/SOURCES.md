# Source provenance

## 用户基线

用户任务：粘贴的文本 (1)(20260928-041847).txt。
用户源码：agi-super-power-rc7-harness-v0.1.0-workspace(1).zip。
输入 ZIP SHA-256：8cf9dd59b4aae99591f6f56a04e799f605974593ed9d5319480c85932462ae21。
基准、原始断言与 rc.7 源码的字节对比：evidence/final/source-boundaries.json。
代码运行与数值来源是本轮实际日志，不来自宣传资料或模型自述。

## 官方接口资料（2026-09-28 检索，仅协议参考）

Alibaba Cloud Model Studio — OpenAI API compatibility:
https://www.alibabacloud.com/help/en/model-studio/compatibility-of-openai-with-dashscope

该官方页面记录 Singapore 工作空间形态的兼容端点以及迁移说明。因此不把旧通用地址当成任何账户的保证有效值，
应使用已授权控制台提供的 exact base URL，不自动替换账户端点或模型。

Alibaba Cloud Model Studio — Free quota:
https://www.alibabacloud.com/help/en/model-studio/new-free-quota

本报告不据此承诺当前用户账户的免费额度、有效期或某个模型一定免费；这些必须在账户侧确认。

Python urllib.request 官方文档:
https://docs.python.org/3/library/urllib.request.html

以上资料不是实际模型调用证据。Provider 身份、可用性、返回 seed 的真实执行与供应商计费均未通过账户实验核实。
