# Audit findings and remediation ledger

| Finding in the earlier asset / design | Action in v0.1 | Evidence / limit |
|---|---|---|
| Legacy `grade_dict({})` returns PASS because checks are optional | New strict grader rejects missing traces, roster and receipts | Empty-trace unit regression; legacy behavior preserved only for historical comparison |
| Legacy receipt comparison can trust two caller-supplied hashes | New grader hashes raw bytes and binds them to request, journal and artifact | Tamper/seal/nonce/identity tests; no signed attestation claim |
| Old replay summary sets a consistency field to true | New replay actually executes deterministic grading again and compares the result | Replay runs with HTTP access mocked to fail |
| Code task grading imports supplied Python in the host | New finite AST interpreter, expanded predicate grid | Import/call/loop/dynamic annotation rejected; correct out-of-grammar code may be rejected |
| Empty or unavailable usage could look like zero cost | Null cost/token totals and coverage fields | Missing-cost and failed-cost denominator tests |
| Old global router logits ignore individual task features | New linear task-conditioned categorical policy | Per-task probability differences tested |
| Earlier baseline-all vs learned-test result was not like-for-like | Uniform-test vs learned-test on identical held-out task IDs | Same-cohort test and task-level split audit |
| Synthetic rubric preferences were discussed alongside RLHF | New labeling explicitly says no human feedback and no LLM-weight training | Training only on train-task pairs; same synthetic environment assumptions disclosed |
| Experiments could silently change the fixed sixteen-worker objective | Production default fixed Dual16, baseline switch explicit, lab has no deployment path | Opt-in/default tests |
| Concurrent task failure could lead to blind replay | Intent-before-dispatch, bounded completed-response repair, uncertain transport blocked | 429/5xx/timeout tests; automated crash reconciliation remains not implemented |

An internal review also found a potential bool/int mismatch in the first AST interpreter draft: Python `and`/`or` return operands, not always booleans. This was corrected before release and a regression now rejects a predicate returning integer `1` instead of `True`. The final release includes the corrected interpreter; no failed model benchmark is being erased.

Baseline snapshots under `legacy/` remain unchanged. The new runtime is a bounded local software-task pilot, not a replacement for every original rc.7 native-host feature. No original 793-test pass count is recycled as new coverage.

A final parser review added explicit rejection of floating-point exponent overflow (`1e309`), not just NaN/Infinity tokens, and separated bounded model-response parsing from larger sealed-evidence reads. Regression tests cover both.
