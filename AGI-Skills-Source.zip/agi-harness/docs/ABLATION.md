# Ablation — controls implemented; live study NOT_EXECUTED

五组为 full、no_cross_review、no_ownership、no_grader、no_replay_guard，每组 Dual16 × 六题 × 三次，共 90 Episode。
真实消融要等真实 54 Episode Gate 通过才可启动。每次只关一个控制，题目、Prompt、模型、seed、温度、超时、配置预算和外层判分保持一致。
执行顺序是 seed 决定的随机分组顺序；不是五组同时推理。实际请求数因删掉审查阶段会下降，不能伪装成本相同。

| Arm | 关闭内容 | 从未关闭的安全/测量边界 |
|---|---|---|
| full | 无 | 所有控制 |
| no_cross_review | 两次 Controller 最终交叉审查 | 2 Controller + 16 Worker；task oracle |
| no_ownership | 文件写入的逻辑 ownership 放行 | 文件路径/长度限制；外层冲突与产物一致性检查 |
| no_grader | 运行结果对外放行前的独立判分 gate | shadow evaluator 始终执行，继续记录真实结果 |
| no_replay_guard | runtime nonce /重复 response 接受保护 | 独立离线重判；绝不盲目重发不确定 HTTP |

`operational_success` 代表某配置是否会把 Agent 自称成功的结果放行，`verified_success` 始终来自 shadow evaluator。
因此 no_grader 不会把错误变成真正正确，而能测出 false PASS released。
其代价是本轮总测量仍包含外层 grader；无法宣称完全删掉评测后能节省多少端到端时延。

本次离线五组全部 18/18 正常夹具符合预期，合计 90，回放一致；这不是消融有效性证据。
单元测试另注入了错误产物、越权写入、stale nonce，验证关闭控制确实改变运行接受行为，而 shadow grading 不被放宽。
Replay 注入共十个组件案例：stale nonce、duplicate response、replayed receipt、uncertain retry、old result，在 Guard 开/关各一次。
这是纯 receipt-admission 组件测试，不是供应商真实过期返回、网络级安全证明或 exactly-once 验收。

## 识别性限制

六题是单写入者结构，正常模型很可能根本不尝试冲突。即使真实消融得到 0 冲突，也不能证明 Ownership 无效。
没有自动语义返工闭环；review veto 会失败，不会自行修改题目或不断重试到通过。
后续若要评估复杂协作，应新增独立版本的 benchmark 并预注册，而不是改本轮冻结题目。
