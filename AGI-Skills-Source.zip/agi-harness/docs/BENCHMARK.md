# Benchmark — frozen software-smoke-v1.1

## 冻结边界

本次全部六题的 public input、oracle、manifest 字节未改；有限 AST 解释器 `safe_expr.py` 字节未改。
基准聚合 digest：`15effcdf4484993a3f04b7e3c80f6268adaf2b108f42b1e022bb3278f3c66f80`。
manifest 文件 SHA-256：`d0f8056b3360eb5d520515f8b9a24214f80e08ee87bc69941e18dfa9eeef7842`。
独立 receipt evaluator 从 v2 强化为 v3，`GRADER_VERSION = strict-receipts-and-task-v3`；
变化是 health、返回模型、HTTP 回执、运行身份、消融外层验证和证据一致性检查，不是放宽题目正确性。
旧版本证据不能套新版本偷偷改判，需使用原始 ZIP/代码快照。

| Task ID | 固定任务 |
|---|---|
| tb001_csv_summary | CSV 汇总 |
| tb002_json_dedupe | JSON 去重 |
| tb003_dag_order | DAG 顺序 |
| tb004_ownership_conflicts | 所有权冲突判定 |
| tb005_retry_safety | 重试安全谓词 |
| tb006_budget_gate | 预算闸门谓词 |

这些是公开、有限、微型软件任务，不是保密 held-out 软件开发集；不能推导复杂项目或真实岗位绩效。
输入中的 ownership/retry 问题是模型要解的任务，与运行时真的发生多文件竞争不是同一回事。

## 严格顺序

Probe：一题 Dual16 一次；Pilot：六题 Dual16 各一次；正式 benchmark：六题 × single/dual8/dual16 × 三次，共 54 Episode。
消融另跑 90 Episode。每阶段先健康检查，不以 Fixture 替代真实 Stage Gate。
Probe 衡量联通与证据完整性，不要求题目答对才继续抽样；独立题目 PASS/FAIL 原样保留。
后续 Population Gate 拒绝缺失/不确定/Provider 故障，题目错误则进入分析，不删除失败样本。

每个 Episode 记录 UUID、benchmark/task/architecture/provider/model/seed/attempt/code/grader/timestamp。
调度 seed 固定顺序。可通过 `AGI_MODEL_SEED` 请求供应商 seed，但其是否真正生效为 NOT_VERIFIED；
不能把相同 seed 写成相同输出保证。温度默认 0.2，任何可比 cohort 配置要一致。

## 分母和统计

已通过 preflight 的计划 Episode 全部进入分母，包括未完成行。配置缺失在 admission 之前阻塞，不伪造失败模型 Run。
成功率、first pass、false success（全体/自称成功两个分母）、grader reject、修复尝试和冲突率均从独立重判结果生成。
均值、中位数、p50、p95、样本标准差、最大值和缺失覆盖率分开报告；失败延迟不丢弃。
95% Wilson 区间仅是描述性 episode 区间，重复题目不独立；架构差异另用 task-cluster bootstrap。
六个任务簇统计功效低，必须报告 **low statistical power**，不作显著领先宣传。

## 本次结果的正确读法

真实 benchmark：**NOT_EXECUTED，0/54 已执行**。三架构真实成功率、成本、时延都为空，不是 0%，也不是 100%。
本地 fixture 矩阵为 54/54 符合预期，只证明流水线、判分与回放能工作。不能据此排序 Single/Dual8/Dual16。
逐行 evidence 位于 `evidence/final/offline-final/core/smoke-matrix`；矩阵的 JSON/CSV 均标记 FIXTURE_ONLY。
