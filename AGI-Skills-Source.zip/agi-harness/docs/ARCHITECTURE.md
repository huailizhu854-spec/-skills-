# Architecture — v1.0.0rc1

## 保留架构，明确实际做了什么

正式模式是两名 Controller 分别负责 W01–W08 / W09–W16，随后各自审查另一组结果，最后由独立确定性 evaluator 判分。
这不是 ChatGPT 原生子 Agent 工具，provider session 不可用时不伪造 session ID。
本实现通过带历史的 HTTP 请求维护 18 个独立应用上下文；供应商 response ID 与应用 context ID 分开存储。

当前六题微型任务沿用 **W01 唯一实现者 + W02–W16 分工检查者**。并非 16 个 Worker 同时修改代码。
顺序为：2 个 Controller 规划 → W01 生成产物 → 其余 15 个 Worker 检查 → 2 个 Controller 交叉审查 → shadow evaluator。
没有额外第 17、18 或 32 个 Worker。Grader 是本地确定性程序，不是冒充独立模型 Worker。

| 模式 | Controller | Worker | 正常请求数/题（不含健康） |
|---|---:|---:|---:|
| single，实验对照 | 0 | 1 | 1 |
| dual8，实验对照 | 2 | 8 | 12 |
| dual16，正式默认 | 2 | 16 | 20 |
| dual16 no_cross_review，实验 | 2 | 16 | 18 |

16 Worker 的职责仍存在时可以把并发从 16 调低为 2；这不是减少 Worker。HTTP 并发不证明供应商内部的推理并发。

## 文件与职责

为兼容原 rc.7 与现有 import，保留已有平铺 `agi_harness/`，未为了目录外观重写工程。
用户 Prompt 中的 runtime/scheduler/providers/sessions/artifacts/tracing/recovery 分层对应下表中的逻辑职责，
本轮不是已经完成物理目录迁移的虚假交付。

| 模块 | 主要职责 |
|---|---|
| runtime.py / contracts.py | roster、职责、调度、历史、产物所有权、追加式 dispatch journal |
| live_provider.py | async Provider 合同、严格 HTTP、真实 health、精确模型核验、telemetry |
| campaign.py | Probe/Pilot/Benchmark/Ablation 顺序、配置指纹、总请求闸门、每阶段证据 |
| evaluation.py / benchmark.py / safe_expr.py | 独立 receipt 审计与冻结任务判分；不执行任意模型 Python |
| replay.py | 按目录/UUID 定位并离线重判 |
| telemetry.py / metrics.py / statistics.py | 全 trace 计量、缺失覆盖率、分布、置信区间、成对比较 |
| ablation.py | 四个单变量运行控制与单独的 receipt-admission 组件注入 |
| live_router.py / rl_lab.py | 真实数据路由实验接口 / 明确分离的合成实验 |
| security.py | 静态密钥/环境文件/符号链接/动态 Python 调用检查 |

## Provider 与证据合同

ENV/Secret 决定 exact base URL、model、allowed host、key。模型名称或返回模型不一致阻塞；不自动 fallback。
健康检查真实生成固定短应答，验证 HTTP 200、非空 response ID、精确模型、finish_reason 和内容，不能用配置齐全冒充模型健康。
每次保留 request ID、上游 request ID（若返回）、response ID、请求与响应时间、latency、usage、finish reason、HTTP status、重试次数。
缺失 usage 为 null/unknown；金额没有供应商账单则为 null。没有持久化 Authorization 请求头。

原始响应中回显当前 Key 时，脱敏副本被明确标记并拒绝；完整收到的字节哈希单独保留，绝不把脱敏内容冒充未经修改的原文。
禁止跨主机重定向及继承进程全局代理。Localhost 只在明确 allow-local 时可用；验证中仅用了 fixture_http 本地服务。
DNS allowlist 校验不是完整的抗 DNS rebinding 网络沙箱；生产环境仍须部署出站策略。

## 不确定恢复与回放

先写 dispatch intent，再请求。完成回复但格式不合格最多修复一次，每次新 request ID / nonce；无响应、超时、429 不盲目重发。
没有自动从崩溃中恢复供应商执行的 exactly-once 保证。人工核对残留 intent 和供应商状态后才可开新 attempt。
所有计划 Episode 在派发前就有全局 UUID；中断后的未完成条目不从分母删除。
本地 seal 与 hash-chain 用于检查内容一致性，不是数字签名，也不能抗同时改写所有内容的本机攻击者。
