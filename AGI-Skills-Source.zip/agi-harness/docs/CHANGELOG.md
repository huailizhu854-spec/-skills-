# Change log — 1.0.0rc1

Added strict async-compatible Provider, real health evidence, no-fallback model matching, per-call telemetry and secret echo rejection.
Added stage-gated live campaign with explicit request ceiling, immutable snapshots, bounded concurrency, UUID identities and retained failed attempts.
Added operational one-variable ablations with an always-on independent shadow grader; added separate pure receipt-admission fault injection.
Added deterministic UUID replay, comprehensive metering, paired comparison controls, Wilson intervals and per-episode grader profiles.
Added guarded real-data contextual routing with train/validation/held-out separation and honest masking of unobserved dual16_strict.
Added static secret/security checks, 65 new tests (80 → 145), offline verification and unchanged rc.7 regression scripts.

Frozen benchmark, task oracles, safe_expr.py and the original 80 test assertions were not modified. Receipt evaluator is versioned v3; legacy evidence needs matching old source.
rc.7 sibling source is byte-identical to the input archive. No cloud publish, extra worker, paid fallback or native host agent claim.

## Audit corrections retained

Initial monolithic rc.7 and two module attempts exceeded wall-clock limits. All tests were rerun as module/class groups, without changing test assertions.
The final regression summary parser initially expected plural 'tests' and missed two successful 'Ran 1 test' log summaries.
The parser was corrected to accept singular/plural, original successful raw logs were not edited, original summary JSON archived, and a single-test group was actually rerun to verify the parser.
All preliminary source-state runs remain in evidence; pre-final runtime snapshot is supplied for matching-version replay.
