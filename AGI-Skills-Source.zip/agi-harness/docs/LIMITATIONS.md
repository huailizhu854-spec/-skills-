# Limitations / honest release boundaries

## 阻塞项

当前真实 Provider 没有配置：缺少 AGI_MODEL_BASE_URL、AGI_MODEL_API_KEY、AGI_MODEL_NAME、AGI_MODEL_ALLOWED_HOST，
并且授权/零付费确认未设置。实际 doctor 和 Probe admission 已运行，返回 BLOCKED_CONFIG；外部 HTTP 请求/真实模型响应均为 0。
因此真实 Probe、六题 Pilot、54 Episode benchmark、真实消融、真实失败频率、真实数据 Router 训练均未执行。
不能回答三架构谁更强、多 Agent 是否值得成本、哪个任务值得 16 Worker，也不能把本地延迟当推理性能。

## 仍未覆盖或只部分实现

1. 本地 HTTP 编排，不是宿主原生真实子 Agent 召唤；现有 rc.7 源码保持兼容但未重新部署云端。
2. 静态单实现者 + 15 检查者，不是自主动态规划的 16 个并行写代码 Worker；review veto 不触发内容返工。
3. 完成回复格式错误支持受限修复，不确定网络请求不自动重发；没有跨进程 resume / exactly-once / 签名回执。
4. Replay 的三类细粒度 receipt/epoch/uncertain admission 注入为组件测试；不能外推到真实 Provider 的所有重放攻击。
5. 独立 Grader 消融只改变运行放行，外层测量保留；不能估计完全移除评测的全部时延节省。
6. HTTP usage 是供应商返回值，未经账单核对；实际 USD 字段没有真实账单接入，始终 null。估价只能明确单列 estimated。
7. supplier 端的 free-only 限制不由本地环境变量执行；本工具不能证明账户不会扣费。额度适用性/模型可用性未核实。
8. 本地密钥静态扫描无命中不等于所有编码形式与漏洞不存在；无第三方渗透测试，DNS 二次解析不是网络沙箱。
9. 2 项真实 Windows 文件系统测试因 Linux 环境跳过；Windows/macOS 真实宿主最终验收 NOT_EXECUTED。
10. 六个公开任务不支持广泛结论。sample 间有重复相关性，路由只有 3/1/2 任务划分；dual16_strict 没有真实 action 数据。
11. 未按 Prompt 的示意图物理迁移所有目录；保留旧平铺 import，逻辑边界见 ARCHITECTURE。
12. 审计证据版本与协议指纹绑定。先前版本 raw runs 留存，但必须搭配对应快照回放，不能让新 grader假装旧代码。

## 状态词

PASS 只描述被实际执行的对应检查；NOT_EXECUTED 表示没运行；NOT_VERIFIED 表示无法外部证实；UNKNOWN/null 表示缺少测量。
**RELEASE=BLOCKED** 是本次交付的最终状态，不能改成 PASS 来满足文件名中的 v1.0。
