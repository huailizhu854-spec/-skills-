# Benchmark — frozen software-smoke-v1.1

## 冻结边界

本次全部六题的 public input、oracle、manifest 字节未改；有限 AST 解释器 `safe_expr.py` 字节未改。
基准聚合 digest：`15effcdf4484993a3f04b7e3c80f6268adaf2b108f42b1e022bb3278f3c66f80`。
manifest 文件 SHA-256：`d0f8056b3360eb5d520515f8b9a24214f80e08ee87bc69941e18dfa9eeef7842`。
独立 receipt evaluator 从 v2 强化为 v3，`GRADER_VERSION = strict-receipts-and-task-v3`；
变化是 health、返回模型、HTTP 回执、运行身份、消融外层验证和证据一致性检查，不是放宽题目正确性。
旧版本证据不能套新版本偷偷改判，需使用原始 ZIP/代码快照。

| Task ID | 固定任务 |
|---|---|
| tb001_csv_summary | CSV 汇总 |
| tb002_json_dedupe | JSON 去重 |
| tb003_dag_order | DAG 顺序 |
| tb004_ownership_conflicts | 所有权冲突判定 |
| tb005_retry_safety | 重试安全谓词 |
| tb006_budget_gate | 预算闸门谓词 |

这些是公开、有限、微型软件任务，不是保密 held-out 软件开发集；不能推导复杂项目或真实岗位绩效。
输入中的 ownership/retry 问题是模型要解的任务，与运行时真的发生多文件竞争不是同一回事。

## 严格顺序

Probe：一题 Dual16 一次；Pilot：六题 Dual16 各一次；正式 benchmark：六题 × single/dual8/dual16 × 三次，共 54 Episode。
消融另跑 90 Episode。每阶段先健康检查，不以 Fixture 替代真实 Stage Gate。
Probe 衡量联通与证据完整性，不要求题目答对才继续抽样；独立题目 PASS/FAIL 原样保留。
后续 Population Gate 拒绝缺失/不确定/Provider 故障，题目错误则进入分析，不删除失败样本。

每个 Episode 记录 UUID、benchmark/task/architecture/provider/model/seed/attempt/code/grader/timestamp。
调度 seed 固定顺序。可通过 `AGI_MODEL_SEED` 请求供应商 seed，但其是否真正生效为 NOT_VERIFIED；
不能把相同 seed 写成相同输出保证。温度默认 0.2，任何可比 cohort 配置要一致。

## 分母和统计

已通过 preflight 的计划 Episode 全部进入分母，包括未完成行。配置缺失在 admission 之前阻塞，不伪造失败模型 Run。
成功率、first pass、false success（全体/自称成功两个分母）、grader reject、修复尝试和冲突率均从独立重判结果生成。
均值、中位数、p50、p95、样本标准差、最大值和缺失覆盖率分开报告；失败延迟不丢弃。
95% Wilson 区间仅是描述性 episode 区间，重复题目不独立；架构差异另用 task-cluster bootstrap。
六个任务簇统计功效低，必须报告 **low statistical power**，不作显著领先宣传。

## 本次结果的正确读法

真实 benchmark：**NOT_EXECUTED，0/54 已执行**。三架构真实成功率、成本、时延都为空，不是 0%，也不是 100%。
本地 fixture 矩阵为 54/54 符合预期，只证明流水线、判分与回放能工作。不能据此排序 Single/Dual8/Dual16。
逐行 evidence 位于 `evidence/final/offline-final/core/smoke-matrix`；矩阵的 JSON/CSV 均标记 FIXTURE_ONLY。


# Ablation — controls implemented; live study NOT_EXECUTED

五组为 full、no_cross_review、no_ownership、no_grader、no_replay_guard，每组 Dual16 × 六题 × 三次，共 90 Episode。
真实消融要等真实 54 Episode Gate 通过才可启动。每次只关一个控制，题目、Prompt、模型、seed、温度、超时、配置预算和外层判分保持一致。
执行顺序是 seed 决定的随机分组顺序；不是五组同时推理。实际请求数因删掉审查阶段会下降，不能伪装成本相同。

| Arm | 关闭内容 | 从未关闭的安全/测量边界 |
|---|---|---|
| full | 无 | 所有控制 |
| no_cross_review | 两次 Controller 最终交叉审查 | 2 Controller + 16 Worker；task oracle |
| no_ownership | 文件写入的逻辑 ownership 放行 | 文件路径/长度限制；外层冲突与产物一致性检查 |
| no_grader | 运行结果对外放行前的独立判分 gate | shadow evaluator 始终执行，继续记录真实结果 |
| no_replay_guard | runtime nonce /重复 response 接受保护 | 独立离线重判；绝不盲目重发不确定 HTTP |

`operational_success` 代表某配置是否会把 Agent 自称成功的结果放行，`verified_success` 始终来自 shadow evaluator。
因此 no_grader 不会把错误变成真正正确，而能测出 false PASS released。
其代价是本轮总测量仍包含外层 grader；无法宣称完全删掉评测后能节省多少端到端时延。

本次离线五组全部 18/18 正常夹具符合预期，合计 90，回放一致；这不是消融有效性证据。
单元测试另注入了错误产物、越权写入、stale nonce，验证关闭控制确实改变运行接受行为，而 shadow grading 不被放宽。
Replay 注入共十个组件案例：stale nonce、duplicate response、replayed receipt、uncertain retry、old result，在 Guard 开/关各一次。
这是纯 receipt-admission 组件测试，不是供应商真实过期返回、网络级安全证明或 exactly-once 验收。

## 识别性限制

六题是单写入者结构，正常模型很可能根本不尝试冲突。即使真实消融得到 0 冲突，也不能证明 Ownership 无效。
没有自动语义返工闭环；review veto 会失败，不会自行修改题目或不断重试到通过。
后续若要评估复杂协作，应新增独立版本的 benchmark 并预注册，而不是改本轮冻结题目。
