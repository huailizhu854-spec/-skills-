# Metrics contract — v1.0.0rc1

所有已 admission 的计划行入分母，未完成行保留 UUID，错误样本不删。配置拒绝不制造模型 Run。
verified success / first pass / grader reject 按全体计算；false success 同时给全体和自称成功两个分母。
rework/recovery 仅指完成回复后的格式修复；不是通用语义返工率。完整 trace 的计量不因 receipt grader 提前报错而截断。
冲突统计来自实际 inspector 提议文件写入；目前未提供通用 duplicate-work 自动量化，Controller 的责任唯一合同不等于重复工作测量。

Token 为 raw provider usage，任何调用缺失则完整总量 null，并保留 known subtotal / coverage。HTTP fixture 的 usage 不冒充真实数据。
provider_cost_usd、cost_per_episode、cost_per_verified_success 缺少供应商账单均 null；rate card 仅给 estimated_*，含失败与重试。
没有任意字符数估 Token，也不把免费确认写成 $0 账单。

Episode wall clock 不含阶段健康请求、不含后置 shadow grading；两者另存 health evidence / grader-profile。
全请求、controller、worker 以及 grader profile 均保留；重放中不重新测量并覆盖首次 grader timing，以保证确定性结果一致。
输出 mean/median/p50/p95/sample SD/min/max/n/missing。缺失项不补 0；失败 run 的可用时间也参与统计。

Wilson 95% 区间是描述性数据；架构差异使用 task-cluster bootstrap，低统计功效必须声明。
Compare 会拒绝 benchmark/grader/protocol/provider/model/budget/rate-card/execution-kind/controls/task-set 差异和不配对/重复行。
标准 Compare 不混消融 arm；消融有专用单变量配对比较。没有静默 non-controlled fallback。
