# Portfolio positioning — capability mapping, not a hiring guarantee

| Capability often discussed in a role | Demonstrable project evidence | Current limit |
|---|---|---|
| Agent systems / orchestration | Fixed Dual16 contracts, isolated contexts, bounded phase execution | Software smoke tasks, not general tool agents |
| Evaluation infrastructure | Immutable task manifest, strict raw-evidence grading, one CLI | Only six small task families |
| Reliability/debugging | Hash-chain journal, fault cases, no-blind-retry, offline replay | Automatic crash recovery not implemented |
| Experiment design | Explicit baselines, paired task cohorts, full-run denominators | No real-model task results yet |
| Cost/latency instrumentation | Usage coverage, unknown-cost semantics, per-success cost | Billing not verified, fixture latency not production |
| Reward modeling | Bradley–Terry on task-separated synthetic preferences | No human labels |
| Reinforcement learning methods | Contextual clipped group-relative categorical policy with KL | Not LLM post-training and not real-world performance |

A defensible English CV line **now**:

> Built a reproducible Agent/Eval Harness with fixed Dual16 execution contracts, frozen software-task fixtures, raw-receipt grading, offline replay, paired metrics and a synthetic preference-learning/GRPO-style policy lab; validated the pipeline with failure injection while keeping real-model results explicitly unmeasured.

Do not write “increased production success to 98%”, “trained an LLM with human feedback”, “launched 18 native ChatGPT agents” or “guaranteed zero API cost”. After live runs exist, replace descriptions only with verified counts and population-specific outcomes.
