#!/usr/bin/env python3
"""Complete offline 3.3 integration: route -> memory -> claim -> fixture -> verifier -> telemetry."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from kernel import load_json
from team_runtime import TeamStore,write_json,digest
from team_runner import run_batch
from intelligence_layer import enrich_plan
from context_engine import MemoryStore
from route_feedback import FeedbackStore

HINTS={'facts':{'artifact_types':['json'],'domains':['general'],'task_shape':'produce','evidence_required':True},
       'outline':{'artifact_types':['json'],'domains':['general'],'task_shape':'produce'},
       'page':{'artifact_types':['html'],'domains':['frontend'],'task_shape':'produce'},
       'audit':{'artifact_types':['audit-report'],'domains':['quality'],'task_shape':'review'}}

def fixture_plan():
    plan=load_json(ROOT/'examples/team-demo/plan.codex-v3.json')
    plan['run_id']='intelligence-fixture-v33'
    plan['goal']['objective']='Offline synthetic fixture for 3.3 intelligence integration; not a native-agent run.'
    plan['goal']['constraints']=['Keep one owner per work item.','Use only synthetic local fixture inputs.','Independent registry acceptance, never self-reported PASS.']
    for task in plan['tasks']:
        task['executor']={'type':'fixture','transport_network':False}
        task['tools']=['file.read','file.write']
        task['capabilities']={'network':False,'shell':False,'model_delegation':False,'external_write':False}
    return plan

def review(store,tid,decision='accept'):
    row=store.row(tid);r=json.loads(row['result'])
    rel='reviews/coordinator-'+tid+'-'+str(row['attempt'])+'.json'
    p=store.root/rel
    if not p.exists():write_json(p,{'fixture':True,'purpose':'Request independent registry validation; not producer acceptance'})
    return store.review({'task_id':tid,'result_id':r['result_id'],'result_digest':digest(r),
        'goal_digest':r['goal_digest'],'reviewer':'coordinator','decision':decision,
        'reason':'Execute independent frozen verifier for synthetic data','evidence_path':rel,
        'evidence_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})

def run(output: Path):
    output=output.absolute()
    if output.resolve().is_relative_to(ROOT): raise ValueError('Keep demo jobs outside the installed skill')
    output.mkdir(parents=True,exist_ok=False)
    with MemoryStore(output/'memory.sqlite3') as memory:
        memory.put({'id':'sample-style','project_id':'demo','kind':'decision','key':'HTML page',
                    'value':'Synthetic demo page must remain static HTML.','source':{'ref':'synthetic fixture specification'},
                    'created_at':time.time()-1,'approved':True},allow_persist=True)
        plan=enrich_plan(fixture_plan(),project_id='demo',available_tools=['file.read','file.write'],hints_by_task=HINTS,memory=memory)
    TeamStore.create(output/'job',plan,ROOT/'examples/team-demo')
    config={'schema_version':1,'adapters':{t['role']:{'argv':[sys.executable,str(ROOT/'examples/intelligence/fixture_worker.py')],
                        'mode':'fixture','timeout_seconds':30} for t in plan['tasks']}}
    batches=[]
    for _ in range(10):
        with TeamStore(output/'job') as store:
            if store.status()['completed']:break
        batch=run_batch(output/'job',config,allow_commands=True);batches.append(batch)
        if not batch['batch']:raise ValueError('No progress')
        with TeamStore(output/'job') as store:
            for item in batch['batch']:
                if item.get('status')!='submitted':raise ValueError('Fixture failed: '+str(item))
                review(store,item['task_id'])
    with TeamStore(output/'job') as store:
        status=store.status()
        if not status['completed']:raise ValueError('Demo did not complete')
        context_count=sum(len(json.loads(row['packet'])['context_capsule']['memory_records']) for row in store.db.execute('SELECT packet FROM tasks'))
    with FeedbackStore(output/'feedback.sqlite3') as feedback:
        inserted=feedback.record_job(output/'job');again=feedback.record_job(output/'job');summary=feedback.summary()
    report={'package_version':'3.3.0','execution_kind':'OFFLINE_DETERMINISTIC_FIXTURE','real_agent_calls':0,
        'model_calls':0,'network_calls':0,'completed':status['completed'],'accepted_tasks':status['metrics']['accepted'],
        'worker_attempts':status['metrics']['attempts'],'batch_count':len(batches),'context_records_delivered':context_count,
        'feedback_first_insert':inserted,'feedback_repeat':again,'feedback_summary':summary,
        'not_verified':['WorkBuddy native execution','Real model routing accuracy','Production generalization','OS sandbox enforcement']}
    write_json(output/'summary.json',report)
    return report
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    print(json.dumps(run(p.parse_args().output),ensure_ascii=False,indent=2))
