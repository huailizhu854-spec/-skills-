#!/usr/bin/env python3
"""Deterministic v3 fixture. No model, no native agent, no network."""
from __future__ import annotations
import hashlib
import html
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from kernel import load_json
from team_runtime import write_json
from v3_protocol import pending_checks

def run(packet: dict, diagnostics: dict | None=None) -> dict:
    sources={i['id']:Path(i['path']) for i in packet['input_snapshots']}
    tid=packet['task_id'];out=packet['contract']['outputs'][0]
    target=Path(packet['output_root'])/out['path'];target.parent.mkdir(parents=True,exist_ok=True)
    if tid=='facts':
        raw=sources['brief'].read_bytes();text=raw.decode('utf-8')
        content=json.dumps({'lines':len(text.splitlines()),'characters':len(text),'brief_sha256':hashlib.sha256(raw).hexdigest()})
    elif tid=='outline':
        lines=sources['brief'].read_text(encoding='utf-8').splitlines()
        content=json.dumps({'title':lines[0],'sections':lines[1:]},ensure_ascii=False)
    elif tid=='page':
        f=load_json(sources['facts-data']);o=load_json(sources['outline-data'])
        content='<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Fixture</title></head><body><h1>'+html.escape(o['title'])+'</h1>'
        content+=''.join('<p>'+html.escape(x)+'</p>' for x in o['sections'])
        content+='<footer>lines='+str(f['lines'])+' '+f['brief_sha256']+'</footer></body></html>'
    elif tid=='audit':
        content=json.dumps({'subject_sha256':hashlib.sha256(sources['page-html'].read_bytes()).hexdigest(),'fixture':True})
    else: raise ValueError('Unknown fixture task')
    target.write_text(content+'\n',encoding='utf-8')
    artifacts=[{**out,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}]
    ep=Path(packet['workspace'])/'evidence/fixture-technical.json'
    write_json(ep,{'fixture':True,'kind':'artifact_integrity','task_id':tid,'all_findings_passed':True,'not_verified':'requirement acceptance'})
    technical={'execution':'EXECUTED','outcome':'PASS','evidence_kind':'RUNTIME_FACT',
               'evidence_path':'evidence/fixture-technical.json','evidence_sha256':hashlib.sha256(ep.read_bytes()).hexdigest()}
    result={'schema_version':3,'result_id':tid+'-fixture-'+packet['lease_token'][:16],
            'task_id':tid,'lease_token':packet['lease_token'],'plan_digest':packet['plan_digest'],
            'goal_digest':packet['goal_digest'],'artifacts':artifacts,'technical_validation':technical,
            'checks':pending_checks(packet,artifacts,technical['evidence_path'],technical['evidence_sha256']),
            'concerns':[],'external_actions':[]}
    result.update(diagnostics or {})
    write_json(Path(packet['result_path']),result)
    return result
if __name__=='__main__': run(load_json(Path(sys.argv[1])))
