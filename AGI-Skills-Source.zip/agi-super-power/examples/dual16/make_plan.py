"""Generate a deterministic synthetic 16-shard benchmark, never a live task plan."""
from __future__ import annotations
import hashlib,json
from pathlib import Path


def make_plan(source: Path, *, corrupt_retries=2, dependencies=False):
    source.mkdir(parents=True,exist_ok=True)
    numbers=source/'numbers.json'
    numbers.write_text(json.dumps({'numbers':list(range(1,4097))})+'\n',encoding='utf-8')
    ids=[f'w{i:02d}' for i in range(1,17)]
    tasks=[]
    for i,tid in enumerate(ids):
        aid='out-'+tid
        tasks.append({'id':tid,'role':'shard-worker','mission':f'Compute count, sum and square-sum for disjoint source shard {i}/16',
            'work_key':'shard-'+str(i),'scope':f'Only source indices congruent to {i} modulo 16',
            'requirements':['R1'],'depends_on':[ids[i-8]] if dependencies and i>=8 else [],
            'reads':['numbers'],'outputs':[{'id':aid,'path':f'shards/{tid}.json'}],
            'steps':['Read pinned source','Compute only assigned shard','Write assigned JSON'],
            'tools':[],'boundaries':['No sibling writes','No delegation','Do not claim acceptance'],
            'executor':{'type':'fixture','transport_network':False},
            'capabilities':{'network':False,'shell':False,'model_delegation':False,'external_write':False},
            'reviewer':'control-b' if i<8 else 'control-a',
            'acceptance':[{'id':'check-'+tid,'requirement':'R1','method':'dual16-shard-v1','evidence_kind':'RUNTIME_FACT',
                           'subject':{'scope':'artifact','artifact_id':aid},'params':{'shard':i,'shards':16}}]})
    return {'schema_version':3,'run_id':'dual16-fixture','goal':{'id':'dual16-benchmark','version':1,
        'objective':'OFFLINE synthetic benchmark: independently compute and verify sixteen disjoint numeric shards',
        'constraints':['Exactly two controller processes, eight workers per controller; these are NOT model agents'],
        'non_goals':['Model intelligence','Native-host compatibility','Production task quality'],
        'requirements':[{'id':'R1','text':'Every shard matches independently recomputed values from its pinned source'}]},
        'policy':{'max_parallel':16,'max_attempts':corrupt_retries,'max_total_attempts':32,'lease_seconds':60},
        'inputs':[{'id':'numbers','path':'numbers.json','sha256':hashlib.sha256(numbers.read_bytes()).hexdigest()}],
        'orchestration':{'profile':'dual-controller-16','min_workers':16,'workers_per_controller':8,
            'on_insufficient_host':'BLOCK','max_controller_turns':32,
            'controllers':[{'id':'control-a','mission':'Schedule shards 0..7; independently review team B', 'members':ids[:8]},
                           {'id':'control-b','mission':'Schedule shards 8..15; independently review team A', 'members':ids[8:]}]},
        'tasks':tasks}
