#!/usr/bin/env python3
"""End-to-end OFFLINE 18-process test. Zero network, zero model calls, zero paid APIs.

The two supervisor processes decide dispatch/review/rework; the 16 worker
processes perform separate computations. These processes are NOT model agents.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import queue
from pathlib import Path
import subprocess
import sys
import threading
import time
import uuid
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'scripts'))
from kernel import local_file, load_json
from team_runtime import TeamStore, TeamError, require, write_json, digest, canonical
from v3_protocol import pending_checks
import dual16
from make_plan import make_plan

class SessionProcess:
    def __init__(self,slot,cwd):
        cwd.mkdir(parents=True,exist_ok=True)
        self.stderr=(cwd/'stderr.log').open('wb')
        self.p=subprocess.Popen([sys.executable,'-B',str(Path(__file__).with_name('fixture_session.py')),slot],
             stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,text=True,encoding='utf-8',bufsize=1,cwd=cwd)
        self.slot=slot;self.lock=threading.Lock();self.lines=queue.Queue()
        self.reader=threading.Thread(target=self._read,daemon=True);self.reader.start()
        hello=self.call({'op':'hello'});require(hello['pid']==self.p.pid,'FIXTURE_PID','PID mismatch')
        self.hid='fixture-process-'+str(self.p.pid)+'-'+slot
    def _read(self):
        try:
            for line in self.p.stdout:self.lines.put(line)
        finally:self.lines.put(None)
    def call(self,request):
        with self.lock:
            if self.p.poll() is not None:raise RuntimeError('Fixture process exited: '+str(self.p.returncode))
            self.p.stdin.write(canonical(request)+'\n');self.p.stdin.flush()
            line=self.lines.get(timeout=15)
            if line is None:raise RuntimeError('Fixture EOF (not a successful host finish)')
            self.last_response=line
            msg=json.loads(line)
            if not msg['ok']:raise RuntimeError(msg['message'])
            return msg['data']
    def close(self):
        if self.p.poll() is None:
            try:self.call({'op':'close'});self.p.wait(timeout=3)
            except Exception:
                self.p.kill();self.p.wait(timeout=3)
        for pipe in (self.p.stdin,self.p.stdout):
            if pipe:pipe.close()
        self.reader.join(timeout=1);self.stderr.close()


def base(store):
    return {'plan_digest':store.meta('plan_digest'),'goal_digest':store.meta('goal_digest'),'execution_kind':'fixture'}


def save(store,name,obj):
    rel='reviews/dual16/'+name+'-'+uuid.uuid4().hex+'.json';write_json(store.root/rel,obj)
    return {'path':rel,'sha256':local_file(store.root,rel)['sha256']}


def collect_fixture(store,packet,session,observation):
    root=Path(packet['workspace']);outroot=Path(packet['output_root'])
    artifacts=[{**out,'sha256':local_file(outroot,out['path'])['sha256']} for out in packet['contract']['outputs']]
    proof={'kind':'artifact_integrity','task_id':packet['task_id'],'all_findings_passed':True,
           'fixture':True,'artifacts':artifacts,'not_verified':['Business requirements','Model execution']}
    tpath=root/'evidence/fixture-integrity.json';write_json(tpath,proof)
    technical={'execution':'EXECUTED','outcome':'PASS','evidence_kind':'RUNTIME_FACT',
               'evidence_path':'evidence/fixture-integrity.json','evidence_sha256':hashlib.sha256(tpath.read_bytes()).hexdigest()}
    rawpath=root/'evidence/process-observation.json';write_json(rawpath,observation)
    receipt={'host_run_id':session.hid,'mode':'fixture','finished':True,'task_id':packet['task_id'],
             'lease_token':packet['lease_token'],'pid':session.p.pid,'exit_code':0,
             'note':'A persistent deterministic local fixture process returned; NOT a model/LLM agent.'}
    rpath=root/'evidence/host-receipt.json';write_json(rpath,receipt)
    result={'schema_version':3,'result_id':packet['task_id']+'-'+packet['lease_token'][:16],
            'task_id':packet['task_id'],'lease_token':packet['lease_token'],'plan_digest':packet['plan_digest'],
            'goal_digest':packet['goal_digest'],'host_run_id':session.hid,'artifacts':artifacts,
            'technical_validation':technical,'checks':pending_checks(packet,artifacts,technical['evidence_path'],technical['evidence_sha256']),
            'concerns':[],'external_actions':[],
            'host_receipt':{'path':'evidence/host-receipt.json','sha256':hashlib.sha256(rpath.read_bytes()).hexdigest()}}
    write_json(root/'controller-result.json',result)
    return store.submit(result)


def run(out: Path,scenario='clean') -> dict:
    require(not out.exists(),'DEMO_EXISTS','Choose a NEW output directory; no deletion/overwrite')
    out.mkdir(parents=True);source=out/'source';plan=make_plan(source,dependencies=scenario=='dependencies')
    write_json(out/'plan.json',plan);job=out/'job'
    TeamStore.create(job,plan,source,offline_fixture=True)
    processes={};observations=[];rejected=0;rounds=0;error=None;started=time.monotonic()
    try:
        with TeamStore(job) as store:
            ref=save(store,'probe',{**base(store),'host':'fixture','session_capacity':18,'worker_parallel_capacity':16,
                  'persistent_sessions':True,'resume':True,'query':True,'async_launch':True,'cancel':True,
                  'authorized':True,'source':'Local deterministic subprocess harness, NOT native model capacity'})
            dual16.register_probe(store,ref)
            # Reserve before every real Popen. All 18 stay alive throughout the job.
            for slot in ['control-a','control-b']+[f'w{i:02d}' for i in range(1,17)]:
                launch=dual16.reserve(store,slot);p=SessionProcess(slot,out/'processes'/slot);processes[slot]=p
                ref=save(store,'start-'+slot,{**base(store),'slot':slot,'launch_nonce':launch['launch_nonce'],
                    'host_run_id':p.hid,'state':'idle','native_tool':'OFFLINE subprocess.Popen',
                    'raw_response':canonical({'pid':p.p.pid,'host_run_id':p.hid,'fixture':True})})
                dual16.observe_start(store,slot,ref)
            for rounds in range(1,33):
                statuses=[{'slot':slot,'host_run_id':p.hid,'state':'idle' if p.p.poll() is None else 'stopped'} for slot,p in processes.items()]
                ref=save(store,'roster',{**base(store),'sessions':statuses,'native_tool':'OFFLINE Popen.poll',
                    'raw_response':canonical(statuses)})
                dual16.barrier(store,ref)
                for cid in ['control-a','control-b']:
                    packet=dual16.request_decision(store,cid)
                    decision=processes[cid].call({'op':'decide','packet':packet,'force_false_accept':scenario=='false-pass' and rounds==2})
                    ref=save(store,'decision-'+cid,{**base(store),'controller':cid,'host_run_id':processes[cid].hid,
                        'turn_nonce':packet['turn_nonce'],'decision':decision,'returned_payload_sha256':digest(decision),
                        'native_tool':'OFFLINE controller stdin/stdout','raw_response':processes[cid].last_response})
                    dual16.record_decision(store,cid,ref)
                grants=list(store.db.execute('SELECT * FROM d16_grants WHERE consumed=0 ORDER BY rowid'))
                packets=[]
                for grant in grants:
                    if grant['action']=='dispatch':
                        tid=grant['task'];packet=store.claim(tid,tid)
                        store.bind(tid,packet['lease_token'],'fixture',processes[tid].hid)
                        packets.append(packet)
                    else:
                        try:dual16.apply_review(store,grant['id'])
                        except TeamError as exc:
                            if exc.code!='GATE_FAILED':raise
                            dual16.invalidate_grant(store,grant['id'],'Injected false acceptance was independently rejected')
                            rejected+=1
                with ThreadPoolExecutor(max_workers=max(1,len(packets))) as pool:
                    future_map={pool.submit(processes[p['task_id']].call,{'op':'work','packet':p,'sleep':0.12,
                        'corrupt':scenario in ('rework','false-pass') and p['task_id']=='w03' and p['attempt']==1,
                        'crash':scenario=='crash' and p['task_id']=='w03'}):p for p in packets}
                    for future in as_completed(future_map):
                        packet=future_map[future];tid=packet['task_id']
                        try:
                            response=future.result();observations.append(response)
                            collect_fixture(store,packet,processes[tid],response)
                        except Exception as exc:
                            store.mark_uncertain(tid,packet['lease_token'],str(exc))
                            ref=save(store,'health-'+tid,{**base(store),'slot':tid,'host_run_id':processes[tid].hid,
                                'state':'stopped' if processes[tid].p.poll() is not None else 'unknown',
                                'raw_response':canonical({'host_run_id':processes[tid].hid,'error':str(exc)})})
                            dual16.observe_health(store,tid,ref);error=str(exc)
                status=store.status()
                if status['completed'] or error or any(x['status']=='blocked' for x in status['tasks']):break
            status=store.status()
            events=[dict(row) for row in store.db.execute('SELECT * FROM events ORDER BY seq')]
            for row in events:row['detail']=json.loads(row['detail'])
            write_json(out/'events.json',events)
            write_json(out/'status.json',status)
    finally:
        for p in processes.values():p.close()
    sweep=sorted([(x['started'],1) for x in observations]+[(x['finished'],-1) for x in observations])
    concurrent=0;peak=0
    for _,delta in sweep:concurrent+=delta;peak=max(peak,concurrent)
    summary={'scenario':scenario,'execution_kind':'OFFLINE_PROCESS_FIXTURE','model_calls':0,
             'native_agents_executed':0,'controller_processes':sum(s.startswith('control-') for s in processes),
             'worker_processes':sum(s.startswith('w') for s in processes),'distinct_pids':len({p.p.pid for p in processes.values()}),
             'workers_per_controller':[8,8],'resident_process_barrier':18 if len(processes)==18 else None,
             'peak_overlapping_worker_operations':peak,'worker_operations_completed':len(observations),
             'all_processes_reaped':all(p.p.poll() is not None for p in processes.values()),
             'rounds':rounds,'false_approvals_rejected':rejected,'completed':status['completed'],
             'accepted':status['metrics']['accepted'],'attempts':status['metrics']['attempts'],
             'observed_error':error,'elapsed_seconds':round(time.monotonic()-started,3),
             'scope':'Scheduling, 2x8 ownership, same-session repair, independent verifier gate, and cleanup only; no LLM/native-host performance claim'}
    write_json(out/'summary.json',summary);return summary


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--scenario',choices=['clean','rework','false-pass','crash','dependencies'],default='clean');a=p.parse_args()
    try:
        result=run(a.out,a.scenario);print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0 if result['completed'] else 2
    except (ValueError,OSError,RuntimeError,queue.Empty) as exc:
        print(json.dumps({'error':type(exc).__name__,'message':str(exc),'native_agents_executed':0}));return 1
if __name__=='__main__':raise SystemExit(main())
