#!/usr/bin/env python3
"""Persistent OFFLINE test process. Not an LLM, not a native model Agent.
Two instances make control decisions; sixteen instances compute disjoint shards.
The root merely relays; each controller's response is received over its own pipe.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import sys
import time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'scripts'))
from team_runtime import canonical
from verifier_registry import evaluate

slot=sys.argv[1]

def respond(req):
    action=req['op']
    if action=='hello':return {'pid':os.getpid(),'slot':slot,'fixture':True}
    if action=='decide':
        p=req['packet']; actions=[]
        for t in p['ready']:
            actions.append({'action':'dispatch','task_id':t['task_id'],'reason':'Execute only my assigned shard: '+t['mission']})
        for t in p['reviews']:
            passed=evaluate(t['packet'],t['result'])['passed']
            choice='accept' if passed else 'rework'
            if req.get('force_false_accept'):choice='accept'
            actions.append({'action':choice,'task_id':t['task_id'],
                            'reason':'Independent read/recompute of frozen shard output: '+('passed' if passed else 'mismatch; same owner must repair')})
        if not actions:actions=[{'action':'wait','task_id':None,'reason':'No ready owned work or assigned review in this snapshot'}]
        return {**{k:p[k] for k in ('controller','turn_nonce','plan_digest','goal_digest')},'actions':actions}
    if action=='work':
        p=req['packet']; started=time.monotonic()
        if req.get('sleep'):time.sleep(req['sleep'])
        if req.get('crash'):os._exit(23)
        src=Path(p['input_snapshots'][0]['path']).read_bytes(); nums=json.loads(src)['numbers']
        i=p['contract']['acceptance'][0]['params']['shard']; values=nums[i::16]
        total=0;squares=0
        for value in values:total+=value;squares+=value**2
        data={'shard':i,'count':len(values),'total':total,'sum_squares':squares,
              'source_sha256':hashlib.sha256(src).hexdigest()}
        if req.get('corrupt'):data['total']+=1
        out=p['contract']['outputs'][0];target=Path(p['output_root'])/out['path'];target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(json.dumps(data)+'\n',encoding='utf-8')
        return {'completed':True,'slot':slot,'pid':os.getpid(),'started':started,'finished':time.monotonic(),
                'output_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'fixture':True}
    if action=='close':return {'stopped':True,'pid':os.getpid()}
    raise ValueError('Unknown fixture operation')

for line in sys.stdin:
    try:
        req=json.loads(line);answer=respond(req)
        print(canonical({'ok':True,'data':answer}),flush=True)
        if req['op']=='close':break
    except Exception as exc:
        print(canonical({'ok':False,'error':type(exc).__name__,'message':str(exc)}),flush=True)
