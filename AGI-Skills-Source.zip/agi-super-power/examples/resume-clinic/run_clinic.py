#!/usr/bin/env python3
"""Drive the resume-clinic plan end to end against the deterministic stub.

  python3 examples/resume-clinic/run_clinic.py --output /abs/new-job [--forge forge-parse]

Dispatches each ready wave through team_runner, then has the coordinator review every
submitted task. `review accept` is what actually runs the registered verifiers, so a task
whose artifact lies is refused HERE and its downstream never unlocks. The script reports
exactly where a run stopped; it never edits a submitted result to make it pass.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts'))

from team_runner import run_batch                      # noqa: E402
from team_runtime import TeamError, TeamStore, digest  # noqa: E402
import team_runtime                                    # noqa: E402

HERE = Path(__file__).resolve().parent
ROLES = ['repo-research', 'qa-auditor', 'research-evidence', 'office-delivery',
         'delivery-integrator', 'general']


def adapters(forge: str | None) -> dict:
    argv = [sys.executable, '-B', str(HERE / 'stub_worker.py')]
    if forge:
        argv += ['--forge', forge]
    return {'schema_version': 1,
            'adapters': {r: {'argv': argv, 'mode': 'command', 'timeout_seconds': 120} for r in ROLES}}


def review_submitted(job: Path, forge: str | None) -> list[dict]:
    """Coordinator review. Acceptance itself is the registry, executed inside review()."""
    outcomes = []
    with TeamStore(job) as store:
        submitted = [r['id'] for r in store.db.execute("SELECT id FROM tasks WHERE status='submitted'")]
        goal = store.meta('goal_digest')
    for tid in submitted:
        with TeamStore(job) as store:
            row = store.row(tid)
            result = json.loads(row['result'])
        evidence = {'reviewer': 'coordinator', 'task_id': tid, 'attempt': row['attempt'],
                    'method': ('Coordinator checked the submitted result is hash-bound to this attempt, then handed it to the '
                               'independent verifier registry. The producer self-report is not evidence. These verifiers prove '
                               'only that nothing was fabricated and nothing was omitted - not that the advice is good.'),
                    'producer': 'deterministic stub_worker.py (no model was called)',
                    'forge_mode_active': forge, 'worker_concerns': result['concerns'],
                    'result_digest': digest(result)}
        rel = f'reviews/{tid}-{row["attempt"]}-evidence.json'
        team_runtime.write_json(job / rel, evidence)
        review = {'task_id': tid, 'result_id': result['result_id'], 'result_digest': digest(result),
                  'goal_digest': goal, 'reviewer': 'coordinator', 'decision': 'accept',
                  'reason': 'Independent registry verifiers decide this; the coordinator does not pre-judge the outcome.',
                  'evidence_path': rel,
                  'evidence_sha256': hashlib.sha256((job / rel).read_bytes()).hexdigest()}
        try:
            with TeamStore(job) as store:
                outcomes.append({'task_id': tid, **store.review(review)})
        except TeamError as exc:
            outcomes.append({'task_id': tid, 'status': 'BLOCKED', 'code': exc.code, 'message': str(exc)})
    return outcomes


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', required=True, type=Path, help='new job directory (must not exist)')
    ap.add_argument('--forge', default=None)
    args = ap.parse_args(argv)

    job = args.output.absolute()
    # Keep init's own JSON off stdout so this script emits exactly one document.
    with contextlib.redirect_stdout(io.StringIO()):
        team_runtime.main(['init', '--plan', str(HERE / 'plan.resume-v3.json'),
                           '--inputs', str(HERE), '--job', str(job)])
    config, log = adapters(args.forge), []
    while True:
        with TeamStore(job) as store:
            ready = store.ready()
        if not ready:
            break
        batch = run_batch(job, config, allow_commands=True)
        reviews = review_submitted(job, args.forge)
        log.append({'dispatched': [b['task_id'] for b in batch['batch']], 'reviews': reviews})
        if any(r['status'] == 'BLOCKED' for r in reviews):
            break
    with TeamStore(job) as store:
        final = store._status()
    blocked = [r for step in log for r in step['reviews'] if r['status'] == 'BLOCKED']
    print(json.dumps({'forge': args.forge, 'job': str(job), 'log': log,
                      'tasks': {t['id']: t['status'] for t in final['tasks']},
                      'accepted': sum(t['status'] == 'accepted' for t in final['tasks']),
                      'completed': final['completed'],
                      'blocked_at': [{'task_id': b['task_id'], 'code': b['code']} for b in blocked],
                      'downstream_locked': [t['id'] for t in final['tasks'] if t['status'] == 'pending']},
                     ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
