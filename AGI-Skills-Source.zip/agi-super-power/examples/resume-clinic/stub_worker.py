#!/usr/bin/env python3
"""Deterministic resume-clinic stub worker (a 桩, NOT a model).

Run as a reviewed local command adapter: `python3 -B stub_worker.py [--forge NAME] PACKET`.
It calls no model and no network; given the same packet it always writes the same bytes.
Its only purpose is to exercise the ledger and the registered verifiers end to end, and --forge
lets a specific task emit a specific lie so the matching verifier can be shown to catch it.

A stub run proves the PIPELINE and the VERIFIERS work. It proves nothing about model quality.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scripts'))
from v3_protocol import pending_checks  # noqa: E402

DATE_RANGE = re.compile(r'^(\d{4}\.\d{2}-\d{4}\.\d{2})\s\s+(.+)$')
JD_ITEM = re.compile(r'^\s*(\d+)[.、)]\s*\S')
# Diagnoses are anchored to the sample resume: (id, 1-based line, verbatim quote, issue).
DIAGNOSES = [
    ('D-1', 10, '负责公司核心交易系统的开发和维护工作', '只写职责范围，没有交付结果或规模。'),
    ('D-2', 11, '积累了丰富的经验', '空泛自评，无项目名称、角色或产出。'),
    ('D-3', 16, '效果显著', '性能优化没有任何量化指标。'),
    ('D-4', 17, '若干需求交付', '工作量含糊，未说明需求数量或影响。'),
]
SUGGESTIONS = {
    'D-1': '改写为“主导核心交易系统 X 模块，日均处理 N 笔订单”，用可核对的规模替代职责描述。',
    'D-2': '删除自评，替换为一个具体项目：名称、你的角色、交付物。',
    'D-3': '补上优化前后的量化对比，例如“P99 从 A ms 降至 B ms”。',
    'D-4': '写明需求条数与业务影响，替换“若干”。',
}
CONCLUSIONS = {
    'JD-1': ('命中', '2020.07 起连续后端岗位，技能列出 Python、Go。'),
    'JD-2': ('部分', '写了“熟悉分布式系统”，但没有服务拆分的具体证据。'),
    'JD-3': ('缺口', '原文只写“了解 Kubernetes”，不足以支撑“熟练使用”。'),
    'JD-4': ('缺口', '“效果显著”没有任何量化口径。'),
    'JD-5': ('部分', '有“带领小组”，但没有跨团队协作或方案输出的例子。'),
}


def parse_resume(lines: list[str]) -> dict:
    """Every value below is sliced out of the resume text, never composed."""
    education, experience = [], []
    for index, line in enumerate(lines):
        match = DATE_RANGE.match(line)
        if not match:
            continue
        parts = [p for p in re.split(r'\s\s+', match.group(2)) if p]
        record = {'period': match.group(1)}
        if any('大学' in p for p in parts):
            record.update({'school': parts[0], 'major': parts[1], 'degree': parts[2]})
            education.append(record)
        else:
            record.update({'company': parts[0], 'title': parts[1]})
            experience.append(record)
    skills: list[str] = []
    for line in lines:
        if '、' in line and 'Python' in line:
            skills = [s for s in line.split('、') if s]
    for extra in ('Kubernetes',):
        if any(extra in line for line in lines):
            skills.append(extra)
    return {'name': lines[0],
            'target_role': lines[1].split('：', 1)[1],
            'education': education, 'experience': experience, 'skills': skills}


def build(task_id: str, reads: dict[str, str], forge: str | None):
    """Return the artifact body for this task, with the requested lie injected if any."""
    if task_id == 'parse':
        data = parse_resume(reads['resume'].splitlines())
        if forge == 'forge-parse':
            # Invented employer: appears nowhere in resume.txt.
            data['experience'].append({'period': '2019.01-2020.06', 'company': '字节跳动', 'title': '后端实习生'})
        return data
    if task_id == 'diag':
        rows = [{'id': i, 'line': n, 'quote': q, 'issue': t} for i, n, q, t in DIAGNOSES]
        if forge == 'forge-diag':
            rows[2]['line'] = 15  # quote '效果显著' actually lives on line 16
        return {'problems': rows}
    if task_id == 'match':
        ids = ['JD-' + JD_ITEM.match(l).group(1) for l in reads['jd'].splitlines() if JD_ITEM.match(l)]
        rows = [{'id': i, 'conclusion': CONCLUSIONS[i][0], 'basis': CONCLUSIONS[i][1]} for i in ids]
        if forge == 'forge-match':
            rows = [r for r in rows if r['id'] != 'JD-5']  # silently drop a requirement
        return {'requirements': rows}
    if task_id == 'rewrite':
        ids = [p['id'] for p in json.loads(reads['diag-json'])['problems']]
        rows = [{'diagnosis_id': i, 'suggestion': SUGGESTIONS[i]} for i in ids]
        if forge == 'forge-rewrite':
            rows.append({'diagnosis_id': 'D-99', 'suggestion': '补一段领导力描述。'})  # no such diagnosis
        return {'suggestions': rows}
    if task_id == 'report':
        suggestions = json.loads(reads['rewrite-json'])['suggestions']
        requirements = json.loads(reads['match-json'])['requirements']
        if forge == 'forge-report':
            suggestions = [s for s in suggestions if s['diagnosis_id'] != 'D-3']  # drop a diagnosis
        out = ['# 简历体检报告', '', '> 本报告只核对“有没有编造、有没有遗漏”，不评价建议写得好不好。', '', '## 诊断与改写建议', '']
        for s in suggestions:
            out.append(f"- **{s['diagnosis_id']}**：{s['suggestion']}")
        out += ['', '## JD 对标', '']
        for r in requirements:
            out.append(f"- **{r['id']}**：{r['conclusion']} —— {r['basis']}")
        out.append('')
        return '\n'.join(out)
    if task_id == 'qa':
        ids = [p['id'] for p in json.loads(reads['diag-json'])['problems']]
        # Whole-token match: a bare `in` would see D-3 inside JD-3 and under-report the gap.
        missing = sorted(i for i in ids
                         if not re.search(r'(?<![0-9A-Za-z_-])' + re.escape(i) + r'(?![0-9A-Za-z_-])',
                                          reads['report-md']))
        return {'coverage_complete': not missing, 'missing_diagnosis_ids': missing,
                'checked': '每条诊断 id 是否出现在报告正文中', 'method': 'deterministic substring scan'}
    raise SystemExit('stub_worker does not know task ' + task_id)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--forge', default=None, help='inject one specific lie, for verifier counter-tests')
    ap.add_argument('packet', type=Path)
    args = ap.parse_args(argv)

    packet = json.loads(args.packet.read_text(encoding='utf-8'))
    contract, workspace = packet['contract'], Path(packet['workspace'])
    reads = {s['id']: Path(s['path']).read_text(encoding='utf-8') for s in packet['input_snapshots']}
    body = build(contract['id'], reads, args.forge)

    artifacts = []
    for spec in contract['outputs']:
        target = Path(packet['output_root']) / spec['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        text = body if isinstance(body, str) else json.dumps(body, ensure_ascii=False, indent=2) + '\n'
        target.write_text(text, encoding='utf-8', newline='\n')
        artifacts.append({'id': spec['id'], 'path': spec['path'],
                          'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})

    proof = {'schema_version': 1, 'kind': 'artifact_integrity', 'task_id': contract['id'],
             'all_findings_passed': True, 'artifacts': artifacts,
             'findings': [{'id': 'declared_files_written', 'ok': True}],
             'not_verified': ['Requirement correctness', 'Whether the content is true',
                              'Anything a model would have contributed - this is a deterministic stub']}
    evidence = workspace / 'evidence' / 'technical.json'
    evidence.parent.mkdir(parents=True, exist_ok=True)
    evidence.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    digest = hashlib.sha256(evidence.read_bytes()).hexdigest()

    result = {'schema_version': 3, 'result_id': f"{contract['id']}-stub-{packet['lease_token'][:16]}",
              'task_id': contract['id'], 'lease_token': packet['lease_token'],
              'plan_digest': packet['plan_digest'], 'goal_digest': packet['goal_digest'],
              'artifacts': artifacts,
              'technical_validation': {'execution': 'EXECUTED', 'outcome': 'PASS',
                                       'evidence_kind': 'RUNTIME_FACT',
                                       'evidence_path': 'evidence/technical.json',
                                       'evidence_sha256': digest},
              'checks': pending_checks(packet, artifacts, 'evidence/technical.json', digest),
              'concerns': [], 'external_actions': []}
    Path(packet['result_path']).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n',
                                           encoding='utf-8', newline='\n')
    print(json.dumps({'task_id': contract['id'], 'forge': args.forge,
                      'artifacts': [a['path'] for a in artifacts]}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
