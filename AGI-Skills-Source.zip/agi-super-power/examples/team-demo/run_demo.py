#!/usr/bin/env python3
"""Run real subprocesses using deterministic fixtures, never real model agents."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from kernel import load_json
from team_runtime import TeamStore, digest, write_json
from team_runner import run_batch


def verify_fixture(tid: str, packet: dict, result: dict) -> dict:
    path = Path(packet["output_root"]) / result["artifacts"][0]["path"]
    raw = path.read_text(encoding="utf-8")
    if tid == "facts":
        assert json.loads(raw)["lines"] == 3
    elif tid == "outline":
        assert json.loads(raw)["title"] == "AGI Super Power" and len(json.loads(raw)["sections"]) == 2
    elif tid == "page":
        assert "<h1>AGI Super Power</h1>" in raw and "lines=3" in raw and raw.count("<p>") == 2
    else:
        assert json.loads(raw)["html_checks"] == "PASS" and json.loads(raw)["fixture"] is True
    return {"fixture": True, "method": "controller independently checks expected fixed output", "task_id": tid, "result_digest": digest(result), "model_test": "NOT_EXECUTED"}


def run(output: Path) -> dict:
    folder = Path(__file__).resolve().parent
    plan = load_json(folder / "plan.json")
    TeamStore.create(output, plan, folder)
    config = {"schema_version": 1, "adapters": {t["role"]: {"argv": [sys.executable, "-B", str(folder / "fixture_worker.py")], "mode": "fixture", "timeout_seconds": 15} for t in plan["tasks"]}}
    batches = []
    for _ in range(4):
        batch = run_batch(output, config, allow_commands=True)
        batches.append(batch)
        with TeamStore(output) as store:
            for row in list(store.db.execute("SELECT * FROM tasks WHERE status='submitted' ORDER BY id")):
                result, packet = json.loads(row["result"]), json.loads(row["packet"])
                checked = verify_fixture(row["id"], packet, result)
                relative = f"reviews/{row['id']}-{row['attempt']}.json"
                write_json(output / relative, checked)
                review = {"task_id": row["id"], "result_id": result["result_id"], "result_digest": digest(result), "goal_digest": packet["goal_digest"],
                          "reviewer": "coordinator", "decision": "accept", "reason": "Fixed fixture output independently checked; not a real model benchmark.",
                          "evidence_path": relative, "evidence_sha256": hashlib.sha256((output / relative).read_bytes()).hexdigest()}
                store.review(review)
            state = store.status()
            if state["completed"]:
                # Duplicate delivery notification must not execute the task again.
                result = json.loads(store.row("audit")["result"])
                duplicate = store.submit(result)
                report = {"execution": "EXECUTED", "outcome": "PASS", "evidence_kind": "RUNTIME_FACT", "scope": "local fixture orchestration only",
                          "batches": batches, "duplicate_receipt": duplicate, "final": store.status(), "real_model_agents": "NOT_EXECUTED"}
                write_json(output / "demo-report.json", report)
                return report
    raise RuntimeError("Demo failed to complete; inspect the job ledger")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__); p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    print(json.dumps(run(args.output.absolute()), ensure_ascii=False, indent=2))
