#!/usr/bin/env python3
"""Deterministic offline worker fixture. NOT an LLM or a professional agent."""
from __future__ import annotations
import hashlib
import html
import json
from pathlib import Path
import sys


def hash_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(packet: dict) -> dict:
    root = Path(packet["output_root"])
    sources = {i["id"]: Path(i["path"]) for i in packet["input_snapshots"]}
    tid = packet["task_id"]
    target = root / packet["contract"]["outputs"][0]["path"]
    target.parent.mkdir(parents=True, exist_ok=True)
    if tid == "facts":
        raw = sources["brief"].read_text(encoding="utf-8")
        content = json.dumps({"lines": len(raw.splitlines()), "characters": len(raw), "brief_sha256": hash_file(sources["brief"])}, ensure_ascii=False)
    elif tid == "outline":
        lines = sources["brief"].read_text(encoding="utf-8").splitlines()
        content = json.dumps({"title": lines[0], "sections": lines[1:]}, ensure_ascii=False)
    elif tid == "page":
        facts = json.loads(sources["facts-data"].read_text(encoding="utf-8"))
        outline = json.loads(sources["outline-data"].read_text(encoding="utf-8"))
        content = '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>' + html.escape(outline["title"]) + '</title><h1>' + html.escape(outline["title"]) + '</h1>'
        content += ''.join('<p>' + html.escape(x) + '</p>' for x in outline["sections"])
        content += '<footer>lines=' + str(facts["lines"]) + '</footer></html>'
    elif tid == "audit":
        page = sources["page-html"].read_text(encoding="utf-8")
        assert page.startswith("<!doctype html>") and "<h1>AGI Super Power</h1>" in page and "lines=3" in page
        content = json.dumps({"fixture": True, "html_checks": "PASS", "subject_sha256": hash_file(sources["page-html"]), "not_tested": ["browser visual quality", "model reasoning"]})
    else:
        raise ValueError("Unsupported fixture task: " + tid)
    target.write_text(content + "\n", encoding="utf-8")
    evidence = Path(packet["workspace"]) / "evidence" / "worker-checks.json"
    evidence.write_text(json.dumps({"fixture": True, "task_id": tid, "method": "executed deterministic branch; output encoded and nonempty", "output_sha256": hash_file(target)}, indent=2), encoding="utf-8")
    checks = [{"id": check["id"], "execution": "EXECUTED", "outcome": "PASS", "evidence_kind": check["evidence_kind"],
               "artifact_id": packet["contract"]["outputs"][0]["id"], "subject_sha256": hash_file(target),
               "evidence_path": "evidence/worker-checks.json", "evidence_sha256": hash_file(evidence)} for check in packet["contract"]["acceptance"]]
    result = {"schema_version": 2, "result_id": tid + "-result-" + packet["lease_token"][:16], "task_id": tid,
              "lease_token": packet["lease_token"], "plan_digest": packet["plan_digest"], "goal_digest": packet["goal_digest"],
              "artifacts": [{**packet["contract"]["outputs"][0], "sha256": hash_file(target)}], "checks": checks,
              "concerns": [], "external_actions": []}
    Path(packet["result_path"]).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


if __name__ == "__main__":
    run(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")))
