#!/usr/bin/env python3
"""Offline 3.4 recovery + quality + original intelligence/ledger/fixture workflow.

A deliberately lost submission is synthetic fault injection, NOT a real host
creation. Four later local fixture processes create actual test artifacts.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'scripts'))
from kernel import local_file
from team_runtime import TeamStore,write_json,digest
from team_runner import run_batch
from intelligence_layer import enrich_plan
from delivery_state import begin_submission,observe,dispatch,resume_plan,usage_summary
from delivery_quality import record_review
from delivery_brief import brief,brief_markdown
from release_version import PACKAGE_VERSION
spec=importlib.util.spec_from_file_location('fixture33_helpers',ROOT/'examples/intelligence/run_demo.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)

def run(output):
    output=Path(output).absolute()
    if output.resolve().is_relative_to(ROOT):raise ValueError('Keep all task artifacts outside installed skill')
    output.mkdir(parents=True,exist_ok=False)
    plan=base.fixture_plan();plan['run_id']='delivery34-offline-fixture'
    plan['tasks'][0]['quality_gates']=[{'id':'Q1','requirement':'R1','layer':'requirements',
        'kind':'main_thread_review','description':'Synthetic coordinator fixture: review exact facts only, not business/visual quality'}]
    plan=enrich_plan(plan,project_id='demo34',available_tools=['file.read','file.write'],hints_by_task=base.HINTS)
    (output/'任务说明.md').write_text(brief_markdown(brief(plan)),encoding='utf-8')
    job=output/'job';TeamStore.create(job,plan,ROOT/'examples/team-demo')
    with TeamStore(job) as s:
        old=s.claim('facts','fixture-worker');reservation=begin_submission(s,'facts',old['lease_token'])
    def event(kind,number):
        p=job/'reviews'/('fault-'+str(number)+'.json')
        write_json(p,{'synthetic_fault_injection':True,'request_key':reservation['request_key'],'state':kind})
        return {'id':'fault'+str(number),'task_id':'facts','lease_token':old['lease_token'],
            'goal_digest':old['goal_digest'],'plan_digest':old['plan_digest'],'request_key':reservation['request_key'],
            'event':kind,'host_run_id':None,'tool':'offline-fault-injector','evidence_path':'reviews/'+p.name,
            'evidence_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    with TeamStore(job) as s:observe(s,event('unknown',1))
    with TeamStore(job) as s:
        resumed=resume_plan(s)
        assert resumed['actions'][0]['retry_authorized'] is False
        observe(s,event('not_created',2))
        p=job/'reviews/termination.json';write_json(p,{'task_id':'facts','lease_token':old['lease_token'],'termination':'confirmed_not_started','fixture':True})
        recovered=s.recover({'task_id':'facts','lease_token':old['lease_token'],'termination':'confirmed_not_started',
            'evidence_path':'reviews/termination.json','evidence_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
            'reason':'Explicit offline proof of non-creation; safe to retry'})
    config={'schema_version':1,'adapters':{t['role']:{'argv':[sys.executable,str(ROOT/'examples/intelligence/fixture_worker.py')],
        'mode':'fixture','timeout_seconds':30} for t in plan['tasks']}}
    batches=[]
    for _ in range(10):
        with TeamStore(job) as s:
            if s.status()['completed']:break
        batch=run_batch(job,config,allow_commands=True);batches.append(batch)
        if not batch['batch']:raise ValueError('No fixture progress')
        with TeamStore(job) as s:
            for item in batch['batch']:
                if item.get('status')!='submitted':raise ValueError(str(item))
                if item['task_id']=='facts':
                    row=s.row('facts');r=json.loads(row['result']);p=job/'reviews/manual-quality.json'
                    write_json(p,{'fixture':True,'review_scope':'Exact synthetic requirement only','not_verified':['Real business quality','PPT visual quality']})
                    record_review(s,{'task_id':'facts','lease_token':row['token'],'goal_digest':r['goal_digest'],'plan_digest':r['plan_digest'],
                        'result_digest':digest(r),'gate_id':'Q1','reviewer':'coordinator','kind':'main_thread_review','status':'PASS',
                        'evidence_path':'reviews/manual-quality.json','evidence_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                        'note':'Synthetic coordinator observation; independent deterministic registry still runs'})
                base.review(s,item['task_id'])
    with TeamStore(job) as s:
        status=s.status();assert status['completed'];usage=usage_summary(s)
        r=json.loads(s.row('facts')['result']);assert s.submit(r)['duplicate']
        accepted=s.valid_artifact('facts-data');before=accepted['sha256']
        late=Path(old['output_root'])/'research/facts.json';late.parent.mkdir(parents=True,exist_ok=True);late.write_text('late obsolete attempt')
        assert s.valid_artifact('facts-data')['sha256']==before
        checkpoints=s.db.execute('SELECT COUNT(*) FROM checkpoints34').fetchone()[0]
    report={'package_version':PACKAGE_VERSION,'execution_kind':'OFFLINE_FIXTURE_WITH_FAULT_INJECTION',
            'completed':True,'accepted_tasks':status['metrics']['accepted'],'worker_attempts':usage['worker_attempts'],
            'local_fixture_processes':sum(len(b['batch']) for b in batches),'batch_count':len(batches),
            'unknown_submission_did_not_authorize_retry':True,'confirmed_noncreation_recovery':recovered['status'],
            'duplicate_result_idempotent':True,'stale_attempt_write_did_not_change_published_artifact':True,
            'checkpoints_created':checkpoints,'real_agent_calls':0,'model_calls':0,'network_calls':0,
            'not_verified':['WorkBuddy Desktop native lifecycle','Windows real filesystem','Host OS sandbox','Real business/PPT quality','Independent model audit']}
    write_json(output/'summary.json',report);return report
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    print(json.dumps(run(p.parse_args().output),ensure_ascii=False,indent=2))
