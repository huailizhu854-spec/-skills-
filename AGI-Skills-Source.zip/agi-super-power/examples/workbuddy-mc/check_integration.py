#!/usr/bin/env python3
"""Check WBMC-INT-01 local evidence. Never creates agents or certifies host truth."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts'))
from kernel import load_json, local_file
from team_runtime import TeamStore, digest
from release_version import PACKAGE_VERSION
from workbuddy_bridge import write_new_json
from workbuddy_evidence import check_record


def check_job(job: Path) -> dict:
    checks = {}
    observations = []
    provenance = {}
    with TeamStore(job) as store:
        # All subsequent access uses an SQLite read-only connection.
        store.db.close()
        store.db = sqlite3.connect((store.root / 'team.sqlite3').as_uri() + '?mode=ro', uri=True)
        store.db.row_factory = sqlite3.Row
        status = store._status()
        from workbuddy_policy import meta_or
        execution_profile = meta_or(store, 'execution_profile', 'legacy')
        plan = store.meta('plan')
        checks['frozen_int01_plan'] = digest(plan) == digest(load_json(ROOT / 'examples/workbuddy-mc/plan.workbuddy-v3.json'))
        checks['current_runtime'] = store.meta('runtime_version') == PACKAGE_VERSION
        checks['both_accepted_and_evidence_intact'] = status['completed']
        rows = list(store.db.execute('SELECT * FROM tasks ORDER BY id'))
        checks['exactly_two_tasks_one_attempt_each'] = len(rows) == 2 and all(r['attempt'] == 1 for r in rows)
        dispatches = list(store.db.execute('SELECT * FROM dispatch34'))
        checks['two_guarded_terminal_dispatches'] = (len(dispatches) == 2 and
            all(d['guarded'] == 1 and d['state'] == 'SUCCEEDED' for d in dispatches))
        events = list(store.db.execute('SELECT * FROM events ORDER BY seq'))
        def sequence(task, kind):
            return [e['seq'] for e in events if e['task_id'] == task and e['kind'] == kind]
        order_ok = True
        for task in ('impl', 'audit'):
            stages = [sequence(task, k) for k in ('CLAIMED', 'SUBMISSION_RESERVED', 'HOST_BOUND', 'SUBMITTED', 'ACCEPTANCE_VERIFIED', 'REVIEWED')]
            order_ok &= all(len(x) == 1 for x in stages)
            if all(len(x) == 1 for x in stages):
                ordered = [x[0] for x in stages]
                order_ok &= ordered == sorted(ordered) and len(set(ordered)) == len(ordered)
        impl_review, audit_claim = sequence('impl', 'REVIEWED'), sequence('audit', 'CLAIMED')
        checks['guarded_order_and_serial_barrier'] = bool(order_ok and impl_review and audit_claim and impl_review[-1] < audit_claim[0])
        checks['two_distinct_native_ids'] = (len(rows) == 2 and all(r['mode'] == 'native' and r['host_run_id'] for r in rows)
                                               and len({r['host_run_id'] for r in rows}) == 2)
        for row in rows:
            if row['packet']:
                try:
                    provenance[row['id']] = check_record(store.root, Path(json.loads(row['packet'])['packet_path']))
                except (ValueError, OSError, KeyError, TypeError, sqlite3.Error) as exc:
                    provenance[row['id']] = {'record_consistency_passed': False, 'reason': str(exc)}
            if not row['result']:
                continue
            result = json.loads(row['result']); packet = json.loads(row['packet'])
            workspace = Path(packet['workspace'])
            receipt = load_json(workspace / result['host_receipt']['path'])
            observation = receipt['observation']
            raw = local_file(workspace, observation['raw_evidence_path'])
            observations.append({'task_id': row['id'], 'host_run_id': row['host_run_id'],
                'raw_evidence_path': (workspace / observation['raw_evidence_path']).relative_to(store.root).as_posix(),
                'raw_evidence_sha256': raw['sha256'],
                'packet_sha256': hashlib.sha256(Path(packet['packet_path']).read_bytes()).hexdigest()})
        expected = (ROOT / 'examples/workbuddy-mc/expected-result.json').read_bytes()
        result_path, review_path = store.root / 'published/result.json', store.root / 'published/review.json'
        checks['strict_result_bytes'] = result_path.is_file() and result_path.read_bytes() == expected
        expected_review = {'verdict': 'PASS', 'checks': {'name': True, 'version': True, 'status': True, 'no_extra_fields': True}}
        checks['strict_review_fields'] = review_path.is_file() and load_json(review_path) == expected_review
        checks['only_declared_published_files'] = {p.relative_to(store.root / 'published').as_posix()
            for p in (store.root / 'published').rglob('*') if p.is_file()} == {'result.json', 'review.json'}
    return {'schema_version': 1, 'test_id': 'WBMC-INT-01', 'package_version': PACKAGE_VERSION,
        'execution_profile': execution_profile,
        'eligible_for_live_review': execution_profile == 'live' and all(checks.values()) and set(provenance) == {'impl','audit'} and all(x['record_consistency_passed'] for x in provenance.values()),
        'local_evidence_checks_passed': all(checks.values()), 'checks': checks,
        'provenance_records_passed': (set(provenance) == {'impl', 'audit'} and
                                      all(x['record_consistency_passed'] for x in provenance.values())),
        'call_provenance': provenance,
        'host_observations': observations, 'real_agent_calls_by_this_checker': 0,
        'real_host_verdict': 'REQUIRES_HOST_TRACE_REVIEW',
        'scope': 'Local file, ledger and ordering consistency only; fixtures can pass these checks.',
        'required_external_evidence': ['Installed Skill path and version/hash, actual load record',
            'Two real WorkBuddy Agent calls with full verbatim returns and distinct host IDs',
            'Host trace showing begin-submit before each call and A accepted before B is created',
            'Current entrance/execution environment; unknown client metadata remains UNKNOWN']}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--job', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path, help='A new report path, outside the Skill directory')
    a = p.parse_args(argv)
    try:
        if a.out.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError('Save job evidence outside the installed Skill')
        report = check_job(a.job)
        write_new_json(a.out, report)
        print(json.dumps({'written': str(a.out), 'local_evidence_checks_passed': report['local_evidence_checks_passed'],
                          'provenance_records_passed': report['provenance_records_passed'],
                          'real_host_verdict': report['real_host_verdict']}))
        return 0 if report['local_evidence_checks_passed'] and report['provenance_records_passed'] else 2
    except (ValueError, OSError, KeyError, TypeError, sqlite3.Error) as exc:
        print(json.dumps({'error': 'WBMC_INT01_INPUT', 'message': str(exc)}), file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
