# AGI-Super-Power 3.4 RC6 — Dual16

A strict, observation-driven **2-supervisor / 16-worker** profile for the existing AGI-Super-Power ledger. Each supervisor owns eight workers and independently reviews the other supervisor's outputs.

## Implemented

- Exactly 18 distinct host session identities, with pre-launch intent and a full-roster query barrier.
- A shared SQLite ledger; no duplicate source of truth or worker access to the database.
- Scope-bound, single-use controller decisions for dispatch and cross-team review.
- Reuse of the reserved worker session, goal/plan/attempt fencing, bounded retries, and independent verification.
- Fail-closed behavior when capacity, host tools, authorization, observations, or requirements cannot be verified.
- Pure-standard-library regression and an 18-process offline harness with clean, repair, false-approval, crash and dependency scenarios.

## Not claimed

This repository does not supply a model service, bypass host limits, prove provider identity, or make a chat interface support native subagents. The shipped process harness is deterministic: **it makes zero model calls**. Live 18-session native validation is **NOT_EXECUTED**. Eighteen resident sessions are not proof of eighteen simultaneous model inferences.

The bundled WorkBuddy synchronous-terminal adapter is not compatible with the persistent-session Dual16 profile. Existing Codex/Claude observation adapters now identify the already-reserved worker session; actual host tools and current capacity still require direct validation.

## One-command offline validation

Python 3.10+, no dependencies, no credentials, no network:

```sh
python -B scripts/validate_dual16.py --out ../dual16-check
# Add --full-regression to include all retained legacy regression tests.
```

The output directory must not exist. A deliberately crashed worker is expected to leave the job blocked, with all fixture processes reaped. The validator checks that behavior rather than labeling the interrupted business task successful.

For native operation read `references/dual16-live-acceptance.md`. For the full contract read `references/dual16-protocol.md`. Chinese quick start: `双主控16快速上手.md`.

All old examples remain legacy regression fixtures, not an alternative default for new user jobs. New jobs enter through `scripts/dual16_cli.py`, which refuses plans without the strict topology.
