# v3：产物完整性与需求验收

本合同适用于母 Skill 与生成的岗位 Skill。岗位配置中的自然语言验收方法只是设计输入；进入真实任务前，总控必须把它映射成已实现、已审阅的方法，不能把描述当测试运行。

## 两层结果

第一层 artifact_integrity：校验文件集合、相对路径、实际字节哈希、输入未变、模型桥的 UTF-8/静态结构。native 路径可以接收二进制产物，不将二进制文件强解码成文本。此层 PASS 只说明相应技术检查通过。

第二层 contract_acceptance：叶节点提交的每项 requirement 保持 NOT_EXECUTED/UNVERIFIED。总控 `review accept` 独立运行 allowlist 中的 verifier，保存结果、goal/plan/contract/result 摘要、令牌、subject 哈希与验证器源码摘要，之后才发布 accepted 产物。下游读取时重新核验报告绑定。哈希是版本绑定，不是语义正确性证明或身份签名。

生产者不能注册 verifier、写父账本、修改验收标准或把技术 PASS 映射成业务 PASS。总控身份仍依赖宿主权限，不是 Python 字段鉴权。旧 schema 2 仅用于历史离线 fixture/inline 协议，不用于模型或原生宿主。

## 显式 subject

每个 acceptance 除 id / requirement / method / evidence_kind 外，必须有 subject，可有 params：

```json
{
  "id": "report-marker",
  "requirement": "R1",
  "method": "text-contains-v1",
  "evidence_kind": "RUNTIME_FACT",
  "subject": {"scope": "artifact", "artifact_id": "report"},
  "params": {"strings": ["核验范围", "未验证事项"]}
}
```

artifact 精确指定一个输入或输出；cross-artifact 使用非空、无重复的 artifact_ids；task 使用本任务 task_id，展开为本任务全部输出。不能引用未分配材料，没有“默认第一个文件”。workflow scope 当前不支持并明确拒绝；跨任务总体验收应另设 integration/audit 任务，显式 reads 其依赖产物。

## 已实现的方法及真实证明范围

| method | 能证明的范围 |
|---|---|
| demo-facts-v3 | 演示 brief 的准确行数、含全部换行的 Unicode 码点数、原始字节 SHA-256 |
| demo-outline-v3 | 演示标题与有序正文行完全匹配 |
| demo-page-v3 | 演示静态 HTML 的结构、标题、正文与上游事实关联；不是浏览器视觉检查 |
| demo-audit-v3 | 演示页面哈希及静态标签复核 |
| json-values-v1 | subject 为 JSON 对象，params.equals 中指定的顶层键和值类型精确匹配 |
| text-contains-v1 | subject 文本包含 params.strings；不证明事实准确或写作质量 |
| file-sha256-v1 | subject 字节与事先冻结的 params.sha256 匹配 |
| equal-bytes-v1 | 至少两个显式 subject 的字节哈希相同 |

注册方法都产生 RUNTIME_FACT。未知方法或没有专用实现的 SOURCE_FACT 保持 NOT_EXECUTED/UNVERIFIED，不会被自动降级成结构检查。模型自述、日志中“PASS”文本、费用字段均不提供业务验收权。

## 扩展与域限制

研究来源真实性、浏览器渲染、Office 内容质量、复杂工程测试均需要真实工具与对应的、经审阅的验收器。本版本没有预先实现所有专业场景。用户任务开工前，总控须确定每条业务要求由哪个真实方法验证；缺失则报告阻塞或让唯一整合者先添加验收器及反例测试。

扩展是对 `verifier_registry.py` 的受控代码改动，不允许任务文档携带任意 Python、shell 或路径来注册新验收。不要把上述通用字节检查冒充业务语义证明。升级后重建清单、回归测试，不能在运行中的作业里临时放宽条件。
