# v3 本地账本与接线手册

Python 3.10+，仅标准库。命令从 Skill 根目录执行；实际作业目录置于 Skill 外，不改安装包。所有命令错误返回非零退出码及 JSON，不自动执行 JSON 中的任意命令。

## 立即跑通离线协议示例

```text
python scripts/team_runtime.py compile examples/team-demo/plan.json
python examples/team-demo/run_demo.py --output /absolute/path/new-demo-job
python scripts/team_runtime.py status --job /absolute/path/new-demo-job
```

输出目录必须不存在。Windows 可换为 `C:/work/new-demo-job`；保持命令参数中的路径按当前 shell 正确引用。示例使用四个真实本地子进程：facts 与 outline 同批，page 依赖二者，audit 依赖 page；主程序独立核对固定预期后验收。模型/网络调用为零，这不是通用 Agent 能力演示。

## v3 与历史兼容边界

包版本为 3.0.0，团队协议版本为 schema 3；这不要求岗位配置、打包清单和旧 kernel 的 schema 一起变成 3。`plan.native-v3.json` 和 `plan.model-v3.json` 是新入口。原 `plan.json`/`run_demo.py` 保留 schema 2，仅允许 fixture/inline，不可用 command/native 偷换执行底座。旧作业不可原地升级，迁移须创建新目录并重验明确复用输入。

## 计划和初始化

团队 plan 与旧 `assets/templates/plan.json` 不是同一契约，不能混用。新任务以 `examples/team-demo/plan.native-v3.json` 为结构基准：executor 必须明确 type/transport_network，capabilities 必须明确 network/shell/model_delegation/external_write；acceptance 必须有 subject。输入必须有正确哈希；任务输出是具体文件，不能指定整个目录为“随便写”。

```text
python scripts/team_runtime.py init --plan /path/plan.json --inputs /path/source-folder --job /path/new-job
python scripts/team_runtime.py claim --job /path/new-job --task facts --worker research-worker
```

claim 输出完整 JSON，含 packet_path、workspace、output_root、输入快照、共同目标及任务契约。租约从领取时开始；正常运行用 heartbeat 续约。不要复制一张任务包给多个执行者。

## 启动、收回与接受

```text
python scripts/team_runtime.py bind --job /path/new-job --task facts --token TOKEN --mode native --host-run-id ACTUAL_HOST_ID
python scripts/team_runtime.py heartbeat --job /path/new-job --task facts --token TOKEN
python scripts/team_runtime.py submit --job /path/new-job --file /path/result.json
python scripts/team_runtime.py review --job /path/new-job --file /path/review.json
```

TOKEN 和 ACTUAL_HOST_ID 必须来自真实领取和宿主启动，不使用示例值冒充运行。模式区分 native、command、inline、fixture；bind 本身不启动 Agent。

v3 result 的必要字段：schema_version=3、technical_validation、result_id、task_id、lease_token、plan_digest、goal_digest、host_run_id、artifacts、checks、concerns、external_actions、host_receipt。

artifacts 每条是 `id/path/sha256`，必须与 outputs 完全一致。technical_validation 只报告 artifact_integrity。checks 使用 `id/execution/outcome/evidence_kind/method/subject/subject_hashes/evidence_path/evidence_sha256`，全部为 NOT_EXECUTED/UNVERIFIED，由接线层生成，禁止 worker 自报需求 PASS。

`review accept` 在总控内部调用独立 registry，保存 `reviews/acceptance-*.json`，报告固定 goal/plan/contract/result 与 subject 字节。未知 verifier 不通过。schema 2 的旧格式仅留给离线兼容测试；通用 kernel 的结构校验也不替代新需求验收。

host_receipt 是 `path/sha256`，文件内容至少包含 `host_run_id/mode/finished/task_id/lease_token`；finished 必须为真正结束后的 true。可附退出码、PID、耗时和注释。原生还必须包含 `host=claude_code_native` 的 finished observation，精确绑定 task/token/host ID 与原始事件文件哈希；由 native_host_bridge.py 收集。本地包装器由 runner 自动记录。哈希绑定不能证明事件叙述真实性。

review 字段：task_id、result_id、result_digest、goal_digest、reviewer、decision、reason、evidence_path、evidence_sha256。decision 为 accept/rework/block；result_digest 以 `team_runtime.digest(result)` 计算，是 sort_keys、紧凑分隔、UTF-8、ensure_ascii=False 的规范 JSON SHA-256。审阅证据相对作业目录，必须放在 reviews/。

所有接受动作由总控执行。脚本核对审阅者名称，但没有实现用户身份认证。不得允许不可信叶节点直接调用这些管理命令或修改数据库。

## 超时恢复

```text
python scripts/team_runtime.py reconcile --job /path/new-job
python scripts/team_runtime.py recover --job /path/new-job --file /path/recovery.json
```

reconcile 仅将过期 leased 改为 uncertain，不重排队。recovery 必须包含 task_id、lease_token、termination、evidence_path、evidence_sha256、reason；可选 action=retry 或 adopt_finished。termination 仅允许 confirmed_stopped / confirmed_not_started。证据放 reviews/，内容须绑定同一个 task_id、令牌和终止结论。

retry 在确认旧执行停止后恢复 pending，下一次 claim 使用新令牌。adopt_finished 仅用于核验已经结束的旧运行，保留原令牌重新开放结果接收；它不应再启动程序，也不增加 attempt。未知状态不算停止证明。

## 目标变更

```text
python scripts/team_runtime.py supersede --job /path/old-job --new-goal-digest NEW_GOAL_SHA256 --reason "用户修订交付要求"
python scripts/team_runtime.py recover --job /path/old-job --file /path/old-worker-stop.json
python scripts/team_runtime.py revise --job /path/old-job --plan /path/new-plan.json --inputs /path/revalidated-inputs --next-job /path/new-job
```

supersede 立即拒收旧版结果，但不会假装取消远端运行。对每个尚存执行者核实停止并 recover（此时变 cancelled），再 revise。新目标 ID 相同、版本递增，摘要必须匹配 supersede 记录；一个旧作业最多创建一个继任作业。不需要重做的成果可以在新计划中注册为已重新核验的输入。

## 文件结构和存储边界

plan.json 是冻结计划；team.sqlite3 是主账本和事件记录；sources/ 是初始化快照；workers/ 是每个任务每次尝试的独立工作区；published/ 是验收后逻辑产物；reviews/ 是总控验收和恢复证据。完整作业目录支持恢复，结束前不要删除 staging 或证据。

使用本机可信文件系统，不放在跨机共享的网络盘来宣称分布式锁。路径检查拒绝穿越、链接与可移植名称冲突，但文件系统仍假设不被拥有同等权限的恶意进程并发修改。运行器不提供容器隔离、账户鉴权、签名回执或远端 exactly-once。

## v3 并发槽位与故障日志

备用桥的 `AGI_MODEL_MAX_CONCURRENT > 0` 要求所有 worker 共享一个 `AGI_MODEL_BUDGET_DIR` 和同一个容量。SQLite 事务领取槽位，容量变化拒绝；0 明确表示不限流。正常响应释放，异常保持 uncertain，进程消失不自动回收。只支持本机可信本地文件系统、合作进程；不是跨机限流器，不阻止绕过门禁的其他程序。

人工/宿主查证远端已停后，总控保存含 owner_token、termination（confirmed_stopped/confirmed_not_started）、reason 的真实结论，再运行：

```text
python scripts/model_semaphore.py --directory BUDGET_DIR --limit N --token OWNER_TOKEN --receipt TERMINATION_RECEIPT.json
```

每次模型尝试前后 fsync 追加 `model-events.jsonl`；预算、调用开始、返回、解析、异常不再等成功才保存。突然中断只留下开始事件意味着 UNKNOWN。错误响应最多保留 256 KiB 文本及原始长度/哈希/截断标志，不能声称超限内容完整保留；超时只能记录已收到的部分。日志是私有证据，哈希链不是远端认证。
