# WBMC-INT-01：安装版 Skill 的双 Agent 串行集成验收

状态：**NOT_EXECUTED**。本文件是 rc.5 的执行规程，不是实测报告。此前 rc.3 的限定结论记录在 VERSION.json；不自动认证当前包。WB-01/01B/02 和 rc.2/rc.3 的历史 ID 不得用作本轮 ID。

本轮只检验手机 App → WorkBuddy 云端。桌面端、手机连接电脑、并发、取消及运行中恢复不在本轮通过声明内。总共至多两次真实创建：A 实现、B 审核；任一步失败或结果未知就停止，不自动重试。所有作业文件放在 Skill 外部的新目录，不修改旧任务账本。

目录：环境与安装 → 初始化 → A → 终态回收与验收 → B → 总体验收 → 失败处理。

先读取 [rc.5 实机交接](workbuddy-rc5-handoff.md)。init 成功后须先冻结当前能力快照，才能 prepare；以下 A/B 流程保持串行。

## 1. 环境与安装证据

1. 确认实际入口和执行地点为 WorkBuddy 手机云端。记录客户端版本/OS、云端 OS、模型配置；不能观察的值写 UNKNOWN。
2. 通过当前宿主实际支持的方式安装本包。历史探测使用 `~/.codebuddy/skills/agi-super-power`，这只是观察到的路径，不保证所有版本一致。若该位置已有技能或有活跃任务，先保留备份，不覆盖活跃安装；候选路径须由宿主真实加载并给出证据。
3. 从**实际被加载的安装目录**读取 `SKILL.md`、`VERSION.json` 与本规程，记录路径、版本 `3.4.0-rc.5`、SKILL.md SHA-256、宿主加载记录。仅浏览 ZIP/源码不算安装通过。不能证明加载则填 `BLOCKED_SKILL_LOAD`，不开始创建。
4. 在安装目录中运行 `python3 -B scripts/delivery_cli.py doctor`。这只检查本地依赖，不证明宿主能力。确认当前会话有真实 Agent 工具并公开核对其接口；未暴露则填 `BLOCKED_HOST_TOOL`。
5. 确认任务可使用真实文件读写工具。禁止为使测试通过而悄悄开 shell、联网或模型 CLI 权限。

以下 `$WBMC_JOB` 为新作业目录绝对路径，`$WBMC_PACKET` 等变量均来自当前命令的真实返回；不得填示例 ID/旧令牌。命令在实际安装目录内执行，Windows 场景不属于本轮。

## 2. 初始化同一份账本

设置一个未使用的包外绝对路径为 `WBMC_JOB`，只预建其父目录。**WBMC_JOB 本身及其 reviews 等子目录都不得提前创建**；init 将排他创建新 job。若已存在或任一准备步骤失败，停止本轮并保存原始错误；不要删除、换目录后继续同一轮，也不要将 JOB_EXISTS 排除出失败统计。然后：

```bash
python3 -B scripts/team_runtime.py compile examples/workbuddy-mc/plan.workbuddy-v3.json
python3 -B scripts/team_runtime.py init --plan examples/workbuddy-mc/plan.workbuddy-v3.json --inputs examples/workbuddy-mc --job "$WBMC_JOB"
```

冻结计划的预算：`max_parallel=1`、`max_attempts=1`、`max_total_attempts=2`。初始化不会启动 Agent。不要更改计划来绕过阻塞。

仅在 init 成功后，按调用证据规程建立 job/reviews/run-authorization.json，使用刚创建账本中的实际计划摘要。之后才进入 prepare。固定顺序为：父目录 → init → 当前能力冻结 → 来源记录 → prepare → begin-submit → intent → 真实调用。

## 3. A：唯一实现者

```bash
python3 -B scripts/native_host_bridge.py prepare --job "$WBMC_JOB" --host workbuddy_mobile_cloud --task impl --worker wbmc-implementer
```

保存实际返回为准备记录。读取其中 `packet_path` 为 `WBMC_PACKET`、`lease_token` 为 `WBMC_TOKEN`、`delegation_path` 为当前派单正文；从 packet 读取 workspace。按 [调用证据规程](workbuddy-mobile-cloud-provenance.md) 独占保存本轮用户指令来源与即将发出的实际工具参数。记录以下提交授权的完整输出到本次 evidence/begin-submit.json（只调用一次；已存在文件不能覆盖）：

```bash
python3 -B scripts/delivery_cli.py begin-submit --job "$WBMC_JOB" --task impl --token "$WBMC_TOKEN"
```

成功返回后，先运行 `workbuddy_evidence.py intent`，固定新作业授权、调用参数、派单和提交返回的关联。具体命令见调用证据规程。

只有本次命令成功返回 `SUBMITTING` 且授权一次创建、调用前证据保存成功时，**由总控在宿主中真实调用一次 Agent 工具**。任务正文使用刚生成的 delegation 文件，不让用户手填工具参数，不在子任务里另建总控。不要自动追加“正确答案”或代替 A 写 result.json。

调用应同步返回终态。逐字保存返回（含宿主尾注）至该尝试 `workspace/evidence/workbuddy-raw-return.txt`，并保留宿主原始调用记录。保存时使用能保留原始文本的工具，禁止手工改 ID、拼接历史返回或补写缺失尾注。A 只写 `output_root/result.json`。必须保留末尾换行与全部空白；不得按渲染行数删除换行。现有文件工具不能核实字节时，A 报告不确定，交总控原验收器裁决，不扩展 shell 权限。

## 4. 从终态返回到原验收器

首先用 `workbuddy_evidence.py return` 固定原始返回关联，再用 `check` 检查记录与文件一致。缺失工具调用 ID 或宿主轨迹时保持 null/NOT_AVAILABLE，不猜测、不补造。

把真实原始返回路径赋给 `WBMC_RAW`，新的事件路径赋给 `WBMC_EVENT`（同一尝试 evidence 目录下的 `workbuddy-finished-event.json`）。确认返回属于本次成功终态后执行：

```bash
python3 -B scripts/workbuddy_bridge.py normalize --raw-return-file "$WBMC_RAW" --observed-outcome completed
python3 -B scripts/workbuddy_bridge.py event --packet "$WBMC_PACKET" --raw-return-file "$WBMC_RAW" --observed-outcome completed --out "$WBMC_EVENT"
python3 -B scripts/native_host_bridge.py bind --job "$WBMC_JOB" --event "$WBMC_EVENT"
python3 -B scripts/native_host_bridge.py collect --job "$WBMC_JOB" --event "$WBMC_EVENT"
```

event 命令只做证据格式转换。bind/collect 会再核对当前账本、令牌、原始哈希和提交闸门；不能因为生成了 JSON 就声称 Agent 已运行。任一命令非零退出立即停止。输出文件必须是新文件，不能覆盖原始返回。

`collect` 后是 submitted。总控实际读取 A 的产物与冻结输入，独立核验；随后用以下代码构造绑定当前结果的审核记录，并调用原 `TeamStore.review`。`review accept` 内的注册验收器会再次执行字节/字段核验；以下代码本身不会改写产物或绕过验收器。

```bash
python3 -B - "$WBMC_JOB" impl <<'PY'
import hashlib, json, sys
from pathlib import Path
sys.path.insert(0, 'scripts')
from team_runtime import TeamStore, digest
job, task = Path(sys.argv[1]), sys.argv[2]
with TeamStore(job) as s:
    r = json.loads(s.row(task)['result'])
    evidence = job / 'reviews' / (task + '-coordinator-review.json')
    with evidence.open('x', encoding='utf-8') as f:
        json.dump({'task_id': task, 'result_digest': digest(r),
                   'method': 'Frozen registered verifiers run on review accept; host truth checked separately'}, f)
    answer = s.review({'task_id': task, 'result_id': r['result_id'],
        'result_digest': digest(r), 'goal_digest': r['goal_digest'],
        'reviewer': 'coordinator', 'decision': 'accept',
        'reason': 'Run frozen requirement verifiers against current artifacts',
        'evidence_path': 'reviews/' + evidence.name,
        'evidence_sha256': hashlib.sha256(evidence.read_bytes()).hexdigest()})
    print(json.dumps(answer))
PY
```

必须返回 accepted 才继续。记录 `published/result.json` 的 SHA-256 为审核前哈希。

## 5. B：独立审核者

使用 `prepare --task audit --worker wbmc-auditor`，其余严格复用第 3–4 步，但所有 packet/token/workspace/event 变量换成本次 audit 的真实值，`begin-submit --task audit`，审核代码末尾参数由 `impl` 改为 `audit`。

B 根据独立标准 `frozen-req` 审核 `result-data`，计算实际检查值；全部符合才 PASS，否则 FAIL 并停止。B 只读自己的冻结输入并只写 `output_root/review.json`，不修改 A 的结果。不要把 A 的 PASS 自述作为审核依据。B 必须是第二次真实 Agent 调用，ID 与 A 不同。不得创建第三个 Agent；任何失败本轮到此结束。

## 6. 总体验收和回传

B accepted 后：

```bash
python3 -B scripts/team_runtime.py status --job "$WBMC_JOB"
python3 -B examples/workbuddy-mc/check_integration.py --job "$WBMC_JOB" --out "$WBMC_JOB/WBMC-INT-01-local-check.json"
```

检查器新增 `provenance_records_passed`，要求 A/B 各有一套通过校验的调用记录；旧的 `local_evidence_checks_passed` 单独不代表完整证据检查通过，两者必须同时为 true。检查器验证两项 accepted、两个不同 ID、提交/绑定/验收的账本先后、原始证据哈希、冻结计划、严格产物字段以及 A 的发布文件未改变。它始终输出 `real_host_verdict=REQUIRES_HOST_TRACE_REVIEW`：**本地合成回执也能通过文件检查，所以绝不自动宣布真实宿主成功。**

总控另行核对宿主真实工具轨迹：两次调用，先授权后创建，A 完整返回并 accepted 后才创建 B；实际安装/加载记录存在；两个真实尾注与事件、账本和回收结果对应。检查重开会话时仍读取同一份账本，不能据摘要重派；这只是作业状态复核，不声明运行中恢复已支持。

回传 `WBMC-INT-01-report.md`，按以下顺序写：

- 结论：`PASS_INSTALLED_SKILL_SERIAL_INTEGRATION` / `FAILED` / `BLOCKED` / `OUTCOME_UNKNOWN`，附失败步骤与真实原因。
- 实际入口/执行地点、已观察到的客户端与模型信息、安装路径、包版本与安装文件哈希、真实加载依据。
- A/B 每次 prepare、begin-submit、真实调用和完整返回、event、bind、collect、review 的证据位置与哈希；实际 ID 不自行生成。
- 本地检查报告、前后 result.json 哈希、两份最终产物、真实创建总数与串行顺序。
- 未验证：桌面、手机连接电脑、异步查询/取消/恢复、宿主权限隔离。不得改成 PASS。

原始返回和账本留在私有作业目录；给项目负责人提供这次汇总材料的报告与必要证据即可。公开发布仍走原脱敏机制，不把日志直接塞进发行包。安装版集成通过后再更新兼容矩阵，不能先改版本状态替代证据。

## 7. 失败、断线与缺失 ID

明确报错可 normalize 为 failed；中断且结果不明为 outcome_unknown；缺尾注保留 ID_UNKNOWN。上述情况都不得绑定成成功，也不得重复创建。

保存原始返回与 `delivery_cli checkpoint --job "$WBMC_JOB"`。本宿主无可用后台 task_id，禁止拿 Agent ID 调用 TaskOutput/TaskStop；没有停止证据时保留归属。账本状态可检查，运行中恢复尚未证明。两次总预算并非两次重试预算。

失败后如用户明确启动新一轮，用新 job 并记录其指令来源与 previous_job。不得把新目录视为自动重试授权。本地时序无法推算用户消息的真实发送时间；不明时间留 null/UNKNOWN。
