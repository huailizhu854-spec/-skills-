# WorkBuddy Mobile Cloud Adapter v0.3 — 合同、兼容矩阵与回退

状态：ADAPTER_CANDIDATE_INTEGRATION_NOT_EXECUTED。WB-01/01B/02 是手机云端宿主观察；rc.3 文件、账本、产物与调用记录一致性已复核通过，保留 JOB_EXISTS 后继续的流程例外及来源核实缺口。当前 rc.4 安装版集成尚未执行，不继承旧轮通过状态。
依据：WB-01、WB-01B、WB-02 实测报告（2026-09-23，WorkBuddy 云端沙箱，Ubuntu 24.04.3 x86_64，容器 49cf4b8837f5）。
范围边界：**WorkBuddy Desktop 不在本适配器范围**，仍为 `handoff_contract_only`（裸别名 `workbuddy` → `workbuddy_candidate` 保持 HANDOFF_ONLY，有既有测试硬断言）。

## 1. 冻结宿主合同（全部来自实测，非文档推断）

| 能力 | 观察结果 | 证据 |
|---|---|---|
| create | 总控一次真实 Agent 工具调用，**阻塞至子 Agent 终态**，返回最终消息 | WB-01/01B/02 三轮 |
| 运行标识 | 返回尾部宿主附加 `[Agent ID: agent-…]`；子 Agent 自身不可见该 ID | WB-02 双自述 + 主线程尾注比对 |
| task_id | 不存在 | WB-01/01B：create 从未返回 task_id |
| query | 不支持：`TaskOutput` 对 Agent ID 返回 `No task found…There are no running background tasks` | WB-01、WB-01B 两次实测 |
| 后台注册表 | `run_in_background=true` 不入注册表：约 80 秒任务仍同步阻塞返回终态 | WB-01B |
| wait | 经由 create 的同步阻塞天然满足；无独立 wait 句柄 | WB-01B 时间线 |
| cancel / confirm_stopped | unknown（无 task_id 句柄可试；未实测） | — |
| resume | unknown（未实测） | — |
| artifacts | 子 Agent 文件写入真实可达（主线程 stat/cat/sha256 独立核验） | WB-01/01B/02 |
| 独立上下文 | 工具定义声明 + 间接证据；无法直接检查 | WB-02 |

禁止假设清单（`workbuddy_bridge.py contract` 可机读）：task_id 存在；Agent ID 可作 task_id；TaskOutput 可查 Agent ID；TaskStop 可停 Agent ID；`run_in_background=true` 入后台注册表；运行中可 resume；运行中可确认取消。

## 2. Adapter v0.3 行为

- 适配器：`scripts/host_adapters/workbuddy_mobile_cloud.py`（继承 `ObservedNativeAdapter`，只消费总控观察，从不创建 Agent）。
- 归一化器：`scripts/workbuddy_bridge.py normalize --raw-return-file F --observed-outcome completed|failed|outcome_unknown`。

### normalized result（冻结规范）

```text
host: workbuddy_mobile_cloud
execution_mode: synchronous_terminal
status: COMPLETED_SYNC | FAILED | EXECUTION_OUTCOME_UNKNOWN
agent_id: 宿主尾注原值；解析失败为 null（agent_id_status=ID_UNKNOWN）
task_id: null（恒定；宿主无 task_id）
terminal_result: create 调用逐字原始返回（含 sha256）
query_supported: false
cancel_supported: "unknown"
live_resume_supported: "unknown"
```

### 状态规则

- **A（COMPLETED_SYNC）**：终态返回 + 恰一个 Agent ID 尾注。保存真实 ID 与原始返回 → `native_host_bridge.py bind/collect`（Agent ID 作为 `host_run_id`）→ 既有验收流程。**不调用 TaskOutput 再证完成**。
- **B（FAILED）**：调用明确报错。保存原始错误，走既有返工规则；无 Agent ID 可言，不伪造。
- **C（EXECUTION_OUTCOME_UNKNOWN）**：宿主/会话异常中断。禁止自动重新创建；保存 checkpoint；账本停留 SUBMITTING/UNKNOWN，等待人工或宿主侧证据核实。
- **D（未来 task_id）**：仅记录为能力候选；v0 不实现任何未实测的异步生命周期，升级需单独验证轮。

### 适配器级闸门（超出基类要求的部分）

1. `bind` 只接受 `event='finished'`（同步终态没有 started/部分观察）。
2. 原始返回必须**恰含一个**独占最后非空行的 `[Agent ID: …]` 尾注，前面须有非空终态消息；ID-shaped 正文也计入歧义检查。尾注中的 ID 必须等于 `host_run_id`，否则拒绝绑定（零个 → ID_UNKNOWN 不入账；多个 → 歧义拒收）。
3. `delivery_state.dispatch.guarded==1` 校验：**未执行 begin-submit 的绑定直接拒绝**（`LIFECYCLE_NOT_ENABLED`）——本宿主不提供旧无闸门路径。

## 3. 唯一责任集成（复用原账本，无第二调度器）

`prepare/claim（dispatch34 PREPARED）→ delivery_cli begin-submit（SUBMITTING，request_key，授权恰好一次真实创建）→ 总控一次真实 Agent 调用 → 逐字保存原始返回 → normalize → bind（HOST_BOUND，RUNNING）→ collect（产物哈希进账本）→ submit → 独立 review（verifier_registry 对冻结方法/subject/参数验收）→ accept/publish`。work_key、artifact ownership、lease、goal_version、checkpoint、begin-submit、acceptance 全部为原有机制，本适配器未新增任何账本结构。

## 4. 兼容矩阵（区分宿主观察与安装版集成）

| 项 | 值 |
|---|---|
| 客户端版本 / 客户端 OS | UNKNOWN（沙箱内不可读；不得伪造） |
| 实际执行端 | WorkBuddy 云端沙箱（Ubuntu 24.04.3，x86_64 容器） |
| 模型配置 | 宿主默认，不可从沙箱观察 |
| rc.4 Skill 安装与加载 | NOT_EXECUTED；需在 WorkBuddy 实际环境确认，不能以读取 ZIP 替代 |
| 宿主原生委派 | WB-01/01B/02 历史报告已有实测；这些 ID 不得复用为新验收结果 |
| 安装版 Skill 集成 | NOT_EXECUTED；待 [WBMC-INT-01](workbuddy-mobile-cloud-int01.md) |
| 生命周期：create/wait | 已验证（synchronous_terminal） |
| 生命周期：query | 不支持（实测两次 No task found） |
| 生命周期：cancel / resume / 后台注册表 | unknown / unknown / 不存在（实测） |
| Windows / macOS 桌面端 | 未验证，不声明 |

注意：`assets/hosts/workbuddy-mobile-cloud-observed-contract.json` 为实测观察记录（绑定本报告证据哈希）。因客户端版本/OS 在沙箱内不可观察，`delivery_cli probe-check` 对本宿主仍会因 PROBE_TARGET/HOST_STATE 项受阻——这是诚实缺口，不是缺陷；probe-check 通道不是本适配器的执行前提。

## 5. 未支持能力清单（v0 明确不做）

1. 后台任务注册表、task_id、TaskOutput 查询、TaskStop 停止
2. 运行中取消与停止确认（WB-03 场景）
3. 运行中恢复、超时仍在运行（WB-05/07 场景）
4. 幂等 create（宿主无 request_key 参数；request_key 仅为本地提交标识）
5. WorkBuddy Desktop、Windows 8.3 实机、宿主嵌套专家团映射
6. 并发多 Agent（max_parallel 冻结为 1；本轮所有验证均为串行）

## 6. 回退方式

1. 原始 rc.1 包未改动：`/root/uploads/…/agi-super-power-3.4.0-rc.1.zip`（SHA-256 `acd7d8b9…abbf012` 与冻结基线一致）。
2. 回退执行：删除 `~/.codebuddy/skills/agi-super-power`（仅在确认无活跃任务、已备份并由用户要求回退时处理安装副本），用原 zip 重新安装即可；原包目录不含 `workbuddy_mobile_cloud` 注册，相关计划会被既有闸门以 HOST_UNKNOWN 拒绝——这是预期的安全失败。
3. 进行中的 3.4 账本不受影响：rc.2 未改任何账本表结构；新目录新任务原则不变。

## 7. rc.2 接入修订

- 仅接受独立尾注与非空终态消息；解析不证明供应商身份。
- 原始返回按 UTF-8 字节保存与哈希，保留 CRLF；归一化和事件输出不覆盖已有文件。
- WorkBuddy 的直接绑定及提交路径也要求 begin-submit；旧账本缺少 3.4 表时拒绝。
- 同一作业内不同 WorkBuddy 尝试不得复用 Agent ID；异步生命周期仍不提供。
- 试验预算写入计划：max_parallel=1、max_attempts=1、max_total_attempts=2。

## 8. rc.3 证据与字节保真修订

- 叶节点保留末尾换行，不以工具显示行数判断字节相等；工具无法确认时报告不确定，不扩权。
- [调用证据规程](workbuddy-mobile-cloud-provenance.md) 为新轮补充调用前意图、实际参数准备副本、返回关联与来源保留项；数据库只读，不新增调度器。
- intent/return/check 是协调者记录与一致性核对，不是宿主原生调用拦截器，不具有宿主幂等创建保证。
- rc.2 R1 字节验收失败且下游未派发；R2 本地文件/账本/产物通过。授权原始消息与宿主轨迹未独立核实，rc.3 不自动继承安装版通过状态。
- 同步终态、无可用 task_id 的观察不能推出宿主一定不保存调用日志；日志可导出能力独立记为 UNKNOWN。
