# 来源机制 → 本包实现

检索日期 2026-09-19。下表描述实际采用或排除，不把目录扫描称为逐行审阅。精确 SHA、许可证与文件阅读范围见 [source-register](../provenance/source-register.json)。所有执行代码均为本项目独立实现；唯一随包上游模板以 `.source.txt` 保存，作为惰性对照资料，不参与技能发现。

| 一手来源 | 采用的机制 | 本包具体落点 | 未采用或限制 |
|---|---|---|---|
| 用户上传 Zhushi Superflow | 通用契约、证据维度、原件保护、科研链、前端七门 | core-sop、evidence、research/frontend playbook、kernel validate-run | 不搬嵌套原档、个人资料、旧商业授权；不要求所有任务过科研或 V5 |
| 前轮 specialist-sop 母版 | 单入口、岗位合同、阶段执行、记录模板 | SKILL.md、六份 roles、S0–S7 | 将单布尔验收升级为执行/结论/证据三维 |
| agentskills/agentskills | 标准目录、name/description、渐进加载、配对评测 | 单入口与按需 references、evaluation、生成器 | 文档许可与代码许可不同；不把扩展字段当通用标准 |
| obra/superpowers | 有边界的实现任务、父级验收、自审与独立审阅分开 | orchestration、任务单、evaluation | 不继承固定模型、无条件提交、每次都停下询问等策略 |
| docker/docker-agent | prepare 与 run 分离、fork执行边界 | runtime-adapters 的 DISCOVER/BIND/LAUNCH | 源码与文档提示词层级有漂移；不复制额外工具集绕过过滤 |
| shiwenwen/hope-agent | 物化前核对目录与正文、受限执行、消费去重 | runtime-adapters、orchestration 恢复协议 | 不把上游固定秒数当通用限制，不悄悄以父 Agent 冒充专属角色 |
| fitchmultz/pi-subagents | criteria/evidence/verify 接受标准、回执、有界修复 | kernel、evidence、S4/S5 | 字段存在不代表正确；不会从资料自动执行 verify shell |
| BjornMelin/dev-skills | scope/ownership、离线检查与真运行区分 | 原创 kernel 与生成器 | 所选代码许可未明确，源码与长模板不随包 |
| langchain-ai/deepagents | 技能按需读取、子 Agent 输入隔离、记忆作为参考数据 | 入口加载、orchestration、恢复摘要 | 不捆绑框架依赖，不默认扫描私人历史 |
| bytedance/deer-flow | 产物可验证句柄、执行回执与自述区分、验收文字不提升系统权限 | evidence、run 模板、委派任务单 | 不承诺等价实现其运行时凭据/回执基础设施 |
| github/copilot-sdk | per-agent skills、scoped tools、started/completed/failed事件 | runtime-adapters、插件能力合同 | 不继承示例 approve-all；需要真实 SDK 与连接 |
| openai/openai-agents-python | handoff 接管与 agents-as-tools 协调的区分 | runtime-adapters 控制流说明 | 本包无模型 API 执行器，不含密钥 |
| ynulihao/AgentSkillOS | 按能力选 Skill，再做依赖图组合 | 岗位/插件按需路由、check-dag | 仅架构参考，未复现其检索模型，根许可未确证不复制 |
| microsoft/autogen | 历史多 Agent 框架对照 | 来源台账与迁移判断 | README 已提示 maintenance mode，不作为最新实现首选 |
| microsoft/agent-framework | 新框架及技能多源设计提案 | 来源台账、按需源与能力分离设计 | 已读ADR状态为 proposed，只作设计参考，不称已落地接口 |
| benchflow-ai/skillsbench | 验证结构、方法、结果与一致性；真实产物评测 | evaluation、回归案例、脚本测试 | 不照搬固定测试数量或安装脚本；不声称跑过其基准 |
| ZypherHQ/agent-orchestration-skill | 小任务轻量、大任务DAG；上下文摘要与派发切片分开 | orchestration、context-capsule、check-dag | 不继承任意固定七阶段上限和强制模型配置 |
| leonardsellem/codex-specialized-subagents | 角色/技能选择需要显式范围和缺失回报 | role-catalog、运行能力探测 | 不捆绑旧 MCP 执行器，关键词匹配不是能力证明 |
| aAAaqwq/AGI-Super-Team | 岗位与技能目录、唯一配置来源、行为验证与目录数量区分 | role-catalog、source-register | 未打包其大型团队与第三方资源库，未继承其组织角色默认值 |
| affaan-m/ECC | 分阶段验证、跨会话摘要、自动块与手工备注区分 | SOP检查点、context-capsule | 不采用固定模型/覆盖率/定时全套检查；原旧仓库名已重定向 |
| wshobson/agents | 角色目录、上下文管理、渐进展开 | 岗位模板与 references | 部分示例为伪代码，不能当可运行优化引擎 |
| OthmanAdi/planning-with-files | 单写者计划、项目隔离、恢复及止损 | DAG ownership、S5恢复、context-capsule | 不安装强制继续 hook，不用阶段计数证明完成 |
| mattpocock/skills | spec→implement→review、引用式交接 | S2/S3/S4、委派任务单 | 不把上游 issue/commit 步骤当本次外发授权 |
| 当前插件审计 | 文档、设计、数据、GitHub、浏览器按能力接入 | plugin-adapters、office/design playbook | 没有复制专有插件实现，缓存不等于已安装，工具可见不等于账号可用 |

## 与此前母版的具体差异

1. 从简易状态清单升级为需求、产物哈希、证据与验收门的可检查关联。
2. 增加 DAG 依赖与并行写入冲突检查，拒绝循环、遗漏依赖和同波路径碰撞。
3. 从一个通用文本模板升级为可验证的角色 JSON 与独立岗位 ZIP 生成器。
4. 加入插件能力路由、按需专业流程、固定来源版本和可复核的检索目录。
5. 发行时使用单入口、文件清单、SHA-256、确定性打包和篡改检查。

## 兼容性边界

来源审计证明所读取版本有对应机制。离线测试证明本包脚本在记录环境的行为。跨宿主真实 Agent 启动、插件业务操作和具体科研/设计成果仍须在对应任务中实际验证，不能混成一次总 PASS。
