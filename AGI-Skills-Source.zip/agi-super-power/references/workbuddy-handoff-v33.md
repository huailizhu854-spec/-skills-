# WorkBuddy：3.3 交接边界

**本版状态：HANDOFF_ONLY。不是 WorkBuddy 原生适配完成。**

已提供 `workbuddy_candidate` 宿主目录条目、路由兼容入口和面向小白的任务交接文件。它可描述当前目标、选定岗位、缺失工具、上下文政策与工作流级别。它不会安装插件、调用未知 CLI、冒充 WorkBuddy 的创建/等待/取消接口，也不会给用户账号提权。

`host_registry.execution_mode()` 只接受本包明确实现的执行类型。手机云端是单独的宿主；即使有人修改目录 JSON 声称桌面可用，也不能把它升级成可执行适配器。`v3_protocol` 仍会拒绝把桌面候选宿主写入原生执行合同。

rc.4 已内置 [桌面探测规程](workbuddy-desktop-probe.md)、初始化与证据检查命令，直接使用主包即可。它们不属于桌面执行适配器，也不自动创建 Agent。

## 小白入口

用户可以直接给总控一句任务：

> 使用 AGI-Super-Power 3.3，根据我上传的教材修正 PPT，保持版式，演讲约 20 分钟。先核对材料，不编造缺失内容；本次任务只保留一个 PPT 修改负责人。

总控负责材料读取、真实工具检查、任务合同和必要的结构化数据，不能把 JSON 配置负担直接扔给用户。若宿主实际能完成本地单 Agent 文件任务，可以明确说明以单 Agent 执行；这不构成本包的 WorkBuddy 原生多 Agent 适配证明。

工程人员可检视一个不执行的交接文件：

```text
python scripts/intelligence_cli.py plan --request "根据教材修正PPT并保持版式" --host workbuddy --output ../workbuddy-handoff33.json
python scripts/intelligence_cli.py host workbuddy
```

`NOT_EXECUTED` 是正常且必要的输出。岗位已选中不等于材料已读取、PPT 已制作或验收已实现。高风险内容依然需要合适的专业核查。

## 进入下一版原生适配的门槛

需要在真实 WorkBuddy 宿主逐项取得当前接口与原始观察：创建并取得 ID、限制能力和工作区、等待终态、取消并确认停止、输出回收、目标/租约绑定、一次完整成功任务、一次真实失败/恢复任务。接口必须依据当前可用工具的实际 schema 实现，不从产品名称猜测。

随后实现独立适配器、保持工作所有权、补终态与迟到结果的对抗测试，再进行同任务、同模型、同预算的前后对比。只有这些证据完成后才增加执行类型；不能仅修改 `HOSTS` 列表就宣布支持。

## 本轮外部资料

2026-09-22 读取到的官方页面：CodeBuddy Code Skills（技能系统），https://www.workbuddy.ai/docs/zh/cli/skills 。该页面属于 **CodeBuddy CLI**；这里仅将其用于了解技能入口形式，不能把页面中的 CLI 能力直接视作 WorkBuddy 桌面产品的运行证据。

另两处目标文档抓取超时，未据此补造接口；本轮没有安装或真实运行 WorkBuddy。没有采用前一轮关于 WorkBuddy Bench 规模或宿主 effort 参数的未复核断言。
