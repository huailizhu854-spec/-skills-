# 3.4.0-rc.1 只读审计交接

你是独立审计者，不是第二个写者。先固定 ZIP SHA-256，读取 `VERSION.json`、`references/release-report.md`、`references/traceability-v34.json`，再看源码差分。只读定位问题，不并行重写同一模块。

## 本轮事实边界

这是可靠交付层的离线候选。WorkBuddy 桌面端适配没有完成，Windows 实机未跑，没有独立模型盲测。本包开发检查是同一主线程进行，不能称为已有 Pro/Ultra 独立审计。

## 独立复核命令

在独立解压目录中运行，所有输出放包外的新位置：

```text
python scripts/delivery_cli.py doctor
python scripts/run_offline_tests.py --report ../independent-tests34.json
python examples/delivery34/run_demo.py --output ../independent-demo34
python scripts/package_release.py verify /absolute/agi-super-power-3.4.0-rc.1.zip
```

## 审计重点

检查新增生命周期在 begin-submit 之前没有宿主副作用。并发/重试只能登记一次。检查非原生或未知 WorkBuddy 不会被目录声明解锁。

检查创建结果未知、取消未确认、过期租约不自动重派；原始终态证据改变时不能恢复；失败不允许冒用 adopt_finished。检查同一事件 ID 不同内容、不同运行 ID、旧目标和旧令牌。

检查新的状态与检查点确实共用 SQLite 事务；检查点不是第二份事实源。验证相同产物大小写/父子路径冲突、旧尝试写暂存目录不会影响正式成果。不要把这些当作操作系统级强制隔离。

检查 quality_gates 在编译前冻结、记录只能由指定非执行者登记、未知/缺失/人工待判断不通过、绑定目标/结果/证据。记录的用户身份/人工审阅是总控观察，不是认证。

检查记忆撤销发生在 claim 前、claim 后但 begin-submit 前、运行中、验收后时的处理；跨项目不能误伤。检查未显式通知的外部记忆变化没有被夸称自动传播。

检查 Windows 修复是否真的解决短/长路径别名，同时不 resolve 掉 symlink/reparse 检查。Linux 通过不能替代 Windows 测试；权限跳过必须列出。

比较 3.3 的 13 个旧测试文件。仅版本断言有预期迁移：从固定 3.3.0 子串改为返回码和 VERSION.json 的精确一致，原测试案例没有删除。确认没有为了通过测试放宽功能约束。

## 每条发现必须写

触发条件、影响、复现命令/最小样例、预期与实际、严重程度、源码位置、证据路径与哈希、是否已复现。结论区分代码缺陷、合同限制、尚未实测和改进建议。

真实 WorkBuddy 能力不足时禁止编造成功回执。审计输出不自动授予正式发布资格；唯一写者按已复现问题修正后再复测。正式发布仍需满足原 R1—R12 的首发门槛。
