# WorkBuddy 新轮调用证据规程（rc.5）

用于新的手机云端作业。只记录本次任务所需的用户指令摘录、调用参数和返回，不收集无关完整聊天。旧 R1/R2 记录保持原样；本规程不用于事后制造调用前凭证。

目录：来源记录 → 调用前 → 调用后 → 独立复核 → 能力边界。

## 1. 记录新一轮的指令来源

先按 INT-01 完成 compile 和 init：只预建父目录，由 init 创建不存在的新 job。**init 成功前不要建立 job/reviews 或来源文件。** 初始化发生 JOB_EXISTS 或其他错误即停止本轮，保存原始输出；不得删除目录或修正后悄悄继续。

init 成功后，由总控根据当前真实会话建立 `$WBMC_JOB/reviews/run-authorization.json`，独占创建，字段如下。所有工程字段从本轮账本取得，不让用户手填。

```json
{
  "schema_version": 1,
  "job": "当前新作业目录绝对路径",
  "plan_digest": "当前账本的计划摘要",
  "instruction": "用户实际发出的相关指令摘录",
  "source_kind": "coordinator_transcription",
  "source_ref": null,
  "message_time": null,
  "previous_job": null,
  "source_file": null
}
```

- `source_kind` 仅取 `coordinator_transcription`（总控誊录）或 `conversation_export`（附会话导出文件）。前者不是独立来源证明。
- `source_ref` 记录可观察的原始消息引用；不可见就用 null。`message_time` 只记录消息来源实际显示的时间和时区，不用文件 mtime、账本时间或估计时钟偏差代替。
- `previous_job`：失败后另开一轮时填写旧作业的实际引用；第一次执行可为 null。`instruction` 应保留用户针对新一轮的指令与必要上下文，不能用原始试验授权自动覆盖无限新轮。
- `source_file`：仅在已有必要会话片段导出时填写其包外作业内相对路径。`conversation_export` 必须附该文件。记录器会固定文件哈希，但不自动认定其内容真实或已授权。
- 已有会话授权足够明确时直接执行记录，不再次向用户索取同一授权。来源缺失是证据保留项；记录器不会授予新权限。

## 2. 调用前保存意图

按 INT-01 prepare 取得当前 packet、workspace、token、delegation。把**即将传给真实工具的完整参数对象**独占保存为该 workspace 的 `evidence/call-arguments.json`。文本字段必须逐字等于本次 delegation；使用实际宿主参数名与真实参数，不追加推测的工具选项。默认文本字段名为 prompt，确实不同才用 `--prompt-key` 指定实际顶层字段名。

运行且仅运行一次 `delivery_cli begin-submit`，把成功返回的完整 JSON 独占保存到 `evidence/begin-submit.json`。不要为补留日志再运行 begin-submit。

以下 WBMC_* 路径均取本轮真实值：

```bash
python3 -B scripts/workbuddy_evidence.py intent --job "$WBMC_JOB" --packet "$WBMC_PACKET" --authorization-file "$WBMC_AUTH" --arguments-file "$WBMC_ARGS" --submission-file "$WBMC_SUBMISSION"
```

仅在本次 guarded dispatch 已为 SUBMITTING、包与数据库一致、参数文本与派单相同、授权记录指向新作业时生成 `evidence/workbuddy-call-intent.json`。文件名固定且禁止覆盖。

成功后，总控才用刚保存的参数对象执行**一次真实 Agent 调用**。此命令本身不创建 Agent，不构成新授权，不提供宿主幂等调用保证。若参数需要改变，停止核查当前尝试，不删除意图后偷偷重新派发。

## 3. 调用后保留原样返回

逐字保存真实返回到本次 `evidence/workbuddy-raw-return.txt`。已有宿主调用导出片段时，将必要片段存入作业目录；没有就如实缺省，不生成模拟日志补足。

```bash
python3 -B scripts/workbuddy_evidence.py return --job "$WBMC_JOB" --packet "$WBMC_PACKET" --raw-return-file "$WBMC_RAW" --observed-outcome completed
python3 -B scripts/workbuddy_evidence.py check --job "$WBMC_JOB" --packet "$WBMC_PACKET"
```

- 工具明确报错则使用 `--observed-outcome failed`；确实中断且结果未知使用 `outcome_unknown`，保存实际错误/中断返回。没有任何可保存返回时只留实际缺失说明和检查点，不编造返回。
- 只有实际可见时，才给 return 加 `--tool-call-id`。它与宿主尾注中的 Agent ID、内部 task_id、lease token 和 request_key 是不同标识。不可见就省略，结果为 null。
- 只有实际导出文件存在时，才加 `--host-trace-file`；附上文件后仍为 `ATTACHED_UNVERIFIED`，不自动升级真实宿主结论。
- `record_consistency_passed=true` 仅表示记录与引用文件相符；另看 `bind_eligible`。failed、未知结果或缺尾注可以留档，但不能据此绑定成成功。
- return 生成固定的新 `evidence/workbuddy-call-record.json`，不得覆盖。之后继续原 normalize/event/bind/collect/review。任何记录校验失败即停，不能重新创建 Agent 来消除证据问题。

## 4. 总体验收

rc.5 的 `check_integration.py` 继续输出原有 10 项本地检查，并增加 `provenance_records_passed` 与每个任务的 `call_provenance`。两类检查都通过才以退出码 0 完成；缺失调用记录即退出码 2。旧 rc.2 证据使用原版本检查或只读独立复核，不向旧账本迁移补写。

无论是否附有来源文件，`real_host_verdict` 始终为 `REQUIRES_HOST_TRACE_REVIEW`，授权为 `REQUIRES_SOURCE_REVIEW`。最后由总控/独立复核者核对真实工具调用参数、消息与时序，缺失则保留 UNKNOWN。不能把时间戳差直接解释为时钟误差。

rc.5 的 return/check 会重新校验意图中的全部必需引用、实际参数文本、授权作业/计划、来源文件对应关系和提交 request_key。即使调用方重新计算全部本地哈希，内容错配或擅自把意图改为执行/授权已通过也会被拒绝。这仍是内部一致性验证，不是防伪签名或宿主认证。证据 schema 保持 1；合规旧结构可只读检查，旧运行继续使用其原版本，不迁移续跑。

## 5. 能力边界

该模块只读现有账本，在 Skill 外当前尝试中新增两份证据文件。它不是新的调度器或宿主工具拦截器。rc.5 将记录一致性核验接入绑定、提交、成功终态记录和验收；缺失记录不能继续推进成功状态。原有 begin-submit 闸门继续执行。

本地副本和哈希可证内部一致，不能证明真实调用时间、发送者身份、工具权限隔离或实际发出的参数。同步返回且无 task_id 的观察不能推导宿主绝不保存日志。桌面、远程电脑、取消、恢复、并发仍未验证。


## rc.5 的强制入口与字节约定

当前作业先按[手机云端交接](workbuddy-rc5-handoff.md)冻结能力。工具参数中的prompt必须由派单文件read_bytes().decode("utf-8")原样构造，原始宿主回执不改写换行。记录检查已进入bind、collect/submit、成功终态observe和accept；独立check不能代替实际宿主来源复核。旧WorkBuddy作业只读，不回填新版凭证。
