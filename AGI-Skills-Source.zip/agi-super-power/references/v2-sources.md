# v2 设计核对来源

核对日期：2026-09-20。这里只支持格式与控制流设计，不表示本包已在对应平台完成部署或性能验证。没有复制第三方实现代码。

| 一手资料 | 用于核对的设计 | 本包采取的边界 |
|---|---|---|
| [Agent Skills specification](https://agentskills.io/specification) | 根 SKILL.md、字符串元数据、脚本/参考资料渐进加载 | 保持一个根入口；岗位 JSON 不冒充已部署 Agent |
| [Claude Code subagents](https://code.claude.com/docs/en/sub-agents) | 子 Agent 有独立上下文、工具与权限配置；宿主委派回收 | 使用现场 schema；是否支持嵌套依版本和配置，本包叶节点策略仍禁止自主递归 |
| [Claude Code skills](https://code.claude.com/docs/en/skills) | Skill 目录、按需加载和宿主扩展配置 | 项目安装使用 .claude/skills/；不默认 fork 总控入口 |
| [OpenAI Agents SDK orchestration](https://openai.github.io/openai-agents-python/multi_agent/) | 管理者把其他 Agent 当工具调用与 handoff 不同 | 总控保留用户目标、回收与整合责任；不捆绑 SDK 或预填模型名 |
| [OpenAI 构建技能](https://developers.openai.com/zh-Hans/docs/build-skills) | Codex 项目级 .agents/skills 与用户级 ~/.agents/skills | 元数据用于技能发现，不作为子 Agent 已启动证据 |

v1 的 provenance 文件保留原字节作为历史来源档案。那些来源快照、旧测试数和曾经的评审不自动升级为 v2 的当前验收证据；本轮结果在 provenance/v2/。
