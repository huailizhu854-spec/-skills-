# 岗位配置目录

本发行版只有一个可发现的 SKILL.md。下面八份 JSON 是母版的岗位配置与个性化起点，并未单独安装或后台运行。

| 配置 | 适用任务 | 主要能力 |
|---|---|---|
| [general](../assets/roles/general.json) | 尚未固化岗位的专项交付 | 从目标装配临时职责与验收 |
| [repo-research](../assets/roles/repo-research.json) | GitHub 搜索、机制核对、源码提炼 | 一手检索、版本锁定、取舍与来源 |
| [research-evidence](../assets/roles/research-evidence.json) | 科研、主张和引文审阅 | 检索边界、证据映射、复现范围 |
| [frontend-delivery](../assets/roles/frontend-delivery.json) | 前端和交互产物 | 实现、真实浏览器、视觉与状态 |
| [office-delivery](../assets/roles/office-delivery.json) | 文档、表格、会议与演示 | 内容准确、文件可用、实际渲染 |
| [skill-agent-builder](../assets/roles/skill-agent-builder.json) | 制作岗位 Skills ZIP | 配置、行为评测、编译和打包 |

| [qa-auditor](../assets/roles/qa-auditor.json) | 分配目标与证据验收 | 找缺陷，不重做实现 |
| [delivery-integrator](../assets/roles/delivery-integrator.json) | 最终产物统一整合 | 单一写入者，消费已验收成果 |

执行时只加载匹配岗位；用户已有更具体的岗位或流程时，以其目标与约束为依据。通用配置中的工具能力名不是任何平台的真实 API 名称，须通过当前宿主发现对应工具。

岗位个性化指南见 [personalization.md](personalization.md)。
