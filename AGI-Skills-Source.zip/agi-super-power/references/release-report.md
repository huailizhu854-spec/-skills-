# 当前候选：AGI-Super-Power 3.4.0-rc.5

2026-09-23，第二轮修复。基于用户提供的rc.4候选增量修改；原始包只读，源码与全部测试/报告在D盘。当前发布级别仍为OFFLINE_CANDIDATE_NOT_NATIVE_VALIDATED。

## 当前实际验证

Windows / Python 3.12.14，全量737项：723通过、0失败、0错误、14项ENVIRONMENT_BLOCKED（13符号链接、1长路径）。coverage_status=INCOMPLETE，不能说737项全部通过。当前无Linux运行环境，也没有本会话可调用的WorkBuddy手机云端工具；用户将在目标客户端执行实机验收。

原35项：21个换行问题已通过；其余14项改为准确的环境阻塞报告，真实覆盖未关闭。没有删掉原安全断言或缩短长路径测试。

## 修改

- 派单固定UTF-8/LF，调用参数原字节读取，原始回执不改换行；负例断言验证正确拒绝原因。
- 新WorkBuddy作业冻结入口、能力、文件工具与证据；claim/begin-submit重复检查。离线fixture与live作业显式隔离。
- 当前调用记录强制绑定到bind、成功observe、submit（含重复结果）、accept/上游消费，校验当前事务中的任务及准确raw/tool。
- 历史WorkBuddy作业只读，不回填证据；status/resume/checkpoint保留只读核查。Codex/Claude保留原路径。
- 文件系统诊断区分实际能力与安全验证，新增真实Windows junction拒绝覆盖，不替代symlink测试。
- 压力测试发现SQLite槽位释放在锁争用下间歇失败；修复为有界事务重试，确认提交才清持有状态，不确定调用继续占容量。新增6项真实SQLite测试全通过，原压力测试修复后12轮通过。

新增测试45项：WorkBuddy入口25项、文件系统13项、锁争用6项、拆分越界检查1项。旧测试改动包括能力夹具、明确环境阻塞、具体错误断言和版本断言，变更原因记录于交付差分。

两项独立协作审阅覆盖文件系统和WorkBuddy入口；这是本轮代码审阅，不是独立第三方安全认证。实机能力、宿主来源、模型质量/token节省均未由本地测试证明。

手机云端按[rc.5交接](workbuddy-rc5-handoff.md)验收。桌面仍HANDOFF_ONLY；Kimi Code/ZCode未实现，不将目录候选称为已兼容。以下内容为历史版本记录，不代表当前包的测试成绩。

---

# 当前主包：AGI-Super-Power 3.4.0-rc.4

2026-09-23，基于 rc.3 增量更新主发行包。新增调用记录读取时的内容复核：必需引用、准确派单文本、授权作业/计划、来源对应关系和提交键均重新检查。已用同一份离线合成材料复现 rc.3 对“修改提示词并重算关联哈希”的漏检，rc.4 拒绝该错配。此改进不提供签名或宿主来源认证。

主包内置桌面探测入口 `scripts/workbuddy_bridge.py desktop-probe init/manifest/check`、冻结输入和报告模板；不需要另一个探测包。初始化排他创建包外目录，拒绝覆盖或放进旧任务内。桌面执行适配仍为 HANDOFF_ONLY。

手机云端规程明确先 init 成功，再创建 reviews 来源记录；准备错误同样立即停止。VERSION.json 保留 rc.3 的限定证据结论和流程例外；当前包实机集成保持 NOT_EXECUTED。移动云端 adapter v0.3、任务账本、原验收器、Codex/Claude 适配器均未改动；证据 schema 仍为 1。

当前主包全量离线测试：692 项，691 通过、1 项真实 Windows 8.3 测试因 Linux 环境跳过、0 失败/错误。WorkBuddy 子集 82 项全部通过。本次代码测试没有实际 WorkBuddy/模型调用；离线通过不能推导桌面原生能力或实机安装成功。

以下保留最初 rc.1 的研发记录，其日期、计数和阶段状态均只对应历史基线。

# 历史记录：AGI-Super-Power 3.4.0-rc.1 开发与实测报告

日期：2026-09-22。发布性质：**第一轮离线候选版；3.4 全部目标尚未完成；不是 WorkBuddy 原生适配正式版。**

## 1. 基线与开发组织

基于实际上传 `agi-super-power-3.3.0.zip` 增量修改，SHA-256：
`fceb2a55cbc174527691aa1d4659adb3ce247d44ac0ffd727ce525a446836e63`。

需求文档写的是 `3.3.0(1).zip`；本轮以已提供的实际字节和上述哈希为准，不凭文件名认定两个包一致。原需求逐字保存在 `references/upgrade34-requirements.md`，文件哈希与旧测试哈希在 `references/baseline-lock-v34.json`。

唯一写者实施，并进行主线程代码复核与实际离线测试。**没有独立 Pro/Ultra 审计运行，也没有真实模型/子 Agent 调用。**模型名称不是测试证据。没有修改用户远端仓库、桌面客户端、账户、客户材料或旧运行账本。

## 2. 已落地的代码

| 模块 | 本轮实装 | 边界 |
|---|---|---|
| 路径规范化 | `kernel.local_file/contained_file` 与 verifier 使用同一规范根，先排除链接/重解析点，再比对归属，读取后校验哈希 | Linux验证；Windows实机尚未验证；非操作系统沙箱 |
| 受保护提交状态 | 原账本新增提交状态和观察；begin-submit原子授权一次；未知提交、取消未确认时拒绝盲目重派 | 总控必须先使用新入口；未使用的旧兼容路径不具备新增幂等保证 |
| 宿主合同 | 原目录之上的审阅适配器元数据、三态能力、产品/版本/OS/时效/证据哈希检查 | WorkBuddy无桌面执行适配器、传输或响应解析器，仍HANDOFF_ONLY |
| 检查点与恢复 | 关键事件同事务记录最小检查点；读取账本核对计划、产物、版本与可选外部材料 | resume只建议下一动作，真实宿主查询次数为0，不自动恢复派单 |
| 记忆撤销 | 显式通知撤销；pending不进入ready，claim及begin-submit阻塞，运行中旧快照不能验收，下游重新核验 | 不监视外部库，不代表物理擦除，不替宿主停止正在运行的任务 |
| 质量闸门 | 冻结质量项，人工/主线程检查绑定结果及证据，未验/失败不通过，并与原自动验证器共同要求 | 不自动证明视觉或事实正确，不冒充独立Agent检查 |
| 用户说明与变更 | 任务卡、要求映射、未确认假设、进度、结构/DAG变更影响、复用候选 | 不完整替代宿主语义理解；未做真实小白可用性测试 |
| 用量与场景 | 如实列出尝试与本地时间；报告/PPT两份场景配方 | 请求/token/费用/真实并发未知为null；配方不是实测业务成果 |

原有路由、SQLite记忆、上下文、预算、独立自动验收、唯一归属及每次尝试的目录继续复用。未新增第二套调度器或模型执行器。不同任务争写同一正式产物仍被原归属机制拒绝。

## 3. 实际测试结果

环境：Python 3.13.5 / Linux；未使用Windows桌面。完整机器诊断见 `provenance/v3.4/doctor-final.json`。

| 运行 | 收集并执行用例 | 通过 | 失败 | 错误 | 跳过 |
|---|---:|---:|---:|---:|---:|
| 原3.3基线独立复跑 | 526 | 526 | 0 | 0 | 0 |
| 3.4第一轮全量（修复前） | 600 | 598 | 1 | 0 | 1 |
| **3.4最终源码全量** | **610** | **609** | **0** | **0** | **1** |

最终源码全量耗时 147.672 秒。唯一跳过：`test_delivery34.PathTests.test_windows_83_real_alias`，原因是本机不是Windows，不能验证真实8.3别名。**610不是“610项全部通过”；Windows跳过不算通过。**

原526项保留，新增84项，分布在 `test_delivery34.py`、`test_delivery34_quality.py`、`test_delivery34_release.py`。原13份测试中12份字节不变，1份只更新版本断言：原来的3.3字符串检查改为CLI与VERSION.json精确一致，没有删除测试或放宽安全断言。

第一轮全量仅失败于旧的版本字符串断言，随后修正并增加3项记忆撤销边界和7项发布/事务检查，最终重跑610项。原始首轮失败日志保留，不只保留成功日志。完整测试ID和运行日志在 `provenance/v3.4/`。

### 版本断言的实际差分

```diff
--- 3.3/tests/test_intelligence33.py
+++ 3.4/tests/test_intelligence33.py
@@ -378,7 +378,11 @@
     def test_no_memory_creation_without_approval(self):
         p=self.base/'memory.sqlite3';r=self.invoke('memory-put','--store',str(p),'--record','missing.json')
         self.assertNotEqual(r.returncode,0);self.assertFalse(p.exists())
-    def test_version(self):self.assertIn('3.3.0',self.invoke('--version').stdout)
+    def test_version(self):
+        expected=read_json(ROOT/'VERSION.json')['package_version']
+        result=self.invoke('--version')
+        self.assertEqual(result.returncode,0,result.stderr)
+        self.assertEqual(expected,result.stdout.strip())
     def test_duplicate_json_key_rejected(self):
         p=self.base/'bad.json';p.write_text('{"a":1,"a":2}')
         with self.assertRaises(ValueError):read_json(p)
```

## 4. 恢复演示：真实本地进程，合成任务

执行：`python examples/delivery34/run_demo.py --output <新的包外目录>`。

| 项目 | 实测 |
|---|---:|
| 通过验收的合成任务 | 4 |
| worker尝试数（含一次未创建的故障注入） | 5 |
| 真正启动的本地确定性fixture进程 | 4 |
| 调度批次 | 3 |
| 检查点 | 23 |
| 真实AI Agent / 模型 / 网络调用 | 0 / 0 / 0 |

注入提交未知状态后不授权再创建，确认未创建才恢复；重复结果只处理一次；向旧尝试的暂存目录迟到写入不会改变正式产物哈希。**这不是向真实WorkBuddy注入故障，也不证明恶意执行者无法绕过宿主权限直接写正式目录。**后者需要宿主隔离。

演示中的人工质量记录是合成fixture，不是实际人工/PPT视觉验收。演示摘要见 `provenance/v3.4/demo-summary.json`。

## 5. 主线程发现与修复

| 编号 | 触发条件 / 影响 | 处理 / 验证 |
|---|---|---|
| F34-01 | 根目录别名/相对路径和解析后的产物路径比较不一致，可误判合法路径越界 | 统一规范化并保持原始链接检查；Linux相关回归通过；Windows原始复现仍待实机 |
| F34-02 | claim后、真实创建前发生记忆撤销，单在领取阶段检查不足 | begin-submit再次检查；增加领取后撤销、ready过滤、resume暴露三项回归，全部通过 |
| F34-03 | 合法版本升级导致旧测试固定3.3.0断言失败 | 精确比较当前VERSION.json与CLI，原失败保留于首轮日志；最终全量通过除明确跳过项 |

这些记录是主线程复核，不冒充独立安全审计。尚无“全部潜在缺陷清零”的证明。

## 6. R1—R12 交付状态

### R1 — PARTIAL_OFFLINE_ONLY

已做：统一合法根路径与绝对产物的规范化，规范化前保留链接/重解析点检查；Linux 中文、空格、长路径与真实越界测试通过。

未完成/边界：Windows 8.3/长路径/权限与原始短路径复现、Windows全量未运行。

### R2 — NOT_IMPLEMENTED_NATIVE

已做：提供明确产品区分、证据模板和HANDOFF_ONLY闸门。

未完成/边界：WorkBuddy Desktop真实传输与原始响应解析器未实现，客户端版本/OS未探测，真实成功/失败/停止/恢复均未运行。

### R3 — PARTIAL_CONTRACT_ONLY

已做：在原host_registry之上增加审阅的适配器元数据与带证据哈希的三态能力快照；标准化生命周期观察严格绑定。

未完成/边界：不是新执行器；没有创建/查询/等待/停止传输。共同离线合同不替代原生端到端测试。

### R4 — IMPLEMENTED_OFFLINE_WITH_BOUNDARY

已做：复用唯一任务/产物归属、独立尝试目录；begin-submit事务并发只授权一次，未知结果不得重派。

未完成/边界：新增提交保护必须显式使用begin-submit；旧兼容路径不自动获得该保证。操作系统写权限隔离需宿主提供。

### R5 — PARTIAL_OFFLINE_RECOVERY

已做：同账本最小检查点、只读恢复核对、外部材料可选重核、显式记忆撤销联动；恢复前要求已确认的终态证据。

未完成/边界：resume不执行真实宿主查询；未通知的外部记忆删除不自动传播；桌面会话恢复尚无实机证明。

### R6 — PARTIAL_BRIEF_IMPLEMENTED

已做：从冻结合同生成目标/交付/约束/验收与缺口说明；假设单独标识，要求可追踪；进度区分已领单与真实运行。

未完成/边界：没有任意自然语言到合同的完整自动编译器；样稿需具体执行者制作；未做真实小白可用性测试。

### R7 — PARTIAL_GATES_AND_RECIPES

已做：冻结人工/主线程复核闸门，区分层次及PASS/FAIL/UNVERIFIED/NEEDS_HUMAN；证据和结果绑定；缺失闸门记录阻止验收。

未完成/边界：两类配方不是完成客户任务；无真实报告/PPT制作、渲染与业务测试；主线程登记不认证用户身份或证明独立Agent运行。

### R8 — IMPLEMENTED_OFFLINE

已做：旧concerns阻塞语义保留，冻结质量要求不随warnings/environment_notes改名而绕过；下游重核证据。

未完成/边界：真实性依赖受信任总控与可验证材料；不自动判断所有业务事实。

### R9 — NOT_COMPLETE_INDEPENDENT_EVAL

已做：保留100条原开发路由回归，新增撤销/跨项目/硬约束预算/材料越权文本检查。

未完成/边界：没有新增独立未见路由评测集、真实模型对照或统计上的质量提升结论。新增84项均为开发回归，不冒充独立审计。

### R10 — PARTIAL_STRUCTURAL_IMPACT

已做：结构差异与总控显式语义影响沿依赖图传递，约束变化保守影响全部；只输出复用候选。

未完成/边界：不自动批准复用，不完整推断任意语义变更；新版需新目录和重新核验。

### R11 — PARTIAL_LOCAL_OBSERVABILITY

已做：记录尝试数、墙钟耗时与账本待结租约峰值；无宿主数据时模型请求/token/费用/真实并发为null。

未完成/边界：没有宿主真实用量收集器，不以attempt估算模型调用或token节省。

### R12 — CANDIDATE_PACKAGE_ONLY

已做：新目录使用、分层版本、隐私打包白名单、哈希清单、源码差分另附、复现脚本与回退说明。

未完成/边界：WorkBuddy桌面安装/权限验证及Windows全量未做，不能发布正式原生适配或生产可售声明。

## 7. 正式发布仍被阻塞

必须补齐真实WorkBuddy Desktop能力探测与适配、Windows全量、代表性报告/PPT质量验收。路由独立盲测和同模型同预算的受控对照也没有执行，不宣称推理质量提升、调用准确率提高或token节省。

总控标准化回执、reviewer字段与用户确认都是受信任协调器的记录，不是供应商/用户身份认证。哈希是字节完整性，不是来源真实、事实准确或软件安全的证明。

已有Codex/Claude离线回归通过不等于本轮真实宿主复测；仅保留原支持范围，没有扩张其兼容声明。其他国内平台仍后置。

## 8. 交付与复现

包内包含源码、原需求、版本基线锁、三份新测试、恢复演示、两类场景配方、能力模板、源日志、逐项追踪、安装/回退说明和只读审计交接。客户数据库、真实回执、凭据、私有记忆、测试作业目录不进入包。原历史provenance维持原白名单，不能用作3.4实机证据。

构建使用原有确定性打包器；发布ZIP自带重新生成的SHA256SUMS.json。源码差分作为另一个下载文件提供；最终ZIP的包哈希、二次构建一致性、独立解压复测和差分回放结果见外部《发布核验》文件，避免把包的哈希嵌入包自身造成循环。

```text
python scripts/delivery_cli.py doctor
python examples/delivery34/run_demo.py --output ../demo34-fresh
python scripts/run_offline_tests.py --report ../tests34-fresh.json
python scripts/package_release.py verify ../agi-super-power-3.4.0-rc.1.zip
```

输出必须使用未存在的新目录/文件。旧3.3保留不动；不要用3.3打开3.4新账本，不把运行中的任务原地升级。详见 `3.4快速上手.md` 和 `references/audit-handoff-v34.md`。
