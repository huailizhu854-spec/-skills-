# 3.4.0-rc.1 执行合同与边界

本包是第一轮可靠交付候选，不是正式 WorkBuddy 原生适配版。需求原文见 `upgrade34-requirements.md`，本轮实际完成程度见 `release-report.md` 与 `traceability-v34.json`。

## 1. 一个账本，不新建第二套调度器

新任务由原 `TeamStore.create` 创建，原 `tasks/artifacts/results/events` 保持职责。只在新任务同一 SQLite 数据库内增加 `dispatch34/observations34/checkpoints34`。已有路由、记忆、上下文、L0–L3 和尝试预算继续使用，不再实现第二套。

旧目录不会被自动迁移。旧任务应由原安装包继续收尾；有必要升级时先保存材料、确认原执行者停止，建立新版本新目录。删除扩展表不是迁移方式。

同一 `work_key` 唯一负责人；输出路径按 Unicode/大小写规范化检查交叉归属，连父子路径也拒绝冲突。每次尝试写自己的 `workers/<task>/<attempt-token>/outputs`。只有总控验收后可写 `published`，使用原独占创建与哈希冲突检查；不让审核者直接改同一最终文件。

这不是操作系统沙箱。宿主必须阻止执行者直接操作账本、正式发布区及他人目录。相同用户权限下恶意并发写文件的攻击，不由 Python 路径检查全面解决。

## 2. 能力目录、当前探测、运行证据分别记录

`host_contract34.py` 使用原 host_registry 的宿主 ID，并为已有实现附加观察合同元数据。不是任意类名动态导入器。WorkBuddy Desktop 与 CodeBuddy CLI/IDE/小程序明确分开。

`assets/hosts/workbuddy-probe.template.json` 初始所有能力均为 unknown。总控只能依据当前真实工具接口与实测回执填入 supported/unsupported；每一项非 unknown 记录必须指向可读取、哈希匹配的证据，并绑定产品、客户端版本、操作系统和时效。文档截图或目录声明不充当运行证明。

检查入口：

```text
python scripts/delivery_cli.py probe-check --probe /absolute/probe.json --evidence-root /absolute/evidence --require create --require query --require wait --require cancel --require confirm_stopped --require artifacts --require recover
```

不支持的操作保留 unsupported，不能模拟成功。探测冲突或缺要求能力返回 BLOCKED。WorkBuddy 没有注册的桌面端执行适配器，始终 HANDOFF_ONLY；即使人为把所有能力写成 supported，也不能进入已验证原生执行状态。

权限区分 host_enforced / instruction_only / unknown；effort 区分 hint_only / setting_accepted / not_exposed。无法追踪宿主嵌套专家团映射时不启用双重调度。通过当前探测也只说明观察合同满足，不代表完成真实任务。

## 3. 受保护派发顺序

原生适配器先 prepare 领单。**在调用真实宿主创建工具之前**调用：

```text
python scripts/delivery_cli.py begin-submit --job /absolute/job --task TASK --token TOKEN
```

返回 request_key 与 NOT_EXECUTED，表示已原子登记一次提交意图。本命令没有执行宿主调用。第二次相同命令不会再次授权发送。同一 token 的并发登记仅允许一次成功。

随后由总控调用当前真实宿主工具一次。原成功路径仍可使用原 native_host_bridge bind/collect。异常生命周期通过 `delivery_cli observe` 登记标准化观察，其原始证据必须由总控保存到 job/reviews，且校验任务、令牌、目标、计划、request_key、运行 ID 与证据哈希。

原生旧入口保持兼容。**不先调用 begin-submit 的旧路径不具备新增提交幂等闸门**；不能把这条兼容路径描述为已经全面升级。request_key 是本地提交标识，不意味着宿主原生支持同名幂等参数。宿主没有该参数时不能捏造参数。

| 状态/事件 | 行为 | 明确禁止 |
|---|---|---|
| PREPARED | 已领单，尚未登记提交 | 宣称宿主已启动 |
| SUBMITTING | 允许总控发一次真实创建调用 | 再次创建 |
| UNKNOWN | 查询原运行或 request_key；无法查询则待核实 | 把超时当作失败/终止 |
| RUNNING | 记录实际运行 ID，继续等待真实终态 | 第二个执行者抢同一产物 |
| CANCEL_REQUESTED | 调用实际停止工具并等待确认 | 直接认为停止成功 |
| SUCCEEDED | 收集产物并验收；迟到结果须 adopt_finished | 直接标业务合格 |
| FAILED / CANCELLED | 证据确认终止后定向恢复 | 未确认停止就重派 |
| NOT_CREATED | 真实查询明确未创建后恢复 | 仅凭没收到响应推断未创建 |

重复同内容 observation ID 仅消费一次；相同 ID 不同内容拒收。旧 goal/plan/token 的结果不能变成新版本合格。终态后迟到的 running/unknown 不会倒退状态，矛盾终态要求核实。取消请求后 running 不会取消“待停止确认”。

此标准化接口由受信任总控填入，不能认证宿主身份，也不能自己理解未知供应商响应。真实 WorkBuddy 响应解析器及 create/query/wait/cancel 传输仍未实现。

## 4. 检查点和恢复

INITIALIZED、CLAIMED、HOST_BOUND、SUBMITTED、REVIEWED、暂停/超时、恢复、目标替换、交接等事件保存最小检查点；主要状态转换与检查点在同一 SQLite 事务。包括冻结目标/要求、任务状态、运行 ID、材料和产物的哈希标识、未完成任务及下一动作，不保存完整聊天或私有思维过程。

```text
python scripts/delivery_cli.py checkpoint --job /absolute/job
python scripts/delivery_cli.py resume --job /absolute/job --inputs /absolute/materials
```

resume 只核实本地状态并给出动作，**不会查询真实宿主**。host_queries_executed 固定为 0。先检查冻结计划、账本、已接收成果和验收证据；提供 --inputs 时对外部材料重新比对。材料变化需要新目标版本，不直接覆盖旧成果。没有 --inputs 时明确未检查外部材料。

未知或仍在运行的旧执行者保留所有权。用户/总控需要按真实工具核实，登记终态观察，再走原 TeamStore.recover。NOT_CREATED 与 confirmed_not_started 对应；真正结束对应 confirmed_stopped；只有 SUCCEEDED 可以 adopt_finished。恢复再次核对原始终态证据哈希。

## 5. 记忆撤销和上下文

继续使用 3.3 MemoryStore；长期保存仍需用户明确许可。检查点不等于长期保存全部对话的许可。宿主记忆仅可从实际获准接口读取，不复制全部个人记忆。

删除/替代获准的记忆后，明确通知：

```text
python scripts/delivery_cli.py memory-invalidate --job /absolute/job --project PROJECT --record-id RECORD --reason "用户撤销该记录"
```

未派发：从 ready 排除，claim/begin-submit 拒绝。运行中：不假装停止宿主，但阻止旧上下文的验收；总控查询/停止并修订目标。已验收：保留原文件，标记需复核，不能自动让下游继续消费。跨项目同名记录不互相影响。

没有监视外部记忆库的后台机制：任意外部删除若未通知，不会神奇传播。历史冻结任务快照可能仍含该记录；本命令不是安全擦除工具。不能自动删除仍在审计范围的证据。

上下文预算不足时，保留硬约束并拒绝静默截断。拆小任务、提高明确预算或回源按需读取，不把必要限制摘要掉。材料里的“忽略用户要求”只是数据，不能改 tools/capabilities/goal。

## 6. 小白入口与分层验收

宿主总控把用户目标和材料转成冻结合同。用户不手填 token/schema。`delivery_cli brief --plan PLAN --markdown` 展示目标、交付、约束、逐项要求与检查；--assumption 明确是未确认假设，--missing 明确材料缺口。本地函数不声称能完整理解任意自然语言。

`quality_gates` 是可选的 v3 task 扩展，在编译前冻结：id、requirement、layer、kind、description。layer 分 integrity / requirements / business / visual / experience，kind 为 main_thread_review 或 user_confirmation。没有列出的层次不得宣称验证过。

`delivery_cli quality-review --job JOB --record RECORD` 只允许指定的非执行者总控登记。记录绑定目标、计划、令牌、结果摘要、gate_id、证据路径及哈希。状态为 PASS / FAIL / UNVERIFIED / NEEDS_HUMAN。只有所有冻结闸门 PASS 且原独立自动验收通过，才能发布。

主线程复核不冒充独立 Agent；用户确认是总控登记的观察，不是身份认证。视觉记录必须指向实际渲染检查/确认材料，不能只写“我觉得很好”。记录 PASS 不代表软件自动证明材料真实。

首发场景配方在 assets/scenarios：依据材料生成报告、修改现有 PPT。它们是施工/验收配方，尚不是已完成客户场景试验。PPT 时长不能按页数声称精确；未演练只标估算。

## 7. 变更、用量和版本

`delivery_cli impact --old-plan OLD --new-plan NEW` 结合要求/材料/合同的结构差异、总控显式声明的语义影响、依赖图传递来列出返工与可复用候选。硬约束变化保守影响全部。reuse_candidates 不是复用授权；必须重新核验并作为新计划输入。

`delivery_cli usage` 区分 worker_attempts、账本待结租约峰值和墙钟耗时。没有真实宿主用量入口时，model_requests/tokens/cost/actual_host_concurrency 都是 null，不用尝试次数换算 token 或宣称节省。

package/runtime 为 3.4.0-rc.1；协议仍支持 plan schema 2/3、context schema 2。原 verifier 语义版和未修改适配器版本不机械替换，修复的 verifier 实现另记实现版。所有旧证据仅是历史基线，不是本轮实机证明。

## 8. 当前硬性限制

WorkBuddy 桌面端没有当前版本/操作系统的实际能力探测和运行证据，未实现可执行传输与原始响应解析。Windows 8.3 实机测试未跑。没有独立模型审计，没有新的独立盲测集和受控模型对照，没有客户报告/PPT质量试验。

因此 R2 及相关正式发布门槛未完成。本版只用于代码复核、离线流程验证和下一轮实机接入准备，不作为“全面原生兼容、生产可售”的证明。
