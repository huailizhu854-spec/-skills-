# 从母版生成专属岗位

当前阶段是通用母版。assets/roles 是可编辑范例，不表示已经部署多个长期 Agent。个性化的重点是专业 SOP 和验收，而非换一个名称。

## 制作步骤

1. 复制最接近的 role JSON 到任务工作目录，保留原模板。
2. 填实 mission、trigger、inputs、outputs、steps、tools、boundaries 和 acceptance。每个 acceptance 写 requirement、method、evidence_kind；只列任务实际需要的能力。
3. 用 `python scripts/kernel.py validate-role /absolute/path/role.json` 校验。
4. 按 evaluation.md 制作真实任务和反例，运行独立走查；能力不足时改流程或补实际工具，不添加空泛“最高标准”。
5. 生成独立包：`python scripts/build_specialist.py /absolute/path/role.json --name my-specialist --output /absolute/path/my-specialist.zip`。
6. 检查 ZIP、单一入口、岗位内容和来源。需要平台原生 fork 或命名 Agent 时，在目标宿主专用副本中适配并实测。

生成器会生成固定岗位入口、岗位正文、元数据与公共流程。它不装配 API 密钥、安装插件或启动后台服务。母包的 kernel/评测/检索台账不是默认全部复制进每个专属包，避免把研究档案变成执行负担。

## 角色字段

schema_version 为 1；name 为小写连字符名；title 为中文显示名；mission 与 trigger 为字符串；inputs/outputs/steps/tools/boundaries/sources 为字符串列表；acceptance 为含 id、requirement、method、evidence_kind 的对象列表。精确约束由附带的 validate-role 实现校验。

## 更新已有岗位

对照旧任务样例和新需求修改必要字段，保留有效步骤。用新文件名生成候选 ZIP，验证后再替换部署版本。不能把用户一次纠正自动推广为所有角色的永久规则。

## v3 继承规则

生成器现在随包附 child-protocol.md，并在入口区分“已受父 Agent 委派”和“独立启动”。收到父任务包时保留 goal_digest、plan_digest、task_id 和 lease_token，只做分配职责，不重复队友工作，不递归创建 Agent。岗位专业方法不覆盖总控边界。候选岗位先经过回归和成对评测，再由有权主体决定替换，不自动修改已安装版本。
