# Dual16 原生宿主验收清单（尚未执行）

本包附带的是离线验收结果。不要把任何 examples、合成 host_run_id、旧 WorkBuddy 报告作为本轮 18 个模型会话启动证据。

## 运行前

确认当前可用工具的真实 schema，而不是照搬下面不存在的函数名。需要创建、向已有会话发消息/继续、查询和取消。记录客户端版本、宿主、模型、权限、计数是否包含根会话与剩余额度。缺任何能力直接 BLOCKED；不能添加未经用户授权的付费服务。

由根协调器读取本 Skill，按真实业务任务编译 16 份任务合同；冻结 2×8 归属。注册真实业务验收器。内置 dual16-shard-v1 只为离线数字例子提供独立校验，不可当真实需求评测。

## CLI 顺序

以下命令在技能根目录执行。JOB、PLAN、INPUTS 由实际环境定位，不要求用户手填计划。

```sh
python scripts/dual16_cli.py compile --plan PLAN
python scripts/dual16_cli.py init --plan PLAN --inputs INPUTS --job JOB
python scripts/dual16_cli.py probe --job JOB --evidence reviews/dual16/observed-probe.json
```

给每个 control-a、control-b、w01…w16 执行：

```sh
python scripts/dual16_cli.py reserve --job JOB --slot SLOT
# 宿主实际创建独立持久会话，把输出 packet 交给对应成员。
# 保存原始工具响应和规范化的观察，字段见 dual16.py observe_start。
python scripts/dual16_cli.py observe-start --job JOB --slot SLOT --evidence reviews/dual16/start-SLOT.json
```

先真实查询全部会话，再：

```sh
python scripts/dual16_cli.py barrier --job JOB --evidence reviews/dual16/roster-query.json
python scripts/dual16_cli.py decision-request --job JOB --controller control-a
# 把这份请求送给已经绑定的 control-a，保存其真实输出。
python scripts/dual16_cli.py decision-record --job JOB --controller control-a --evidence reviews/dual16/control-a-turn.json
# control-b 同样操作；注意每回合证据文件名必须唯一。
python scripts/dual16_cli.py grants --job JOB
```

dispatch 对应工作：

```sh
python scripts/native_host_bridge.py prepare --job JOB --task w01 --worker w01
python scripts/delivery_cli.py begin-submit --job JOB --task w01 --token LEASE_TOKEN
# 按 prepare 输出，用宿主真实 send/resume 向 expected_host_run_id 发送任务。
# 不创建新会话。保存本次 lease 对应的原始 start/finish 工具事件。
python scripts/native_host_bridge.py bind --job JOB --event START_EVENT
python scripts/native_host_bridge.py collect --job JOB --event FINISH_EVENT
```

原 Codex/Claude 观察解析器仍以包内合同为准。真实工具若返回了不兼容的新形状，须审计适配器后再继续，不能临时编造它想看到的 fields/status。

对主控的 accept/rework/block 许可：

```sh
python scripts/dual16_cli.py review --job JOB --grant GRANT_ID
python scripts/dual16_cli.py status --job JOB
```

循环由执行 Skill 的根会话自动推进，无需用户逐个点名。两主控决定调度/审核，根会话仅受限地登记和转交；后台持续执行依赖宿主本身，不由 Markdown 或本地 CLI 保证。

## 必须保存的实机证据

18 个不同宿主 ID、每个创建前 nonce、原始创建响应、绑定到同一 plan/goal 的 18 人查询快照、两主控逐轮原返回、各8人的一次性派单许可、16份任务的 begin-submit/完成观察/产物哈希、交叉审阅与独立验收报告、完整最终账本状态。

至少复测：正常任务、1个错误产物返工、1次主控错误批准、1次执行者超时、1次主控失联、目标变更后的全体取消。只要无法获得原始宿主证据，就保留 NOT_EXECUTED / BLOCKED，不签“原生已通过”。

本机离线测试也不证明 Windows 专属文件系统行为、API性能、任务成本或模型回答质量。
