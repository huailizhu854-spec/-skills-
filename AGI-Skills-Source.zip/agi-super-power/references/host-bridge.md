# v3 原生宿主桥接：Codex 与 Claude Code

## 分层与实际边界

主 Skill 负责目标、任务 DAG、职责去重、领取、产物所有权、独立验收与恢复。Claude Code 负责真实 Agent 工具、模型生命周期、上下文和工具执行。`host_adapters/claude_code.py` 只接线；没有自行实现 spawn/status/cancel 的模型进程。Command/API 文本桥是备用能力，不是原生宿主。Codex 使用独立的 codex_native 适配器；当前 Codex 环境先读 [Codex 桥接](codex-bridge.md)。下文仅描述 Claude 路径。

先读取当前宿主实际工具定义，确认可创建任务、返回运行 ID、等待真实完成、取消/查询、文件可达和权限范围。不能从过去的工具名猜调用参数。无真实委派工具：native_subagents = NOT_EXECUTED，保存可交接任务，不调用 CLI 来伪装 native。

当前官方文档支持 `.claude/agents/*.md` 文件与 tools/disallowedTools/model/permissionMode 等配置。生成器使用白名单工具、model: inherit、permissionMode: default、maxTurns: 30，明确禁止 Agent 递归。它不更改宿主 settings 或绕过审批。文档依据在 `v3-sources.md`；文档支持设计，不证明部署成功。

## 原生执行流程（总控驱动）

1. 使用 schema 3 冻结任务计划；根据真实权限设置 tools/capabilities。示例 `examples/team-demo/plan.native-v3.json` 是 Read/Write 四任务接力，租约 900 秒。提前核实所有 acceptance 方法都在已审阅 registry 中。输入必须有实际 SHA-256。
2. `team_runtime.py compile` 后 `init` 新的外部作业目录。不要在 Skill 安装目录放运行数据。
3. 对 ready 的任务调用 `native_host_bridge.py prepare --job JOB --task TASK --worker WORKER`。这先校验能力再原子 claim，生成 packet、独立工作区和本次尝试专属定义。它没有启动 Agent。
4. 审阅 `definition_path` 指向的定义；`install_claude_agents.py --project PROJECT --definition FILE` 默认只预览。明确授权后加 `--apply`，写入 PROJECT/.claude/agents，不覆盖已有定义、不改权限。重试使用新的令牌和定义名。必要时让宿主重新发现配置；不能发现就停，不冒名使用别的 Agent。
5. 总控调用当前实际可用的 Agent 工具，使用新定义及 packet；只调用一次。每个子 Agent 只收到共同目标、自己的任务与输入，不重新接管用户总需求。宿主不共享本地文件系统时，本接线层不提供自动远程同步；需要另行授权和哈希绑定的传输适配，不能虚构文件已可达。
6. 保存真实 tool 返回的原始观察到本次 evidence/。把实际 host_run_id、task_id、lease_token、native_tool 与原始观察文件哈希映射成下述内部事件。`bind` 登记一次真实启动；同步工具只在完成时返回 ID 的，可用同一个 finished 观察先 bind 再 collect。不伪造启动 ID。
7. 工具仍在运行时，由总控根据实际进度 heartbeat。完成后把已授权输出放到 packet.output_root，调用 collect；collect 独立复核文件集合和输入哈希并 submit，**不会接受业务要求**。
8. 指定审阅者写 reviews/ 请求证据、绑定 result_digest 后 `team_runtime.py review`。accept 将实际执行注册验证器；通过后再取下一批 ready。审阅者检查而不再做一份实现，最后由唯一整合任务消费已验收产物。

## 事件格式不是宿主 API

以下是适配层内部 schema；值必须来自真实工具观察。不要把它作为 Agent 工具参数，也不要用占位符当证据：

```json
{
  "schema_version": 1,
  "host": "claude_code_native",
  "event": "finished",
  "host_run_id": "REPLACE_WITH_ACTUAL_HOST_ID",
  "task_id": "facts",
  "lease_token": "REPLACE_WITH_CLAIM_TOKEN",
  "native_tool": "REPLACE_WITH_ACTUAL_TOOL_NAME",
  "raw_evidence_path": "evidence/actual-host-finished.json",
  "raw_evidence_sha256": "REPLACE_WITH_ACTUAL_FILE_SHA256",
  "observed_by": "coordinator"
}
```

raw_evidence_path 相对本次 workspace，必须是普通 evidence 文件且含实际运行 ID。适配层验证字段、字节哈希、令牌和状态；它**不证明该文本来自可信远端**。身份和访问控制在宿主，总控被信任，receipt 不是密码学认证。本包测试中的 simulated host 观察只证明格式和状态机，不算真子 Agent。

## 失败恢复

创建成功而 bind 失败：查询/取消那个已启动的作业，不另起副本。超时或父会话中断不会释放责任；保持 uncertain。按照 `team-runtime.md` 提供令牌绑定的真实停止证据后 retry，或者确认已完成后 adopt_finished 再收回原成果。不得对旧任务重新执行来“取一次结果”。

`model_semaphore.py` 是备用桥本地并发槽位，不是 native 生命周期执行器。远端未知时保留 running/uncertain 槽位；不得因为 PID 消失或过期就清空数据库。

## 备用文本桥

使用 `plan.model-v3.json`，显式授权模型底座传输，叶节点 tools/capabilities 均关闭。`host_bridge_model_demo.py --emit-adapters FILE` 按当前 Python 和当前安装目录生成 argv；静态 adapters.model.json 只是配方，不可直接用于运行。`AGI_MODEL_*` 配置见 `使用指南.md`。

该桥只让模型返回 UTF-8 文件内容；不执行模型产出的 shell，不支持子 Agent 使用浏览器或生成原生二进制 Office 文件。后者应由真实 native 工具任务完成，并新增相应真实验收器。备用桥绝不能被扩建成私造宿主 runtime。
