# 任务编译：用户目标 → 无重复工作图

这里的“编译”由两部分构成：主 Agent 理解自然语言、形成计划；Python 校验结构、覆盖、去重键、产物归属与依赖。Python 不声称能独立理解所有中文同义任务。

## 先定验收，再拆职责

提取当前明确交付物、输入、硬约束、非目标，按 R1/R2…记录。不要为了匹配现有岗位改变用户目标。每个子任务的 requirements 必须属于同一 goal，每项都要有 acceptance。无要求支撑的“顺手优化”不派发。

输入先锁定内容 SHA-256。真实原生/模型计划采用 schema_version=3；schema 2 仅为历史离线 fixture，岗位配置仍使用 schema 1。Codex 例子见 `examples/team-demo/plan.codex-v3.json`，以 `team_runtime.py compile` 的实际规则为准。

## 语义去重步骤

把“找三个开源项目”“调研候选仓库”“搜索 GitHub 对照实现”归一化成同一责任，例如 `G1:R1:research:repo-candidates`。先检查账本是否已有该责任：未完成则等待/补输入，已完成则引用 artifact ID；不换个名字再发一单。

推荐 work_key = 目标 ID + 要求 ID + 操作 + 对象。scope 写具体问题或产物片段，不能只写“项目整体”。输入变化属于新版本判断，不借机重复派发同一版本。

校验器机械检查：归一化 work_key 唯一；相同 role + scope + reads 不能换键重复；artifact ID 唯一；所有输出路径经 Unicode/大小写归一化后不能重名或父子包含。计划中串行任务也不能共用输出路径。独立任务可共享只读输入快照。

尚不能机械识别的任意换词重复，由总控开工前比较“要回答的问题/要改的对象/产物用途”。该审查是强制步骤，不用路径不同作为不重复的证明。

## 岗位分配示例

| 责任 | 推荐岗位 | 只产出 | 禁止重复的事情 |
|---|---|---|---|
| 锁定开源机制与证据 | repo-research | research/evidence.json | 不写页面、不替设计者做完整方案 |
| 文案/文档内容 | office-delivery | content/copy.md | 不再次检索研究者已锁定的同一事实 |
| 前端实现 | frontend-delivery | patches/frontend.patch | 不另写研究报告，不改审计结论 |
| 独立验收 | qa-auditor | qa/findings.json | 不再实现第二套页面 |
| 最终汇总 | delivery-integrator | delivery/release.zip | 不重新生成已通过的上游产物 |

这些不是每次都要启动的五个角色。一个任务只需一个岗位就不要组队；两个真正独立的问题才使用两名执行者。总控身份不是额外做一遍全部工作的理由。

## 依赖与唯一写入者

一个任务读取其他任务产物时，必须把产物 ID 写入 reads，并将其生产任务直接列入 depends_on。依赖完成以 accepted 为准，不是“已经有文件”或“Agent 已停止”。

需要多人参与一个 index.html：各自返回不同的片段/补丁，唯一整合任务生成最终文件。多人直接写同一文件的方案在本版本中拒绝，即使人为排了串行；需要连续修改同一产物时保留同一任务做定向返工，或显式生成新版本路径。

## 预算和完成

先声明 max_parallel、max_attempts、max_total_attempts、lease_seconds。它们限制本地派发与恢复；token、费用、工具权限由宿主限制，未接入的指标为空，不假装已强制执行。

计划覆盖只是必要条件。最终必须逐项核验真实成果与用户要求，尤其是自然语言内容、图像质量、专业准确性和隐含未经证明的主张。
