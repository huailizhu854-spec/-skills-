# 受控自动迭代：经验进入候选，不直接修改所有岗位

本次用户授权的是制作新版 Skill。正常业务运行只做任务内有界返工；不把“自动迭代”解释为永久后台自改、自扩权或无限消耗模型额度。

## 任务内闭环

运行 → 记录真实失败/代价 → 识别对应 requirement 和唯一责任任务 → 提出最小修复 → 同一任务新尝试 → 重新验收 → 解锁下游。已通过且未受影响的成果不重做。

可用 `python scripts/evolution_gate.py failures --job /path/job` 从日志提取失败候选。脚本列出现象，不会假装根因已确定。总控需要补：原始证据、反例、为什么现有规则失效、修复前后预期和可能副作用。

## 岗位长期迭代

只有用户授权创建/更新技能时才制作新候选目录。总控从重复出现的稳定工作流提炼 mission、inputs、outputs、steps、tools、boundaries、acceptance；再用 build_specialist.py 生成独立岗位。派生入口继承子 Agent 协议，不增加默认委派层级。

观察 → 候选补丁 → 稳定回归集 → 成对评测 → 对抗检查 → 接受/保留旧版 → 版本说明。每一轮必须有新证据，不为追求版本号不断重写。

## 成对评测门

`python scripts/evolution_gate.py compare --baseline /path/baseline.json --candidate /path/candidate.json --root /path/evidence-folder`

两个报告使用相同 suite_id、suite_digest、environment_digest、模式、case ID、input_digest 和 required 标记，candidate_digest 必须不同。每个 case 包含真实证据路径与 SHA-256、passed、hard_violation、cost_units。完整字段见脚本 validate_report；成本单位由同一环境契约明确定义，不混用 token 与货币。

决策：有必过失败、旧通过项退化、硬约束违反或超成本上限 → REJECT；测试桩、缺成本记录、没有测到改进 → HOLD；符合条件 → ELIGIBLE_FOR_REVIEW。最后一种只说明可以交给审阅者，不自动安装或发布。

fixture 不能支持真实模型行为提升；software-runtime 只支持工程机制；real-model 必须来自真正模型运行。将未知费用填 0、填虚构 PASS 或降低标准都不算评测。

## 两轮对抗检查的职责边界

第一轮查调度机制：重复键、重复路径、抢单竞争、依赖未验收、超时盲重派、旧令牌、旧目标、迟到回执、预算失控。

第二轮查证据与交付：篡改输入/产物/日志、检查缺失、执行者自批、假宿主回执、派生 Skill 忘记总目标、文档与代码矛盾、旧功能回归。

没有真正启动独立审计 Agent 就写“测试与对抗走查”，不能称为多模型独立审计。本版本发布记录明确区分工程测试和真实宿主待验证项目。
