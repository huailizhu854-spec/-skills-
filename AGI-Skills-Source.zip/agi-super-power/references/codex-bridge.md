# Codex 原生桥接

适配版本 3.2.0，产品显示名为 AGI-Super-Power v3。无需 Anthropic API、Claude Code 定义文件或额外模型 CLI。当前安装已被 Codex 技能目录发现；原生执行仍须使用当前会话真实提供的委派工具。

## 计划与派发

1. 用户请求适合委派且宿主提供委派工具时，冻结 schema 3 计划，executor.type 为 codex_native。executor.transport_network 表示已授权的模型底座传输，与任务网页访问分开。参考 examples/team-demo/plan.codex-v3.json。
2. tools 为逻辑能力 file.read、file.write、shell、web.read，主线程将其映射到实际可用工具；脚本不授予权限。用 exec_command 读写或计算时，应明确允许 shell，不能把 shell=false 的 Read/Write 示例照搬过来。叶节点不可递归或外发。
3. compile → init 外部作业目录 → prepare。prepare 校验宿主、能力与验收方法后原子领单，返回 packet_path 与 delegation_path；此时没有启动子 Agent。
4. 读取 delegation_path，用当前真实的创建子 Agent 工具发送该内容。此会话暴露的是 collaboration.spawn_agent；参数应以当前工具 schema 为准，优先 fork_turns="none"，不指定用户未要求的模型。不要用 create_thread 创建用户侧新任务来替代内部委派，不调用 codex CLI 自造运行器。
5. 原样保存工具返回，实际 agent ID 作为 host_run_id。创建 event=started 的内部事件，使用 host=codex_native，再 bind。事件字段沿用 host-bridge.md；不得把内部事件误当原生工具参数。
6. 用真实等待/状态工具跟踪这个 Agent。当前已实现的完成证据格式是 collaboration.list_agents 返回的 JSON：agents 数组中恰好一项 agent_name 匹配 host_run_id，agent_status 为 done/completed 字符串，或当前工具实际返回的 {"completed":"最终回复"}。保存原始返回供 collect 核对。running、idle、interrupted、缺失 Agent、等待超时都不能当完成；其他宿主返回结构需要扩展适配，不能编造转换后的成功回执。
7. collect 仅提交完整产物；随后主线程或指定审阅者 review，独立验收通过才 accepted、解锁依赖和交付。

```text
python scripts/team_runtime.py compile examples/team-demo/plan.codex-v3.json
python scripts/team_runtime.py init --plan examples/team-demo/plan.codex-v3.json --inputs examples/team-demo --job NEW_EXTERNAL_JOB
python scripts/native_host_bridge.py prepare --job NEW_EXTERNAL_JOB --task facts --worker facts-worker
python scripts/native_host_bridge.py bind --job NEW_EXTERNAL_JOB --event ACTUAL_STARTED_EVENT.json
python scripts/native_host_bridge.py collect --job NEW_EXTERNAL_JOB --event ACTUAL_FINISHED_EVENT.json
python scripts/team_runtime.py review --job NEW_EXTERNAL_JOB --file ACTUAL_REVIEW_REQUEST.json
```

native_host_bridge 默认按已冻结任务自动选宿主；可加 --host codex_native 作一致性检查，不能用这个参数修改任务宿主。创建失败且确认未启动时走恢复协议；创建返回不明时先查询，不重复派发。长任务在租约失效前 heartbeat。

## 权限与证明范围

Codex 子 Agent 使用宿主提供的真实上下文与工具。此适配器不能建立额外操作系统沙箱、强制隐藏其他可用工具或证明观察文本来自可信远端。总控必须核对原始宿主返回，限制任务范围；若独立工具白名单或更严文件隔离是硬要求而宿主不能提供，应报告缺口。

支持共享本地文件系统的会话；远端文件同步未实现。真实完成观察、输入/产物哈希与独立验收分别证明运行结束、版本一致性和已实现的业务检查，不能互相替代。Claude 路径继续见 [宿主桥接](host-bridge.md)。
