# v3 设计依据与验证边界

查阅日期：2026-09-20。以下均为官方原始文档；仅用于设计核对，不代表在本包上已经实测。

- Claude Code — Create custom subagents: https://code.claude.com/docs/en/sub-agents 。用于文件式 agent 定义、工具白名单/拒绝、model inherit、permissionMode default、Agent 委派职责边界。实际会话必须重新探测工具 schema，不能凭文档杜撰可调用工具。新建 agent 目录不能被会话发现时按官方说明重新启动宿主，不重复领取任务。
- SQLite — Transaction: https://www.sqlite.org/lang_transaction.html 。用于 BEGIN IMMEDIATE 事务语义。事务防止合作参与者的领取竞态，不提供远端任务停止证明。
- Python — sqlite3: https://docs.python.org/3/library/sqlite3.html 。用于标准库连接与事务管理。

本轮本地回归在 Python 3.13.5/Linux 执行；Python 3.10+ 是源码兼容目标，并未遍历 Python 版本与 Windows/macOS。Claude Code 原生子 Agent、远端 HTTP、真实模型稳定性与浏览器渲染不在本轮运行证据范围。

`provenance/v3` 是上传候选的历史记录，保持原始字节；其中 275 项测试和历史模型调用描述属于旧代码。`provenance/v3-final` 是本轮本地工程记录；两者不可合并为新版真实模型通过证据。
