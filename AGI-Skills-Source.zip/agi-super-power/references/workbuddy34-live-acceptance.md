# WorkBuddy 桌面端：下一轮实机接入验收

## 当前状态

HANDOFF_ONLY。没有当前桌面版本和操作系统的真实能力探测，没有创建/查询/停止工具的实际运行证据，没有 WorkBuddy 专用响应解析器。本包不声称这些已完成。

2026-09-22 本轮在 ChatGPT 的可用插件目录搜索 WorkBuddy，返回空列表；这仅说明本轮未找到该连接器，不代表 WorkBuddy 产品本身不存在接口。当前执行环境为 Linux/Python，而非用户的 WorkBuddy 桌面端。

## 在目标客户端的首条任务

rc.4 已将首轮有界探测整合到主包。先读 [WBD-PROBE-01](workbuddy-desktop-probe.md)，入口为 `scripts/workbuddy_bridge.py desktop-probe init`。本页后续生命周期清单属于适配器实现后的分阶段验收，不在一次最小探测里全部执行。

> 读取本包 SKILL.md 和 references/delivery-v34.md。先做只读能力盘点，不启动子 Agent，不调用模型 CLI，不安装软件，不读取无关个人文件/长期记忆/凭据。记录当前产品名称、版本与操作系统，读取当前真正暴露的创建、状态、等待、停止确认、产物、恢复和权限工具的完整参数合同。只根据可观察证据填 probe 模板；未知就留 unknown。不要把 CodeBuddy CLI、IDE 或小程序的文档字段借给 WorkBuddy Desktop，不要用角色扮演伪造运行 ID。

没有实际可调用接口时，结束在 HANDOFF_ONLY，保留清晰缺口；不借另起一个 CLI 冒充桌面原生适配。

## 适配代码准入

先保存客户端版本、操作系统、工具模式和原始返回。由唯一写者实现该产品的明确解析器与真实生命周期桥；加入原 host_registry 和共同合同测试。候选 JSON 不能解锁执行。是否支持 request_key、resume、effort、工具隔离必须分别检查，不能猜字段。

取得实际工具后，在独立临时工作区使用合成文件进行生命周期验收。首次允许的只是一个 bounded 子任务；未经用户授权不得扩大并发、外发材料、安装软件或写外部系统。

## 必测案例

| 编号 | 目标 | 必需证据 |
|---|---|---|
| WB-01 | 创建、返回真实运行 ID、等待、收集、独立验收 | 原始 create/status 返回、目标/令牌绑定、产物哈希、验收记录 |
| WB-02 | 故意缺一项要求，原负责人定向返工 | 缺陷、停止/完成、重试新令牌及修复验收 |
| WB-03 | 取消并确认真正停止 | 取消请求和最终停止状态，不能只保存“请求已发” |
| WB-04 | 提交回执丢失 | 原请求标识/查询，不重新发送创建；不能查询则明确暂停 |
| WB-05 | 超时但后台仍运行 | 查询原任务，避免新执行者竞争 |
| WB-06 | 重复回执、迟到结果、旧目标结果 | 幂等、隔离、拒收与必要 adopt_finished 流程 |
| WB-07 | 重开会话、材料变化、目标修订 | 本地检查点+最新账本+宿主查询+成果核对 |
| WB-08 | 宿主自动委派/专家团 | 证明映射和唯一产物责任可追踪；否则保持禁用 |

Windows 另外运行 `scripts/delivery_cli.py doctor` 与全量测试。8.3、中文空格、长路径与符号链接防护分别有实机结果；8.3 未开启或符号链接权限不足时写 NOT_VERIFIED，不把跳过算通过。

## 两个客户代表场景

依据材料生成报告：区分源事实、推断和缺口，进行需求覆盖和内容核对。

修改原 PPT：保留约定版式，实际打开/渲染，对照原材料检查内容、遮挡、字号、来源和样稿方向。约 20 分钟只给估算口径或演练记录。

这两个配方必须用真实代表材料完整跑过后，才能填“客户场景已验证”。当前包的 HTML/JSON 合成演示不能替代它们。

## 官方资料核对（不是实机证据）

- WorkBuddy 快速开始：https://www.codebuddy.cn/docs/workbuddy/Quickstart
- WorkBuddy 专家/专家团：https://www.codebuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Expert-Center
- CodeBuddy Code CLI Skills：https://www.workbuddy.ai/docs/zh/cli/skills
- Python 路径规范化说明：https://docs.python.org/3/library/os.path.html

上述资料于本轮读取，分别只用于核对产品边界、专家团会自行调度、CLI 文档所属产品，以及 canonical path 策略。没有从这些资料推断当前客户端可调用的生命周期 API。Skills-Market 页本轮抓取超时，未据此承诺具体安装按钮或导入步骤。
