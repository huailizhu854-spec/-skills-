# WBD-PROBE-01：桌面原生最小能力探测 v0.1

这是 3.4.0-rc.4 主包内置的桌面探测入口。命令只初始化合成材料、生成清单和检查证据，不启动模型或子 Agent，不建立新调度器或任务账本。桌面适配仍为 `HANDOFF_ONLY`；实际宿主调用由目标客户端总控按已授权合同执行。

## 执行范围

只在 **WorkBuddy 电脑端原生入口**、当前获授权工作区执行。手机连接电脑与手机云端分别记录为其他入口，本轮停止。操作系统、客户端、模型、执行地点依据当前可观察事实填写；看见 Linux 路径不能单独证明是桌面或云端。

阶段一仅盘点环境与可公开的工具合同。具备真实子 Agent 创建接口、可限定的合成任务、可保存原始返回且桌面执行地点明确后，阶段二最多进行 **一次创建、一个子 Agent、一次尝试**。不自动重试、不追加第二个子 Agent；不测试取消、恢复、并发或跨端。缺少 Skill 安装或加载不是原生能力探测的阻塞条件，须如实记录，不在本轮安装或更新 Skill。

## 1. 环境与目录

在读取附件后，先执行当前已允许的只读检查：客户端/入口、实际执行地点、可写工作区、Python 版本、SQLite 可导入性、当前可公开的原生创建/等待/结果接口及其参数。不安装任何依赖；不检查私人文件或凭据。Python 3.10+ 不可用时保存文字盘点并以 `BLOCKED` 结束，创建数为 0。

目录必须在 Skill 与所有旧 job 之外。可从主包直接运行 `python scripts/workbuddy_bridge.py desktop-probe init /absolute/path/new-run`；只预建父目录，命令排他创建运行目录并复制冻结材料，拒绝覆盖。手工操作时同样遵守以下顺序：

1. 选一个不存在的运行目录 `RUN`。只预建其父目录。
2. 一次性、排他地创建 `RUN`，已存在则停止，不清空、不覆盖、不换目录继续本轮。文件浏览器或脚本均须执行相同语义。
3. 创建 `RUN/evidence` 及 `RUN/evidence/raw`；复制本包 examples/workbuddy-desktop 中原样的 `source.csv` 和 `probe-contract.json` 到 evidence。
4. 把 examples/workbuddy-desktop/report.template.json 复制为 `RUN/evidence/report.json`，再写来源与能力盘点记录。

本轮不调用 AGI 的 `init`、`prepare`、`begin-submit`、bind 或 collect：这是独立宿主探测，未进入 Skill 集成，不绕过桌面闸门。未来 Skill 集成的固定顺序为：只预建父目录 → init 创建新 job 成功 → 写 job/reviews 来源记录 → prepare → begin-submit → intent → 原生调用。此说明不修改历史 rc.3 的停止条件。

## 2. 在创建前记录

所有 `_ref` 都是相对于 evidence 的文件路径，使用 `/`，不得使用绝对路径、`..` 或符号链接。

| 文件/字段 | 内容 |
|---|---|
| `raw/environment.md` → `environment_ref` | 入口、实际执行地点、OS/客户端/模型、Python/SQLite、Skill 安装与加载的观察依据；不能观察就写 UNKNOWN |
| `raw/inventory.md` → `inventory_ref` | 当前公开工具的准确名称、参数及返回合同；声明可用与实测分别标记；不导出隐藏指令 |
| `raw/authorization.md` → `authorization.record_ref` | 本轮用户指令、可观察消息来源标识/时间；复制内容使用 COORDINATOR_TRANSCRIPTION，独立会话导出才用 CONVERSATION_EXPORT |
| `raw/child-prompt.txt` → attempt 的 `prompt_ref` | 原样复制本包 examples/workbuddy-desktop/child-prompt.txt；不把主线程的预期答案加入子任务 |
| `raw/create-request.json` → `create_request_ref` | 按当前工具合同准备的完整参数 JSON；prompt 字段逐字等于上述文本 |

无法导出原始来源时，保留诚实的协调方记录及 UNKNOWN，不编造宿主调用编号或消息时间。复制的指令内容不等于原始用户消息凭证；本地记录时间也不是宿主调用时间。各时钟保留原显示值与精度，不推算时差。

根据当前工具的真实参数，把 examples/workbuddy-desktop/attempt.template.json 的 `prompt_json_pointer` 改为指向提示词的 JSON Pointer：例如 `/prompt` 或 `/input/prompt`，不能因为模板写了 `/prompt` 就猜宿主支持该字段。如果接口无法将任务文本映射到参数，停止并交回合同，不临时修改检查器。

预检完成后，在报告中预留一次 attempt 并将 `declared_create_calls` 设为 1，随即发出一次真实调用。若在发出前失败，恢复为 0 并记录未发出；若是否发出不确定，保留一次、写 `OUTCOME_UNKNOWN`。这个数字是执行方声明，检查器不能证明实际调用次数。所有创建前准备都必须完成后才允许发出调用。

## 3. 唯一一次宿主调用

直接调用当前真实暴露的原生接口。不要套用手机云端 `Agent` 名称、同步行为或尾注格式，也不要调用其他模型 API/CLI。不得由总控计算后冒充子 Agent 输出。仅有不可追踪的专家团界面，或无法限定为一个执行者时，报告 `BLOCKED`，不创建。

- **同步返回终态**：完整保存为 `raw/create-return.txt`（或保真 JSON），同一路径可同时作为 `create_return_ref` 和 `terminal_return_ref`；`response_mode=SYNC_TERMINAL`，不额外轮询。
- **明确的异步运行**：保存创建返回，仅用合同明确接受该种返回标识的只读等待/查询接口。最多 3 次后续读取，每次请求的等待参数不超过 60 秒；无等待参数的即时读取记录 0。若无法确定调用会否无限阻塞，不调用。每次记录工具名、参数文件、返回文件及 `requested_wait_seconds`。终态后设置 `ASYNC_TERMINAL`。
- **失败、超时或结果未知**：立即停止本轮后续业务动作，写 `FAILED` 或 `OUTCOME_UNKNOWN`。不得换工具重新创建。异步预算用尽仍运行时保留活跃标识，不释放归属、不宣称停止；不为凑终态调用取消。允许继续保存已有证据与生成失败报告。

`tool_call_id`、`agent_id`、`task_id` 分别按宿主来源填写，未提供就为 null；任何非空值须指向 `identifier_basis_ref` 中可观察的依据。只有真实合同明确要求的 ID 才能传给后续接口，禁止拿某种 ID 猜另一种字段。

完整原始返回和可取得的宿主执行记录原样保留。界面复制、协调方保存均用 `trace.kind=COORDINATOR_CAPTURE`；只有取得宿主原始导出才用 `ORIGINAL_HOST_EXPORT`，仍待独立核实；不可得则 `NOT_AVAILABLE/ref=null`。不得修改文字使其看起来像原生回执。

## 4. 结果与状态

默认子任务通过原生返回通道给 JSON。协调者可把返回中实际 JSON 原样提取为 `result.json`，使用 `result_source=RETURN_TRANSCRIPTION` 并让 `result_source_ref` 指向原始终态返回；不得改数字、补不存在的字段或声称是子 Agent 写的文件。若宿主实际交付文件，保留原文件并使用 `CHILD_FILE`。没有结果则所有 result 引用为 null，source 为 NOT_AVAILABLE。

总控独立验算：A=36、B=14、C=20、合计=70。正确数字仅证明内容正确，不证明真实委派。结果不正确写 `FAILED`，不返工。文件字节保真只适用于原始材料保存，本探测不要求 JSON 字段顺序或行尾必须与某个预置答案相同。

| report.status | 条件 |
|---|---|
| `BLOCKED` | 创建前缺少环境或合同能力；写明原因 |
| `FAILED` | 准备、创建、回收或结果发生确定失败，保留失败记录 |
| `OUTCOME_UNKNOWN` | 可能已发出创建、返回或终态不明，或有界等待后仍运行 |
| `OBSERVED_TERMINAL` | 一次创建得到终态和正确结果，过程无失败；仍只是执行方报告，需复核原始来源 |

任何步骤发生失败，停止本轮，记录在 `failures`，`continued_after_failure=false` 表示失败后只保存与封存证据。若已违规继续，填 true，不能隐瞒或把错误改称“无失败”。创建前目录错误同样适用。

## 5. 本地检查与回传

检查器仅依赖 Python 标准库，不创建 Agent，不读取环境变量/凭据，不写任务账本，不联网。`manifest` 仅首次创建清单，拒绝覆盖；`check` 只读。

把下面的 Python 命令替换为当前已经确认可用的解释器及实际路径。示例不要求宿主必须使用某种 shell。

```text
python scripts/workbuddy_bridge.py desktop-probe manifest /path/to/RUN/evidence
python scripts/workbuddy_bridge.py desktop-probe check /path/to/RUN/evidence
```

保存第二条的 stdout 为 `RUN/local-check.json`，放在 evidence 外面。不要将清单自身或检查输出反复纳入清单；封存后不得改 evidence 内容。命令退出码：0=本地文件一致、计算正确、可交原始轨迹复核；2=结构一致的停止报告；1=文件/字段/预算声明不一致。2 不是要求重试，1 也不授权重跑 Agent 或改冻结合同。缺材料时照实回传。

回传一个 ZIP，包含 `evidence/`、`local-check.json`、简短的 `report.md`；不要打包整个用户工作区。report.md 写出环境、工具合同、真实动作数、原生返回模式、标识含义、失败及未验证项。无可用 Python 或早期无法建目录时，仅回传文字盘点和已有原始输出，声明没有运行检查器，不虚构 JSON PASS。

即使检查器退出 0，也只报告 `LOCAL_EVIDENCE_READY_FOR_REVIEW`。它总是保留 `REQUIRES_HOST_TRACE_REVIEW`、`REQUIRES_SOURCE_REVIEW`、`NOT_TESTED`（Skill 集成），桌面适配始终 `HANDOFF_ONLY`。本轮不使用 `PASS_INSTALLED_SKILL_SERIAL_INTEGRATION`。

后续在真实合同和原始证据足以评估后，再实现桌面 adapter/normalizer 并接入原账本。手机连接电脑、取消、恢复独立排期，不由本次探测结果推断。
