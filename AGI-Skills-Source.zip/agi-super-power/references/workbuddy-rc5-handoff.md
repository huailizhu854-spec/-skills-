# WorkBuddy 手机云端 rc.5 实机验收交接

此规程用于真实 WorkBuddy 手机云端总控。当前包仍为候选：本地离线测试不代表已安装成功或真实调用通过。先读取实际加载的 SKILL.md、VERSION.json 与本文件；桌面入口不使用手机云端合同。

## 1. 范围与停止规则

- 本轮最多两次真实创建：A实现、A验收后B审核；每任务一次尝试。同步终态返回，无后台query/cancel/resume承诺。
- 实际工具未暴露、必要文件工具不可用、加载版本不明、准备失败、调用失败或结果未知时，停止下一项业务动作，保存原始证据，不自动重试或改目录继续同一轮。
- 本机交付文件在D盘；手机云端使用该宿主实际获授权的工作目录，记录其真实绝对路径，不编造D盘路径。
- 不改旧任务账本、不回填旧授权/旧调用记录；候选安装不要覆盖活跃的旧安装。

## 2. 安装与环境

确认实际入口是手机App→云端，记录可观察的客户端版本、云端OS、模型和实际Skill加载路径。不可观察的客户端版本使用UNKNOWN，云端OS必须实际观察。保存加载当前3.4.0-rc.5的依据和安装文件哈希。

用实际可用的Python（3.10+）运行 `scripts/delivery_cli.py doctor`。在包外新报告目录运行 `scripts/run_offline_tests.py --report <包外路径/offline-tests.json>`，日志也存包外；这一步不调用真实Agent。解释每个skip，不将Linux跳过Windows专用测试算成通过。

如未能证明实际Skill已加载，标BLOCKED_SKILL_LOAD，不开始真实创建。若宿主工具接口没有真实子Agent调用，标BLOCKED_HOST_TOOL，不以角色文字代替。

## 3. 初始化并冻结当前能力

选择一个未使用的包外绝对路径作为JOB，只预建父目录，不预建JOB/reviews。成功执行：

```text
python -B scripts/team_runtime.py compile examples/workbuddy-mc/plan.workbuddy-v3.json
python -B scripts/team_runtime.py init --plan examples/workbuddy-mc/plan.workbuddy-v3.json --inputs examples/workbuddy-mc --job <JOB>
python -B scripts/delivery_cli.py workbuddy-capability-template --job <JOB>
```

**实机不得加 --offline-fixture。** 该选项仅用于合成测试；离线作业输出不授权真实调用。

由总控根据当前真实工具合同填写模板，保存新文件 JOB/reviews/workbuddy-capabilities.json：

- 保留模板job/plan_digest/host；entry=MOBILE_CLOUD、execution_mode=synchronous_terminal。
- native_tool填写实际创建工具准确名称，不默认猜为Agent。
- probe.evidence_kind=CURRENT_TOOL_OBSERVATION；observed_at/expires_at为本地UTC Unix秒，有效期最多24小时。不同来源时钟不可推算消息时间。
- product=WorkBuddy Mobile Cloud。client_version不可见写UNKNOWN；os记录实际云端系统。
- create/wait/artifacts/workspace/shared_files须有当前工具/环境观察支持，evidence引用JOB内保存的原始工具合同或环境观察及SHA-256。wait指创建同步等待终态，不要求额外后台查询工具。
- file_tools分别填写file.read与file.write：status=supported、native_tool=实际对应工具名、evidence={path,sha256}。无法确认所需文件读写就停止。
- 其他能力明确supported/unsupported/unknown；unknown的evidence为null。不能为了通过将query/cancel/recover填成支持。
- 所有evidence.path均相对于JOB；原始工具合同不包含私人凭据或隐藏指令。协调方观察不等于宿主真实性已认证。

然后执行一次：

```text
python -B scripts/delivery_cli.py workbuddy-capability-freeze --job <JOB> --record <JOB/reviews/workbuddy-capabilities.json>
```

冻结后不可覆盖。过期时不继续创建，不篡改时间；停止并报告。已有尝试的快照不能被新快照覆盖。

## 4. 调用、回收和验收

继续完整执行 [WBMC-INT-01](workbuddy-mobile-cloud-int01.md) 的A/B顺序及 [调用证据规程](workbuddy-mobile-cloud-provenance.md)。固定顺序：

init → 当前能力冻结及用户指令来源记录 → prepare → begin-submit → intent → 一次真实宿主调用 → 原样保存返回 → return/check → event → bind/collect → review accept。

每次prepare取得本次packet、token、workspace。工具参数中的任务正文必须来自本次 workbuddy-delegation.md 的原始字节UTF-8解码；不要使用会改变换行的读取。示例：

```python
prompt = Path(delegation_path).read_bytes().decode('utf-8')
```

按宿主真正支持的参数名构造调用JSON，把完整参数写入新文件；用intent --prompt-key <实际字段名>固定它。不要在任务文本后加其他指令。当前证据入口要求prompt在顶层字段；若宿主只有嵌套prompt接口，报告合同不适用，不临时猜字段或改验证器。

begin-submit的stdout保存到新submission文件；intent记录真实用户指令来源，无法导出的来源使用coordinator_transcription并保留REQUIRES_SOURCE_REVIEW。

返回文本保留原字节/文本内容及真实尾注；不可编辑ID或用旧返回替换。真实tool_call_id可取得则填写，不可取得使用null。event --native-tool 与能力记录、实际调用、intent必须一致。

bind、collect、submit和accept现在会强制重新检查调用记录；缺记录、错原始返回或工具名不能继续。手工运行check仍用于提前定位问题。成功observe是恢复用的辅助记录路径，不替代本轮要求的bind→collect顺序。

A结果必须accepted后才准备B。B读取独立冻结标准和A产物，只写自己的review.json。两者真实宿主ID必须不同。不得由总控代写结果以取得验收通过。

## 5. 回传

完成后运行check_integration.py生成包外/作业内的新报告，并保存status、doctor、完整离线测试结果、实际加载证据、两次调用参数及原始返回、真实创建次数、review证据和产物哈希。

填写 WBMC-INT-01-report.md：入口与环境、实际加载版本、每一步执行结果、A/B真实ID、失败或例外、最终结论、未验证能力。集成检查输出eligible_for_live_review仅表示本地材料具备复核条件，不是宿主已认证。

私有回传包仅含本轮必要材料，不包含整个用户目录、凭据或其他项目。将报告和证据交回原审阅任务，由其独立复核。桌面、并发、查询、取消、运行中恢复仍分别保持未验证。

历史作业的normalize等只读转换报告应写包外新目录，不能把通用输出路径指向旧作业。event CLI 对绑定旧packet的写入会拒绝。
