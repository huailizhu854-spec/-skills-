"""Independent synthetic shard verifier; not a general-purpose business verifier."""
import hashlib
import json
from verifier_registry import finding


def verify(ctx):
    if ctx.packet['contract']['executor']['type']!='fixture':
        raise ValueError('dual16-shard-v1 is restricted to OFFLINE fixture tasks')
    source=ctx.raw('numbers'); nums=json.loads(source)['numbers']
    index=ctx.spec['params']['shard']; count=ctx.spec['params']['shards']
    if type(index) is not int or type(count) is not int or count!=16 or not 0<=index<count:
        raise ValueError('Invalid shard assignment')
    selected=nums[index::count]
    data=ctx.json_object(ctx.output_id())
    expected={'shard':index,'count':len(selected),'total':sum(selected),
              'sum_squares':sum(x*x for x in selected),'source_sha256':hashlib.sha256(source).hexdigest()}
    return [finding(k,type(data.get(k)) is type(v) and data[k]==v) for k,v in expected.items()]
