#!/usr/bin/env python3
"""Offline evidence inventory/checks only. Never dispatches or certifies a host."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys

PINNED = {
    "source.csv": "dcdc3b09a870b3e9003f4f508fe48dcb3b4ae321944f37019468515354b582c6",
    "probe-contract.json": "5d6803f1c85a18e182a780e8657fc7f9e2f2c0f4b39afd0f11de6190ebca13b8",
}
STOP_STATUSES = {"BLOCKED", "FAILED", "OUTCOME_UNKNOWN"}
SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATES = SKILL_ROOT / 'examples/workbuddy-desktop'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def initialize(root):
    """Exclusive preparation outside the skill; no dispatch or new ledger."""
    require(not root.exists() and not root.is_symlink(), 'run directory already exists; stop this round')
    require(root.parent.is_dir(), 'create only the run parent directory before init')
    require(not root.resolve().is_relative_to(SKILL_ROOT.resolve()), 'run must be outside the skill')
    require(not any((p / 'team.sqlite3').exists() for p in root.resolve().parents),
            'run must be outside existing task jobs')
    payload = {name: (TEMPLATES / name).read_bytes() for name in PINNED}
    for name, data in payload.items():
        require(sha(data) == PINNED[name], 'frozen template changed: ' + name)
    report = (TEMPLATES / 'report.template.json').read_bytes()
    prompt = (TEMPLATES / 'child-prompt.txt').read_bytes()
    root.mkdir()
    evidence = root / 'evidence'
    evidence.mkdir()
    (evidence / 'raw').mkdir()
    for name, data in {**payload, 'report.json': report, 'raw/child-prompt.txt': prompt}.items():
        with (evidence / name).open('xb') as handle:
            handle.write(data)
    return {'probe_id': 'WBD-PROBE-01', 'run_directory': str(root.absolute()),
            'evidence_directory': str(evidence.absolute()), 'real_agent_calls': 0,
            'execution': 'NOT_EXECUTED', 'desktop_adapter_status': 'HANDOFF_ONLY'}


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique_object)


def safe_path(root, name):
    require(isinstance(name, str) and name != "", "empty/non-string evidence path")
    p = PurePosixPath(name)
    require(not p.is_absolute() and "\\" not in name and ":" not in name
            and all(part not in {"", ".", ".."} for part in name.split("/")),
            "unsafe evidence path: " + name)
    target = root.joinpath(*p.parts)
    for part in [target, *target.parents]:
        if part == root:
            break
        require(not part.is_symlink(), "symlink evidence path: " + name)
    require(target.is_file(), "missing evidence file: " + name)
    require(target.resolve().is_relative_to(root.resolve()), "path leaves evidence root")
    return target


def scan(root):
    require(root.is_dir() and not root.is_symlink(), "evidence root must be a real directory")
    files = {}
    for path in sorted(root.rglob("*")):
        require(not path.is_symlink(), "symlinks are not allowed: " + str(path))
        if path.is_file() and path.name != "manifest.json":
            name = path.relative_to(root).as_posix()
            safe_path(root, name)
            files[name] = sha(path.read_bytes())
        elif path.is_file():
            require(path.parent == root, "nested manifest.json is not allowed")
        else:
            require(path.is_dir(), "non-regular evidence entry")
    return files


def manifest(root):
    files = scan(root)
    require(files, "empty evidence directory")
    payload = {"schema_version": 1, "files": files}
    with (root / "manifest.json").open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    return {"manifest_created": True, "file_count": len(files)}


def inspect(root):
    files = scan(root)
    index = read_json(safe_path(root, "manifest.json"))
    require(type(index.get("schema_version")) is int and index["schema_version"] == 1,
            "invalid manifest schema")
    require(index.get("files") == files, "manifest hashes or file coverage differ")
    for name, digest in PINNED.items():
        require(files.get(name) == digest, "frozen input changed: " + name)
    report = read_json(safe_path(root, "report.json"))
    require(type(report.get("schema_version")) is int and report["schema_version"] == 1,
            "invalid report schema")
    require(report.get("probe_id") == "WBD-PROBE-01", "wrong probe_id")
    status = report.get("status")
    require(status in STOP_STATUSES | {"OBSERVED_TERMINAL"}, "unsupported status")
    terminal = status == "OBSERVED_TERMINAL"

    def ref(value, required=False):
        if value is None:
            require(not required, "required evidence reference is null")
            return None
        target = safe_path(root, value)
        require(value in files and target.stat().st_size > 0, "unlisted/empty evidence: " + value)
        return target

    require(report.get("entry") in {"DESKTOP_NATIVE", "MOBILE_TO_DESKTOP", "MOBILE_CLOUD", "UNKNOWN"},
            "invalid entry")
    for field in ("environment_ref", "inventory_ref"):
        require(field in report, "missing " + field)
        ref(report[field], terminal)
    require(isinstance(report.get("environment"), dict), "missing environment")
    require(isinstance(report.get("execution_location"), str) and report["execution_location"],
            "missing execution_location")
    for flag in ("continued_after_failure", "external_model_used", "recursive_delegation_used",
                 "cancellation_tested", "resume_tested"):
        require(report.get(flag) is False, "out-of-scope action or missing flag: " + flag)
    require(isinstance(report.get("unverified"), list), "missing unverified list")
    auth = report.get("authorization")
    require(isinstance(auth, dict), "missing authorization record")
    require(auth.get("source_kind") in {"CONVERSATION_EXPORT", "COORDINATOR_TRANSCRIPTION", "NOT_AVAILABLE"},
            "invalid authorization source")
    ref(auth.get("record_ref"), terminal or auth.get("source_kind") == "CONVERSATION_EXPORT")
    if terminal:
        require(auth["source_kind"] != "NOT_AVAILABLE", "missing authorization content")
    trace = report.get("trace")
    require(isinstance(trace, dict), "missing trace record")
    require(trace.get("kind") in {"ORIGINAL_HOST_EXPORT", "COORDINATOR_CAPTURE", "NOT_AVAILABLE"},
            "invalid trace kind")
    ref(trace.get("ref"), trace["kind"] != "NOT_AVAILABLE")
    require(trace["kind"] != "NOT_AVAILABLE" or trace.get("ref") is None,
            "NOT_AVAILABLE trace must have null ref")
    failures = report.get("failures")
    require(isinstance(failures, list), "missing failures")
    for failure in failures:
        require(isinstance(failure, dict) and failure.get("stage") and failure.get("detail"),
                "failure needs stage and detail")
        ref(failure.get("evidence_ref"))
    attempts = report.get("attempts")
    require(isinstance(attempts, list) and len(attempts) <= 1, "create budget exceeded")
    count = report.get("declared_create_calls")
    require(type(count) is int and count == len(attempts), "create count mismatch")
    if attempts or terminal:
        require(report["entry"] == "DESKTOP_NATIVE" and report["execution_location"] != "UNKNOWN",
                "creation requires observed desktop entry/location")
        ref(report["environment_ref"], True)
        ref(report["inventory_ref"], True)
        require(auth["source_kind"] != "NOT_AVAILABLE", "creation requires authorization content")
        ref(auth.get("record_ref"), True)
    if terminal:
        require(len(attempts) == 1 and not failures, "terminal success requires one attempt and no failures")
    else:
        require(isinstance(report.get("reason"), str) and report["reason"].strip(), "stop reason required")

    result_correct = None
    for attempt in attempts:
        require(type(attempt.get("sequence")) is int and attempt["sequence"] == 1, "invalid attempt sequence")
        require(isinstance(attempt.get("tool_name"), str) and attempt["tool_name"].strip(), "missing native tool name")
        for field in ("prompt_ref", "create_request_ref"):
            ref(attempt.get(field), True)
        prompt = ref(attempt["prompt_ref"], True).read_text(encoding="utf-8")
        require((root / "source.csv").read_text(encoding="utf-8").strip() in prompt,
                "child prompt does not contain frozen source")
        pointer = attempt.get("prompt_json_pointer")
        require(isinstance(pointer, str) and pointer.startswith("/"), "missing prompt JSON pointer")
        value = read_json(ref(attempt["create_request_ref"], True))
        for part in pointer[1:].split("/"):
            key = part.replace("~1", "/").replace("~0", "~")
            if isinstance(value, list):
                require(key.isdigit() and int(key) < len(value), "invalid prompt array pointer")
                value = value[int(key)]
            else:
                require(isinstance(value, dict) and key in value, "prompt pointer does not resolve")
                value = value[key]
        require(value == prompt, "saved create arguments differ from child prompt")
        for field in ("create_return_ref", "terminal_return_ref"):
            ref(attempt.get(field), terminal)
        mode = attempt.get("response_mode")
        require(mode in {"SYNC_TERMINAL", "ASYNC_TERMINAL", "UNKNOWN"}, "invalid response mode")
        require(not terminal or mode != "UNKNOWN", "terminal response mode unknown")
        ids = attempt.get("host_ids")
        require(isinstance(ids, dict) and set(ids) == {"tool_call_id", "agent_id", "task_id"}, "invalid identifier fields")
        require(all(v is None or isinstance(v, str) and v.strip() for v in ids.values()), "invalid identifier value")
        ref(attempt.get("identifier_basis_ref"), any(ids.values()))
        # No assumption that Agent ID, task_id and tool-call ID share a namespace.
        reads = attempt.get("followup_reads")
        require(isinstance(reads, list) and len(reads) <= 3, "follow-up read budget exceeded")
        for read in reads:
            require(isinstance(read, dict) and isinstance(read.get("tool_name"), str) and read["tool_name"],
                    "invalid follow-up tool")
            seconds = read.get("requested_wait_seconds")
            require(type(seconds) is int and 0 <= seconds <= 60, "invalid wait budget")
            ref(read.get("request_ref"), True)
            ref(read.get("return_ref"), terminal)
        require(mode != "SYNC_TERMINAL" or not reads, "sync terminal should not be polled")
        result_path = ref(attempt.get("result_ref"), terminal)
        source = attempt.get("result_source")
        require(source in {"CHILD_FILE", "RETURN_TRANSCRIPTION", "NOT_AVAILABLE"}, "invalid result source")
        ref(attempt.get("result_source_ref"), result_path is not None)
        require(not result_path or source != "NOT_AVAILABLE", "result source missing")
        if result_path:
            result = read_json(result_path)
            require(isinstance(result, dict) and set(result) == {"items", "total"}, "invalid result fields")
            items = result["items"]
            require(isinstance(items, list) and len(items) == 3, "invalid result rows")
            actual = {}
            for row in items:
                require(isinstance(row, dict) and set(row) == {"item", "line_total"}, "invalid result row")
                require(isinstance(row["item"], str) and row["item"] not in actual, "duplicate result item")
                require(type(row["line_total"]) is int, "line_total must be integer")
                actual[row["item"]] = row["line_total"]
            result_correct = actual == {"A": 36, "B": 14, "C": 20} and type(result["total"]) is int and result["total"] == 70
            require(result_correct or not terminal, "incorrect arithmetic result")

    ready = terminal and result_correct is True
    return {
        "probe_id": "WBD-PROBE-01", "local_evidence_consistent": True,
        "reported_status": status, "file_count": len(files), "result_correct": result_correct,
        "declared_bounds_passed": True, "ready_for_host_review": ready,
        "verdict": "LOCAL_EVIDENCE_READY_FOR_REVIEW" if ready else "VALID_STOP_REPORT",
        "host_verdict": "REQUIRES_HOST_TRACE_REVIEW",
        "authorization_verdict": "REQUIRES_SOURCE_REVIEW",
        "skill_integration_verdict": "NOT_TESTED",
        "desktop_adapter_status": "HANDOFF_ONLY",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("init", "manifest", "check"))
    parser.add_argument("directory", type=Path)
    args = parser.parse_args(argv)
    try:
        result = {'init': initialize, 'manifest': manifest, 'check': inspect}[args.command](args.directory)
        code = 0 if args.command != 'check' or result["ready_for_host_review"] else 2
    except (ValueError, OSError, KeyError, TypeError, AttributeError) as exc:
        result = {"local_evidence_consistent": False, "verdict": "INVALID_EVIDENCE", "error": str(exc),
                  "host_verdict": "REQUIRES_HOST_TRACE_REVIEW", "skill_integration_verdict": "NOT_TESTED"}
        code = 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return code


if __name__ == "__main__":
    sys.exit(main())
