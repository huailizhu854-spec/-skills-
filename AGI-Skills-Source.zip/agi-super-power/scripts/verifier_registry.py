"""Independent, allowlisted acceptance verifiers (coordinator-owned code).

Unknown methods return NOT_EXECUTED/UNVERIFIED. The producer's checks are never
used as requirement evidence. Extending this registry is a reviewed code change,
not a command/plugin path supplied by a worker or document.
"""
from __future__ import annotations
import hashlib
import html.parser
import re
from pathlib import Path
from typing import Callable
from kernel import local_file, contained_file
from v3_protocol import digest, strict_loads, subject_hashes, subject_ids

VERSION = '3.0.0'


class Context:
    def __init__(self, packet: dict, result: dict, spec: dict):
        self.packet, self.result, self.spec = packet, result, spec
        self.paths = {x['id']: Path(x['path']) for x in packet['input_snapshots']}
        self.paths.update({x['id']: Path(packet['output_root']) / x['path'] for x in result['artifacts']})
        self.hashes = subject_hashes(spec, packet, result['artifacts'])

    def raw(self, aid):
        if aid not in set(self.packet['contract']['reads']) | {x['id'] for x in self.packet['contract']['outputs']}:
            raise ValueError('Verifier cannot read undeclared input')
        p = self.paths[aid]
        workspace = Path(self.packet['workspace'])
        resolved, info = contained_file(workspace, p)
        raw = resolved.read_bytes()
        if hashlib.sha256(raw).hexdigest() != info["sha256"]:
            raise ValueError("Verifier input changed after containment/hash validation")
        return raw

    def text(self, aid):
        return self.raw(aid).decode('utf-8')

    def json(self, aid):
        return strict_loads(self.text(aid))

    def json_object(self, aid):
        value = self.json(aid)
        if not isinstance(value, dict):
            raise ValueError('Verifier requires a JSON object, not an array/scalar')
        return value

    def output_id(self):
        ids = subject_ids(self.spec, self.packet['contract'])
        if len(ids) != 1:
            raise ValueError('This verifier requires one artifact subject')
        return ids[0]


def finding(check, ok, detail=''):
    return {'check': check, 'ok': bool(ok), 'detail': detail, 'blocking': True}


class StaticText(html.parser.HTMLParser):
    """Static DOM text approximation, NOT browser/CSS visual verification."""
    VOID = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack, self.texts, self.headings = [], [], []
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        hidden = (tag in {'style','script','template','head'} or 'hidden' in a
                  or a.get('aria-hidden') == 'true'
                  or 'display:none' in (a.get('style') or '').replace(' ', '').lower()
                  or 'visibility:hidden' in (a.get('style') or '').replace(' ', '').lower())
        if tag not in self.VOID:
            self.stack.append((tag, hidden))
    def handle_endtag(self, tag):
        for i in range(len(self.stack)-1, -1, -1):
            if self.stack[i][0] == tag:
                del self.stack[i:]
                break
    def handle_data(self, text):
        if not any(h for _,h in self.stack):
            self.texts.append(text)
            if any(t == 'h1' for t,_ in self.stack):
                self.headings.append(text)


def facts(ctx):
    raw = ctx.raw('brief'); text = raw.decode('utf-8')
    data = ctx.json_object(ctx.output_id())
    # Plan v3 defines key names and Unicode-codepoint count INCLUDING all newlines.
    return [finding('line_count', type(data.get('lines')) is int and data['lines'] == len(text.splitlines())),
            finding('unicode_codepoints_including_newlines', type(data.get('characters')) is int and data['characters'] == len(text)),
            finding('input_sha256', data.get('brief_sha256') == hashlib.sha256(raw).hexdigest())]


def outline(ctx):
    lines = ctx.text('brief').splitlines(); data = ctx.json_object(ctx.output_id())
    return [finding('exact_title', data.get('title') == lines[0]),
            finding('ordered_body_lines', data.get('sections') == lines[1:])]


def page(ctx):
    text = ctx.text(ctx.output_id())
    facts_data, outline_data = ctx.json_object('facts-data'), ctx.json_object('outline-data')
    parser = StaticText(); parser.feed(text); parser.close()
    visible = ''.join(parser.texts)
    from model_worker import check_html
    return [finding('html_structure', check_html(text)[0]),
            finding('h1_title', ''.join(parser.headings).strip() == outline_data['title']),
            finding('outline_lines_static_text', all(line in visible for line in outline_data['sections'])),
            finding('accepted_facts_binding', facts_data['brief_sha256'] in visible),
            finding('accepted_line_count', re.search(r'\blines\s*=\s*' + re.escape(str(facts_data['lines'])) + r'(?!\d)', visible) is not None)]


def audit(ctx):
    data = ctx.json_object(ctx.output_id()); text = ctx.text('page-html')
    from model_worker import check_html
    return [finding('page_hash', data.get('subject_sha256') == hashlib.sha256(ctx.raw('page-html')).hexdigest()),
            finding('independent_static_structure', check_html(text)[0])]


def json_values(ctx):
    data = ctx.json_object(ctx.output_id()); expected = ctx.spec.get('params', {}).get('equals')
    if not isinstance(expected, dict) or not expected:
        raise ValueError('json-values-v1 requires nonempty params.equals (top-level exact typed values)')
    return [finding('json_key:' + k, k in data and type(data[k]) is type(v) and data[k] == v)
            for k,v in expected.items()]


def text_contains(ctx):
    values = ctx.spec.get('params', {}).get('strings')
    if not isinstance(values, list) or not values or not all(isinstance(v,str) and v for v in values):
        raise ValueError('text-contains-v1 needs a nonempty strings array')
    text = ctx.text(ctx.output_id())
    return [finding('contains:' + str(i), v in text) for i,v in enumerate(values)]


def expected_sha(ctx):
    value = ctx.spec.get('params', {}).get('sha256')
    if not isinstance(value, str) or len(value) != 64:
        raise ValueError('file-sha256-v1 requires a pinned expected sha256')
    return [finding('file_sha256', hashlib.sha256(ctx.raw(ctx.output_id())).hexdigest() == value)]


def equal_bytes(ctx):
    ids = subject_ids(ctx.spec, ctx.packet['contract'])
    if len(ids) < 2:
        raise ValueError('equal-bytes-v1 needs at least two explicit subjects')
    hashes = [hashlib.sha256(ctx.raw(x)).hexdigest() for x in ids]
    return [finding('equal_bytes', len(set(hashes)) == 1)]


REGISTRY: dict[str, Callable] = {
    'dual16-shard-v1': lambda ctx: __import__('dual16_fixture_verifier').verify(ctx),
    'demo-facts-v3': facts, 'demo-outline-v3': outline, 'demo-page-v3': page, 'demo-audit-v3': audit,
    'json-values-v1': json_values, 'text-contains-v1': text_contains,
    'file-sha256-v1': expected_sha, 'equal-bytes-v1': equal_bytes,
    # Resume-clinic verifiers. Deterministic anti-fabrication / anti-omission only; they do NOT
    # score advice quality. Imported lazily so this module stays import-cycle free.
    'resume-parse-v1': lambda ctx: __import__('verifiers_resume').parse_grounded(ctx),
    'resume-diag-v1': lambda ctx: __import__('verifiers_resume').diagnosis_anchored(ctx),
    'resume-match-v1': lambda ctx: __import__('verifiers_resume').jd_coverage(ctx),
    'resume-rewrite-v1': lambda ctx: __import__('verifiers_resume').rewrite_traceable(ctx),
    'resume-report-v1': lambda ctx: __import__('verifiers_resume').report_complete(ctx),
    'resume-qa-v1': lambda ctx: __import__('verifiers_resume').qa_honest(ctx),
}


def evaluate(packet: dict, result: dict) -> dict:
    checks = []
    for spec in packet['contract']['acceptance']:
        base = {'id': spec['id'], 'requirement': spec['requirement'], 'method': spec['method'],
                'evidence_kind': spec['evidence_kind'], 'subject': spec['subject'],
                'subject_hashes': subject_hashes(spec, packet, result['artifacts'])}
        verifier = REGISTRY.get(spec['method'])
        if verifier is None or spec['evidence_kind'] != 'RUNTIME_FACT':
            checks.append({**base, 'execution': 'NOT_EXECUTED', 'outcome': 'UNVERIFIED',
                           'findings': [], 'reason': 'No registered verifier for this method/evidence kind'})
            continue
        try:
            findings = verifier(Context(packet, result, spec))
            ok = bool(findings) and all(f['ok'] for f in findings)
            checks.append({**base, 'execution': 'EXECUTED', 'outcome': 'PASS' if ok else 'FAILED',
                           'findings': findings})
        except (ValueError, TypeError, KeyError, OSError, IndexError) as exc:
            checks.append({**base, 'execution': 'EXECUTED', 'outcome': 'FAILED',
                           'findings': [finding('verifier_error', False, str(exc))]})
    return {'schema_version': 1, 'kind': 'contract_acceptance', 'verifier_registry_version': VERSION,
            'verifier_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'task_id': packet['task_id'], 'lease_token': packet['lease_token'],
            'goal_digest': packet['goal_digest'], 'plan_digest': packet['plan_digest'],
            'result_digest': digest(result), 'contract_digest': digest(packet['contract']),
            'checks': checks, 'passed': bool(checks) and all(x['outcome'] == 'PASS' for x in checks),
            'not_verified': ['Browser/CSS rendering', 'Model/backend identity attestation',
                             'Unregistered business requirements', 'Production model stability']}
