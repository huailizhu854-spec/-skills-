#!/usr/bin/env python3
"""Export hash-only release evidence by default, without user prompts or sources.
Explicit --private --ack-sensitive creates a raw forensic copy with a blocking
privacy marker. This operation does not attest to model identity or native runs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import stat
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from team_runtime import TeamStore, write_json

COPY_TREES = ("published", "reviews", "sources")
WORKER_FILES = ("packet.json", "result.json", "controller-result.json")


def event_log(job: Path) -> list[dict]:
    with TeamStore(job) as store:
        rows = store.db.execute("SELECT seq, at, kind, task_id, detail FROM events ORDER BY seq")
        return [{"seq": r["seq"], "at": r["at"], "kind": r["kind"], "task_id": r["task_id"],
                 "detail": json.loads(r["detail"])} for r in rows]


def task_table(job: Path) -> list[dict]:
    with TeamStore(job) as store:
        columns = ("id", "status", "attempt", "worker", "mode", "host_run_id", "started", "finished")
        return [{c: row[c] for c in columns}
                for row in store.db.execute("SELECT * FROM tasks ORDER BY id")]


def export_private(job: Path, target: Path) -> dict:
    from kernel import checked_root, local_file
    job, target = checked_root(job), target.absolute()
    if target.resolve().is_relative_to(job):
        raise ValueError('Export target must be outside the job')
    # Preflight all source files; never follow a symlink into unrelated data.
    for source in job.rglob('*'):
        if source.is_symlink(): raise ValueError('Linked evidence is forbidden')
        if not source.is_dir() and not stat.S_ISREG(source.lstat().st_mode):
            raise ValueError('Only ordinary files/directories can be exported')
        # Empty stdout/stderr logs are valid forensic files, not empty artifacts.
    if target.exists():
        raise SystemExit(f"refusing to overwrite {target}")
    target.mkdir(parents=True)
    write_json(target / "PRIVATE_EVIDENCE.json", {"classification":"private_forensic", "publish":False})
    write_json(target / "event-log.json", event_log(job))
    write_json(target / "task-table.json", task_table(job))
    for name in ("demo-report.json", "plan.json", "adapters.resolved.json"):
        if (job / name).is_file():
            shutil.copy2(job / name, target / name)
    for tree in COPY_TREES:
        if (job / tree).is_dir():
            shutil.copytree(job / tree, target / tree)
    for workspace in sorted((job / "workers").glob("*/*")):
        out = target / "workers" / workspace.parent.name / workspace.name
        out.mkdir(parents=True)
        for name in WORKER_FILES:
            if (workspace / name).is_file():
                shutil.copy2(workspace / name, out / name)
        if (workspace / "evidence").is_dir():
            shutil.copytree(workspace / "evidence", out / "evidence")
        if (workspace / "outputs").is_dir():
            shutil.copytree(workspace / "outputs", out / "outputs")
    files = sorted(p for p in target.rglob("*") if p.is_file() and p.name != "MANIFEST.json")
    manifest = {"schema_version": 1, "source_job": str(job), "files": [
        {"path": p.relative_to(target).as_posix(), "bytes": p.stat().st_size,
         "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
    write_json(target / "MANIFEST.json", manifest)
    return {"exported": str(target), "files": len(manifest["files"])}


def export(job: Path, target: Path, *, private: bool = False, acknowledge_sensitive: bool = False) -> dict:
    """Default allowlist export: hashes and constrained metadata, NEVER raw inputs."""
    if private:
        if not acknowledge_sensitive:
            raise ValueError('Private export requires acknowledge_sensitive=True')
        return export_private(job, target)
    from kernel import checked_root, local_file
    from team_runtime import digest
    job = checked_root(job); target = target.absolute()
    if target.resolve().is_relative_to(job) or target.exists() or target.is_symlink():
        raise ValueError('Use a new export directory outside the job')
    with TeamStore(job) as store:
        state = store.status()
        tasks = [{'task_key_sha256':digest(row['id']), 'status':row['status'],
                  'attempt':row['attempt'], 'mode':row['mode']}
                 for row in store.db.execute('SELECT * FROM tasks ORDER BY id')]
        artifacts = []
        for row in store.db.execute('SELECT * FROM artifacts ORDER BY id'):
            info = local_file(job, row['storage'])
            artifacts.append({'artifact_key_sha256':digest(row['id']), 'sha256':info['sha256'],
                              'bytes':info['bytes'], 'hash_matches_ledger':info['sha256']==row['sha256']})
        summary = {'schema_version':1, 'classification':'release_provenance',
                   'goal_digest':store.meta('goal_digest'),'plan_digest':store.meta('plan_digest'),
                   'completed':state['completed'], 'tasks':tasks, 'artifacts':artifacts,
                   'omitted':['input text','prompts','model replies','lease tokens','paths','host IDs','raw tool observations'],
                   'identity_attestation':False, 'claim_scope':'local ledger metadata and artifact hashes only'}
    target.mkdir(parents=True)
    write_json(target/'summary.json',summary)
    data=(target/'summary.json').read_bytes()
    write_json(target/'MANIFEST.json',{'schema_version':1,'files':[{'path':'summary.json','bytes':len(data),
               'sha256':hashlib.sha256(data).hexdigest()}]})
    return {'exported':str(target),'files':1,'profile':'release'}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--job", type=Path, required=True)
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--private", action="store_true")
    parser.add_argument("--ack-sensitive", action="store_true")
    args = parser.parse_args(argv)
    print(json.dumps(export(args.job, args.target, private=args.private, acknowledge_sensitive=args.ack_sensitive), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
