"""Shared native observation, artifact collection and independent-review handoff.
No host is launched here. Raw coordinator observations are not identity signatures.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from kernel import local_file
from team_runtime import TeamStore, require, write_json
from v3_protocol import pending_checks

class ObservedNativeAdapter:
    HOST = None
    def __init__(self, job: Path):
        self.job = Path(job)

    def _validate_event(self, store, event, *, finished=False):
        required = {'schema_version','host','event','host_run_id','task_id','lease_token','native_tool',
                    'raw_evidence_path','raw_evidence_sha256','observed_by'}
        require(isinstance(event, dict) and set(event) == required, 'HOST_EVENT', 'Unexpected host event fields')
        require(type(event['schema_version']) is int and event['schema_version'] == 1 and event['host'] == self.HOST
                and event['observed_by'] == 'coordinator', 'HOST_EVENT', 'Coordinator-owned native observation required')
        require(event['event'] in (('finished',) if finished else ('started','finished')), 'HOST_EVENT', 'No partial/interrupted run can finish')
        require(isinstance(event['host_run_id'], str) and event['host_run_id'].strip()
                and isinstance(event['native_tool'], str) and event['native_tool'].strip(), 'HOST_EVENT', 'Actual tool and run identifier required')
        row = store.bound(event['task_id'], event['lease_token'], states={'leased'})
        packet = json.loads(row['packet']); workspace = Path(packet['workspace'])
        require(packet['contract'].get('executor',{}).get('type') == self.HOST, 'HOST_MISMATCH', 'Not a native contract')
        require(isinstance(event['raw_evidence_path'], str) and event['raw_evidence_path'].startswith('evidence/'), 'HOST_EVENT', 'Raw observation must be in attempt evidence')
        info = local_file(workspace, event['raw_evidence_path'])
        require(info['sha256'] == event['raw_evidence_sha256'], 'HOST_EVENT', 'Raw observation hash changed')
        raw = (workspace / event['raw_evidence_path']).read_text(encoding='utf-8')
        require(event['host_run_id'] in raw, 'HOST_EVENT', 'Host ID absent from raw tool observation')
        from dual16 import enabled as dual16_enabled
        if (finished or event['event']=='finished') and dual16_enabled(store.meta('plan')):
            require(all(value in raw for value in (row['token'],row['id'],packet['goal_digest'],packet['plan_digest'])),
                    'D16_ATTEMPT_OBSERVATION','A reused session needs a fresh terminal response echoing this task/lease/goal/plan; a previous done snapshot is insufficient')
        # Do not pretend to authenticate provider internals by parsing arbitrary API text.
        return row, packet

    def bind_observed(self, event: dict) -> dict:
        with TeamStore(self.job) as store:
            row, packet = self._validate_event(store, event)
            answer = store.bind(row['id'], row['token'], 'native', event['host_run_id'])
            write_json(Path(packet['workspace'])/'evidence/native-start-observation.json', event)
            return answer

    def collect_observed(self, event: dict, concerns: list[str] | None = None, *, diagnostics: dict | None = None) -> dict:
        from diagnostics import validate_diagnostics
        diagnostics = validate_diagnostics({} if diagnostics is None else diagnostics)
        with TeamStore(self.job) as store:
            row, packet = self._validate_event(store, event, finished=True)
            require(row['mode'] == 'native' and row['host_run_id'] == event['host_run_id'], 'HOST_UNBOUND', 'Must bind the exact observed native run first')
            workspace, output_root = Path(packet['workspace']), Path(packet['output_root'])
            artifacts = []
            expected = {x['path'] for x in packet['contract']['outputs']}
            actual = {p.relative_to(output_root).as_posix() for p in output_root.rglob('*') if p.is_file() or p.is_symlink()}
            require(actual == expected, 'OUTPUT_SCOPE', 'Exactly the assigned files must be returned')
            for a in packet['contract']['outputs']:
                info = local_file(output_root, a['path']); artifacts.append({**a,'sha256':info['sha256']})
            for src in packet['input_snapshots']:
                info = local_file(workspace, Path(src['path']).relative_to(workspace).as_posix())
                require(info['sha256'] == src['sha256'], 'INPUT_MUTATED', src['id'])
            proof = {'schema_version':1, 'kind':'artifact_integrity', 'task_id':row['id'],
                     'all_findings_passed':True, 'artifacts':artifacts,
                     'findings':[{'id':'assigned_files_and_input_hashes', 'ok':True}],
                     'not_verified':['Requirement correctness', 'Host identity attestation', 'Host sandbox enforcement']}
            evidence = workspace/'evidence/native-technical.json'; write_json(evidence, proof)
            technical = {'execution':'EXECUTED','outcome':'PASS','evidence_kind':'RUNTIME_FACT',
                         'evidence_path':'evidence/native-technical.json','evidence_sha256':hashlib.sha256(evidence.read_bytes()).hexdigest()}
            receipt = {'host_run_id':row['host_run_id'], 'mode':'native', 'finished':True,
                       'task_id':row['id'],'lease_token':row['token'], 'observation':event,
                       'note':'Coordinator observed a host event. Not cryptographic provider attestation.'}
            path = workspace/'evidence/host-receipt.json'; write_json(path,receipt)
            result = {'schema_version':3,'result_id':row['id']+'-native-'+row['token'][:16],
                      'task_id':row['id'],'lease_token':row['token'],'plan_digest':packet['plan_digest'],
                      'goal_digest':packet['goal_digest'],'host_run_id':row['host_run_id'],
                      'artifacts':artifacts, 'technical_validation':technical,
                      'checks':pending_checks(packet, artifacts, technical['evidence_path'],technical['evidence_sha256']),
                      'concerns':concerns or [],'external_actions':[],
                      'host_receipt':{'path':'evidence/host-receipt.json','sha256':hashlib.sha256(path.read_bytes()).hexdigest()}}
            result.update(diagnostics)
            write_json(workspace/'controller-result.json',result)
            answer = store.submit(result)
            return {'task_id':row['id'], **answer, 'acceptance':'UNVERIFIED until independent review'}
