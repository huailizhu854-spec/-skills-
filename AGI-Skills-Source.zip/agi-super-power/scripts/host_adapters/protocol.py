"""Host-neutral observations. No spawn implementation is hidden in this API."""
from typing import Protocol

class ObservedHostAdapter(Protocol):
    def prepare(self, task_id: str, worker: str) -> dict: ...
    def bind_observed(self, event: dict) -> dict: ...
    def collect_observed(self, event: dict, concerns: list[str] | None = None, *, diagnostics: dict | None = None) -> dict: ...

# The host/main agent calls its actual delegate/wait/cancel tools between these
# steps. It must inspect those tools' current schemas, not invent Python methods.
# Codex and Claude native adapters consume observations; neither silently aliases command mode.
