"""Frozen WorkBuddy Mobile Cloud host contract constants (evidence-bound).

Sources: WB-01 / WB-01B / WB-02 live reports (2026-09-23, WorkBuddy cloud sandbox).
Shared by the adapter and the workbuddy_bridge normalizer so both fail on any
contract drift instead of silently drifting apart.
"""
from __future__ import annotations
import re

HOST_ID = 'workbuddy_mobile_cloud'
EXECUTION_MODE = 'synchronous_terminal'
AGENT_ID_FOOTER = re.compile(r'\[Agent ID:\s*([A-Za-z0-9._-]+)\]')

# Only what WB-01/WB-01B/WB-02 actually observed. Anything else stays unknown.
QUERY_SUPPORTED = False          # TaskOutput: "No task found with ID: agent-..." (2 runs)
CANCEL_SUPPORTED = 'unknown'     # never tested; no task_id handle exists to try
LIVE_RESUME_SUPPORTED = 'unknown'  # never tested
BACKGROUND_REGISTRY = False      # run_in_background=true blocked to terminal in both runs


def parse_agent_ids(raw_text: str) -> list[str]:
    """Find ID-shaped candidates, not authenticated host identities.

    Parsing never fabricates: zero or multiple footers stay zero or multiple and
    the caller must reject the observation instead of inventing an identifier.
    """
    return AGENT_ID_FOOTER.findall(raw_text or '')


def validate_sync_terminal_observation(raw_text: str, host_run_id: str) -> str:
    """A WorkBuddy Mobile Cloud create return is bindable only when exactly one
    host-attached Agent ID footer exists and equals the observed run identifier."""
    from team_runtime import require
    ids = parse_agent_ids(raw_text)
    require(len(ids) == 1, 'WB_AGENT_ID',
            'Exactly one host-attached "[Agent ID: ...]" footer is required; got %d. '
            'Refusing to guess or fabricate an identifier.' % len(ids))
    require(ids[0] == host_run_id, 'WB_AGENT_ID',
            'Observation host_run_id does not equal the Agent ID in the raw return')
    lines = raw_text.rstrip().splitlines()
    require(bool(lines) and AGENT_ID_FOOTER.fullmatch(lines[-1].strip()) is not None,
            'WB_AGENT_ID', 'Agent ID must be a standalone final footer, not body text')
    require(bool('\n'.join(lines[:-1]).strip()), 'WB_OBSERVATION',
            'Raw return must contain the child terminal message before the footer')
    return ids[0]
