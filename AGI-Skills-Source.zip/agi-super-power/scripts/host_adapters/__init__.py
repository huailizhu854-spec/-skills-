"""Host boundaries, not an agent executor. Real execution belongs to the host."""
