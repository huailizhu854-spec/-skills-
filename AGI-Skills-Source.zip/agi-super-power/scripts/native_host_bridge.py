#!/usr/bin/env python3
"""Prepare/bind/collect Codex or Claude Code native work; NEVER spawn a custom executor."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from kernel import load_json
from team_runtime import TeamError
from host_adapters.claude_code import ClaudeCodeAdapter
from host_adapters.codex import CodexAdapter
from host_adapters.workbuddy_mobile_cloud import WorkBuddyMobileCloudAdapter
from team_runtime import TeamStore, require


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['prepare','bind','collect'])
    p.add_argument('--job',type=Path,required=True)
    p.add_argument('--host',choices=['auto','codex_native','claude_code_native','workbuddy_mobile_cloud'],default='auto')
    p.add_argument('--task');p.add_argument('--worker');p.add_argument('--event',type=Path)
    p.add_argument('--concerns',type=Path)
    p.add_argument('--diagnostics',type=Path,help='Optional v3 blockers/warnings/environment_notes JSON')
    a=p.parse_args(argv)
    try:
        task_id=a.task if a.action=='prepare' else (load_json(a.event).get('task_id') if a.event else None)
        if not task_id: p.error('prepare needs --task; bind/collect needs --event with task_id')
        with TeamStore(a.job) as store:
            contract=__import__('json').loads(store.row(task_id)['contract'])
            host=contract.get('executor',{}).get('type')
        require(host in {'codex_native','claude_code_native','workbuddy_mobile_cloud'}, 'HOST_MISMATCH', 'Frozen contract must use a supported native host')
        require(a.host=='auto' or a.host==host,'HOST_MISMATCH','--host cannot change the frozen executor')
        adapter=({'codex_native':CodexAdapter,'claude_code_native':ClaudeCodeAdapter,
                  'workbuddy_mobile_cloud':WorkBuddyMobileCloudAdapter}[host])(a.job)
        if a.action=='prepare':
            if not a.task or not a.worker: p.error('prepare needs --task and --worker')
            result=adapter.prepare(a.task,a.worker)
        else:
            if not a.event: p.error('bind/collect needs a real --event observation file')
            event=load_json(a.event)
            result=(adapter.bind_observed(event) if a.action=='bind' else
                    adapter.collect_observed(event,load_json(a.concerns) if a.concerns else None, diagnostics=load_json(a.diagnostics) if a.diagnostics else None))
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    except (ValueError,OSError,KeyError,TypeError) as exc:
        print(json.dumps({'error':getattr(exc,'code','HOST_INPUT'),'message':str(exc)}));return 1
if __name__=='__main__':
    raise SystemExit(main())
