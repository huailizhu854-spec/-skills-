#!/usr/bin/env python3
"""AGI-Super-Power contract checks. Standard library only; Python 3.10+.

This module reads JSON and local evidence. It never starts an agent, runs declared
commands, performs network requests, or proves that an evidence narrative is true.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import unicodedata
from typing import Any


KINDS = {"SOURCE_FACT", "RUNTIME_FACT", "INFERENCE", "UNKNOWN"}
EXECUTIONS = {"EXECUTED", "NOT_EXECUTED", "SKIPPED", "NOT_APPLICABLE"}
OUTCOMES = {"PASS", "FAILED", "BLOCKED", "UNVERIFIED", "ACCEPTED_RISK"}
STATUSES = {"planned", "running", "reviewing", "rework", "blocked", "completed"}
NAME = re.compile(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*\Z")
SHA256 = re.compile(r"[0-9a-f]{64}\Z")
UTC_TIME = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|\+00:00)\Z")
RESERVED = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}
MAX_JSON_BYTES = 8 * 1024 * 1024


class ContractError(ValueError):
    """An expected input error that is safe to return as structured output."""


class Report:
    def __init__(self, command: str):
        self.command = command
        self.errors: list[dict[str, str]] = []
        self.details: dict[str, Any] = {}

    def error(self, code: str, location: str, message: str) -> None:
        self.errors.append({"code": code, "location": location, "message": message})

    def result(self) -> dict[str, Any]:
        return {
            "schema_version": 1,
            "command": self.command,
            "valid": not self.errors,
            "outcome": "FAILED" if self.errors else "PASS",
            "validation_scope": "structure_and_local_file_binding",
            "errors": self.errors,
            "limitations": [
                "A contract does not prove agent startup, evidence truth, or tool permission enforcement.",
                "DAG waves require a barrier between waves; this checker does not schedule or execute tasks.",
                "File checks assume the workspace is not being adversarially mutated during validation.",
            ],
            **self.details,
        }


def nonempty(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def member(value: Any, choices: set[str]) -> bool:
    return isinstance(value, str) and value in choices


def sha(value: Any) -> bool:
    return isinstance(value, str) and SHA256.fullmatch(value) is not None


def slug(value: Any) -> bool:
    return isinstance(value, str) and 0 < len(value) < 64 and NAME.fullmatch(value) is not None


def utc_timestamp(value: Any) -> bool:
    if not isinstance(value, str) or not UTC_TIME.fullmatch(value):
        return False
    try:
        stamp = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
        return stamp.utcoffset() == dt.timedelta(0)
    except ValueError:
        return False


def object_fields(value: Any, required: set[str], report: Report, location: str) -> bool:
    if not isinstance(value, dict):
        report.error("OBJECT_REQUIRED", location, "Expected a JSON object.")
        return False
    for field in sorted(required - value.keys()):
        report.error("MISSING_FIELD", f"{location}.{field}", "Required field is missing.")
    return True


def text_field(value: Any, report: Report, location: str) -> None:
    if not nonempty(value):
        report.error("TEXT_REQUIRED", location, "Expected a non-empty string.")


def string_list(value: Any, report: Report, location: str, *, allow_empty: bool = True) -> bool:
    if not isinstance(value, list) or (not value and not allow_empty):
        report.error("STRING_LIST_REQUIRED", location, "Expected a string array" + ("." if allow_empty else " with at least one item."))
        return False
    valid = True
    seen: set[str] = set()
    for index, item in enumerate(value):
        if not nonempty(item):
            report.error("TEXT_REQUIRED", f"{location}[{index}]", "Expected a non-empty string.")
            valid = False
        elif item in seen:
            report.error("DUPLICATE_VALUE", f"{location}[{index}]", "Duplicate array item.")
            valid = False
        else:
            seen.add(item)
    return valid


def list_field(value: Any, report: Report, location: str) -> list[Any]:
    if not isinstance(value, list):
        report.error("LIST_REQUIRED", location, "Expected an array.")
        return []
    return value


def unique_id(value: Any, seen: set[str], report: Report, location: str) -> bool:
    if not nonempty(value):
        report.error("TEXT_REQUIRED", location, "Expected a non-empty identifier.")
        return False
    if value in seen:
        report.error("DUPLICATE_ID", location, "Identifier is duplicated.")
        return False
    seen.add(value)
    return True


def relative_path(value: Any, *, directory: bool = False) -> str:
    """Validate a portable, unambiguous relative path without touching disk."""
    if not nonempty(value):
        raise ContractError("A non-empty relative path is required.")
    if value != value.strip() or value.startswith("/") or "\\" in value:
        raise ContractError("Absolute, whitespace-padded, and backslash paths are forbidden.")
    candidate = value[:-1] if directory and value.endswith("/") else value
    if not candidate:
        raise ContractError("The workspace root cannot be declared as a write path.")
    for part in candidate.split("/"):
        normalized = unicodedata.normalize("NFKC", part)
        if not normalized or normalized in {".", ".."} or normalized.endswith((".", " ")):
            raise ContractError("Empty, dot, parent, and trailing-dot/space path components are forbidden.")
        if any(unicodedata.category(char).startswith("C") or char in '<>:"|?*\\/' for char in normalized):
            raise ContractError("Control characters and non-portable path characters are forbidden.")
        if normalized.split(".", 1)[0].casefold() in RESERVED:
            raise ContractError("Windows device paths are forbidden.")
    return candidate


def path_key(path: str) -> str:
    return unicodedata.normalize("NFKC", path).casefold()


def linked(st: os.stat_result) -> bool:
    return stat.S_ISLNK(st.st_mode) or bool(getattr(st, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))


def checked_root(raw: Any) -> Path:
    try:
        root = Path(raw).absolute()
        # Do not resolve away a link before checking its physical components.
        for component in reversed((root, *root.parents)):
            info = component.lstat()
            if linked(info):
                raise ContractError("Evidence root must not contain symlinks or reparse points.")
        if not root.is_dir():
            raise ContractError("Evidence root must be an existing directory.")
        return root.resolve(strict=True)
    except (OSError, TypeError, ValueError, RuntimeError) as exc:
        if isinstance(exc, ContractError):
            raise
        raise ContractError("Evidence root is missing, inaccessible, or invalid.") from exc


def local_file(root: Path, raw: Any) -> dict[str, Any]:
    relative = relative_path(raw)
    root = checked_root(root)  # Normalize BOTH operands; never resolve away links.
    current = root
    for part in relative.split("/"):
        current = current / part
        info = current.lstat()
        if linked(info):
            raise ContractError("Evidence and artifact paths must not contain links or reparse points.")
    try:
        current.resolve(strict=True).relative_to(root)
    except ValueError as exc:
        raise ContractError("Path resolves outside the supplied root.") from exc
    before = current.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size == 0:
        raise ContractError("Expected a non-empty regular file.")
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(current, flags)
    with os.fdopen(descriptor, "rb") as handle:
        opened = os.fstat(handle.fileno())
        if linked(opened) or not stat.S_ISREG(opened.st_mode) or (before.st_dev, before.st_ino) != (opened.st_dev, opened.st_ino):
            raise ContractError("File identity changed during validation.")
        digest = hashlib.sha256()
        byte_count = 0
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            byte_count += len(chunk)
            digest.update(chunk)
        after = os.fstat(handle.fileno())
        if (opened.st_size, opened.st_mtime_ns) != (after.st_size, after.st_mtime_ns) or byte_count != after.st_size:
            raise ContractError("File changed while hashing.")
    if byte_count == 0:
        raise ContractError("Expected a non-empty regular file.")
    return {"path": relative, "sha256": digest.hexdigest(), "bytes": byte_count}


def contained_file(root: Path, absolute: Path) -> tuple[Path, dict[str, Any]]:
    """Validate original physical components before canonical containment.

    Handles Windows 8.3 aliases without weakening reparse/link checks. Like
    local_file, assumes the host prevents adversarial concurrent path mutation.
    """
    canonical_root = checked_root(root)
    original = Path(absolute).absolute()
    for component in reversed((original, *original.parents)):
        if linked(component.lstat()):
            raise ContractError("File path must not contain links or reparse points.")
    resolved = original.resolve(strict=True)
    try:
        relative = resolved.relative_to(canonical_root).as_posix()
    except ValueError as exc:
        raise ContractError("Path resolves outside the supplied root.") from exc
    info = local_file(canonical_root, relative)
    return resolved, info


def file_check(root: Path | None, raw: Any, report: Report, location: str) -> dict[str, Any] | None:
    try:
        relative_path(raw)
        if root is None:
            return None
        return local_file(root, raw)
    except (OSError, ContractError, RuntimeError, ValueError) as exc:
        report.error("FILE_BINDING_INVALID", location, str(exc) if isinstance(exc, ContractError) else "File is missing, inaccessible, or not a safe regular file.")
        return None


def validate_role(role: Any) -> dict[str, Any]:
    report = Report("validate-role")
    required = {"schema_version", "name", "title", "mission", "trigger", "inputs", "outputs", "steps", "acceptance", "tools", "boundaries", "sources"}
    if not object_fields(role, required, report, "role"):
        return report.result()
    if type(role.get("schema_version")) is not int or role["schema_version"] != 1:
        report.error("SCHEMA_VERSION", "role.schema_version", "Expected integer 1.")
    if not slug(role.get("name")):
        report.error("ROLE_NAME", "role.name", "Use a lowercase letter followed by lowercase letters/digits and single hyphens; length must be 1–63.")
    for field in ("title", "mission", "trigger"):
        text_field(role.get(field), report, f"role.{field}")
    for field in ("inputs", "outputs", "steps", "tools", "boundaries", "sources"):
        string_list(role.get(field), report, f"role.{field}", allow_empty=field in {"inputs", "tools", "sources"})
    checks = list_field(role.get("acceptance"), report, "role.acceptance")
    if not checks:
        report.error("ACCEPTANCE_EMPTY", "role.acceptance", "At least one acceptance criterion is required.")
    seen: set[str] = set()
    for index, check in enumerate(checks):
        where = f"role.acceptance[{index}]"
        if not object_fields(check, {"id", "requirement", "method", "evidence_kind"}, report, where):
            continue
        unique_id(check.get("id"), seen, report, where + ".id")
        for field in ("requirement", "method"):
            text_field(check.get(field), report, where + "." + field)
        if not member(check.get("evidence_kind"), KINDS):
            report.error("EVIDENCE_KIND", where + ".evidence_kind", "Unsupported evidence kind.")
    return report.result()


def validate_run(run: Any, root: Any) -> dict[str, Any]:
    report = Report("validate-run")
    required = {"schema_version", "task_id", "role", "objective", "mode", "status", "agent_id", "requirements", "artifacts", "gates", "blockers", "external_actions", "next_action"}
    if not object_fields(run, required, report, "run"):
        return report.result()
    if type(run.get("schema_version")) is not int or run["schema_version"] != 1:
        report.error("SCHEMA_VERSION", "run.schema_version", "Expected integer 1.")
    for field in ("task_id", "objective"):
        text_field(run.get(field), report, f"run.{field}")
    if not slug(run.get("role")):
        report.error("ROLE_NAME", "run.role", "Role must use the role-name convention.")
    if not member(run.get("mode"), {"inline", "delegated"}):
        report.error("MODE", "run.mode", "Expected inline or delegated.")
    if not member(run.get("status"), STATUSES):
        report.error("STATUS", "run.status", "Unsupported run status.")
    if run.get("agent_id") is not None and not nonempty(run.get("agent_id")):
        report.error("AGENT_ID", "run.agent_id", "Use null or a non-empty agent identifier.")
    if run.get("mode") == "delegated" and not nonempty(run.get("agent_id")):
        report.error("DELEGATION_UNBOUND", "run.agent_id", "Delegated mode requires an agent identifier; this field is not startup proof.")
    for field in ("blockers", "external_actions"):
        for index, entry in enumerate(list_field(run.get(field), report, f"run.{field}")):
            if not nonempty(entry) and not isinstance(entry, dict):
                report.error("RECORD_REQUIRED", f"run.{field}[{index}]", "Expected a non-empty string or an object.")
    if run.get("next_action") is not None and not isinstance(run.get("next_action"), str):
        report.error("NEXT_ACTION", "run.next_action", "Expected a string or null.")
    try:
        workspace = checked_root(root)
    except ContractError as exc:
        report.error("ROOT_INVALID", "root", str(exc))
        workspace = None

    requirement_ids: set[str] = set()
    required_ids: set[str] = set()
    requirements = list_field(run.get("requirements"), report, "run.requirements")
    if not requirements:
        report.error("REQUIREMENTS_EMPTY", "run.requirements", "At least one requirement is required.")
    for index, requirement in enumerate(requirements):
        where = f"run.requirements[{index}]"
        if not object_fields(requirement, {"id", "required"}, report, where):
            continue
        valid_id = unique_id(requirement.get("id"), requirement_ids, report, where + ".id")
        if type(requirement.get("required")) is not bool:
            report.error("BOOLEAN_REQUIRED", where + ".required", "Expected a JSON boolean.")
        elif requirement["required"] and valid_id:
            required_ids.add(requirement["id"])

    artifacts = list_field(run.get("artifacts"), report, "run.artifacts")
    checked_artifacts: list[dict[str, Any]] = []
    seen_paths: set[str] = set()
    for index, artifact in enumerate(artifacts):
        where = f"run.artifacts[{index}]"
        if not object_fields(artifact, {"path", "sha256"}, report, where):
            continue
        if not sha(artifact.get("sha256")):
            report.error("SHA256", where + ".sha256", "Expected a lowercase SHA-256 hex digest.")
        actual = file_check(workspace, artifact.get("path"), report, where + ".path")
        if actual is None:
            continue
        canonical = path_key(actual["path"])
        if canonical in seen_paths:
            report.error("PATH_COLLISION", where + ".path", "Artifact paths collide after Unicode normalization and case folding.")
        seen_paths.add(canonical)
        if actual["sha256"] != artifact.get("sha256"):
            report.error("ARTIFACT_HASH_MISMATCH", where + ".sha256", "Artifact content no longer matches the declared hash.")
        else:
            checked_artifacts.append(actual)
    current_hashes = {artifact["sha256"] for artifact in checked_artifacts}

    gates = list_field(run.get("gates"), report, "run.gates")
    gate_ids: set[str] = set()
    covered: set[str] = set()
    checked_evidence: list[dict[str, Any]] = []
    gate_fields = {"id", "requirement_id", "required", "execution", "outcome", "evidence_kind", "subject_sha256", "evidence_path", "method", "executed_at"}
    for index, gate in enumerate(gates):
        where = f"run.gates[{index}]"
        start_errors = len(report.errors)
        if not object_fields(gate, gate_fields, report, where):
            continue
        unique_id(gate.get("id"), gate_ids, report, where + ".id")
        if not nonempty(gate.get("requirement_id")) or gate["requirement_id"] not in requirement_ids:
            report.error("UNKNOWN_REQUIREMENT", where + ".requirement_id", "Gate must refer to an existing requirement.")
        if type(gate.get("required")) is not bool:
            report.error("BOOLEAN_REQUIRED", where + ".required", "Expected a JSON boolean.")
        if not member(gate.get("execution"), EXECUTIONS):
            report.error("EXECUTION", where + ".execution", "Unsupported execution state.")
        if not member(gate.get("outcome"), OUTCOMES):
            report.error("OUTCOME", where + ".outcome", "Unsupported gate outcome.")
        if not member(gate.get("evidence_kind"), KINDS):
            report.error("EVIDENCE_KIND", where + ".evidence_kind", "Unsupported evidence kind.")
        for field in ("subject_sha256", "evidence_path", "method", "executed_at"):
            if gate.get(field) is not None and not nonempty(gate.get(field)):
                report.error("OPTIONAL_TEXT", where + "." + field, "Expected null or a non-empty string.")
        if gate.get("subject_sha256") is not None and not sha(gate["subject_sha256"]):
            report.error("SHA256", where + ".subject_sha256", "Expected a lowercase SHA-256 hex digest.")
        if gate.get("executed_at") is not None and not utc_timestamp(gate["executed_at"]):
            report.error("UTC_TIMESTAMP", where + ".executed_at", "Expected an ISO timestamp with seconds and Z or +00:00.")
        evidence = None
        if gate.get("evidence_path") is not None:
            evidence = file_check(workspace, gate["evidence_path"], report, where + ".evidence_path")
            if evidence:
                checked_evidence.append({"gate_id": gate.get("id"), **evidence})
        if gate.get("outcome") == "PASS":
            if gate.get("execution") != "EXECUTED":
                report.error("PASS_NOT_EXECUTED", where, "PASS requires EXECUTED.")
            if not member(gate.get("evidence_kind"), {"SOURCE_FACT", "RUNTIME_FACT"}):
                report.error("PASS_WITHOUT_FACT", where, "Inference or unknown evidence cannot support PASS.")
            if evidence is None:
                report.error("PASS_WITHOUT_EVIDENCE", where + ".evidence_path", "PASS requires a current non-empty local evidence file.")
            if not nonempty(gate.get("method")):
                report.error("PASS_WITHOUT_METHOD", where + ".method", "PASS requires a named method.")
            if not utc_timestamp(gate.get("executed_at")):
                report.error("PASS_WITHOUT_TIME", where + ".executed_at", "PASS requires a valid UTC execution timestamp.")
            if not sha(gate.get("subject_sha256")) or gate["subject_sha256"] not in current_hashes:
                report.error("STALE_SUBJECT", where + ".subject_sha256", "PASS must bind to a declared artifact whose content hash was recomputed successfully.")
            if len(report.errors) == start_errors and gate.get("required") is True:
                covered.add(gate["requirement_id"])
        if run.get("status") == "completed" and gate.get("required") is True and gate.get("outcome") != "PASS":
            report.error("REQUIRED_GATE_NOT_PASS", where, "A completed run cannot contain a required gate without PASS.")

    if run.get("status") == "completed":
        if not checked_artifacts:
            report.error("COMPLETED_WITHOUT_ARTIFACT", "run.artifacts", "A completed run requires at least one valid current artifact.")
        for missing in sorted(required_ids - covered):
            report.error("REQUIREMENT_UNCOVERED", "run.requirements", "Required requirement has no valid required PASS gate: " + missing)
        if run.get("blockers"):
            report.error("COMPLETED_WITH_BLOCKERS", "run.blockers", "Resolve or remove recorded blockers before completion.")
    report.details = {"checked_artifacts": checked_artifacts, "checked_evidence": checked_evidence, "covered_required_requirements": sorted(covered)}
    return report.result()


def check_dag(plan: Any) -> dict[str, Any]:
    report = Report("check-dag")
    if not object_fields(plan, {"tasks"}, report, "plan"):
        return report.result()
    tasks = list_field(plan.get("tasks"), report, "plan.tasks")
    if not tasks:
        report.error("TASKS_EMPTY", "plan.tasks", "At least one task is required.")
    ids: set[str] = set()
    parsed: dict[str, dict[str, Any]] = {}
    for index, task in enumerate(tasks):
        where = f"plan.tasks[{index}]"
        if not object_fields(task, {"id", "depends_on", "writes"}, report, where):
            continue
        valid_id = unique_id(task.get("id"), ids, report, where + ".id")
        dependencies_valid = string_list(task.get("depends_on"), report, where + ".depends_on")
        writes_valid = string_list(task.get("writes"), report, where + ".writes")
        writes: list[str] = []
        if writes_valid:
            for write_index, raw in enumerate(task["writes"]):
                try:
                    normalized = relative_path(raw, directory=True)
                    if path_key(normalized) in {path_key(path) for path in writes}:
                        report.error("PATH_COLLISION", where + ".writes", "Write paths collide after normalization and case folding.")
                    writes.append(normalized)
                except ContractError as exc:
                    report.error("WRITE_PATH_INVALID", f"{where}.writes[{write_index}]", str(exc))
        if valid_id and dependencies_valid:
            parsed[task["id"]] = {"depends_on": set(task["depends_on"]), "writes": writes}
    for task_id, task in parsed.items():
        for missing in sorted(task["depends_on"] - parsed.keys()):
            report.error("DEPENDENCY_MISSING", "plan.tasks." + task_id, "Unknown dependency: " + missing)
    if report.errors:
        return report.result()
    pending = set(parsed)
    done: set[str] = set()
    waves: list[list[str]] = []
    while pending:
        ready = sorted(task_id for task_id in pending if parsed[task_id]["depends_on"] <= done)
        if not ready:
            report.error("DEPENDENCY_CYCLE", "plan.tasks", "Dependency cycle detected among: " + ", ".join(sorted(pending)))
            break
        waves.append(ready)
        for left_index, left in enumerate(ready):
            for right in ready[left_index + 1:]:
                for left_path in parsed[left]["writes"]:
                    for right_path in parsed[right]["writes"]:
                        a, b = path_key(left_path), path_key(right_path)
                        if a == b or a.startswith(b + "/") or b.startswith(a + "/"):
                            report.error("WRITE_CONFLICT", f"plan.wave[{len(waves) - 1}]", f"{left} and {right} have overlapping write ownership: {left_path} / {right_path}")
        pending.difference_update(ready)
        done.update(ready)
    report.details = {"waves": waves, "scheduling_contract": "barriered_waves", "tasks_executed": 0}
    return report.result()


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ContractError("Duplicate JSON object keys are forbidden.")
        result[key] = value
    return result


def _reject_constant(_: str) -> Any:
    raise ContractError("Non-finite JSON numeric constants are forbidden.")


def load_json(path: str | Path) -> Any:
    with Path(path).open("rb") as handle:
        raw = handle.read(MAX_JSON_BYTES + 1)
    if len(raw) > MAX_JSON_BYTES:
        raise ContractError("JSON document exceeds the 8 MiB input limit.")
    return json.loads(raw.decode("utf-8-sig"), object_pairs_hook=_unique_object, parse_constant=_reject_constant)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("validate-role", "validate-run", "check-dag"):
        command = commands.add_parser(name)
        command.add_argument("file", help="JSON contract path")
        if name == "validate-run":
            command.add_argument("--root", required=True, help="Existing directory containing declared artifacts and evidence")
    args = parser.parse_args(argv)
    try:
        data = load_json(args.file)
        if args.command == "validate-role":
            result = validate_role(data)
        elif args.command == "validate-run":
            result = validate_run(data, args.root)
        else:
            result = check_dag(data)
    except (OSError, UnicodeError, ValueError, TypeError, RecursionError, RuntimeError):
        report = Report(args.command)
        report.error("INPUT_INVALID", "input", "Input JSON could not be read or validated; check encoding, duplicate keys, shape, nesting, and file access.")
        result = report.result()
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    sys.exit(main())
