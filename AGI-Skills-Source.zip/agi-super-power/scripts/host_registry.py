"""Reviewed local host catalog; a catalog entry is never a live capability probe."""
from __future__ import annotations
from pathlib import Path
from intelligence_common import read_json, ensure, names

CATALOG = Path(__file__).resolve().parents[1] / 'assets/hosts/catalog.json'
# Adding JSON must NEVER turn a candidate into a supported executable adapter.
# workbuddy_mobile_cloud: adapter implementation based on host-only WB-01/WB-01B/WB-02
# observations; installed-Skill integration remains NOT_EXECUTED.
# (synchronous_terminal create with host-attached Agent ID; see
# references/workbuddy-mobile-cloud-adapter-v0.md). Desktop stays handoff-only.
IMPLEMENTED = {'codex_native': 'native', 'claude_code_native': 'native',
               'bounded_model': 'command', 'fixture': 'fixture',
               'workbuddy_mobile_cloud': 'native'}
ALIASES = {'workbuddy': 'workbuddy_candidate', 'codex': 'codex_native',
           'claude-code': 'claude_code_native'}

def catalog() -> dict:
    raw = read_json(CATALOG)
    ensure(raw.get('schema_version') == 1, 'HOST_REGISTRY', 'Unsupported catalog schema')
    return raw['hosts']

def host_info(host: str) -> dict:
    host = ALIASES.get(host, host)
    entries = catalog()
    ensure(host in entries, 'HOST_UNKNOWN', 'No reviewed host entry: ' + host)
    return {'id': host, **entries[host], 'implemented': host in IMPLEMENTED,
            'execution_mode': IMPLEMENTED.get(host), 'live_probe_performed': False}

def execution_mode(host: str) -> str:
    ensure(host in IMPLEMENTED, 'HOST_UNIMPLEMENTED', 'Host has no executable adapter in this release')
    return IMPLEMENTED[host]

def preflight(host: str, required_tools: list[str], available_tools: list[str]) -> dict:
    names(required_tools, 'required_tools'); names(available_tools, 'available_tools')
    info = host_info(host)
    missing = sorted(set(required_tools) - set(available_tools))
    return {'host': info['id'], 'adapter_implemented': info['implemented'],
            'missing_tools': missing,
            'status': 'TOOLS_MISSING' if missing else ('READY_FOR_HOST_PROBE' if info['implemented'] else 'HANDOFF_ONLY'),
            'available_tools_source': 'coordinator_declaration_not_attestation',
            'execution': 'NOT_EXECUTED', 'live_probe_performed': False}
