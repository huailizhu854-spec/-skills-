"""Local prerequisite/path probes. Never installs software or contacts a model."""
from __future__ import annotations
import os
import platform
import sys
import tempfile
from pathlib import Path
from kernel import ContractError, local_file, contained_file
from filesystem_capabilities import probe_symlink_support, probe_long_path_support

def doctor():
    report={'python':platform.python_version(),'python_supported':sys.version_info>=(3,10),
            'os':platform.system(),'os_release':platform.release(),'host_product':'NOT_PROBED',
            'workbuddy_version':None,'real_agent_calls':0,'dependencies':'Python standard library only'}
    with tempfile.TemporaryDirectory(prefix='agi34-path-') as tmp:
        root=Path(tmp);folder=root/'中文 空格';folder.mkdir();(folder/'合法.txt').write_text('fixture',encoding='utf-8')
        report['unicode_space_path']=bool(local_file(root,'中文 空格/合法.txt'))
        capabilities = {
            'file_symlink': probe_symlink_support(root),
            'directory_symlink': probe_symlink_support(root, target_is_directory=True),
            'long_path': probe_long_path_support(root),
        }
        report['filesystem_capabilities'] = capabilities
        report['environment_blockers'] = [name for name, value in capabilities.items()
                                          if value['status'] == 'ENVIRONMENT_BLOCKED']
        if capabilities['file_symlink']['status'] == 'AVAILABLE':
            target=root/'target.txt';target.write_text('fixture',encoding='utf-8')
            (root/'alias.txt').symlink_to(target)
            try:local_file(root,'alias.txt');report['symlink_protection']='FAILED'
            except ContractError:report['symlink_protection']='PASS'
        else:
            report['symlink_protection']='NOT_VERIFIED'
            report['symlink_reason']=capabilities['file_symlink']['reason']
        report['long_path_io'] = capabilities['long_path']['status']
        if os.name=='nt':
            import ctypes
            fn=ctypes.windll.kernel32.GetShortPathNameW
            fn.argtypes=[ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_uint32];fn.restype=ctypes.c_uint32
            buf=ctypes.create_unicode_buffer(32768);n=fn(str(folder),buf,len(buf))
            if not n or n>=len(buf) or '~' not in buf.value:
                report['windows_83_alias']='NOT_VERIFIED';report['windows_83_reason']='No 8.3 alias available in this filesystem'
            else:
                report['windows_83_alias']='PASS' if local_file(Path(buf.value),'合法.txt') else 'FAILED'
        else: report['windows_83_alias']='NOT_EXECUTED_NON_WINDOWS'
    report['native_compatibility_proven']=False
    return report
