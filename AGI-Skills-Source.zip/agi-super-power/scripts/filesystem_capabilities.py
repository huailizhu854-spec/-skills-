"""Actual local filesystem probes; never change OS settings or grant privileges.

A blocked probe describes missing test coverage, not a successful security check.
Unexpected I/O errors propagate instead of being mislabeled as unavailable features.
"""
from __future__ import annotations
import errno
import os
from pathlib import Path
import tempfile


def symlink_unavailable(exc: BaseException) -> bool:
    if isinstance(exc, NotImplementedError):
        return True
    if not isinstance(exc, OSError):
        return False
    # Only explicit permission or unsupported-operation errors are environmental.
    winerror = getattr(exc, 'winerror', None)
    if winerror is not None:
        return winerror in {1, 5, 50, 1314}
    return exc.errno in {
        errno.EPERM, errno.EACCES, errno.ENOSYS, errno.ENOTSUP,
        getattr(errno, 'EOPNOTSUPP', errno.ENOTSUP),
    }


def blocked(capability: str, exc: BaseException) -> dict:
    return {'status': 'ENVIRONMENT_BLOCKED', 'capability': capability,
            'reason': str(exc), 'errno': getattr(exc, 'errno', None),
            'winerror': getattr(exc, 'winerror', None),
            'security_protection_verified': False}


def probe_symlink_support(root: Path, *, target_is_directory: bool = False) -> dict:
    capability = 'directory_symlink' if target_is_directory else 'file_symlink'
    with tempfile.TemporaryDirectory(prefix='link-probe-', dir=root) as temporary:
        base = Path(temporary)
        target, link = base / 'target', base / 'link'
        if target_is_directory:
            target.mkdir()
        else:
            target.write_bytes(b'filesystem capability fixture')
        try:
            link.symlink_to(target, target_is_directory=target_is_directory)
        except (OSError, NotImplementedError) as exc:
            if not symlink_unavailable(exc):
                raise
            return blocked(capability, exc)
        if not link.is_symlink():
            raise RuntimeError('Symlink creation returned without creating a symlink')
        return {'status': 'AVAILABLE', 'capability': capability,
                'security_protection_verified': False}


def _long_path_unavailable(exc: OSError, attempted: Path) -> bool:
    if exc.errno == errno.ENAMETOOLONG:
        return True
    # Windows may report PATH_NOT_FOUND when MAX_PATH blocks an existing-parent
    # mkdir. Do not mask ordinary missing paths or errors on short paths.
    return (os.name == 'nt' and getattr(exc, 'winerror', None) in {3, 206}
            and len(str(attempted.absolute())) >= 248 and attempted.parent.is_dir())


def probe_long_path_support(root: Path, *, minimum_length: int = 280) -> dict:
    if minimum_length <= 260:
        raise ValueError('The long-path probe must exceed 260 characters')
    with tempfile.TemporaryDirectory(prefix='long-probe-', dir=root) as temporary:
        current = Path(temporary)
        attempted = current
        try:
            index = 0
            while len(str(current / 'fixture.txt')) < minimum_length:
                attempted = current / ('part-' + str(index) + '-' + 'x' * 24)
                attempted.mkdir()
                current = attempted
                index += 1
            attempted = current / 'fixture.txt'
            payload = b'actual long-path read/write fixture'
            attempted.write_bytes(payload)
            if attempted.read_bytes() != payload:
                raise RuntimeError('Long-path fixture did not round trip')
        except OSError as exc:
            if not _long_path_unavailable(exc, attempted):
                raise
            return {**blocked('long_path', exc), 'attempted_path_length': len(str(attempted)),
                    'minimum_length': minimum_length, 'io_mode': 'ordinary_paths'}
        return {'status': 'AVAILABLE', 'capability': 'long_path',
                'tested_path_length': len(str(attempted)), 'minimum_length': minimum_length,
                'io_mode': 'ordinary_paths', 'security_protection_verified': False}
