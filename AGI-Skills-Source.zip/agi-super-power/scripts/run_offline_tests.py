#!/usr/bin/env python3
"""Run the repository's offline unittest fixtures and emit machine-readable counts."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import platform
import sys
import time
import unittest
ROOT=Path(__file__).resolve().parents[1]

def skip_record(test, reason):
    classification = 'ENVIRONMENT_BLOCKED' if reason.startswith('ENVIRONMENT_BLOCKED:') else 'NOT_EXECUTED'
    item = {'test': test.id(), 'reason': reason, 'classification': classification}
    if classification == 'ENVIRONMENT_BLOCKED':
        item['capability'] = reason.split(':', 2)[1].split(' ', 1)[0]
    return item

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--pattern',default='test_*.py')
    p.add_argument('--report',type=Path,required=True);a=p.parse_args(argv)
    started=time.monotonic()
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern=a.pattern)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    data={'suite':a.pattern,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
          'skipped':[skip_record(t,why) for t,why in result.skipped],
          'successful_tests':result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped)-len(result.expectedFailures)-len(result.unexpectedSuccesses),
          'expected_failures':len(result.expectedFailures),
          'all_tests_executed_successfully':result.wasSuccessful() and not result.skipped and not result.expectedFailures,
          'coverage_status':('FAILED' if not result.wasSuccessful() else 'INCOMPLETE' if result.skipped or result.expectedFailures else 'COMPLETE'),
          'environment_blocked_count':sum(why.startswith('ENVIRONMENT_BLOCKED:') for _,why in result.skipped),
          'unexpected_successes':len(result.unexpectedSuccesses),
          'passed':result.wasSuccessful(),'passed_semantics':'unittest success; skips are excluded from successful_tests and never establish complete coverage','seconds':round(time.monotonic()-started,3),
          'python':platform.python_version(),'platform':platform.system(),
          'failed_test_ids':[t.id() for t,_ in result.failures+result.errors],
          'scope':'Offline fixtures and mocks; this runner does not prove real host/model performance.'}
    a.report.parent.mkdir(parents=True,exist_ok=True)
    with a.report.open('x',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
    return 0 if result.wasSuccessful() else 1
if __name__=='__main__':raise SystemExit(main())
