#!/usr/bin/env python3
"""Run the offline Dual16 regression and five 18-process scenarios. No model calls."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--full-regression',action='store_true');a=p.parse_args(argv)
    if a.out.exists():p.error('Use a new output directory; existing evidence is never overwritten')
    a.out.mkdir(parents=True)
    command=[sys.executable,'-B',str(ROOT/'scripts/run_offline_tests.py'),'--report',str(a.out/'unit-tests.json')]
    if not a.full_regression:command+=['--pattern','test_dual16.py']
    unit=subprocess.run(command,capture_output=True,text=True,encoding='utf-8')
    (a.out/'unit-tests.log').write_text(unit.stdout+unit.stderr,encoding='utf-8')
    cases=[]
    for scenario in ('clean','rework','false-pass','crash','dependencies'):
        run=subprocess.run([sys.executable,'-B',str(ROOT/'examples/dual16/run_demo.py'),'--out',str(a.out/scenario),
                            '--scenario',scenario],capture_output=True,text=True,encoding='utf-8')
        (a.out/(scenario+'.log')).write_text(run.stdout+run.stderr,encoding='utf-8')
        path=a.out/scenario/'summary.json';summary=json.loads(path.read_text()) if path.exists() else {}
        expected_code=2 if scenario=='crash' else 0
        passed=(run.returncode==expected_code and summary.get('distinct_pids')==18 and summary.get('all_processes_reaped') is True
                and summary.get('model_calls')==0 and summary.get('completed') is (scenario!='crash'))
        if scenario!='crash':passed=passed and summary.get('accepted')==16
        if scenario in ('rework','false-pass'):passed=passed and summary.get('attempts')==17
        if scenario=='false-pass':passed=passed and summary.get('false_approvals_rejected')==1
        if scenario=='clean':passed=passed and summary.get('peak_overlapping_worker_operations')==16
        cases.append({'scenario':scenario,'passed':bool(passed),'expected_exit':expected_code,'actual_exit':run.returncode,
                      'summary':summary})
        print(json.dumps({'scenario':scenario,'offline_check_passed':bool(passed)},ensure_ascii=False),flush=True)
    units=json.loads((a.out/'unit-tests.json').read_text()) if (a.out/'unit-tests.json').exists() else {}
    report={'offline_passed':unit.returncode==0 and bool(units.get('passed')) and all(x['passed'] for x in cases),
            'native_validation':'NOT_EXECUTED','model_calls':0,'unit_tests':units,'scenarios':cases,
            'scope':'Local protocol and deterministic process fixtures only; not production readiness or universal host support'}
    (a.out/'verification-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'offline_passed':report['offline_passed'],'native_validation':'NOT_EXECUTED'},ensure_ascii=False))
    return 0 if report['offline_passed'] else 1
if __name__=='__main__':raise SystemExit(main())
