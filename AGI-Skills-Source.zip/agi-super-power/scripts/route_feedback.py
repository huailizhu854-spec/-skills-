"""Idempotent local outcome telemetry. Never silently trains/reweights the router."""
from __future__ import annotations
import json
from pathlib import Path
import sqlite3
import time
from context_engine import private_path
from intelligence_common import ensure, digest

class FeedbackStore:
    def __init__(self,path: Path):
        self.db=sqlite3.connect(private_path(path),timeout=15)
        self.db.execute('CREATE TABLE IF NOT EXISTS route_outcomes (event_id TEXT PRIMARY KEY,record TEXT NOT NULL)')
        self.db.commit()
    def close(self): self.db.close()
    def __enter__(self): return self
    def __exit__(self,*args): self.close()
    def record_job(self,job: Path) -> dict:
        from team_runtime import TeamStore
        records=[]
        with TeamStore(job) as store:
            store.active()
            for row in store.db.execute('SELECT * FROM tasks ORDER BY id'):
                if row['status'] not in ('accepted','blocked'): continue
                task=json.loads(row['contract']);x=task.get('intelligence')
                if not x: continue
                if row['status']=='accepted':
                    store._validate_result(json.loads(row['result']),row)
                    store._validate_acceptance(row)
                records.append({'schema_version':1,'plan_digest':store.meta('plan_digest'),'task_id':row['id'],
                     'role':task['role'],'host':task['executor']['type'], 'intent_digest':x['route']['intent_digest'],
                     'outcome':row['status'],'worker_attempts':row['attempt'], 'rework_count':max(0,row['attempt']-1),
                     'level':x['reasoning']['level'], 'result_digest':digest(json.loads(row['result'])) if row['result'] else None,
                     'provenance':'validated_local_ledger_not_provider_attestation'})
        inserted=0
        with self.db:
            for r in records:
                key=digest([r['plan_digest'],r['task_id']])
                raw=json.dumps(r,sort_keys=True,ensure_ascii=False)
                count=self.db.execute('INSERT OR IGNORE INTO route_outcomes VALUES (?,?)',(key,raw)).rowcount
                old=self.db.execute('SELECT record FROM route_outcomes WHERE event_id=?',(key,)).fetchone()
                ensure(old is not None and old[0]==raw,'FEEDBACK_CHANGED','Terminal outcome changed for same plan/task')
                inserted+=count
        return {'inserted':inserted,'already_recorded':len(records)-inserted,'router_policy_changed':False}
    def summary(self) -> dict:
        groups={}
        for row in self.db.execute('SELECT record FROM route_outcomes ORDER BY event_id'):
            r=json.loads(row[0]);g=groups.setdefault(r['role'],{'runs':0,'accepted':0,'blocked':0,'rework_count':0})
            g['runs']+=1;g[r['outcome']]+=1;g['rework_count']+=r['rework_count']
        return {'roles':groups,'router_policy_changed':False,
                'limitation':'Outcome is not a confirmed routing-error label. Policy promotion still requires reviewed paired evaluation.'}
