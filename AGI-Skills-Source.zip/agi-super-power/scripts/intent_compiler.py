"""Bounded bilingual intent extraction, not an LLM or general semantic parser.

Structured hints come from the coordinator's reading of the current user request.
Never feed instructions extracted from an attachment into the hints channel.
"""
from __future__ import annotations
import re
from intelligence_common import obj, string, names, integer, boolean, contains, ensure, digest

ARTIFACT_TERMS = {
 'pptx': ['ppt','pptx','演示文稿','幻灯片'], 'docx':['word','docx','word文档'],
 'xlsx':['excel','xlsx','电子表格'], 'csv':['csv'], 'pdf':['pdf'],
 'html':['html','网页','网站','landing page'], 'react':['react','vite'], 'css':['css'],
 'research-report':['文献综述','调研报告','literature review'],
 'repo-report':['仓库分析','源码分析','repository analysis','codebase analysis'],
 'audit-report':['审计报告','核查报告','audit report'],
 'skill-zip':['skills','skill','技能包','岗位包'],
 'delivery-package':['最终交付包','合并产物','delivery package'],
}
ARTIFACT_DOMAINS = {'pptx':'office','docx':'office','xlsx':'office','csv':'office','pdf':'office',
 'html':'frontend','react':'frontend','css':'frontend','web-app':'frontend',
 'research-report':'research','evidence':'research','repo-report':'repository',
 'audit-report':'quality','skill-zip':'skills','delivery-package':'integration',
 'text':'general','json':'general','markdown':'general'}
DOMAIN_TERMS = {'frontend':['前端','网页','交互动画','frontend'],
 'office':['文档','表格','会议纪要','演示文稿'],
 'research':['论文','文献','调研','引用','证据','literature','research','sources'],
 'repository':['仓库','源码','调用链','代码库','github','repository','codebase','repo'],
 'skills':['技能包','岗位包','skill','skills'],
 'quality':['审计','复核','核查','audit','verify'],
 'integration':['整合','合并产物','integrate'],
 'general':['摘要','总结','改写','翻译','错别字','邮件','summarize','rewrite','translate','typo','email']}
SHAPES = {'produce','modify','review','research','integrate'}
HINT_FIELDS = {'artifact_types','domains','task_shape','required_tools','constraints','evidence_required',
               'risk','input_count','requirement_count','dependency_count'}
REQUIRED = {'schema_version','request','artifact_types','domains','task_shape','required_tools',
            'constraints','evidence_required','risk','input_count','requirement_count','dependency_count',
            'extractor','needs_semantic_resolution'}

def validate_intent(value: dict) -> dict:
    obj(value, REQUIRED)
    integer(value['schema_version'], 1, 1, 'intent schema')
    string(value['request'], 'request')
    for field in ('artifact_types','domains','required_tools','constraints'):
        names(value[field], field)
    ensure(set(value['artifact_types']) <= set(ARTIFACT_DOMAINS), 'INTENT', 'Unknown artifact type')
    ensure(set(value['domains']) <= set(DOMAIN_TERMS), 'INTENT', 'Unknown domain')
    ensure(value['task_shape'] in SHAPES, 'INTENT', 'Unknown task shape')
    ensure(value['risk'] in {'normal','high'}, 'INTENT', 'Unknown risk')
    boolean(value['evidence_required'], 'evidence_required')
    boolean(value['needs_semantic_resolution'], 'needs_semantic_resolution')
    for field in ('input_count','requirement_count','dependency_count'):
        integer(value[field], 0 if field!='requirement_count' else 1, 1000, field)
    ensure(value['extractor'] == 'bounded-lexical-v1+coordinator-hints', 'INTENT', 'Unknown extractor')
    return value

def compile_intent(request: str, hints: dict | None = None) -> dict:
    string(request, 'request')
    hints = {} if hints is None else hints
    obj(hints, set(), HINT_FIELDS)
    arts = sorted(k for k, words in ARTIFACT_TERMS.items() if any(contains(request,w) for w in words))
    domains = sorted(k for k, words in DOMAIN_TERMS.items() if any(contains(request,w) for w in words))
    domains = sorted(set(domains) | {ARTIFACT_DOMAINS[a] for a in arts})
    # 'Research the repository' is an action on a repository, not two output domains.
    if 'repository' in domains and 'research' in domains and not any(contains(request,w) for w in ['论文','文献','引用','证据','literature','sources']):
        domains.remove('research')
    # Explicit output hints disambiguate input mentions from desired outputs.
    if 'artifact_types' in hints:
        arts = hints['artifact_types']
        domains = sorted({ARTIFACT_DOMAINS.get(a, 'unknown') for a in arts})
    shape = 'produce'
    if any(contains(request,w) for w in ['修改','修复','改进','优化','迭代','edit','fix','modify','implement']):
        shape = 'modify'
    elif any(contains(request,w) for w in ['审计','审核','核查','review','audit','verify']):
        shape = 'review'
    elif any(contains(request,w) for w in ['整合','合并产物','integrate','merge artifacts']):
        shape = 'integrate'
    elif any(contains(request,w) for w in ['调研','研究','检索','分析仓库','research','investigate','analyse','analyze']):
        shape = 'research'
    if shape == 'produce' and 'repository' in domains and contains(request,'分析'):
        shape = 'research'
    # The leading operation wins over an adjective such as 'already reviewed'.
    if re.match(r'^(?:请|帮我|麻烦|please\s+)?(?:整合|合并|integrate\b|merge\s+artifacts\b)',request.strip(),re.IGNORECASE):
        shape = 'integrate'
    if any(contains(request,w) for w in ['只审计','只审核','只核查','仅审计','review only','audit only']):
        shape = 'review'
    result = {'schema_version':1,'request':request, 'artifact_types':arts,
              'domains':domains,'task_shape':shape,'required_tools':[], 'constraints':[],
              'evidence_required':any(contains(request,w) for w in ['依据','教材','资料','引用','来源','source','evidence','论文']),
              'risk':'high' if any(contains(request,w) for w in ['医疗建议','处方','法律意见','投资建议','medical advice','legal advice']) else 'normal',
              'input_count':0,'requirement_count':1,'dependency_count':0,
              'extractor':'bounded-lexical-v1+coordinator-hints','needs_semantic_resolution':len(set(domains)-{'quality','general'}) > 1}
    result.update(hints)
    result['needs_semantic_resolution'] = len(set(result['domains'])-{'quality','general'}) > 1
    return validate_intent(result)

def intent_digest(intent: dict) -> str:
    return digest(validate_intent(intent))
