"""Deterministic resume-clinic acceptance verifiers (coordinator-owned code).

Scope, stated once so it is never overclaimed: these verifiers prove ONLY that a
task did not FABRICATE and did not OMIT. They re-derive every asserted value from
the frozen source bytes the task was given and compare. They do NOT judge whether a
diagnosis is insightful, whether a rewrite is good writing, or whether the candidate
should be hired. "PASS" here means "nothing invented, nothing dropped", nothing more.

No model is called, no network, no clock, no randomness: same bytes in, same findings
out. Each verifier reads only artifacts its task declared, enforced by Context.raw.
"""
from __future__ import annotations

import re

from verifier_registry import finding

CONCLUSIONS = ('命中', '部分', '缺口')
JD_ITEM = re.compile(r'^\s*(\d+)[.、)]\s*\S')
ID_CHAR = r'[0-9A-Za-z_-]'


def _mentions(text: str, token: str) -> bool:
    """Whole-token match, not naive substring.

    A plain `'D-3' in text` is a false negative generator: it also matches inside 'JD-3',
    so a report that dropped D-3 but still listed JD-3 would look complete. Require that the
    token is not glued to another id character on either side.
    """
    return re.search(f'(?<!{ID_CHAR}){re.escape(token)}(?!{ID_CHAR})', text) is not None


def _leaves(value, path='$'):
    """Yield (path, leaf) for every non-container value, so nothing escapes review."""
    if isinstance(value, dict):
        for key, item in value.items():
            yield from _leaves(item, f'{path}.{key}')
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from _leaves(item, f'{path}[{index}]')
    else:
        yield path, value


def _jd_requirement_ids(text: str) -> list[str]:
    """Numbered JD requirements, in file order. The numbering in the JD is the contract."""
    return ['JD-' + JD_ITEM.match(line).group(1) for line in text.splitlines() if JD_ITEM.match(line)]


def _records(ctx, aid, key):
    data = ctx.json_object(aid)
    rows = data.get(key)
    if not isinstance(rows, list) or not rows or not all(isinstance(r, dict) for r in rows):
        raise ValueError(f'{aid} needs a nonempty {key} array of objects')
    return rows


def _ids(rows, field, label):
    out = []
    for row in rows:
        value = row.get(field)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f'{label} entry is missing a text {field}')
        out.append(value)
    return out


def parse_grounded(ctx):
    """FAIL if any parsed value is not quoted verbatim from the resume (invented experience)."""
    source = ctx.text('resume')
    data = ctx.json_object(ctx.output_id())
    leaves = list(_leaves(data))
    untyped = [p for p, v in leaves if not isinstance(v, str)]
    empty = [p for p, v in leaves if isinstance(v, str) and not v.strip()]
    ungrounded = [f'{p}={v!r}' for p, v in leaves if isinstance(v, str) and v.strip() and v not in source]
    return [
        finding('parse_not_empty', bool(leaves), f'{len(leaves)} leaf values'),
        finding('all_leaves_are_text', not untyped,
                'non-text leaves cannot be provenance-checked: ' + ', '.join(untyped[:5])),
        finding('no_blank_values', not empty, ', '.join(empty[:5])),
        finding('every_value_quoted_from_resume', not ungrounded,
                'not found verbatim in resume.txt: ' + '; '.join(ungrounded[:5])),
    ]


def diagnosis_anchored(ctx):
    """FAIL if a problem points past the end of the resume, or quotes text not on that line."""
    lines = ctx.text('resume').splitlines()
    rows = _records(ctx, ctx.output_id(), 'problems')
    ids = _ids(rows, 'id', 'problem')
    bad_line, bad_quote = [], []
    for row in rows:
        number, quote = row.get('line'), row.get('quote')
        if type(number) is not int or not 1 <= number <= len(lines):
            bad_line.append(f'{row["id"]}: line={number!r} outside 1..{len(lines)}')
            continue
        if not isinstance(quote, str) or not quote.strip() or quote not in lines[number - 1]:
            bad_quote.append(f'{row["id"]}: quote {quote!r} is not a substring of line {number}')
    return [
        finding('unique_problem_ids', len(ids) == len(set(ids)), 'duplicate diagnosis id'),
        finding('line_numbers_within_resume', not bad_line, '; '.join(bad_line[:5])),
        finding('quotes_are_substrings_of_their_line', not bad_quote, '; '.join(bad_quote[:5])),
    ]


def jd_coverage(ctx):
    """FAIL if a numbered JD requirement has no conclusion, or the conclusion is off-vocabulary."""
    expected = _jd_requirement_ids(ctx.text('jd'))
    if not expected:
        raise ValueError('No numbered requirements found in the JD; nothing to verify against')
    rows = _records(ctx, ctx.output_id(), 'requirements')
    got = _ids(rows, 'id', 'requirement')
    missing = [x for x in expected if x not in got]
    extra = [x for x in got if x not in expected]
    bad = [f'{r["id"]}={r.get("conclusion")!r}' for r in rows if r.get('conclusion') not in CONCLUSIONS]
    return [
        finding('every_jd_requirement_has_a_conclusion', not missing, 'missing: ' + ', '.join(missing)),
        finding('no_invented_requirements', not extra, 'not in the JD: ' + ', '.join(extra)),
        finding('unique_requirement_ids', len(got) == len(set(got)), 'duplicate requirement id'),
        finding('conclusions_use_the_fixed_vocabulary', not bad,
                'allowed ' + '/'.join(CONCLUSIONS) + '; got ' + ', '.join(bad[:5])),
    ]


def rewrite_traceable(ctx):
    """FAIL unless suggestions map one-to-one onto diagnosis ids (no orphans, no drops)."""
    diagnosed = _ids(_records(ctx, 'diag-json', 'problems'), 'id', 'problem')
    rows = _records(ctx, ctx.output_id(), 'suggestions')
    cited = _ids(rows, 'diagnosis_id', 'suggestion')
    orphan = [x for x in cited if x not in set(diagnosed)]
    dropped = [x for x in diagnosed if x not in set(cited)]
    return [
        finding('no_suggestion_without_a_diagnosis', not orphan, 'orphan suggestions: ' + ', '.join(orphan[:5])),
        finding('no_diagnosis_left_unaddressed', not dropped, 'dropped diagnoses: ' + ', '.join(dropped[:5])),
        finding('one_suggestion_per_diagnosis', len(cited) == len(set(cited)) and len(cited) == len(diagnosed),
                f'{len(cited)} suggestions ({len(set(cited))} distinct) for {len(diagnosed)} diagnoses'),
    ]


def report_complete(ctx):
    """FAIL if the report drops any diagnosis id or any JD requirement id."""
    text = ctx.text(ctx.output_id())
    diagnosed = _ids(_records(ctx, 'rewrite-json', 'suggestions'), 'diagnosis_id', 'suggestion')
    required = _ids(_records(ctx, 'match-json', 'requirements'), 'id', 'requirement')
    lost_diag = [x for x in dict.fromkeys(diagnosed) if not _mentions(text, x)]
    lost_jd = [x for x in dict.fromkeys(required) if not _mentions(text, x)]
    return [
        finding('report_carries_every_diagnosis_id', not lost_diag, 'absent from report: ' + ', '.join(lost_diag[:5])),
        finding('report_carries_every_jd_requirement_id', not lost_jd, 'absent from report: ' + ', '.join(lost_jd[:5])),
    ]


def qa_honest(ctx):
    """FAIL if QA claims full coverage while the report actually drops diagnoses."""
    text = ctx.text('report-md')
    diagnosed = _ids(_records(ctx, 'diag-json', 'problems'), 'id', 'problem')
    actual = sorted({x for x in diagnosed if not _mentions(text, x)})
    data = ctx.json_object(ctx.output_id())
    claimed_complete, claimed_missing = data.get('coverage_complete'), data.get('missing_diagnosis_ids')
    if type(claimed_complete) is not bool or not isinstance(claimed_missing, list):
        raise ValueError('qa-json needs boolean coverage_complete and a missing_diagnosis_ids array')
    return [
        finding('completeness_claim_matches_reality', claimed_complete == (not actual),
                f'claimed complete={claimed_complete}; report actually drops {actual or "nothing"}'),
        finding('declared_gaps_match_reality', sorted(map(str, claimed_missing)) == actual,
                f'declared {sorted(map(str, claimed_missing))}; actual {actual}'),
    ]
