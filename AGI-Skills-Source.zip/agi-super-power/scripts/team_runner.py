#!/usr/bin/env python3
"""Dispatch ONE ready batch through explicitly approved local command adapters.

No shell, no default model endpoint, no automatic acceptance. The parent agent
reviews submitted results, then invokes another batch. Adapters must be trusted;
a working directory is NOT an OS sandbox. Only use audited foreground wrappers.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import uuid

from kernel import load_json
from team_runtime import TeamError, TeamStore, fields, require, strings, write_json


def validate_adapters(config: dict) -> None:
    fields(config, {"schema_version", "adapters"})
    require(type(config["schema_version"]) is int and config["schema_version"] == 1, "ADAPTER_VERSION", "Expected version 1")
    require(isinstance(config["adapters"], dict) and bool(config["adapters"]), "ADAPTERS", "At least one role adapter is required")
    for role, adapter in config["adapters"].items():
        fields(adapter, {"argv", "mode", "timeout_seconds"})
        strings(adapter["argv"], "argv")
        require(Path(adapter["argv"][0]).is_absolute() and Path(adapter["argv"][0]).is_file(), "EXECUTABLE", "Use an explicit absolute executable path")
        require(adapter["mode"] in ("command", "fixture"), "ADAPTER_MODE", "Only command or fixture modes are supported by this runner")
        require(type(adapter["timeout_seconds"]) is int and 1 <= adapter["timeout_seconds"] <= 3600, "TIMEOUT", "Timeout must be 1-3600 seconds")
        require(isinstance(role, str) and role, "ROLE", "Role key must be text")


def execute(job: Path, tid: str, adapter: dict) -> dict:
    worker = "worker-" + uuid.uuid4().hex[:12]
    with TeamStore(job) as store:
        try:
            store.active()
            store.validate_host(tid, adapter["mode"])
            packet = store.claim(tid, worker)
        except TeamError as exc:
            return {"task_id": tid, "status": "not_started", "error": exc.code}
        token, workspace = packet["lease_token"], Path(packet["workspace"])
        proc = None
        started = time.monotonic()
        try:
            # No interpolation of task content into executable arguments.
            # Packet path is always the final argument of the trusted wrapper.
            with (workspace / "evidence" / "stdout.log").open("xb") as out, (workspace / "evidence" / "stderr.log").open("xb") as err:
                proc = subprocess.Popen([*adapter["argv"], packet["packet_path"]], cwd=workspace,
                                        stdin=subprocess.DEVNULL, stdout=out, stderr=err, shell=False)
                host_run_id = "process-" + str(proc.pid) + "-" + token[:12]
                store.bind(tid, token, adapter["mode"], host_run_id)
                lease = store.meta("plan")["policy"]["lease_seconds"]
                while True:
                    remaining = adapter["timeout_seconds"] - (time.monotonic() - started)
                    if remaining <= 0:
                        raise subprocess.TimeoutExpired(adapter["argv"], adapter["timeout_seconds"])
                    try:
                        code = proc.wait(timeout=min(remaining, max(1, lease / 3)))
                        break
                    except subprocess.TimeoutExpired:
                        store.heartbeat(tid, token)
                require(code == 0, "ADAPTER_FAILED", f"Wrapper exited {code}; inspect local stderr")
            receipt_path = workspace / "evidence" / "host-receipt.json"
            receipt = {"host_run_id": host_run_id, "mode": adapter["mode"], "finished": True,
                       "task_id": tid, "lease_token": token, "exit_code": code, "pid": proc.pid,
                       "duration_seconds": round(time.monotonic() - started, 6),
                       "backend_identity": {"adapter":"foreground-command", "adapter_version":"3.0.0",
                           "executable_name":Path(adapter['argv'][0]).name,
                           "executable_sha256":hashlib.sha256(Path(adapter['argv'][0]).read_bytes()).hexdigest(),
                           "argv_redacted":[Path(adapter['argv'][0]).name]+['<redacted-argument>']*(len(adapter['argv'])-1),
                           "attestation":False},
                       "note": "Foreground wrapper returned. Adapter contract forbids detached jobs; OS sandboxing is external."}
            write_json(receipt_path, receipt)
            result = load_json(packet["result_path"])
            require(isinstance(result, dict), "RESULT_OBJECT", "Wrapper must return a JSON object")
            # Controller-owned receipt: wrapper output cannot choose its host identity.
            result["host_run_id"] = host_run_id
            result["host_receipt"] = {"path": "evidence/host-receipt.json", "sha256": hashlib.sha256(receipt_path.read_bytes()).hexdigest()}
            write_json(workspace / "controller-result.json", result)
            return {"task_id": tid, "mode": adapter["mode"], **store.submit(result)}
        except Exception as exc:
            if proc is not None and proc.poll() is None:
                proc.kill()
                proc.wait()
            # No blind retry: killing a wrapper alone does not prove remote work or
            # detached descendants have stopped. Require a reconciliation receipt.
            try:
                store.mark_uncertain(tid, token, str(exc))
            except TeamError:
                pass  # A concurrent goal revision may already have fenced it.
            return {"task_id": tid, "status": "uncertain", "error": getattr(exc, "code", type(exc).__name__), "message": str(exc)}


def run_batch(job: str | Path, config: dict, *, allow_commands: bool = False) -> dict:
    require(allow_commands, "AUTHORIZATION", "Command adapters execute local programs; pass --allow-commands only for reviewed wrappers")
    validate_adapters(config)
    job = Path(job).absolute()
    with TeamStore(job) as store:
        store.active(); store.reconcile()
        plan = store.meta("plan")
        roles = {t["id"]: t["role"] for t in plan["tasks"]}
        ready = store.ready()
        capacity = plan["policy"]["max_parallel"] - store.db.execute("SELECT COUNT(*) FROM tasks WHERE status IN ('leased','uncertain')").fetchone()[0]
        assigned = [(tid, config["adapters"][roles[tid]]) for tid in ready if roles[tid] in config["adapters"]][:max(0, capacity)]
        missing = [tid for tid in ready if roles[tid] not in config["adapters"]]
        # Reject a bad batch before ANY child process is created or task is leased.
        for tid, adapter in assigned:
            store.validate_host(tid, adapter["mode"])
    results = []
    if assigned:
        with ThreadPoolExecutor(max_workers=len(assigned)) as pool:
            futures = [pool.submit(execute, job, tid, adapter) for tid, adapter in assigned]
            for future in as_completed(futures):
                results.append(future.result())
    return {"batch": sorted(results, key=lambda x: x["task_id"]), "missing_adapters": missing,
            "automatic_acceptance": False, "next": "Coordinator reviews submitted outputs before downstream dispatch"}


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--job", required=True); p.add_argument("--adapters", required=True)
    p.add_argument("--allow-commands", action="store_true")
    args = p.parse_args(argv)
    try:
        result = run_batch(args.job, load_json(args.adapters), allow_commands=args.allow_commands)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if not result["missing_adapters"] and all(r.get("submitted") for r in result["batch"]) else 1
    except (ValueError, OSError, TypeError, KeyError) as exc:
        print(json.dumps({"error": getattr(exc, "code", "ADAPTER_ERROR"), "message": str(exc)}, ensure_ascii=False)); return 1


if __name__ == "__main__":
    raise SystemExit(main())
