"""Release versions are distinct from persisted wire/schema versions."""
PACKAGE_VERSION = '3.4.0-rc.7'
RUNTIME_VERSION = '3.4.0-rc.7'
INTELLIGENCE_SCHEMA_VERSION = 1
CONTEXT_SCHEMA_VERSION = 2
SUPPORTED_PLAN_SCHEMAS = (2, 3)
VERIFIER_VERSION = '3.0.0'  # Verification semantics have not been changed.
NATIVE_ADAPTER_VERSION = '3.3.0'
