"""Deterministic beginner task cards and conservative, explicit change impact."""
from __future__ import annotations
import json
from team_runtime import compile_plan, require, digest

def brief(plan, *, assumptions=None, missing_materials=None):
    compile_plan(plan)
    assumptions=[] if assumptions is None else assumptions
    missing_materials=[] if missing_materials is None else missing_materials
    require(isinstance(assumptions,list) and all(isinstance(a,str) and a.strip() for a in assumptions), 'BRIEF','Assumptions must be explicit text, never silently user facts')
    require(isinstance(missing_materials,list) and all(isinstance(a,str) and a.strip() for a in missing_materials), 'BRIEF','Missing materials must be explicit text')
    mappings=[]
    for r in plan['goal']['requirements']:
        tasks=[t for t in plan['tasks'] if r['id'] in t['requirements']]
        mappings.append({'requirement':r,'tasks':[t['id'] for t in tasks],
            'auto_checks':[{'task_id':t['id'],'id':c['id'],'method':c['method']} for t in tasks for c in t['acceptance'] if c['requirement']==r['id']],
            'manual_checks':[{'task_id':t['id'],**c} for t in tasks for c in t.get('quality_gates',[]) if c['requirement']==r['id']]})
    return {'goal':plan['goal']['objective'],'goal_version':plan['goal']['version'],
            'deliverables':[{'owner':t['id'],**o} for t in plan['tasks'] for o in t['outputs']],
            'constraints':plan['goal']['constraints'],'requirement_trace':mappings,
            'assumptions':[{'text':a,'status':'UNCONFIRMED_NOT_USER_FACT'} for a in assumptions],
            'missing_materials':missing_materials,
            'sample_policy':'Complex/style-sensitive tasks require a sample when frozen into their task contract; not every task gets a new agent',
            'acceptance_limit':'Only listed checks are covered. Timing, factual correctness and visual quality are not implied by file generation'}

def brief_markdown(card):
    lines=['# 任务说明','',f"目标：{card['goal']}",f"目标版本：{card['goal_version']}",'','## 交付内容']
    lines += ['- '+a['path']+'（负责人：'+a['owner']+'）' for a in card['deliverables']]
    lines += ['','## 必须遵守']+[ '- '+s for s in card['constraints']]
    lines += ['','## 要求与检查']
    for r in card['requirement_trace']:
        lines += [f"- {r['requirement']['id']}：{r['requirement']['text']}；任务：{', '.join(r['tasks'])}；自动检查 {len(r['auto_checks'])} 项，人工检查 {len(r['manual_checks'])} 项。"]
    lines += ['','## 未确认假设（不是用户事实）']+['- '+a['text'] for a in card['assumptions']]
    if not card['assumptions']:lines += ['无已登记假设。']
    lines += ['','## 缺失材料']+['- '+s for s in card['missing_materials']]
    if not card['missing_materials']:lines += ['无已登记缺口；这不代表已自动判断材料充分。']
    lines += ['','文件生成不等于业务或视觉验收通过。所有未知检查必须明确保留。','']
    return '\n'.join(lines)

def progress(store):
    s=store.status()
    completed=[t['id'] for t in s['tasks'] if t['status']=='accepted']
    running=[t['id'] for t in s['tasks'] if t['status'] in ('leased','submitted')]
    blocked=[{'task':t['id'],'reason':t['status']} for t in s['tasks'] if t['status'] in ('uncertain','blocked','cancelled')]
    return {'已完成':completed,'进行中':running,'阻塞原因':blocked,'下一步':s['ready'],
            '完成状态':s['completed'],'说明':'已领取不等于宿主已经启动；submitted 仍需验收。',
            '证据变化':s['changed_artifacts']+s['changed_evidence']}

def change_impact(old, new, *, declared_impacted=()):
    compile_plan(old);compile_plan(new)
    require(old['goal']['id']==new['goal']['id'] and new['goal']['version']>old['goal']['version'],
            'GOAL_VERSION','Compare successive versions of the same goal')
    before={r['id']:r['text'] for r in old['goal']['requirements']};after={r['id']:r['text'] for r in new['goal']['requirements']}
    changed={k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)} | set(declared_impacted)
    require(set(declared_impacted)<=before.keys()|after.keys(),'IMPACT_REQUIREMENT','Unknown declared requirement')
    a={t['id']:t for t in old['tasks']};b={t['id']:t for t in new['tasks']}
    source_a={x['id']:x for x in old['inputs']};source_b={x['id']:x for x in new['inputs']}
    inputs={k for k in source_a.keys()|source_b.keys() if source_a.get(k)!=source_b.get(k)}
    global_change=any(old['goal'][k]!=new['goal'][k] for k in ('objective','constraints','non_goals'))
    affected=set(a.keys()^b.keys())
    for tid in a.keys()|b.keys():
        candidates=[t for t in (a.get(tid),b.get(tid)) if t]
        if global_change or any(set(t['requirements'])&changed or set(t['reads'])&inputs for t in candidates):affected.add(tid)
        if tid in a and tid in b and a[tid]!=b[tid]:affected.add(tid)
    while True:
        next_set=affected | {tid for tid in a.keys()|b.keys() if any(set(t['depends_on'])&affected for t in (a.get(tid),b.get(tid)) if t)}
        if next_set==affected:break
        affected=next_set
    return {'changed_requirements':sorted(changed),'changed_inputs':sorted(inputs),'global_goal_change':global_change,
            'affected_tasks':sorted(affected),'reuse_candidates':sorted((a.keys()&b.keys())-affected),
            'new_goal_digest':digest(new['goal']), 'automatic_reuse_authorized':False,
            'next':'Fence old goal, confirm old hosts stopped, rehash/review reusable artifacts and declare them as explicit inputs in a NEW job',
            'limitation':'Exact structural difference plus coordinator-declared semantic impact, not automated semantic understanding'}
