#!/usr/bin/env python3
"""Run the explicit schema-3 demo through a bounded command/API model interface.

The original plan.json/run_demo.py remain schema-2 OFFLINE fixtures. This driver
uses plan.model-v3.json (model transport permitted, all leaf tool capabilities
disabled) and coordinator-owned verifiers. A command may be a local stub: neither
its label nor a cost field proves a real model identity. Native subagents are NOT
invoked by this program. Use native_host_bridge.py with actual host tools instead.

Usage:
    python scripts/host_bridge_model_demo.py --output /abs/path/new-job \
        --provider command --model-id <label> \
        --model-command '["/abs/bin/model-cli", "--reviewed-flag"]'
    python scripts/host_bridge_model_demo.py --emit-adapters /abs/path/config.json
"""
from __future__ import annotations

import argparse
import hashlib
import html.parser
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from kernel import load_json
from team_runtime import TeamStore, TeamError, digest, write_json
from team_runner import run_batch, validate_adapters

DEMO = ROOT / "examples/team-demo"
ROLE_TIMEOUT = 600


# --------------------------------------------------------------------------- #
# Adapters
# --------------------------------------------------------------------------- #

def resolve_adapters(worker: Path | None = None, python: str | None = None) -> dict:
    """Generate adapter paths for this checkout; no shipped machine-specific argv."""
    worker = (worker or (ROOT / "scripts/model_worker.py")).resolve()
    interpreter = python or sys.executable
    plan = load_json(DEMO / "plan.model-v3.json")
    return {"schema_version": 1,
            "adapters": {task["role"]: {"argv": [interpreter, "-B", str(worker)],
                                        "mode": "command", "timeout_seconds": ROLE_TIMEOUT}
                         for task in plan["tasks"]}}


# --------------------------------------------------------------------------- #
# Coordinator-side independent verification
# --------------------------------------------------------------------------- #

SILENT = {"style", "script"}


class _Text(html.parser.HTMLParser):
    """Rendered text and element census, so checks look at what a reader sees."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.counts: dict[str, int] = {}
        self.stack: list[str] = []
        self.text: dict[str, list[str]] = {}
        self.visible: list[str] = []

    def handle_starttag(self, tag, attrs):
        self.counts[tag] = self.counts.get(tag, 0) + 1
        self.stack.append(tag)

    def handle_endtag(self, tag):
        if tag in self.stack:
            while self.stack and self.stack.pop() != tag:
                pass

    def handle_data(self, data):
        if any(tag in SILENT for tag in self.stack):
            return
        chunk = data.strip()
        if not chunk:
            return
        self.visible.append(chunk)
        if self.stack:
            self.text.setdefault(self.stack[-1], []).append(chunk)


def scalars(value: object, sink: list[str]) -> list[str]:
    """Flatten a JSON document to its scalar values, as text."""
    if isinstance(value, dict):
        for item in value.values():
            scalars(item, sink)
    elif isinstance(value, list):
        for item in value:
            scalars(item, sink)
    elif value is not None and not isinstance(value, bool):
        sink.append(str(value))
    return sink


def expectations(brief: Path) -> dict:
    raw = brief.read_text(encoding="utf-8")
    lines = raw.splitlines()
    return {"line_count": len(lines), "title": lines[0], "body_lines": lines[1:],
            "brief_sha256": hashlib.sha256(brief.read_bytes()).hexdigest(),
            "characters": len(raw)}


def inspect(tid: str, artifact_text: str, expect: dict,
            upstream: dict | None = None) -> list[dict]:
    """Return findings the COORDINATOR executed, independent of the worker.

    `upstream` carries what the coordinator already accepted and re-hashed
    itself: `page_sha256`, and `facts_tokens`, the scalar values of the accepted
    facts artifact plus that artifact's own hash. Checks are written against the
    plan's requirements, not against the shape of the fixture worker's output:
    a page that lists the outline in <li> satisfies R3 exactly as one using <p>.
    """
    upstream = upstream or {}
    page_sha = upstream.get("page_sha256")
    findings: list[dict] = []

    def record(name: str, ok: bool, detail: str, *, blocking: bool = True) -> None:
        findings.append({"check": name, "ok": bool(ok), "blocking": blocking, "detail": detail})

    if tid in ("facts", "outline", "audit"):
        try:
            document = json.loads(artifact_text)
        except json.JSONDecodeError as exc:
            record("json_parses", False, f"invalid JSON: {exc}")
            return findings
        record("json_parses", isinstance(document, (dict, list)) and bool(document),
               f"parsed {type(document).__name__}")
        values = scalars(document, [])
        joined = "\n".join(values)
        if tid == "facts":
            record("binds_input_hash", expect["brief_sha256"] in values,
                   "artifact carries the coordinator's own sha256 of brief.txt")
            record("reports_line_count", str(expect["line_count"]) in values,
                   f"coordinator counted {expect['line_count']} lines in brief.txt")
            # The plan says "character count" without fixing an encoding or
            # whether newlines count, so the coordinator reports the comparison
            # instead of gating on one arbitrary reading of it.
            candidates = {expect["characters"], expect["characters"] - expect["line_count"],
                          len(expect["title"]) + sum(len(x) for x in expect["body_lines"])}
            record("character_count_matches_a_coordinator_reading",
                   any(str(c) in values for c in sorted(candidates)),
                   "coordinator readings " + str(sorted(candidates))
                   + "; artifact scalars " + str(values), blocking=False)
        elif tid == "outline":
            record("carries_title", any(expect["title"] in value for value in values),
                   f"title line {expect['title']!r} appears in the outline")
            missing = [line for line in expect["body_lines"] if line not in joined]
            record("carries_every_body_line", not missing,
                   "missing body lines: " + str(missing) if missing
                   else f"all {len(expect['body_lines'])} body lines are present")
        else:
            record("binds_reviewed_page_hash", bool(page_sha) and page_sha in values,
                   "audit report carries the coordinator's own sha256 of the published page")
        return findings

    parser = _Text()
    try:
        parser.feed(artifact_text); parser.close()
    except Exception as exc:  # pragma: no cover - html.parser rarely raises
        record("html_parses", False, f"{type(exc).__name__}")
        return findings
    record("html_parses", parser.counts.get("html", 0) >= 1 or parser.counts.get("body", 0) >= 1,
           f"tags seen: {sorted(parser.counts)[:12]}")
    heading = " ".join(parser.text.get("h1", []))
    record("h1_matches_title", expect["title"] in heading,
           f"<h1> text {heading!r} vs outline title {expect['title']!r}")
    visible = "\n".join(parser.visible)
    absent = [line for line in expect["body_lines"] if line not in visible]
    record("carries_every_outline_line", not absent,
           "outline lines missing from the rendered text: " + str(absent) if absent
           else f"all {len(expect['body_lines'])} accepted outline lines are on the page")
    tokens = [t for t in (upstream.get("facts_tokens") or []) if len(str(t)) >= 2]
    cited = sorted(t for t in tokens if str(t) in artifact_text)
    record("cites_the_accepted_facts_artifact", bool(cited) if tokens else False,
           f"values carried over from the accepted facts artifact: {cited}"
           if cited else f"none of {tokens} appear on the page")
    record("wraps_outline_lines_in_a_list_or_paragraph",
           (parser.counts.get("p", 0) + parser.counts.get("li", 0)) >= len(expect["body_lines"]),
           f"{parser.counts.get('p', 0)} <p> and {parser.counts.get('li', 0)} <li> elements",
           blocking=False)
    return findings


NOT_CHECKED = [
    "factual accuracy of any prose the model wrote",
    "browser rendering, layout, and visual quality",
    "whether a second run of the same model would produce the same artifact",
    "cost, rate limits, and provider-side behaviour beyond this one run",
]


# --------------------------------------------------------------------------- #
# Run
# --------------------------------------------------------------------------- #

def accepted_facts(store: TeamStore, job: Path, tid: str) -> dict:
    """What the coordinator re-reads from its own published copy after accepting."""
    if tid == "page":
        return {"page_sha256": store.valid_artifact("page-html")["sha256"]}
    if tid != "facts":
        return {}
    artifact = store.valid_artifact("facts-data")
    text = (job / artifact["storage"]).read_text(encoding="utf-8")
    try:
        values = scalars(json.loads(text), [])
    except json.JSONDecodeError:            # pragma: no cover - acceptance re-parses
        values = []
    return {"facts_tokens": sorted(set(values) | {artifact["sha256"]})}


def call_records(job: Path) -> list[dict]:
    """Read durable call-start journals, including attempts with no result file.

    A truncated final line after a crash is recorded as such, not fabricated.
    Missing return/parse events leave parsed=None, never True.
    """
    records = []
    for path in sorted((job / 'workers').rglob('evidence/model-events.jsonl')):
        calls, task_id = {}, None
        for line in path.read_text(encoding='utf-8').splitlines():
            try:
                event = json.loads(line)
            except (ValueError, TypeError):
                if calls: list(calls.values())[-1]['journal_incomplete'] = True
                break
            kind, ticket = event.get('event'), event.get('budget_ticket')
            if kind == 'WORKER_STARTED': task_id = event.get('task_id')
            if kind == 'CALL_STARTED':
                identity = event.get('identity', {})
                calls[ticket] = {'task_id': task_id, 'attempt': event.get('attempt'),
                    'provider': identity.get('provider'), 'model': identity.get('configured_model_label'),
                    'budget_ticket': ticket, 'parsed': None, 'seconds': None,
                    'prompt_characters': len(event.get('prompt', '')), 'reply_characters': None,
                    'usage': None, 'cost_usd': None, 'state': 'started_unresolved'}
            elif ticket in calls:
                call = calls[ticket]
                if kind == 'CALL_RETURNED':
                    meta = event.get('meta') or {}
                    call.update(seconds=event.get('seconds'), reply_characters=len(event.get('reply', '')),
                                usage=meta.get('usage'), cost_usd=meta.get('total_cost_usd'), state='returned')
                elif kind in ('CALL_PARSE_PASSED', 'CALL_PARSE_FAILED'):
                    call.update(parsed=kind == 'CALL_PARSE_PASSED', state=kind.lower())
                elif kind == 'CALL_FAILED_OR_UNKNOWN':
                    call.update(state='failed_or_unknown', error=event.get('error'))
        records.extend(calls.values())
    return records


def run(output: Path, config: dict, *, max_batches: int = 8) -> dict:
    plan = load_json(DEMO / "plan.model-v3.json")
    validate_adapters(config)
    TeamStore.create(output, plan, DEMO)
    write_json(output / "adapters.resolved.json", config)
    expect = expectations(DEMO / "brief.txt")
    started = time.time()
    batches: list[dict] = []
    reviews: list[dict] = []
    upstream: dict = {}

    for _ in range(max_batches):
        batches.append(run_batch(output, config, allow_commands=True))
        with TeamStore(output) as store:
            for row in list(store.db.execute("SELECT * FROM tasks WHERE status='submitted' ORDER BY id")):
                tid = row["id"]
                result = json.loads(row["result"])
                artifact = result["artifacts"][0]
                text = (Path(json.loads(row["packet"])["output_root"]) / artifact["path"]).read_text(encoding="utf-8")
                from verifier_registry import evaluate
                packet = json.loads(row['packet'])
                assessment = evaluate(packet, result)
                findings = [f for c in assessment['checks'] for f in c['findings']]
                blocking = [f for f in findings if f.get("blocking", True)]
                accepted = assessment["passed"] and result["technical_validation"]["outcome"] == "PASS" and not result["concerns"]
                relative = f"reviews/{tid}-{row['attempt']}.json"
                write_json(output / relative, {
                    "reviewer": "coordinator", "task_id": tid, "attempt": row["attempt"],
                    "method": ("Coordinator recomputed what it could from the frozen inputs and "
                               "the already-published artifacts, then checked the submitted "
                               "artifact against those values. The worker's own report was not "
                               "used as evidence."),
                    "subject_sha256": artifact["sha256"],
                    "worker_concerns": result["concerns"],
                    "checked": [f for f in findings if f.get("blocking", True)],
                    "observed_not_gating": [f for f in findings if not f.get("blocking", True)],
                    "not_checked": NOT_CHECKED,
                    "result_digest": digest(result)})
                decision = "accept" if accepted else "rework"
                reason = ("Independent coordinator checks passed; no model capability claim."
                          if accepted else
                          "Independent coordinator checks failed: " + "; ".join(
                              f["check"] for f in blocking if not f["ok"])
                          + ("; worker concerns: " + "; ".join(result["concerns"])
                             if result["concerns"] else ""))
                outcome = store.review({
                    "task_id": tid, "result_id": result["result_id"],
                    "result_digest": digest(result), "goal_digest": store.meta("goal_digest"),
                    "reviewer": "coordinator", "decision": decision, "reason": reason[:2000],
                    "evidence_path": relative,
                    "evidence_sha256": hashlib.sha256((output / relative).read_bytes()).hexdigest()})
                reviews.append({"task_id": tid, "attempt": row["attempt"], "decision": decision,
                                "status": outcome["status"], "findings": findings})
                if outcome["status"] == "accepted":
                    upstream.update(accepted_facts(store, output, tid))
            state = store.status()
            if state["completed"]:
                # A duplicate delivery notice must be idempotent, never a re-run.
                final_result = json.loads(store.row("audit")["result"])
                duplicate = store.submit(final_result)
                return report(output, plan, config, batches, reviews, store.status(),
                              duplicate, started, blocked=False)
            stuck = [t["id"] for t in state["tasks"] if t["status"] == "blocked"]
            stalled = not state["ready"] and not [t for t in state["tasks"]
                                                  if t["status"] in ("leased", "uncertain",
                                                                     "submitted", "pending")]
            if stuck or stalled:
                return report(output, plan, config, batches, reviews, state, None,
                              started, blocked=True, stuck=stuck)
    with TeamStore(output) as store:
        state = store.status()
    return report(output, plan, config, batches, reviews, state, None, started, blocked=True)


def report(output: Path, plan: dict, config: dict, batches: list, reviews: list,
           state: dict, duplicate: dict | None, started: float, *, blocked: bool,
           stuck: list[str] | None = None) -> dict:
    calls = call_records(output)
    adapter = next(iter(config["adapters"].values()))
    payload = {
        "execution": "EXECUTED",
        "outcome": "BLOCKED" if blocked else "PASS",
        "evidence_kind": "RUNTIME_FACT",
        "scope": ("one four-task demo through a configured command-backed model interface; "
                  "local protocol verification only; backend identity and model capability unverified"),
        "run_id": plan["run_id"],
        "job": str(output),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(started)),
        "wall_clock_seconds": round(time.time() - started, 3),
        "model_bridge_calls": {
            "status": "EXECUTED" if calls else "NOT_EXECUTED",
            "mode": "command",
            "adapter_argv": adapter["argv"],
            "adapter_timeout_seconds": adapter["timeout_seconds"],
            "provider": sorted({c["provider"] for c in calls if c.get("provider")}),
            "model": sorted({c["model"] for c in calls if c.get("model")}),
            "model_calls": len(calls),
            "model_calls_by_task": {tid: sum(1 for c in calls if c["task_id"] == tid)
                                    for tid in sorted({c["task_id"] for c in calls})},
            "unparseable_replies": sum(1 for c in calls if c.get("parsed") is False),
            "failed_or_unresolved_calls": sum(1 for c in calls if c.get("parsed") is None),
            "max_concurrent_model_calls": int(os.environ.get("AGI_MODEL_MAX_CONCURRENT", "0")),
            "model_seconds_total": round(sum(c.get("seconds") or 0 for c in calls), 3),
            "cost_usd_reported_by_wrapper": round(
                sum(c.get("cost_usd") or 0 for c in calls), 6) or None,
            "calls": calls,
        },
        "native_subagents": "NOT_EXECUTED",
        "model_identity_verified": False,
        "real_model_run": "UNVERIFIED_COMMAND_BACKEND",
        "native_subagents_reason": ("No host delegation tool was discovered for this session; "
                                    "per references/host-bridge.md a native run stays "
                                    "NOT_EXECUTED rather than being simulated."),
        "batches": batches,
        "reviews": reviews,
        "blocked_tasks": stuck or [],
        "duplicate_receipt": duplicate,
        "final": state,
        "not_verified": NOT_CHECKED,
    }
    write_json(output / "demo-report.json", payload)
    return payload


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--output", type=Path, help="new job directory (must not exist)")
    parser.add_argument("--emit-adapters", type=Path,
                        help="write an adapters file re-pinned to this checkout and exit")
    parser.add_argument("--provider", choices=("command", "anthropic_api"))
    parser.add_argument("--model-id")
    parser.add_argument("--model-command", help="JSON argv array for --provider command")
    parser.add_argument("--max-calls", type=int, default=12)
    parser.add_argument("--timeout-seconds", type=int, default=300)
    parser.add_argument("--parse-retries", type=int, default=1)
    parser.add_argument("--max-concurrent", type=int, default=0,
                        help="in-flight model calls across all workers (0 = unlimited)")
    args = parser.parse_args(argv)

    config = resolve_adapters()
    if args.emit_adapters:
        write_json(args.emit_adapters.absolute(), config)
        print(json.dumps({"written": str(args.emit_adapters.absolute())}))
        return 0
    if args.output is None:
        parser.error("--output is required unless --emit-adapters is used")

    if args.provider:
        os.environ["AGI_MODEL_PROVIDER"] = args.provider
    if args.model_id:
        os.environ["AGI_MODEL_ID"] = args.model_id
    if args.model_command:
        json.loads(args.model_command)  # fail here, not inside a worker
        os.environ["AGI_MODEL_COMMAND"] = args.model_command
    output = args.output.absolute()
    os.environ["AGI_MODEL_BUDGET_DIR"] = str(output.parent / (output.name + "-budget"))
    os.environ["AGI_MODEL_MAX_CALLS"] = str(args.max_calls)
    os.environ["AGI_MODEL_TIMEOUT_SECONDS"] = str(args.timeout_seconds)
    os.environ["AGI_MODEL_PARSE_RETRIES"] = str(args.parse_retries)
    os.environ["AGI_MODEL_MAX_CONCURRENT"] = str(args.max_concurrent)
    if not os.environ.get("AGI_MODEL_PROVIDER"):
        print(json.dumps({"error": "CONFIG", "message": "--provider or AGI_MODEL_PROVIDER "
                                                        "must select a model backend"}),
              file=sys.stderr)
        return 2
    try:
        payload = run(output, config)
    except TeamError as exc:
        print(json.dumps({"error": exc.code, "message": str(exc)}, ensure_ascii=False),
              file=sys.stderr)
        return 1
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload["outcome"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
