"""Additive v3 diagnostics; legacy concerns remain blocking."""
from intelligence_common import obj, names
FIELDS={'blockers','warnings','environment_notes'}

def validate_diagnostics(value: dict) -> dict:
    obj(value,set(),FIELDS)
    for k,v in value.items(): names(v,k)
    return value

def blocking_items(result: dict) -> list[str]:
    return list(dict.fromkeys(result.get('concerns',[])+result.get('blockers',[])))
