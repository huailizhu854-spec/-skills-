"""Small, strict shared helpers. No network, imports from task text, or eval."""
from __future__ import annotations
import json
import math
import os
from pathlib import Path
import re
import unicodedata
from typing import Any
from v3_protocol import strict_loads, digest, canonical

class IntelligenceError(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)

def ensure(ok: Any, code: str, message: str) -> None:
    if not ok:
        raise IntelligenceError(code, message)

def obj(value: Any, required: set[str], optional: set[str] = frozenset()) -> dict:
    ensure(isinstance(value, dict), 'SCHEMA', 'Expected an object')
    ensure(required <= value.keys() <= required | optional, 'SCHEMA',
           'Missing or unknown fields: ' + str(sorted(required ^ (set(value) - optional))))
    return value

def string(value: Any, name: str, limit: int = 16000) -> str:
    ensure(isinstance(value, str) and bool(value.strip()) and len(value) <= limit
           and not any(unicodedata.category(c).startswith('C') and c not in '\n\r\t' for c in value),
           'TEXT', name + ' must be nonempty bounded text without invisible controls')
    return value

def names(value: Any, name: str, limit: int = 128) -> list[str]:
    ensure(isinstance(value, list) and len(value) <= limit, 'SCHEMA', name + ' must be a bounded list')
    for item in value:
        string(item, name, 2000)
    ensure(len(set(value)) == len(value), 'DUPLICATE', name + ' contains duplicates')
    return value

def integer(value: Any, low: int, high: int, name: str) -> int:
    ensure(type(value) is int and low <= value <= high, 'NUMBER', name + ' outside bounds')
    return value

def boolean(value: Any, name: str) -> bool:
    ensure(type(value) is bool, 'SCHEMA', name + ' must be boolean')
    return value

def finite(value: Any, low: float, high: float, name: str) -> float:
    ensure(type(value) in (int, float) and math.isfinite(value) and low <= value <= high,
           'NUMBER', name + ' must be finite and bounded')
    return value

def normalized(text: str) -> str:
    return unicodedata.normalize('NFKC', text).casefold()

def contains(text: str, term: str) -> bool:
    text, term = normalized(text), normalized(term)
    if re.fullmatch(r'[a-z0-9_+.-]+', term):
        return bool(re.search(r'(?<![a-z0-9_])' + re.escape(term) + r'(?![a-z0-9_])', text))
    return term in text

def terms(text: str) -> set[str]:
    text = normalized(text)
    result = set(re.findall(r'[a-z0-9_]{2,}', text))
    for part in re.findall(r'[\u3400-\u9fff]+', text):
        result.update(part[i:i+2] for i in range(max(0, len(part)-1)))
        if len(part) == 1:
            result.add(part)
    return result

def read_json(path: Path) -> Any:
    ensure(path.stat().st_size <= 8 * 1024 * 1024, 'SIZE', 'JSON input exceeds 8 MiB')
    return strict_loads(path.read_text(encoding='utf-8'))

def write_new(path: Path, value: Any) -> None:
    """Exclusive write: a repeated command never silently overwrites a handoff."""
    path = Path(path).absolute()
    for part in (path, *path.parents):
        ensure(not part.is_symlink(), 'PATH', 'Symlink output paths are forbidden')
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    with path.open('x', encoding='utf-8', newline='\n') as f:
        f.write(raw)
