"""Version 3 contract semantics. Pure validation; no executable plan strings."""
from __future__ import annotations
import hashlib
import json
from typing import Any

# Keep the wire protocol closed to reviewed implementations (not candidate JSON entries).
# workbuddy_mobile_cloud joined on 2026-09-23 with a reviewed adapter and live
# evidence (WB-01/WB-01B/WB-02); the desktop candidate remains excluded.
HOSTS = {'codex_native', 'claude_code_native', 'bounded_model', 'fixture',
         'workbuddy_mobile_cloud'}
CAPABILITIES = {'network', 'shell', 'model_delegation', 'external_write'}


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def strict_loads(raw: str) -> Any:
    def pairs(items):
        obj = {}
        for key, value in items:
            if key in obj:
                raise ValueError('Duplicate JSON key: ' + key)
            obj[key] = value
        return obj
    def constant(value):
        raise ValueError('Non-finite JSON number: ' + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)


def subject_ids(spec: dict, task: dict) -> list[str]:
    subject = spec.get('subject')
    if not isinstance(subject, dict):
        raise ValueError('v3 acceptance needs an explicit subject')
    scope = subject.get('scope')
    if scope == 'artifact' and set(subject) == {'scope', 'artifact_id'}:
        ids = [subject['artifact_id']]
    elif scope == 'cross-artifact' and set(subject) == {'scope', 'artifact_ids'}:
        ids = subject['artifact_ids']
    elif scope == 'task' and set(subject) == {'scope', 'task_id'} and subject['task_id'] == task['id']:
        ids = [a['id'] for a in task['outputs']]
    else:
        raise ValueError('Unsupported/malformed subject scope; no first-output fallback')
    available = set(task['reads']) | {a['id'] for a in task['outputs']}
    if (not isinstance(ids, list) or not ids or not all(isinstance(x, str) for x in ids)
            or len(ids) != len(set(ids)) or not set(ids) <= available):
        raise ValueError('Subject must name unique assigned output/input artifacts')
    return sorted(ids)


def validate_task(task: dict) -> None:
    executor = task.get('executor')
    caps = task.get('capabilities')
    if (not isinstance(executor, dict) or set(executor) != {'type', 'transport_network'}
            or executor['type'] not in HOSTS or type(executor['transport_network']) is not bool):
        raise ValueError('v3 executor requires type and explicit transport_network')
    if not isinstance(caps, dict) or set(caps) != CAPABILITIES or any(type(v) is not bool for v in caps.values()):
        raise ValueError('v3 capabilities must explicitly set four boolean permissions')
    if executor['type'] in {'bounded_model', 'codex_native', 'claude_code_native', 'workbuddy_mobile_cloud'} and not executor['transport_network']:
        raise ValueError('Model/native transport needs explicit network-substrate authorization; use fixture for offline protocol tests')
    if caps['model_delegation'] or caps['external_write']:
        raise ValueError('Leaf recursion and external writes are not supported by this artifact kernel')
    if executor['type'] == 'bounded_model' and any(caps.values()):
        raise ValueError('Bounded text model has no task tools; use native host for tool tasks')
    if executor['type'] == 'fixture' and executor['transport_network']:
        raise ValueError('Fixture transport is offline')
    for spec in task['acceptance']:
        subject_ids(spec, task)
        if not isinstance(spec.get('params', {}), dict):
            raise ValueError('Verifier params must be an object, never executable text')


def subject_hashes(spec: dict, packet: dict, artifacts: list[dict]) -> dict[str, str]:
    hashes = {x['id']: x['sha256'] for x in packet['input_snapshots']}
    hashes.update({x['id']: x['sha256'] for x in artifacts})
    return {aid: hashes[aid] for aid in subject_ids(spec, packet['contract'])}


def pending_checks(packet: dict, artifacts: list[dict], evidence_path: str, evidence_sha256: str) -> list[dict]:
    """A producer can report availability, NEVER infer requirement success."""
    return [{'id': spec['id'], 'execution': 'NOT_EXECUTED', 'outcome': 'UNVERIFIED',
             'evidence_kind': spec['evidence_kind'], 'method': spec['method'],
             'subject': spec['subject'], 'subject_hashes': subject_hashes(spec, packet, artifacts),
             'evidence_path': evidence_path, 'evidence_sha256': evidence_sha256}
            for spec in packet['contract']['acceptance']]
