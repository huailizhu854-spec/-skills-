"""3.4 lifecycle safeguards inside the existing TeamStore ledger.

No scheduler, model client, host tool, or second task owner is created here.
Coordinator observations are hash-bound evidence, NOT provider authentication.
The guarded lifecycle is entered explicitly BEFORE dispatch by begin_submission.
"""
from __future__ import annotations
import json
import time
from pathlib import Path
from kernel import checked_root, local_file, load_json, sha
from team_runtime import require, fields, identifier, text, canonical, digest

TERMINAL = {'SUCCEEDED', 'FAILED', 'CANCELLED', 'NOT_CREATED'}
OBSERVATIONS = {'started':'RUNNING', 'running':'RUNNING', 'succeeded':'SUCCEEDED',
                'failed':'FAILED', 'cancelled':'CANCELLED', 'not_created':'NOT_CREATED', 'unknown':'UNKNOWN'}
CHECKPOINT_EVENTS = {'CLAIMED','HOST_BOUND','SUBMITTED','REVIEWED','LEASE_UNCERTAIN',
                     'HOST_UNCERTAIN','RECOVERED','SUPERSEDED','SUCCESSOR_CREATED',
                     'SUBMISSION_RESERVED','HOST_OBSERVED','CANCEL_REQUESTED','QUALITY_REVIEWED'}

def create_schema(db):
    db.executescript('''
    CREATE TABLE dispatch34 (
      token TEXT PRIMARY KEY, task_id TEXT NOT NULL, request_key TEXT UNIQUE NOT NULL,
      goal_digest TEXT NOT NULL, plan_digest TEXT NOT NULL, state TEXT NOT NULL,
      host_run_id TEXT, guarded INTEGER NOT NULL DEFAULT 0, started REAL NOT NULL, updated REAL NOT NULL);
    CREATE TABLE observations34 (id TEXT PRIMARY KEY, token TEXT NOT NULL, payload_hash TEXT NOT NULL, payload TEXT NOT NULL);
    CREATE TABLE checkpoints34 (seq INTEGER PRIMARY KEY AUTOINCREMENT, at REAL NOT NULL, reason TEXT NOT NULL,
      payload TEXT NOT NULL, payload_hash TEXT NOT NULL);
    ''')

def available(store):
    return store.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='dispatch34'").fetchone() is not None

def need_schema(store):
    require(available(store), 'NEW_JOB_REQUIRED', 'Do not migrate a running 3.3 ledger; create a new 3.4 job directory')

def dispatch(store, token):
    need_schema(store)
    row = store.db.execute('SELECT * FROM dispatch34 WHERE token=?',(token,)).fetchone()
    require(row is not None, 'DISPATCH_MISSING','Claim the task before managing dispatch')
    return row

def _update(store, token, state, run_id=None):
    store.db.execute('UPDATE dispatch34 SET state=?,host_run_id=COALESCE(?,host_run_id),updated=? WHERE token=?',
                     (state,run_id,time.time(),token))

def save_checkpoint(store, reason):
    """Called inside the same SQLite transaction as the state change. No full chat."""
    from workbuddy_policy import guard_writes
    guard_writes(store)
    need_schema(store)
    plan=store.meta('plan')
    tasks=[{k:r[k] for k in ('id','work_key','status','attempt','token','host_run_id','mode')}
           for r in store.db.execute('SELECT * FROM tasks ORDER BY id')]
    artifacts=[{k:r[k] for k in ('id','storage','sha256','producer')}
               for r in store.db.execute('SELECT * FROM artifacts ORDER BY id')]
    open_tasks=[r['id'] for r in tasks if r['status'] not in ('accepted','cancelled')]
    value={'schema_version':1,'goal':plan['goal'], 'goal_digest':store.meta('goal_digest'),
           'plan_digest':store.meta('plan_digest'),'state':store.meta('state'),
           'tasks':tasks,'artifacts':artifacts,'open_tasks':open_tasks,
           'next_action':'Recheck ledger and artifacts, then query original host before any retry',
           'authority':'Checkpoint is a recovery hint; frozen goal, ledger and evidence remain authoritative'}
    raw=canonical(value)
    cur=store.db.execute('INSERT INTO checkpoints34(at,reason,payload,payload_hash) VALUES (?,?,?,?)',
                         (time.time(),reason,raw,digest(value)))
    return {'seq':cur.lastrowid,'reason':reason,'payload_hash':digest(value)}

def on_event(store, kind, tid, detail):
    if not available(store): return  # No implicit migration of legacy jobs.
    if kind=='CLAIMED':
        r=store.row(tid); token=r['token'];now=time.time()
        key='dispatch-'+digest([store.meta('plan_digest'),tid,token])
        store.db.execute('INSERT INTO dispatch34 VALUES (?,?,?,?,?,?,NULL,0,?,?)',
                         (token,tid,key,store.meta('goal_digest'),store.meta('plan_digest'),'PREPARED',now,now))
    elif kind=='HOST_BOUND':
        r=store.row(tid);d=dispatch(store,r['token'])
        _update(store,r['token'],'RUNNING',detail['host_run_id'])
    elif kind=='SUBMITTED':
        r=store.row(tid)
        _update(store,r['token'],'SUCCEEDED',r['host_run_id'])
    elif kind in ('LEASE_UNCERTAIN','HOST_UNCERTAIN'):
        r=store.row(tid);d=dispatch(store,r['token'])
        if d['state'] not in TERMINAL and d['state']!='CANCEL_REQUESTED': _update(store,r['token'],'UNKNOWN')
    if kind in CHECKPOINT_EVENTS: save_checkpoint(store,kind)

def begin_submission(store, tid, token):
    """Reserve once BEFORE the real host call. Repeating never authorizes resend."""
    with store.transaction():
        r=store.bound(tid,token,states={'leased'})
        guard_context(store, tid)
        contract=json.loads(r['contract'])
        if 'intelligence' in contract:
            from intelligence_layer import ensure_context_fresh
            ensure_context_fresh(contract['intelligence']['context'])
        d=dispatch(store,token)
        require(r['mode'] is None and r['host_run_id'] is None,'ALREADY_BOUND','Host already exists')
        require(d['state']=='PREPARED' and not d['guarded'],'SUBMISSION_UNKNOWN',
                'A previous dispatch may have reached the host. Query it; do not send another create')
        host=json.loads(r['contract']).get('executor',{}).get('type','fixture')
        from host_registry import execution_mode
        execution_mode(host)  # A JSON catalog entry cannot grant execution.
        if host == 'workbuddy_mobile_cloud':
            from workbuddy_policy import capabilities
            capabilities(store, packet=json.loads(r['packet']))
        store.db.execute('UPDATE dispatch34 SET state=?,guarded=1,updated=? WHERE token=?',('SUBMITTING',time.time(),token))
        store.event('SUBMISSION_RESERVED',tid,request_key=d['request_key'],execution='NOT_EXECUTED')
        from workbuddy_policy import meta_or
        profile=meta_or(store,'execution_profile','existing_host')
        return {'request_key':d['request_key'],'state':'SUBMITTING','execution':'NOT_EXECUTED',
                'execution_profile':profile, 'host_call_performed':False,
                'authorization':('OFFLINE_FIXTURE: synthetic observations only; do not call a real host' if profile=='offline_fixture' else 'Local reservation for one separately authorized coordinator host call; this command does not call the host or authenticate user authorization'),
                'on_lost_receipt':'Query by this key if the host supports it; otherwise pause for reconciliation'}

def guard_workbuddy_run(store, row, run_id):
    """Apply the same mobile-only rules at every ledger entry point."""
    if json.loads(row['contract']).get('executor', {}).get('type') == 'workbuddy_mobile_cloud':
        d = dispatch(store, row['token'])
        require(d['guarded'] == 1, 'LIFECYCLE_NOT_ENABLED',
                'WorkBuddy Mobile Cloud requires begin-submit before every real create')
        for previous in store.db.execute(
                'SELECT d.token,t.contract FROM dispatch34 d JOIN tasks t ON t.id=d.task_id '
                'WHERE d.host_run_id=? AND d.token<>?', (run_id, row['token'])):
            require(json.loads(previous['contract']).get('executor', {}).get('type')
                    != 'workbuddy_mobile_cloud', 'RUN_COLLISION',
                    'A WorkBuddy Agent ID cannot identify two different attempts in this job')


def guard_bind(store, row, run_id):
    guard_workbuddy_run(store, row, run_id)
    from workbuddy_policy import guard_success
    guard_success(store, row, run_id)
    if not available(store): return
    d=dispatch(store,row['token'])
    require(d['state'] not in TERMINAL and d['state']!='CANCEL_REQUESTED','HOST_STATE','Cannot bind a ended/cancelling dispatch')
    require(d['host_run_id'] in (None,run_id),'RUN_COLLISION','Attempt is already bound to another host run')

def request_cancel(store, tid, token):
    with store.transaction():
        r=store.bound(tid,token,states={'leased','uncertain'},fresh=False)
        d=dispatch(store,token)
        require(d['state'] not in TERMINAL,'HOST_TERMINAL','Host already ended; verify its result or failure')
        _update(store,token,'CANCEL_REQUESTED')
        store.db.execute("UPDATE tasks SET status='uncertain' WHERE id=?",(tid,))
        store.event('CANCEL_REQUESTED',tid,request_key=d['request_key'],host_run_id=d['host_run_id'])
        return {'state':'CANCEL_REQUESTED','stop_confirmed':False,'host_call_performed':False,
                'next_action':'Invoke the actual host stop tool, then record its confirmed terminal observation'}

def observe(store, event):
    """Consume a coordinator-normalized, raw-evidence-backed observation.

    Unknown response schemas must NOT be guessed by this function's caller.
    Supported existing adapters remain observational. WorkBuddy Mobile Cloud
    supports terminal observation only; it has no asynchronous lifecycle transport.
    """
    fields(event,{'id','task_id','lease_token','request_key','goal_digest','plan_digest',
                  'event','host_run_id','tool','evidence_path','evidence_sha256'})
    identifier(event['id'],'observation.id'); text(event['tool'],'tool')
    require(event['event'] in OBSERVATIONS,'HOST_EVENT','Unsupported lifecycle observation')
    with store.transaction():
        d=dispatch(store,event['lease_token']);r=store.row(event['task_id'])
        require(d['task_id']==event['task_id'] and r['token']==event['lease_token'], 'FENCED_TOKEN','Old/wrong attempt')
        require(event['goal_digest']==d['goal_digest']==store.meta('goal_digest') and
                event['plan_digest']==d['plan_digest']==store.meta('plan_digest') and
                event['request_key']==d['request_key'], 'HOST_BINDING','Wrong goal, plan or request binding')
        require(d['guarded']==1,'LIFECYCLE_NOT_ENABLED','Call begin-submit before using guarded lifecycle observations')
        wb_success = json.loads(r['contract']).get('executor', {}).get('type') == 'workbuddy_mobile_cloud' and event['event'] == 'succeeded'
        require(isinstance(event['evidence_path'],str) and (event['evidence_path'].startswith('reviews/') or wb_success),
                'HOST_EVIDENCE','Coordinator evidence must be under reviews/')
        info=local_file(store.root,event['evidence_path'])
        require(info['sha256']==event['evidence_sha256'],'HOST_EVIDENCE','Missing or changed raw observation')
        raw=(store.root/event['evidence_path']).read_text(encoding='utf-8')
        run_id=event['host_run_id'];target=OBSERVATIONS[event['event']]
        if target in ('NOT_CREATED','UNKNOWN'):
            require(run_id is None or (isinstance(run_id,str) and bool(run_id.strip())), 'HOST_ID','Invalid run identifier')
        else: text(run_id,'host_run_id')
        require((run_id is not None and run_id in raw) or d['request_key'] in raw,'HOST_EVIDENCE','Raw observation lacks run/request identifier')
        require(d['host_run_id'] in (None,run_id) or (target=='UNKNOWN' and run_id is None), 'RUN_COLLISION','Different host run for same attempt')
        require(r['host_run_id'] in (None,run_id) or (target=='UNKNOWN' and run_id is None), 'RUN_COLLISION','Ledger host run differs')
        if wb_success:
            from workbuddy_policy import guard_success
            guard_success(store, r, run_id, event, lifecycle=True)
        old=store.db.execute('SELECT * FROM observations34 WHERE id=?',(event['id'],)).fetchone()
        if old:
            require(old['payload_hash']==digest(event),'OBSERVATION_COLLISION','Observation ID reused with changed payload')
            return {'duplicate':True,'state':d['state'],'business_acceptance':'UNVERIFIED'}
        require(r['status'] in ('leased','uncertain','submitted','accepted'),'STATE','Attempt no longer owns the task')
        if json.loads(r['contract']).get('executor', {}).get('type') == 'workbuddy_mobile_cloud':
            guard_workbuddy_run(store, r, run_id)
            if target == 'SUCCEEDED':
                from host_adapters.workbuddy_contract import validate_sync_terminal_observation
                validate_sync_terminal_observation(raw, run_id)
        if target=='NOT_CREATED':
            require(d['host_run_id'] is None and run_id is None and d['state'] in ('SUBMITTING','UNKNOWN','CANCEL_REQUESTED'),
                    'HOST_CONTRADICTION','Cannot claim not-created after a host run exists')
        if d['state'] in TERMINAL:
            require(target not in TERMINAL or target==d['state'],'HOST_CONTRADICTION','Conflicting terminal observations require investigation')
            effective=d['state']  # Never regress on a late running/unknown observation.
        elif d['state']=='CANCEL_REQUESTED' and target in ('RUNNING','UNKNOWN'):
            effective='CANCEL_REQUESTED'
        else: effective=target
        if run_id and r['host_run_id'] is None:
            from host_registry import execution_mode
            host=json.loads(r['contract']).get('executor',{}).get('type','fixture')
            mode=execution_mode(host)
            store.db.execute('UPDATE tasks SET host_run_id=?,mode=? WHERE id=?',(run_id,mode,r['id']))
        _update(store,d['token'],effective,run_id)
        if effective in ('UNKNOWN','CANCEL_REQUESTED','FAILED','CANCELLED','NOT_CREATED') and r['status']=='leased':
            store.db.execute("UPDATE tasks SET status='uncertain' WHERE id=?",(r['id'],))
        store.db.execute('INSERT INTO observations34 VALUES (?,?,?,?)',(event['id'],d['token'],digest(event),canonical(event)))
        store.event('HOST_OBSERVED',r['id'],observation_id=event['id'],state=effective,
                    evidence_path=event['evidence_path'],evidence_sha256=event['evidence_sha256'])
        return {'duplicate':False,'state':effective,'business_acceptance':'UNVERIFIED',
                'note':'Coordinator observation, not provider identity attestation; success still needs collect + independent review'}

def guard_recovery(store, row, request):
    if not available(store): return
    d=dispatch(store,row['token'])
    if not d['guarded']: return  # Explicit legacy path, not a newly guaranteed lifecycle.
    require(d['state'] in TERMINAL,'HOST_STILL_UNKNOWN','No retry until host termination/non-creation is confirmed')
    want='confirmed_not_started' if d['state']=='NOT_CREATED' else 'confirmed_stopped'
    require(request['termination']==want,'RECOVERY_CONTRADICTION','Termination receipt conflicts with host lifecycle')
    if request.get('action','retry')=='adopt_finished':
        require(d['state']=='SUCCEEDED','NO_SUCCESS_RESULT','Only confirmed success can adopt a late output')
    # Recheck raw observations: a terminal row alone is not sufficient evidence.
    evidence=list(store.db.execute('SELECT payload FROM observations34 WHERE token=?',(row['token'],)))
    matches=[json.loads(x[0]) for x in evidence if OBSERVATIONS[json.loads(x[0])['event']]==d['state']]
    require(bool(matches),'HOST_EVIDENCE','Missing terminal observation')
    for e in matches:
        require(local_file(store.root,e['evidence_path'])['sha256']==e['evidence_sha256'],
                'HOST_EVIDENCE','Terminal evidence changed')

def resume_plan(store, inputs_root=None):
    """Read-only reconciliation advice. Never resume/retry based on a summary."""
    need_schema(store)
    with store.transaction(readonly=True):
        status=store._status(); reasons=[]
        cp=store.db.execute('SELECT * FROM checkpoints34 ORDER BY seq DESC LIMIT 1').fetchone()
        require(cp is not None,'CHECKPOINT_MISSING','No task checkpoint')
        payload=json.loads(cp['payload'])
        if digest(payload)!=cp['payload_hash']: reasons.append('CHECKPOINT_TAMPERED')
        if payload.get('goal_digest')!=store.meta('goal_digest') or payload.get('plan_digest')!=store.meta('plan_digest'):
            reasons.append('CHECKPOINT_CONFLICT')
        if not status['plan_integrity'] or status['changed_artifacts'] or status['changed_evidence']: reasons.append('LEDGER_OR_ARTIFACT_CHANGED')
        for task_row in store.db.execute('SELECT id FROM tasks'):
            try: guard_context(store, task_row['id'])
            except ValueError: reasons.append('CONTEXT_REVOKED:'+task_row['id'])
        if payload.get('state')!=store.meta('state'):
            reasons.append('CHECKPOINT_STATE_CONFLICT')
        changed_inputs=[]
        if inputs_root is not None:
            source=checked_root(inputs_root)
            for src in store.meta('plan')['inputs']:
                try: same=local_file(source,src['path'])['sha256']==src['sha256']
                except (ValueError,OSError): same=False
                if not same: changed_inputs.append(src['id'])
            if changed_inputs: reasons.append('EXTERNAL_MATERIAL_CHANGED')
        actions=[]
        for r in store.db.execute('SELECT * FROM tasks ORDER BY id'):
            if r['status'] in ('leased','uncertain'):
                d=dispatch(store,r['token'])
                action=('RECOVERY_REVIEW_REQUIRED' if d['state'] in TERMINAL else
                        'QUERY_ORIGINAL_HOST' if (d['guarded'] or r['host_run_id']) else 'VERIFY_NOT_STARTED')
                actions.append({'task_id':r['id'],'action':action,'host_run_id':r['host_run_id'],
                                'request_key':d['request_key'],'state':d['state'],'retry_authorized':False})
            elif r['status']=='submitted': actions.append({'task_id':r['id'],'action':'INDEPENDENT_REVIEW','retry_authorized':False})
        return {'checkpoint_seq':cp['seq'],'state':status['state'],'completed':status['completed'] and not reasons,
                'blockers':reasons,'changed_inputs':changed_inputs,'actions':actions,
                'ready':status['ready'] if not reasons else [],'host_queries_executed':0,
                'external_materials_checked':inputs_root is not None,
                'memory_note':'Checkpoint is task state, not approval for long-term memory; revoked memory requires explicit goal review'}

def usage_summary(store):
    rows=list(store.db.execute('SELECT * FROM tasks'))
    events=list(store.db.execute('SELECT at,kind,task_id FROM events ORDER BY seq'))
    active=set();peak=0
    for e in events:
        if e['kind']=='CLAIMED': active.add(e['task_id']);peak=max(peak,len(active))
        elif e['kind'] in ('SUBMITTED','RECOVERED','REVIEWED'): active.discard(e['task_id'])
    return {'worker_attempts':sum(r['attempt'] for r in rows),'peak_outstanding_ledger_leases':peak,
            'elapsed_seconds':max(0,time.time()-store.meta('created')),
            'model_requests':None,'tokens':None,'cost':None,'actual_host_concurrency':None,
            'measurement':'Ledger elapsed wall time and leases only; leases/attempts are NOT model calls or confirmed active host workers'}

def invalidate_memory(store, project_id, record_ids, reason):
    """Explicit coordinator notification after approved deletion/replacement.

    No hidden DB watcher. External memory edits must be notified; existing frozen
    bytes are retained for task audit, not advertised as secure erasure.
    """
    text(project_id,'project_id');text(reason,'reason')
    require(isinstance(record_ids,list) and bool(record_ids) and
            all(isinstance(x,str) and x.strip() for x in record_ids),'MEMORY_IDS','Nonempty record IDs required')
    with store.transaction():
        store.active();affected=[]
        for row in store.db.execute('SELECT * FROM tasks'):
            capsule=json.loads(row['contract']).get('intelligence',{}).get('context',{})
            if capsule.get('project_id')==project_id and set(record_ids)&{r['id'] for r in capsule.get('memory_records',[])}:
                affected.append(row['id'])
        store.event('CONTEXT_INVALIDATED',None,project_id=project_id,record_ids=sorted(set(record_ids)),
                    reason=reason,affected_tasks=sorted(affected))
        if available(store):save_checkpoint(store,'CONTEXT_INVALIDATED')
        return {'affected_tasks':sorted(affected),'action':'Blocked claim/acceptance; revise the goal into a new job after reconciling old hosts',
                'old_artifacts_deleted':False,'secure_erasure_guaranteed':False}

def guard_context(store, tid):
    contract=json.loads(store.row(tid)['contract'])
    capsule=contract.get('intelligence',{}).get('context',{})
    if not capsule:return
    ids={r['id'] for r in capsule.get('memory_records',[])}
    for e in store.db.execute("SELECT detail FROM events WHERE kind='CONTEXT_INVALIDATED'"):
        detail=json.loads(e[0])
        require(detail['project_id']!=capsule.get('project_id') or not ids & set(detail['record_ids']),
                'CONTEXT_REVOKED','A frozen memory record was revoked/replaced; revise and revalidate, never silently reuse it')
