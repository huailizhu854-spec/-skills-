"""Local SQLite semaphore. No TTL/PID reclamation; uncertain remote calls keep slots.

Same-host, local-filesystem, cooperating processes only. All participants must
share one directory and one positive limit. Database deletion/admin tampering,
NFS/distributed locking and an unlimited caller are outside this guarantee.
"""
from __future__ import annotations
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import time
import uuid


class SemaphoreError(ValueError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


class ConcurrencyGate:
    def __init__(self, limit: int, directory: Path | None, wait_seconds: float = 600):
        if type(limit) is not int or limit < 0 or wait_seconds < 0:
            raise SemaphoreError('CONFIG', 'Invalid semaphore bounds')
        if limit and directory is None:
            raise SemaphoreError('CONFIG', 'Positive concurrency limit requires a shared budget directory')
        self.limit, self.directory, self.wait_seconds = limit, directory, wait_seconds
        self.held = None
        if limit:
            from kernel import checked_root
            directory.mkdir(parents=True, exist_ok=True)
            checked_root(directory)
            self.path = directory / 'model-slots.sqlite3'
            if self.path.is_symlink():
                raise SemaphoreError('CONFIG', 'Semaphore DB cannot be a symlink')
            deadline = time.monotonic() + max(1, min(wait_seconds, 10))
            while True:
                with closing(self._connect()) as db:
                    try:
                        db.execute('BEGIN IMMEDIATE')
                        db.execute('CREATE TABLE IF NOT EXISTS config (id INTEGER PRIMARY KEY CHECK(id=1), capacity INTEGER NOT NULL)')
                        db.execute('CREATE TABLE IF NOT EXISTS slots (token TEXT PRIMARY KEY, pid INTEGER NOT NULL, state TEXT NOT NULL, started REAL NOT NULL, receipt_hash TEXT)')
                        db.execute('INSERT OR IGNORE INTO config VALUES (1, ?)', (limit,))
                        if db.execute('SELECT capacity FROM config WHERE id=1').fetchone()[0] != limit:
                            db.rollback()
                            raise SemaphoreError('CONCURRENCY_CONFIG', 'Shared semaphore capacity differs; never mix limits')
                        db.commit()
                        break
                    except sqlite3.OperationalError as exc:
                        db.rollback()
                        if 'locked' not in str(exc).lower() or time.monotonic() >= deadline:
                            raise
                time.sleep(0.01)

    def _connect(self):
        db = sqlite3.connect(str(self.path), timeout=0.1, isolation_level=None)
        db.execute('PRAGMA busy_timeout=100')
        return db

    def __enter__(self):
        if not self.limit:
            return self
        if self.held:
            raise SemaphoreError('CONCURRENCY_REENTRY', 'One gate instance cannot be entered twice')
        deadline = time.monotonic() + self.wait_seconds
        while True:
            db = self._connect()
            try:
                db.execute('BEGIN IMMEDIATE')
                count = db.execute("SELECT count(*) FROM slots WHERE state IN ('running','uncertain')").fetchone()[0]
                if count < self.limit:
                    token = uuid.uuid4().hex
                    db.execute("INSERT INTO slots VALUES (?,?,'running',?,NULL)", (token, os.getpid(), time.time()))
                    db.commit()
                    self.held = token
                    return self
                db.rollback()
            except sqlite3.OperationalError as exc:
                if 'locked' not in str(exc).lower():
                    raise
            finally:
                db.close()
            if time.monotonic() >= deadline:
                raise SemaphoreError('CONCURRENCY_WAIT', f'No confirmed-free slot within {self.wait_seconds}s')
            time.sleep(min(0.025, max(0, deadline - time.monotonic())))

    def __exit__(self, exc_type, exc_value, traceback):
        if not self.held:
            return
        # Persist the observed outcome before relinquishing local ownership.
        # An uncertain remote call still occupies capacity. Local SQLite writer
        # contention is retryable, but never authorizes silently freeing a slot.
        state = 'uncertain' if exc_type else 'released'
        release_wait = min(self.wait_seconds, 10)
        deadline = time.monotonic() + release_wait
        while True:
            try:
                with closing(self._connect()) as db:
                    remaining = max(0, deadline - time.monotonic())
                    db.execute('PRAGMA busy_timeout=' + str(min(100, int(remaining * 1000))))
                    db.execute('BEGIN IMMEDIATE')
                    changed = db.execute("UPDATE slots SET state=? WHERE token=? AND state='running'",
                                         (state, self.held)).rowcount
                    if changed != 1:
                        db.rollback()
                        raise SemaphoreError('CONCURRENCY_RELEASE_STATE',
                            'Owned running slot was not found; local ownership retained')
                    db.commit()
                self.held = None
                return
            except sqlite3.OperationalError as exc:
                code = getattr(exc, 'sqlite_errorcode', None)
                locked = ((code & 0xff) in (sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED)
                          if code is not None else 'locked' in str(exc).lower())
                if not locked:
                    raise
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise SemaphoreError('CONCURRENCY_RELEASE_WAIT',
                        f'Could not persist slot outcome within {release_wait}s; '
                        'slot state is unconfirmed and local ownership is retained') from exc
                time.sleep(min(0.01, remaining))

    def reconcile(self, token: str, receipt_path: Path) -> None:
        from v3_protocol import strict_loads
        raw = receipt_path.read_bytes()
        receipt = strict_loads(raw.decode('utf-8'))
        if (receipt.get('owner_token') != token or receipt.get('termination') not in
                ('confirmed_stopped', 'confirmed_not_started') or not receipt.get('reason')):
            raise SemaphoreError('TERMINATION', 'A coordinator-owned token-bound termination receipt is required')
        with closing(self._connect()) as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT state FROM slots WHERE token=?', (token,)).fetchone()
            if not row or row[0] not in ('running', 'uncertain'):
                db.rollback()
                raise SemaphoreError('FENCED_TOKEN', 'No active owner with this token')
            db.execute("UPDATE slots SET state='released',receipt_hash=? WHERE token=?", (hashlib.sha256(raw).hexdigest(), token))
            db.commit()


def main():
    import argparse
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory', type=Path, required=True)
    p.add_argument('--limit', type=int, required=True)
    p.add_argument('--token', required=True)
    p.add_argument('--receipt', type=Path, required=True)
    args = p.parse_args()
    ConcurrencyGate(args.limit, args.directory).reconcile(args.token, args.receipt)
    print(json.dumps({'released': args.token, 'authority': 'coordinator assertion, not remote attestation'}))

if __name__ == '__main__':
    main()
