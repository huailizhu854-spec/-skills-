#!/usr/bin/env python3
"""3.4 local delivery controls. No command here launches a real host agent."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from kernel import load_json
from team_runtime import TeamStore
from delivery_state import begin_submission, request_cancel, observe, resume_plan, save_checkpoint, usage_summary, invalidate_memory
from delivery_quality import record_review
from delivery_brief import brief, brief_markdown, progress, change_impact
from host_contract34 import blank_probe, evaluate_probe
from doctor34 import doctor

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='action',required=True)
    sub.add_parser('doctor')
    b=sub.add_parser('brief');b.add_argument('--plan',required=True,type=Path);b.add_argument('--markdown',action='store_true')
    b.add_argument('--assumption',action='append',default=[]);b.add_argument('--missing',action='append',default=[])
    h=sub.add_parser('probe-template');h.add_argument('--host',default='workbuddy')
    h=sub.add_parser('probe-check');h.add_argument('--probe',required=True,type=Path);h.add_argument('--evidence-root',required=True,type=Path);h.add_argument('--require',action='append',default=[])
    for action in ('begin-submit','cancel-request'):
        c=sub.add_parser(action);c.add_argument('--job',required=True,type=Path);c.add_argument('--task',required=True);c.add_argument('--token',required=True)
    for action in ('observe','quality-review'):
        c=sub.add_parser(action);c.add_argument('--job',required=True,type=Path);c.add_argument('--record',required=True,type=Path)
    for action in ('resume','checkpoint','progress','usage'):
        c=sub.add_parser(action);c.add_argument('--job',required=True,type=Path)
        if action=='resume':c.add_argument('--inputs',type=Path)
    c=sub.add_parser('memory-invalidate');c.add_argument('--job',required=True,type=Path);c.add_argument('--project',required=True);c.add_argument('--record-id',required=True,action='append');c.add_argument('--reason',required=True)
    c=sub.add_parser('workbuddy-capability-template');c.add_argument('--job',required=True,type=Path)
    c=sub.add_parser('workbuddy-capability-freeze');c.add_argument('--job',required=True,type=Path);c.add_argument('--record',required=True,type=Path)
    c=sub.add_parser('impact');c.add_argument('--old-plan',required=True,type=Path);c.add_argument('--new-plan',required=True,type=Path);c.add_argument('--requirement',action='append',default=[])
    a=p.parse_args(argv)
    try:
        if a.action=='doctor':out=doctor()
        elif a.action=='brief':
            out=brief(load_json(a.plan),assumptions=a.assumption,missing_materials=a.missing)
            if a.markdown:print(brief_markdown(out));return 0
        elif a.action=='probe-template':out=blank_probe(a.host)
        elif a.action=='probe-check':out=evaluate_probe(load_json(a.probe),a.evidence_root,required=a.require)
        elif a.action=='impact':out=change_impact(load_json(a.old_plan),load_json(a.new_plan),declared_impacted=a.requirement)
        else:
            with TeamStore(a.job) as store:
                if a.action=='workbuddy-capability-template':
                    from workbuddy_policy import template
                    out=template(store)
                elif a.action=='workbuddy-capability-freeze':
                    from workbuddy_policy import freeze
                    out=freeze(store,a.record)
                elif a.action=='memory-invalidate':out=invalidate_memory(store,a.project,a.record_id,a.reason)
                elif a.action=='begin-submit':out=begin_submission(store,a.task,a.token)
                elif a.action=='cancel-request':out=request_cancel(store,a.task,a.token)
                elif a.action=='observe':out=observe(store,load_json(a.record))
                elif a.action=='quality-review':out=record_review(store,load_json(a.record))
                elif a.action=='resume':out=resume_plan(store,a.inputs)
                elif a.action=='progress':out=progress(store)
                elif a.action=='usage':out=usage_summary(store)
                elif a.action=='checkpoint':
                    from workbuddy_policy import legacy, checkpoint_readonly
                    if legacy(store):out=checkpoint_readonly(store)
                    else:
                        with store.transaction():out=save_checkpoint(store,'EXPLICIT_HANDOFF')
        print(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False))
        return 2 if isinstance(out,dict) and (out.get('blockers') or out.get('status') in ('BLOCKED','HANDOFF_ONLY')) else 0
    except (ValueError,OSError,KeyError,TypeError) as exc:
        print(json.dumps({'error':getattr(exc,'code','INPUT'),'message':str(exc)},ensure_ascii=False),file=sys.stderr);return 1
if __name__=='__main__':raise SystemExit(main())
