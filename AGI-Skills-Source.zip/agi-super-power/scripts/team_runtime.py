#!/usr/bin/env python3
"""Transactional work ledger for AGI-Super-Power v3 (Python 3.10+, stdlib).

The coordinator alone owns this database. Workers receive bounded task packets,
not database credentials. This is a cooperative scheduler, NOT an OS sandbox or
an identity service. Native/model execution is supplied by the host/adapter.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import re
import shutil
import sqlite3
import sys
import time
import unicodedata
import uuid
from typing import Any, Iterator

from kernel import ContractError, checked_root, linked, load_json, local_file, path_key, relative_path, sha, slug, RESERVED

from release_version import RUNTIME_VERSION as VERSION
from v3_protocol import validate_task, pending_checks, subject_hashes
MODES = {"native", "command", "inline", "fixture"}
ACTIVE = {"leased", "uncertain"}


class TeamError(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


def require(condition: Any, code: str, message: str) -> None:
    if not condition:
        raise TeamError(code, message)


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def text(value: Any, label: str) -> str:
    require(isinstance(value, str) and bool(value.strip()) and "\x00" not in value,
            "TEXT", label + " must be nonempty text")
    return value


def identifier(value: Any, label: str) -> str:
    require(isinstance(value, str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,79}", value),
            "ID", label + " must be a portable identifier (1-80 characters)")
    require(value.casefold() not in RESERVED, "ID_RESERVED", label + " cannot be a Windows device name")
    return value


def fields(value: Any, required: set[str], optional: set[str] | None = None) -> dict:
    require(isinstance(value, dict), "OBJECT", "Expected an object")
    require(not required - value.keys(), "FIELD_MISSING", "Missing fields: " + str(sorted(required - value.keys())))
    require(not value.keys() - required - (optional or set()), "FIELD_UNKNOWN", "Unexpected fields: " + str(sorted(value.keys() - required - (optional or set()))))
    return value


def array(value: Any, label: str, *, empty: bool = False) -> list:
    require(isinstance(value, list) and (empty or bool(value)), "ARRAY", label + " must be an array" + ("" if empty else " with items"))
    return value


def strings(value: Any, label: str, *, empty: bool = False) -> list[str]:
    items = array(value, label, empty=empty)
    for item in items:
        text(item, label)
    require(len(items) == len(set(items)), "DUPLICATE", label + " contains duplicates")
    return items


def work_key(value: Any) -> str:
    # Explicitly assigned semantic key; not a claim to understand paraphrases.
    value = text(value, "work_key")
    require(not any(unicodedata.category(c).startswith("C") and not c.isspace() for c in value), "INVISIBLE_KEY", "work_key/scope cannot contain invisible control characters")
    return " ".join(unicodedata.normalize("NFKC", value).casefold().split())


def overlapping(a: str, b: str) -> bool:
    a, b = path_key(a), path_key(b)
    return a == b or a.startswith(b + "/") or b.startswith(a + "/")


def compile_plan(plan: Any) -> dict:
    """Validate the coordinator's decomposition, never execute plan strings."""
    fields(plan, {"schema_version", "run_id", "goal", "policy", "inputs", "tasks"}, {"orchestration"})
    require(type(plan["schema_version"]) is int and plan["schema_version"] in (2, 3), "VERSION", "Expected schema_version 2 (legacy fixture) or 3")
    identifier(plan["run_id"], "run_id")
    goal = fields(plan["goal"], {"id", "version", "objective", "constraints", "non_goals", "requirements"})
    identifier(goal["id"], "goal.id")
    require(type(goal["version"]) is int and goal["version"] >= 1, "GOAL_VERSION", "Goal version must be a positive integer")
    text(goal["objective"], "objective")
    strings(goal["constraints"], "constraints", empty=True)
    strings(goal["non_goals"], "non_goals", empty=True)
    requirement_ids: set[str] = set()
    for r in array(goal["requirements"], "requirements"):
        fields(r, {"id", "text"})
        identifier(r["id"], "requirement.id"); text(r["text"], "requirement.text")
        require(r["id"] not in requirement_ids, "DUPLICATE_REQUIREMENT", r["id"])
        requirement_ids.add(r["id"])
    policy = fields(plan["policy"], {"max_parallel", "max_attempts", "max_total_attempts", "lease_seconds"})
    for name, maximum in (("max_parallel", 32), ("max_attempts", 10), ("max_total_attempts", 1000), ("lease_seconds", 86400)):
        require(type(policy[name]) is int and 1 <= policy[name] <= maximum, "POLICY", name + " is outside allowed bounds")
    require(policy["lease_seconds"] >= 5, "POLICY", "lease_seconds must be at least 5")
    artifacts: dict[str, dict] = {}
    input_paths: set[str] = set()
    for src in array(plan["inputs"], "inputs", empty=True):
        fields(src, {"id", "path", "sha256"})
        identifier(src["id"], "input.id"); relative_path(src["path"])
        require(sha(src["sha256"]), "INPUT_HASH", "Each input needs a pinned SHA-256")
        require(src["id"] not in artifacts and path_key(src["path"]) not in input_paths, "DUPLICATE_INPUT", src["id"])
        input_paths.add(path_key(src["path"]))
        artifacts[src["id"]] = {**src, "producer": None}
    tasks: dict[str, dict] = {}
    keys: set[str] = set()
    owners: dict[str, str] = {}
    scope_signatures: set[str] = set()
    coverage: set[str] = set()
    for task in array(plan["tasks"], "tasks"):
        fields(task, {"id", "role", "mission", "work_key", "scope", "requirements", "depends_on", "reads", "outputs", "steps", "tools", "boundaries", "acceptance", "reviewer"}, {"executor", "capabilities", "intelligence", "quality_gates"} if plan["schema_version"] == 3 else set())
        tid = identifier(task["id"], "task.id")
        require(tid not in tasks, "DUPLICATE_TASK", tid)
        require(slug(task["role"]), "ROLE", "Role names must use lowercase hyphenated slugs"); identifier(task["reviewer"], "reviewer")
        text(task["mission"], "mission"); text(task["scope"], "scope")
        key = work_key(task["work_key"])
        require(key not in keys, "DUPLICATE_WORK", "One owner per work_key: " + key)
        keys.add(key)
        reqs = strings(task["requirements"], "task.requirements")
        require(set(reqs) <= requirement_ids, "UNKNOWN_REQUIREMENT", tid)
        coverage.update(reqs)
        for name in ("depends_on", "reads", "tools"):
            strings(task[name], name, empty=True)
        signature = digest([work_key(task["scope"]), task["role"], sorted(task["reads"])])
        require(signature not in scope_signatures, "DUPLICATE_SCOPE", "Same role, scope and inputs with a renamed work_key: " + tid)
        scope_signatures.add(signature)
        strings(task["steps"], "steps"); strings(task["boundaries"], "boundaries")
        check_ids: set[str] = set()
        checked: set[str] = set()
        for check in array(task["acceptance"], "acceptance"):
            fields(check, {"id", "requirement", "method", "evidence_kind"}, {"subject", "params"} if plan["schema_version"] == 3 else set())
            identifier(check["id"], "check.id"); text(check["method"], "check.method")
            require(check["id"] not in check_ids, "DUPLICATE_CHECK", tid)
            require(isinstance(check["requirement"], str) and check["requirement"] in reqs, "CHECK_REQUIREMENT", tid)
            require(check["evidence_kind"] in ("SOURCE_FACT", "RUNTIME_FACT"), "EVIDENCE_KIND", tid)
            checked.add(check["requirement"]); check_ids.add(check["id"])
        require(checked == set(reqs), "CHECK_COVERAGE", tid)
        for out in array(task["outputs"], "outputs"):
            fields(out, {"id", "path"})
            identifier(out["id"], "output.id"); relative_path(out["path"])
            require(out["id"] not in artifacts, "DUPLICATE_ARTIFACT", out["id"])
            for path, owner in owners.items():
                require(not overlapping(out["path"], path), "OUTPUT_OWNERSHIP", f"{tid} and {owner}: {out['path']} / {path}")
            owners[out["path"]] = tid
            artifacts[out["id"]] = {**out, "producer": tid}
        if plan["schema_version"] == 3:
            try:
                validate_task(task)
                if "quality_gates" in task:
                    from delivery_quality import validate_gates
                    validate_gates(task)
                if "intelligence" in task:
                    from intelligence_layer import validate_extension
                    validate_extension(task, goal, policy)
            except ValueError as exc:
                raise TeamError("V3_CONTRACT", str(exc)) from exc
        tasks[tid] = task
    require(coverage == requirement_ids, "GOAL_COVERAGE", "Unassigned goal requirements: " + str(sorted(requirement_ids - coverage)))
    for tid, task in tasks.items():
        require(set(task["depends_on"]) <= tasks.keys() and tid not in task["depends_on"], "DEPENDENCY", tid)
        for aid in task["reads"]:
            require(aid in artifacts, "UNKNOWN_INPUT", aid)
            producer = artifacts[aid]["producer"]
            require(producer is None or producer in task["depends_on"], "READ_DEPENDENCY", tid + " must directly depend on " + str(producer))
    remaining, done, waves = set(tasks), set(), []
    while remaining:
        wave = sorted(t for t in remaining if set(tasks[t]["depends_on"]) <= done)
        require(bool(wave), "CYCLE", "Dependency graph contains a cycle")
        waves.append(wave); done.update(wave); remaining.difference_update(wave)
    from dual16 import validate as validate_dual16
    validate_dual16(plan)
    return {"valid": True, "version": VERSION, "plan_digest": digest(plan), "goal_digest": digest(goal),
            "waves": waves, "owners": owners, "covered_requirements": sorted(coverage),
            "semantic_dedup": "coordinator-assigned canonical work_key; paraphrases require coordinator review"}


def safe_parent(path: Path) -> None:
    """Create directories without following existing symlinks/reparse points."""
    parent = path.absolute().parent
    current = Path(parent.anchor)
    for part in parent.parts[1:]:
        current /= part
        if current.exists() or current.is_symlink():
            require(not linked(current.lstat()) and current.is_dir(), "UNSAFE_PARENT", str(current))
        else:
            current.mkdir()


def write_json(path: Path, value: Any) -> None:
    safe_parent(path)
    with path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def snapshot(source_root: Path, relative: str, expected: str, target: Path) -> dict:
    actual = local_file(source_root, relative)
    require(actual["sha256"] == expected, "HASH_CHANGED", relative)
    require(not target.exists() and not target.is_symlink(), "DEST_EXISTS", str(target))
    safe_parent(target)
    with (source_root / relative).open("rb") as src, target.open("xb") as dst:
        shutil.copyfileobj(src, dst)
    require(local_file(target.parent, target.name)["sha256"] == expected, "COPY_CHANGED", relative)
    return actual


class TeamStore:
    """One local directory / one immutable plan. SQLite serializes claims."""
    def __init__(self, job: str | Path):
        self.root = checked_root(job)
        path = self.root / "team.sqlite3"
        require(path.is_file() and not path.is_symlink(), "DB_MISSING", "Initialize a new job first")
        self.db = sqlite3.connect(str(path), timeout=10, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA busy_timeout=10000")
        self.db.execute("PRAGMA foreign_keys=ON")

    def close(self) -> None:
        self.db.close()

    def __enter__(self) -> "TeamStore":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    @classmethod
    def create(cls, job: str | Path, plan: dict, inputs_root: str | Path, *, offline_fixture=False) -> dict:
        compiled = compile_plan(plan)
        source = checked_root(inputs_root)
        root = Path(job).absolute()
        checked_root(root.parent)
        require(not root.exists() and not root.is_symlink(), "JOB_EXISTS", "Never overwrite a run; use a new directory")
        # Validate every input BEFORE creating persistent state.
        for src in plan["inputs"]:
            actual = local_file(source, src["path"])
            require(actual["sha256"] == src["sha256"], "INPUT_HASH", src["path"])
        root.mkdir()
        # Windows may supply an 8.3 TEMP alias; freeze canonical paths before
        # copying snapshots and persisting paths into the task ledger.
        root = checked_root(root)
        try:
            for folder in ("sources", "workers", "published", "reviews"):
                (root / folder).mkdir()
            write_json(root / "plan.json", plan)
            db = sqlite3.connect(str(root / "team.sqlite3"))
            try:
                db.executescript("""
                CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE tasks(id TEXT PRIMARY KEY, work_key TEXT UNIQUE NOT NULL,
                  contract TEXT NOT NULL, status TEXT NOT NULL, attempt INTEGER NOT NULL DEFAULT 0,
                  token TEXT, lease_until REAL, worker TEXT, mode TEXT, host_run_id TEXT,
                  packet TEXT, result TEXT, started REAL, finished REAL);
                CREATE TABLE artifacts(id TEXT PRIMARY KEY, path TEXT NOT NULL, storage TEXT NOT NULL,
                  sha256 TEXT NOT NULL, bytes INTEGER NOT NULL, producer TEXT);
                CREATE TABLE results(id TEXT PRIMARY KEY, task_id TEXT NOT NULL,
                  token TEXT NOT NULL, payload_hash TEXT NOT NULL);
                CREATE TABLE events(seq INTEGER PRIMARY KEY AUTOINCREMENT, at REAL NOT NULL,
                  kind TEXT NOT NULL, task_id TEXT, detail TEXT NOT NULL);
                """)
                from delivery_state import create_schema
                create_schema(db)
                from dual16 import create_schema as create_dual16_schema
                create_dual16_schema(db, plan, offline_fixture)
                for key, value in {"runtime_version": VERSION, "plan": plan, "plan_digest": compiled["plan_digest"], "goal_digest": compiled["goal_digest"], "state": "active", "created": time.time()}.items():
                    db.execute("INSERT INTO meta VALUES (?,?)", (key, canonical(value)))
                if any(t.get('executor', {}).get('type') == 'workbuddy_mobile_cloud' for t in plan['tasks']):
                    db.execute('INSERT INTO meta VALUES (?,?)', ('workbuddy_policy_version', '1'))
                    db.execute('INSERT INTO meta VALUES (?,?)', ('execution_profile', canonical('offline_fixture' if offline_fixture else 'live')))
                for task in plan["tasks"]:
                    db.execute("INSERT INTO tasks(id,work_key,contract,status) VALUES (?,?,?,?)", (task["id"], work_key(task["work_key"]), canonical(task), "pending"))
                for src in plan["inputs"]:
                    storage = "sources/" + src["id"] + "/" + Path(src["path"]).name
                    info = snapshot(source, src["path"], src["sha256"], root / storage)
                    db.execute("INSERT INTO artifacts VALUES (?,?,?,?,?,NULL)", (src["id"], src["path"], storage, info["sha256"], info["bytes"]))
                db.execute("INSERT INTO events(at,kind,detail) VALUES (?,?,?)", (time.time(), "INITIALIZED", canonical(compiled)))
                db.commit()
            finally:
                db.close()
        except Exception:
            shutil.rmtree(root)
            raise
        with cls(root) as store:
            with store.transaction():
                from delivery_state import save_checkpoint
                save_checkpoint(store, "INITIALIZED")
        return {**compiled, "job": str(root), "state": "active", "agents_started": 0}

    @contextmanager
    def transaction(self, *, readonly=False) -> Iterator[None]:
        from workbuddy_policy import guard_writes
        if not readonly:
            guard_writes(self)
        if readonly:
            self.db.execute('PRAGMA query_only=ON')
        self.db.execute("BEGIN" if readonly else "BEGIN IMMEDIATE")
        try:
            yield
            self.db.execute("COMMIT")
        except Exception:
            self.db.execute("ROLLBACK")
            raise
        finally:
            if readonly:
                self.db.execute('PRAGMA query_only=OFF')

    def meta(self, key: str) -> Any:
        row = self.db.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        require(row is not None, "DB_CORRUPT", key)
        return json.loads(row[0])

    def event(self, kind: str, task: str | None = None, **detail: Any) -> None:
        from workbuddy_policy import guard_writes
        guard_writes(self)
        self.db.execute("INSERT INTO events(at,kind,task_id,detail) VALUES (?,?,?,?)", (time.time(), kind, task, canonical(detail)))
        from delivery_state import on_event
        on_event(self, kind, task, detail)

    def row(self, tid: str) -> sqlite3.Row:
        row = self.db.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone()
        require(row is not None, "TASK_UNKNOWN", tid)
        return row

    def active(self) -> None:
        require(self.meta("state") == "active", "RUN_FENCED", "Run is superseded; old work cannot be accepted")
        require(digest(load_json(self.root / "plan.json")) == self.meta("plan_digest"), "PLAN_TAMPERED", "Plan is immutable; create a new goal version")

    def bound(self, tid: str, token: str, *, states: set[str], fresh: bool = True) -> sqlite3.Row:
        self.active()
        row = self.row(tid)
        require(isinstance(token, str) and row["token"] == token, "FENCED_TOKEN", "Wrong or obsolete attempt token")
        require(row["status"] in states, "STATE", f"{tid} is {row['status']}")
        if fresh:
            require(row["lease_until"] is not None and row["lease_until"] > time.time(), "LEASE_EXPIRED", "Reconcile and confirm termination; never blindly relaunch")
        return row

    def valid_artifact(self, aid: str) -> dict:
        row = self.db.execute("SELECT * FROM artifacts WHERE id=?", (aid,)).fetchone()
        require(row is not None, "ARTIFACT_UNAVAILABLE", aid)
        info = local_file(self.root, row["storage"])
        require(info["sha256"] == row["sha256"], "ARTIFACT_CHANGED", aid)
        return dict(row)

    def ready(self) -> list[str]:
        rows = list(self.db.execute("SELECT * FROM tasks ORDER BY id"))
        accepted = {r["id"] for r in rows if r["status"] == "accepted"}
        from delivery_state import guard_context
        ready = []
        for row in rows:
            if row['status'] != 'pending' or not set(json.loads(row['contract'])['depends_on']) <= accepted:
                continue
            try:
                guard_context(self, row['id'])
            except TeamError:
                continue
            ready.append(row['id'])
        return ready

    def claim(self, tid: str, worker: str) -> dict:
        identifier(worker, "worker")
        with self.transaction():
            self.active()
            row = self.row(tid)
            require(row["status"] == "pending", "ALREADY_CLAIMED", tid)
            from delivery_state import guard_context
            guard_context(self, tid)
            require(tid in self.ready(), "DEPENDENCY_WAIT", "Only accepted upstream results unlock work")
            plan = self.meta("plan"); policy = plan["policy"]
            count = self.db.execute("SELECT COUNT(*) FROM tasks WHERE status IN ('leased','uncertain')").fetchone()[0]
            require(count < policy["max_parallel"], "CAPACITY", "Includes uncertain workers until termination is confirmed")
            attempts = self.db.execute("SELECT SUM(attempt) FROM tasks").fetchone()[0]
            require(attempts < policy["max_total_attempts"] and row["attempt"] < policy["max_attempts"], "BUDGET", "Attempt budget exhausted")
            from dual16 import guard_claim
            guard_claim(self, tid, worker)
            contract = json.loads(row["contract"])
            if contract.get('executor', {}).get('type') == 'workbuddy_mobile_cloud':
                from workbuddy_policy import capabilities
                capabilities(self)
            if "intelligence" in contract:
                from intelligence_layer import validate_extension, ensure_context_fresh
                try:
                    validate_extension(contract, plan["goal"], policy)
                    ensure_context_fresh(contract["intelligence"]["context"])
                except ValueError as exc:
                    raise TeamError(getattr(exc, "code", "INTELLIGENCE"), str(exc)) from exc
                require(row["attempt"] < contract["intelligence"]["reasoning"]["worker_attempt_limit"],
                        "DEPTH_BUDGET", "Per-task reasoning attempt limit exhausted")
            for dependency in contract["depends_on"]:
                upstream = self.row(dependency)
                self._validate_result(json.loads(upstream["result"]), upstream)
                self._validate_acceptance(upstream)
                event = self.db.execute("SELECT detail FROM events WHERE task_id=? AND kind='REVIEWED' ORDER BY seq DESC LIMIT 1", (dependency,)).fetchone()
                require(event is not None, "REVIEW_MISSING", dependency)
                review = json.loads(event[0])
                require(local_file(self.root, review["evidence_path"])["sha256"] == review["evidence_sha256"], "REVIEW_CHANGED", dependency)
            require(worker != contract["reviewer"], "SELF_REVIEW", "Worker ID cannot be its designated reviewer ID")
            token = uuid.uuid4().hex
            relative = f"workers/{tid}/{row['attempt'] + 1}-{token}"
            workspace = self.root / relative
            workspace.mkdir(parents=True)
            for name in ("inputs", "outputs", "evidence"):
                (workspace / name).mkdir()
            inputs = []
            for aid in contract["reads"]:
                artifact = self.valid_artifact(aid)
                target = workspace / "inputs" / aid / Path(artifact["path"]).name
                snapshot(self.root, artifact["storage"], artifact["sha256"], target)
                inputs.append({"id": aid, "path": str(target), "sha256": artifact["sha256"], "producer": artifact["producer"]})
            packet = {"schema_version": plan["schema_version"], "run_id": plan["run_id"], "task_id": tid,
                      "plan_digest": self.meta("plan_digest"), "goal_digest": self.meta("goal_digest"), "goal": plan["goal"],
                      "lease_token": token, "attempt": row["attempt"] + 1, "worker": worker,
                      "contract": contract, "input_snapshots": inputs,
                      "workspace": str(workspace), "output_root": str(workspace / "outputs"),
                      "result_path": str(workspace / "result.json"), "packet_path": str(workspace / "packet.json"),
                      "do_not": ["change shared goal or acceptance", "work outside assigned scope", "write other workers' files", "re-delegate or publish externally", "repeat existing work instead of referencing its artifact"],
                      "enforcement": "ledger + validated snapshots; OS/tool isolation must be provided by host"}
            from dual16 import enabled as dual16_enabled, session as dual16_session
            if dual16_enabled(plan):
                member = dual16_session(self, tid)
                packet["dual16"] = {"controller_id": member["controller"], "worker_slot": tid, "expected_host_run_id": member["host_run_id"], "leaf_recursion": False}
            if "intelligence" in contract:
                packet["context_capsule"] = contract["intelligence"]["context"]
                packet["reasoning_plan"] = contract["intelligence"]["reasoning"]
                packet["routing_decision"] = contract["intelligence"]["route"]
            if contract.get('executor', {}).get('type') == 'workbuddy_mobile_cloud':
                from workbuddy_policy import packet_policy
                packet['workbuddy_policy'] = packet_policy(self)
            write_json(workspace / "packet.json", packet)
            self.db.execute("UPDATE tasks SET status='leased',attempt=attempt+1,token=?,lease_until=?,worker=?,mode=NULL,host_run_id=NULL,packet=?,result=NULL,started=?,finished=NULL WHERE id=?",
                            (token, time.time() + policy["lease_seconds"], worker, canonical(packet), time.time(), tid))
            self.event("CLAIMED", tid, worker=worker, token=token, attempt=packet["attempt"])
            return packet

    def validate_host(self, tid: str, mode: str) -> None:
        """Read-only preflight BEFORE invoking a process/native tool; bind repeats it."""
        require(isinstance(mode, str) and mode in MODES, "MODE", "Unknown execution mode")
        if self.meta("plan")["schema_version"] == 3:
            host = json.loads(self.row(tid)["contract"])["executor"]["type"]
            from host_registry import execution_mode
            required_mode = execution_mode(host)
            require(mode == required_mode, "HOST_MISMATCH", "Execution host must match the frozen contract")
        else:
            require(mode in ("fixture", "inline"), "LEGACY_HOST", "Migrate to schema 3 before model/native execution")

    def bind(self, tid: str, token: str, mode: str, host_run_id: str) -> dict:
        require(isinstance(mode, str) and mode in MODES, "MODE", "Unknown execution mode")
        text(host_run_id, "host_run_id")
        with self.transaction():
            row = self.bound(tid, token, states={"leased"})
            self.validate_host(tid, mode)
            from dual16 import guard_bind as guard_dual16_bind
            guard_dual16_bind(self, tid, mode, host_run_id)
            require(row["mode"] is None, "ALREADY_BOUND", "Attempt already has a host run")
            from delivery_state import guard_bind
            guard_bind(self, row, host_run_id)
            self.db.execute("UPDATE tasks SET mode=?,host_run_id=? WHERE id=?", (mode, host_run_id, tid))
            self.event("HOST_BOUND", tid, mode=mode, host_run_id=host_run_id)
        return {"bound": True, "mode": mode, "host_run_id": host_run_id}

    def heartbeat(self, tid: str, token: str) -> dict:
        with self.transaction():
            self.bound(tid, token, states={"leased"})
            expiry = time.time() + self.meta("plan")["policy"]["lease_seconds"]
            self.db.execute("UPDATE tasks SET lease_until=? WHERE id=?", (expiry, tid))
        return {"lease_until": expiry}

    def _validate_result(self, result: dict, row: sqlite3.Row) -> None:
        fields(result, {"schema_version", "result_id", "task_id", "lease_token", "plan_digest", "goal_digest", "host_run_id", "artifacts", "checks", "concerns", "external_actions", "host_receipt"}, {"technical_validation", "blockers", "warnings", "environment_notes"})
        require(type(result["schema_version"]) is int and result["schema_version"] == self.meta("plan")["schema_version"], "VERSION", "Result schema must match plan")
        identifier(result["result_id"], "result_id")
        require(result["plan_digest"] == self.meta("plan_digest") and result["goal_digest"] == self.meta("goal_digest"), "GOAL_DRIFT", "Result belongs to a different goal or plan")
        require(row["mode"] is not None and result["host_run_id"] == row["host_run_id"], "HOST_UNBOUND", "Bind a real host run, or explicitly label inline/fixture")
        strings(result["concerns"], "concerns", empty=True)
        for label in ("blockers", "warnings", "environment_notes"):
            if label in result:
                require(result["schema_version"] == 3, "VERSION", "Typed diagnostics require schema 3")
                strings(result[label], label, empty=True)
        require(result["external_actions"] == [], "SIDE_EFFECT", "This executor supports artifact production only; external actions need a separate authorized controller")
        packet = json.loads(row["packet"]); contract = json.loads(row["contract"])
        workspace = checked_root(packet["workspace"])
        # Reject mutated input snapshots, including substitutions after dispatch.
        for src in packet["input_snapshots"]:
            rel = Path(src["path"]).relative_to(workspace).as_posix()
            require(local_file(workspace, rel)["sha256"] == src["sha256"], "INPUT_MUTATED", src["id"])
        declared = {a["id"]: a["path"] for a in contract["outputs"]}
        current: dict[str, dict] = {}
        for artifact in array(result["artifacts"], "artifacts"):
            fields(artifact, {"id", "path", "sha256"})
            aid = identifier(artifact["id"], "artifact.id")
            require(aid in declared and artifact["path"] == declared[aid] and aid not in current, "OUTPUT_SCOPE", aid)
            info = local_file(workspace / "outputs", artifact["path"])
            require(sha(artifact["sha256"]) and info["sha256"] == artifact["sha256"], "OUTPUT_HASH", aid)
            current[aid] = info
        require(set(current) == set(declared), "OUTPUT_MISSING", "Return exactly the assigned outputs")
        actual_paths = {p.relative_to(workspace / "outputs").as_posix() for p in (workspace / "outputs").rglob("*") if p.is_file() or p.is_symlink()}
        require(actual_paths == set(declared.values()), "UNDECLARED_OUTPUT", "Unassigned files in output directory")
        receipt = fields(result["host_receipt"], {"path", "sha256"})
        require(isinstance(receipt["path"], str) and receipt["path"].startswith("evidence/"), "RECEIPT_PATH", "Host receipt must be in evidence/")
        info = local_file(workspace, receipt["path"])
        require(sha(receipt["sha256"]) and info["sha256"] == receipt["sha256"], "HOST_RECEIPT_HASH", "Host receipt has changed")
        host = fields(load_json(workspace / receipt["path"]), {"host_run_id", "mode", "finished", "task_id", "lease_token"}, {"exit_code", "pid", "duration_seconds", "note", "backend_identity", "observation"})
        require(host["finished"] is True and host["host_run_id"] == row["host_run_id"] and host["mode"] == row["mode"] and host["task_id"] == row["id"] and host["lease_token"] == row["token"], "HOST_NOT_FINISHED", "A finished host event for this attempt is required")
        if result['schema_version'] == 3 and row['mode'] == 'native':
            observation = host.get('observation')
            require(isinstance(observation, dict) and observation.get('host') == contract['executor']['type']
                    and observation.get('event') == 'finished' and observation.get('observed_by') == 'coordinator'
                    and observation.get('host_run_id') == row['host_run_id']
                    and observation.get('task_id') == row['id'] and observation.get('lease_token') == row['token'],
                    'NATIVE_OBSERVATION', 'A completed, token-bound native host observation is mandatory')
            require(isinstance(observation.get('raw_evidence_path'), str) and observation['raw_evidence_path'].startswith('evidence/'),
                    'NATIVE_OBSERVATION', 'Raw observation must be in evidence')
            info = local_file(workspace, observation['raw_evidence_path'])
            require(info['sha256'] == observation.get('raw_evidence_sha256'), 'NATIVE_OBSERVATION', 'Raw observation changed')
            from dual16 import enabled as dual16_enabled
            if dual16_enabled(self.meta('plan')):
                raw_attempt = (workspace / observation['raw_evidence_path']).read_text(encoding='utf-8')
                require(all(value in raw_attempt for value in (row['token'],row['id'],packet['goal_digest'],packet['plan_digest'])),
                        'D16_ATTEMPT_OBSERVATION','Terminal evidence must refer to this attempt, not an earlier result from the reused session')
            if contract['executor']['type'] == 'codex_native':
                from host_adapters.codex import validate_finished_observation
                validate_finished_observation(load_json(workspace / observation['raw_evidence_path']), row['host_run_id'])
            elif contract['executor']['type'] == 'workbuddy_mobile_cloud':
                from host_adapters.workbuddy_contract import validate_sync_terminal_observation
                from delivery_state import guard_workbuddy_run
                guard_workbuddy_run(self, row, row['host_run_id'])
                from workbuddy_policy import guard_success
                guard_success(self, row, row['host_run_id'], observation)
                validate_sync_terminal_observation(
                    (workspace / observation['raw_evidence_path']).read_bytes().decode('utf-8'),
                    row['host_run_id'])
        if "exit_code" in host:
            require(type(host["exit_code"]) is int and host["exit_code"] == 0, "HOST_EXIT_CODE", "A failed wrapper exit cannot support successful submission")
        if result['schema_version'] == 3:
            technical = fields(result.get('technical_validation'), {'execution', 'outcome', 'evidence_kind', 'evidence_path', 'evidence_sha256'})
            require(technical['execution'] == 'EXECUTED' and technical['evidence_kind'] == 'RUNTIME_FACT'
                    and technical['outcome'] in ('PASS', 'FAILED'), 'TECHNICAL_STATE', 'Invalid technical check')
            require(isinstance(technical['evidence_path'], str) and technical['evidence_path'].startswith('evidence/'), 'EVIDENCE_PATH', 'Technical evidence must be local')
            tinfo = local_file(workspace, technical['evidence_path'])
            require(tinfo['sha256'] == technical['evidence_sha256'], 'EVIDENCE_CHANGED', 'Technical evidence hash mismatch')
            proof = load_json(workspace / technical['evidence_path'])
            require(proof.get('kind') == 'artifact_integrity' and proof.get('task_id') == row['id'], 'TECHNICAL_KIND', 'Structure is not requirement evidence')
            require(proof.get('all_findings_passed') is (technical['outcome'] == 'PASS'), 'TECHNICAL_STATE', 'Evidence and technical state differ')
            expected_checks = pending_checks(packet, result['artifacts'], technical['evidence_path'], technical['evidence_sha256'])
            require(result['checks'] == expected_checks, 'WORKER_ACCEPTANCE_CLAIM', 'Producer acceptance must remain NOT_EXECUTED/UNVERIFIED with explicit subjects')
            return
        expected = {c["id"]: c for c in contract["acceptance"]}
        found: set[str] = set()
        for check in array(result["checks"], "checks"):
            fields(check, {"id", "execution", "outcome", "evidence_kind", "artifact_id", "subject_sha256", "evidence_path", "evidence_sha256"})
            cid = identifier(check["id"], "check.id")
            require(cid in expected and cid not in found, "CHECK_SCOPE", cid)
            require(check["execution"] in ("EXECUTED", "NOT_EXECUTED") and check["outcome"] in ("PASS", "FAILED", "UNVERIFIED"), "CHECK_STATE", cid)
            require(check["evidence_kind"] == expected[cid]["evidence_kind"], "EVIDENCE_KIND", cid)
            aid = identifier(check["artifact_id"], "artifact_id")
            require(aid in current and check["subject_sha256"] == current[aid]["sha256"], "STALE_CHECK", cid)
            require(isinstance(check["evidence_path"], str) and check["evidence_path"].startswith("evidence/"), "EVIDENCE_PATH", cid)
            evidence = local_file(workspace, check["evidence_path"])
            require(sha(check["evidence_sha256"]) and evidence["sha256"] == check["evidence_sha256"], "EVIDENCE_CHANGED", cid)
            require(check["outcome"] != "PASS" or check["execution"] == "EXECUTED", "FALSE_PASS", cid)
            found.add(cid)
        require(found == set(expected), "CHECK_MISSING", "Every assigned acceptance check must be reported")

    def _validate_acceptance(self, row):
        from delivery_quality import require_quality
        require_quality(self, row, json.loads(row['result']))
        if self.meta('plan')['schema_version'] != 3:
            return
        event = self.db.execute("SELECT detail FROM events WHERE task_id=? AND kind='ACCEPTANCE_VERIFIED' ORDER BY seq DESC LIMIT 1", (row['id'],)).fetchone()
        require(event is not None, 'ACCEPTANCE_MISSING', row['id'])
        receipt = json.loads(event[0])
        info = local_file(self.root, receipt['evidence_path'])
        require(info['sha256'] == receipt['evidence_sha256'], 'ACCEPTANCE_CHANGED', row['id'])
        proof = load_json(self.root / receipt['evidence_path'])
        require(proof.get('kind') == 'contract_acceptance' and proof.get('passed') is True
                and proof.get('result_digest') == digest(json.loads(row['result']))
                and proof.get('lease_token') == row['token']
                and proof.get('goal_digest') == self.meta('goal_digest')
                and proof.get('plan_digest') == self.meta('plan_digest'), 'ACCEPTANCE_BINDING', row['id'])

    def submit(self, result: dict) -> dict:
        require(isinstance(result, dict), "OBJECT", "Expected result object")
        with self.transaction():
            row = self.bound(result.get("task_id"), result.get("lease_token"), states={"leased", "submitted", "accepted"}, fresh=False)
            # Validate digests even on duplicate receipt; an old goal is never revived.
            require(result.get("goal_digest") == self.meta("goal_digest") and result.get("plan_digest") == self.meta("plan_digest"), "GOAL_DRIFT", "Obsolete goal or plan")
            old = self.db.execute("SELECT * FROM results WHERE id=?", (result.get("result_id"),)).fetchone()
            if old:
                require(old["payload_hash"] == digest(result) and old["task_id"] == row["id"] and old["token"] == row["token"], "RESULT_COLLISION", "Result ID reused with different content")
                if json.loads(row['contract']).get('executor', {}).get('type') == 'workbuddy_mobile_cloud':
                    self._validate_result(result, row)
                self.event("DUPLICATE_RECEIPT", row["id"], result_id=result["result_id"])
                return {"submitted": True, "duplicate": True, "status": row["status"]}
            require(row["status"] == "leased" and row["lease_until"] > time.time(), "LEASE_EXPIRED", "Late result rejected; reconcile first")
            self._validate_result(result, row)
            self.db.execute("INSERT INTO results VALUES (?,?,?,?)", (result["result_id"], row["id"], row["token"], digest(result)))
            self.db.execute("UPDATE tasks SET status='submitted',result=?,finished=? WHERE id=?", (canonical(result), time.time(), row["id"]))
            self.event("SUBMITTED", row["id"], result_id=result["result_id"], result_digest=digest(result))
        return {"submitted": True, "duplicate": False, "status": "submitted", "requires_review": True}

    def review(self, review: dict) -> dict:
        fields(review, {"task_id", "result_id", "result_digest", "goal_digest", "reviewer", "decision", "reason", "evidence_path", "evidence_sha256"})
        require(review["decision"] in ("accept", "rework", "block"), "REVIEW_DECISION", "Invalid review decision")
        text(review["reason"], "reason")
        with self.transaction():
            self.active(); row = self.row(review["task_id"])
            require(row["status"] == "submitted", "STATE", "Only submitted work can be reviewed")
            contract = json.loads(row["contract"]); result = json.loads(row["result"])
            require(review["reviewer"] == contract["reviewer"] and review["reviewer"] != row["worker"], "REVIEWER", "Only the designated non-worker reviewer may accept")
            require(review["result_id"] == result["result_id"] and review["result_digest"] == digest(result) and review["goal_digest"] == self.meta("goal_digest"), "REVIEW_STALE", "Review is not bound to the current result")
            require(isinstance(review["evidence_path"], str) and review["evidence_path"].startswith("reviews/"), "REVIEW_PATH", "Store review evidence in reviews/")
            info = local_file(self.root, review["evidence_path"])
            require(sha(review["evidence_sha256"]) and info["sha256"] == review["evidence_sha256"], "REVIEW_EVIDENCE", "Missing or changed review evidence")
            from dual16 import guard_review
            guard_review(self, review)
            if review["decision"] == "accept":
                self._validate_result(result, row)  # Rehash on acceptance, not just submission.
                from delivery_quality import require_quality
                require_quality(self, row, result)
                if result['schema_version'] == 3:
                    require(result['technical_validation']['outcome'] == 'PASS', 'GATE_FAILED', 'Artifact integrity failed')
                    from verifier_registry import evaluate
                    packet = json.loads(row['packet'])
                    evaluation = evaluate(packet, result)
                    relative = 'reviews/acceptance-' + row['token'] + '-' + digest(evaluation)[:16] + '.json'
                    target = self.root / relative
                    if not target.exists():
                        write_json(target, evaluation)
                    require(digest(load_json(target)) == digest(evaluation), 'EVIDENCE_CHANGED', 'Acceptance report collision')
                    require(evaluation['passed'], 'GATE_FAILED', 'Independent requirement verifiers failed or remain UNVERIFIED; see ' + relative)
                    self.event('ACCEPTANCE_VERIFIED', row['id'], evidence_path=relative,
                               evidence_sha256=local_file(self.root, relative)['sha256'], result_digest=digest(result))
                else:
                    require(all(c["execution"] == "EXECUTED" and c["outcome"] == "PASS" for c in result["checks"]), "GATE_FAILED", "Required checks are not all PASS")
                from diagnostics import blocking_items
                require(not blocking_items(result), "UNRESOLVED_CONCERNS", "Resolve blockers/legacy concerns in a revised attempt; do not edit the submitted result")
                packet = json.loads(row["packet"])
                # Recoverable publication: preflight all targets, then write by exclusive create.
                for artifact in result["artifacts"]:
                    target = self.root / "published" / artifact["path"]
                    if target.exists():
                        require(local_file(self.root / "published", artifact["path"])["sha256"] == artifact["sha256"], "PUBLISH_CONFLICT", artifact["path"])
                for artifact in result["artifacts"]:
                    target = self.root / "published" / artifact["path"]
                    if not target.exists():
                        snapshot(Path(packet["output_root"]), artifact["path"], artifact["sha256"], target)
                    checked = local_file(self.root / "published", artifact["path"])
                    self.db.execute("INSERT INTO artifacts VALUES (?,?,?,?,?,?)", (artifact["id"], artifact["path"], "published/" + artifact["path"], checked["sha256"], checked["bytes"], row["id"]))
                status = "accepted"
            elif review["decision"] == "rework":
                attempt_limit = self.meta("plan")["policy"]["max_attempts"]
                if "intelligence" in contract:
                    attempt_limit = min(attempt_limit, contract["intelligence"]["reasoning"]["worker_attempt_limit"])
                status = "pending" if row["attempt"] < attempt_limit else "blocked"
            else:
                status = "blocked"
            self.db.execute("UPDATE tasks SET status=?,token=CASE WHEN ?='accepted' THEN token ELSE NULL END WHERE id=?", (status, status, row["id"]))
            self.event("REVIEWED", row["id"], **review)
        return {"task_id": row["id"], "status": status}

    def reconcile(self) -> dict:
        with self.transaction():
            rows = list(self.db.execute("SELECT id FROM tasks WHERE status='leased' AND lease_until<=?", (time.time(),)))
            for row in rows:
                self.db.execute("UPDATE tasks SET status='uncertain' WHERE id=?", (row["id"],))
                self.event("LEASE_UNCERTAIN", row["id"])
        return {"uncertain": [r["id"] for r in rows], "auto_requeued": 0}

    def mark_uncertain(self, tid: str, token: str, reason: str) -> dict:
        text(reason, "reason")
        with self.transaction():
            self.bound(tid, token, states={"leased"}, fresh=False)
            self.db.execute("UPDATE tasks SET status='uncertain' WHERE id=?", (tid,))
            self.event("HOST_UNCERTAIN", tid, reason=reason)
        return {"task_id": tid, "status": "uncertain", "auto_requeued": 0}

    def recover(self, request: dict) -> dict:
        fields(request, {"task_id", "lease_token", "termination", "evidence_path", "evidence_sha256", "reason"}, {"action"})
        require(request["termination"] in ("confirmed_stopped", "confirmed_not_started"), "TERMINATION", "Unknown/lost host is not proof of termination")
        text(request["reason"], "reason")
        with self.transaction():
            retired = self.meta("state") == "superseded"
            if retired:
                row = self.row(request["task_id"])
                require(row["token"] == request["lease_token"] and row["status"] in ACTIVE, "FENCED_TOKEN", "Not a live retired attempt")
            else:
                row = self.bound(request["task_id"], request["lease_token"], states={"uncertain"}, fresh=False)
            require(isinstance(request["evidence_path"], str) and request["evidence_path"].startswith("reviews/"), "RECOVERY_PATH", "Use a controller receipt in reviews/")
            info = local_file(self.root, request["evidence_path"])
            require(info["sha256"] == request["evidence_sha256"], "RECOVERY_EVIDENCE", "Recovery receipt hash mismatch")
            ack = load_json(self.root / request["evidence_path"])
            require(isinstance(ack, dict) and ack.get("task_id") == row["id"] and ack.get("lease_token") == row["token"] and ack.get("termination") == request["termination"], "RECOVERY_BINDING", "Termination receipt must identify this attempt")
            from delivery_state import guard_recovery
            guard_recovery(self, row, request)
            action = request.get("action", "retry")
            require(action in ("retry", "adopt_finished"), "RECOVERY_ACTION", "Unknown recovery action")
            if retired:
                status = "cancelled"
            elif action == "adopt_finished":
                require(request["termination"] == "confirmed_stopped", "RECOVERY_ACTION", "Only an ended host can supply a late result")
                status = "leased"
            else:
                contract = json.loads(row["contract"])
                attempt_limit = self.meta("plan")["policy"]["max_attempts"]
                if "intelligence" in contract:
                    attempt_limit = min(attempt_limit, contract["intelligence"]["reasoning"]["worker_attempt_limit"])
                status = "pending" if row["attempt"] < attempt_limit else "blocked"
            self.db.execute("UPDATE tasks SET status=?,token=?,lease_until=? WHERE id=?", (status, row["token"] if status == "leased" else None, time.time() + self.meta("plan")["policy"]["lease_seconds"], row["id"]))
            self.event("RECOVERED", row["id"], **request)
        return {"task_id": row["id"], "status": status}

    def supersede(self, new_goal_digest: str, reason: str) -> dict:
        require(sha(new_goal_digest), "GOAL_DIGEST", "Expected a SHA-256")
        text(reason, "reason")
        with self.transaction():
            self.active()
            require(new_goal_digest != self.meta("goal_digest"), "UNCHANGED_GOAL", "Use a new goal version")
            self.db.execute("UPDATE meta SET value=? WHERE key='state'", (canonical("superseded"),))
            self.db.execute("INSERT OR REPLACE INTO meta VALUES (?,?)", ("successor_goal_digest", canonical(new_goal_digest)))
            running = [r[0] for r in self.db.execute("SELECT id FROM tasks WHERE status IN ('leased','uncertain')")]
            self.event("SUPERSEDED", new_goal_digest=new_goal_digest, reason=reason, cancel_required=running)
        from dual16 import enabled as dual16_enabled
        sessions_to_stop = [dict(r) for r in self.db.execute("SELECT slot,host_run_id,state FROM d16_sessions WHERE state NOT IN ('NEW','STOPPED')")] if dual16_enabled(self.meta("plan")) else []
        return {"state": "superseded", "cancel_required": running, "dual16_sessions_to_stop": sessions_to_stop,
                "next": "Confirm old host termination before replacement dispatch. Create a NEW job with the revised plan; reuse only revalidated artifacts as explicit inputs."}

    def revise(self, new_job: str | Path, plan: dict, inputs: str | Path) -> dict:
        compiled = compile_plan(plan)
        with self.transaction():
            require(self.meta("state") == "superseded", "NOT_SUPERSEDED", "Fence the old goal first")
            count = self.db.execute("SELECT COUNT(*) FROM tasks WHERE status IN ('leased','uncertain')").fetchone()[0]
            require(count == 0, "OLD_HOST_ACTIVE", "Confirm every previous worker has stopped before replacing work")
            from dual16 import guard_revise
            guard_revise(self)
            old_goal = self.meta("plan")["goal"]
            require(plan["goal"]["id"] == old_goal["id"] and plan["goal"]["version"] > old_goal["version"], "GOAL_VERSION", "Successor must increment the same goal")
            require(compiled["goal_digest"] == self.meta("successor_goal_digest"), "SUCCESSOR_GOAL", "New plan does not match the fenced successor goal")
            existing = self.db.execute("SELECT value FROM meta WHERE key='successor_job'").fetchone()
            require(existing is None, "SUCCESSOR_EXISTS", "A successor has already been created")
            result = TeamStore.create(new_job, plan, inputs)
            self.db.execute("INSERT INTO meta VALUES (?,?)", ("successor_job", canonical(str(Path(new_job).absolute()))))
            self.event("SUCCESSOR_CREATED", job=result["job"], goal_digest=compiled["goal_digest"])
            return result

    def status(self) -> dict:
        with self.transaction(readonly=True):
            return self._status()

    def _status(self) -> dict:
        rows = list(self.db.execute("SELECT * FROM tasks ORDER BY id"))
        accepted = sum(r["status"] == "accepted" for r in rows)
        changed = []
        for row in self.db.execute("SELECT id FROM artifacts"):
            try:
                self.valid_artifact(row[0])
            except (TeamError, OSError, ContractError) as exc:
                changed.append({"id": row[0], "error": str(exc)})
        changed_evidence = []
        for task in rows:
            if task["status"] != "accepted":
                continue
            try:
                self._validate_result(json.loads(task["result"]), task)
                self._validate_acceptance(task)
                event = self.db.execute("SELECT detail FROM events WHERE task_id=? AND kind='REVIEWED' ORDER BY seq DESC LIMIT 1", (task["id"],)).fetchone()
                require(event is not None, "REVIEW_MISSING", task["id"])
                review = json.loads(event[0])
                require(local_file(self.root, review["evidence_path"])["sha256"] == review["evidence_sha256"], "REVIEW_CHANGED", task["id"])
            except (TeamError, OSError, ContractError) as exc:
                changed_evidence.append({"id": task["id"], "error": str(exc)})
        immutable = digest(load_json(self.root / "plan.json")) == self.meta("plan_digest")
        completed = self.meta("state") == "active" and immutable and not changed and not changed_evidence and accepted == len(rows)
        from dual16 import enabled as dual16_enabled, report as dual16_report
        topology = dual16_report(self) if dual16_enabled(self.meta("plan")) else None
        if topology is not None:
            completed = completed and topology["topology_evidence_valid"]
        from workbuddy_policy import legacy, meta_or
        old_workbuddy = legacy(self)
        return {"run_id": self.meta("plan")["run_id"], "state": self.meta("state"), "completed": completed and not old_workbuddy,
                "dual16": topology,
                "workbuddy_legacy_read_only": old_workbuddy, "execution_profile": meta_or(self, 'execution_profile', 'existing_host'),
                "plan_integrity": immutable, "goal_digest": self.meta("goal_digest"),
                "ready": self.ready() if not old_workbuddy and self.meta("state") == "active" and immutable and not changed and not changed_evidence else [],
                "tasks": [{k: r[k] for k in ("id", "status", "attempt", "worker", "mode", "host_run_id", "lease_until")} for r in rows],
                "changed_artifacts": changed, "changed_evidence": changed_evidence,
                "metrics": {"tasks": len(rows), "accepted": accepted, "attempts": sum(r["attempt"] for r in rows),
                            "accepted_first_attempt": sum(r["status"] == "accepted" and r["attempt"] == 1 for r in rows),
                            "duplicate_receipts": self.db.execute("SELECT COUNT(*) FROM events WHERE kind='DUPLICATE_RECEIPT'").fetchone()[0],
                            "model_tokens": None, "model_cost": None},
                "limitations": ["Semantic equivalence requires coordinator review of work_key/scope.", "Registry is not an OS sandbox or a trusted identity provider.", "Fixture/inline evidence is not a real multi-model benchmark.", "Exactly-once external side effects are not supported; external_actions must be empty."]}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    c = commands.add_parser("compile"); c.add_argument("plan")
    c = commands.add_parser("init"); c.add_argument("--plan", required=True); c.add_argument("--inputs", required=True); c.add_argument("--job", required=True); c.add_argument("--offline-fixture", action="store_true", help="Synthetic WorkBuddy observations only; never authorizes a real host call")
    for name in ("status", "reconcile", "claim", "bind", "heartbeat", "submit", "review", "recover", "supersede", "revise"):
        c = commands.add_parser(name); c.add_argument("--job", required=True)
        if name in {"claim", "bind", "heartbeat"}: c.add_argument("--task", required=True)
        if name == "claim": c.add_argument("--worker", required=True)
        if name in {"bind", "heartbeat"}: c.add_argument("--token", required=True)
        if name == "bind":
            c.add_argument("--mode", required=True, choices=sorted(MODES)); c.add_argument("--host-run-id", required=True)
        if name in {"submit", "review", "recover"}: c.add_argument("--file", required=True)
        if name == "revise":
            c.add_argument("--plan", required=True); c.add_argument("--inputs", required=True); c.add_argument("--next-job", required=True)
        if name == "supersede": c.add_argument("--new-goal-digest", required=True); c.add_argument("--reason", required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "compile": output = compile_plan(load_json(args.plan))
        elif args.command == "init": output = TeamStore.create(args.job, load_json(args.plan), args.inputs, offline_fixture=args.offline_fixture)
        else:
            with TeamStore(args.job) as store:
                if args.command == "claim": output = store.claim(args.task, args.worker)
                elif args.command == "bind": output = store.bind(args.task, args.token, args.mode, args.host_run_id)
                elif args.command == "heartbeat": output = store.heartbeat(args.task, args.token)
                elif args.command in {"submit", "review", "recover"}: output = getattr(store, args.command)(load_json(args.file))
                elif args.command == "revise": output = store.revise(args.next_job, load_json(args.plan), args.inputs)
                elif args.command == "supersede": output = store.supersede(args.new_goal_digest, args.reason)
                else: output = getattr(store, args.command)()
        print(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False)); return 0
    except (TeamError, ContractError, OSError, sqlite3.Error, ValueError, TypeError, KeyError, RecursionError) as exc:
        print(json.dumps({"valid": False, "error": getattr(exc, "code", "INPUT_OR_STORAGE"), "message": str(exc)}, ensure_ascii=False)); return 1


if __name__ == "__main__":
    raise SystemExit(main())
