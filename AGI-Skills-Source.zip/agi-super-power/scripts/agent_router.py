"""Capability filter -> explainable ranking -> optional bounded host decision.

Scores are matching heuristics, NOT probabilities. No candidate is spawned here.
An ambiguous request produces no selected role, not two competing workers.
"""
from __future__ import annotations
from pathlib import Path
from intelligence_common import read_json, names, obj, ensure, string, contains, digest
from intent_compiler import validate_intent, intent_digest
from host_registry import host_info

PROFILES = Path(__file__).resolve().parents[1] / 'assets/intelligence/role-profiles.json'

def profiles() -> list[dict]:
    data = read_json(PROFILES)
    ensure(data.get('schema_version') == 1, 'PROFILE', 'Unsupported profile schema')
    items = data['profiles']; seen = set()
    for p in items:
        obj(p, {'id','domains','artifact_types','task_shapes','keywords','supported_tools','hosts'})
        string(p['id'], 'profile id', 80)
        ensure(p['id'] not in seen, 'PROFILE', 'Duplicate role'); seen.add(p['id'])
        for k in set(p)-{'id'}: names(p[k], k)
    return items

def route(intent: dict, *, host: str, available_tools: list[str], semantic_decision: dict | None = None) -> dict:
    validate_intent(intent); names(available_tools, 'available_tools')
    host = host_info(host)['id']; ps = profiles()
    required = set(intent['required_tools'])
    # Explicit names only. '*' does not grant any capability.
    missing = sorted(required - set(available_tools))
    base = {'schema_version':1, 'host':host, 'intent_digest':intent_digest(intent),
            'profiles_digest':digest(ps), 'available_tools':sorted(available_tools),
            'score_semantics':'heuristic_match_not_probability','candidates':[], 'rejected':[],
            'selected_role':None, 'decision_source':'deterministic', 'semantic_decision':None,
            'missing_tools':missing}
    if missing:
        return {**base,'state':'TOOLS_MISSING','candidate_digest':digest([])}
    for p in ps:
        reasons = []
        if host not in p['hosts']: reasons.append('host_unsupported')
        if intent['task_shape'] not in p['task_shapes']: reasons.append('task_shape_unsupported')
        if not required <= set(p['supported_tools']): reasons.append('required_tool_unsupported')
        if host == 'bounded_model' and required: reasons.append('bounded_model_has_no_task_tools')
        # Negative shape boundary: review/integration is not a second implementation.
        if intent['task_shape'] == 'review' and p['id'] not in {'qa-auditor','repo-research','general'}:
            reasons.append('review_must_not_implement')
        if intent['task_shape'] == 'integrate' and p['id'] != 'delivery-integrator':
            reasons.append('unique_integrator')
        if reasons:
            base['rejected'].append({'role':p['id'],'reasons':reasons}); continue
        dm = sorted(set(intent['domains']) & set(p['domains']))
        am = sorted(set(intent['artifact_types']) & set(p['artifact_types']))
        km = sorted(w for w in p['keywords'] if contains(intent['request'], w))
        score = min(2,len(dm))*4 + min(2,len(am))*8 + min(4,len(km))
        if intent['task_shape']=='review' and p['id']=='qa-auditor': score += 8
        if intent['task_shape']=='integrate' and p['id']=='delivery-integrator': score += 12
        # General remains a real supported task profile, not a tool-bypass fallback.
        if p['id']=='general' and not dm and not am: score = min(score, 2)
        base['candidates'].append({'role':p['id'],'score':score,
                                   'matched_domains':dm,'matched_artifacts':am,'matched_terms':km})
    base['candidates'].sort(key=lambda x:(-x['score'],x['role']))
    base['candidate_digest'] = digest(base['candidates'])
    if semantic_decision is not None:
        obj(semantic_decision, {'intent_digest','candidate_digest','role','rationale','evidence_refs'})
        ensure(semantic_decision['intent_digest']==base['intent_digest'] and
               semantic_decision['candidate_digest']==base['candidate_digest'], 'ROUTE_STALE', 'Semantic decision belongs to a different intent/candidate set')
        string(semantic_decision['rationale'], 'rationale', 2000)
        names(semantic_decision['evidence_refs'], 'evidence_refs')
        ensure(bool(semantic_decision['evidence_refs']), 'ROUTE_EVIDENCE', 'Host decision needs references to the current request/contract')
        ensure(semantic_decision['role'] in {x['role'] for x in base['candidates']},
               'ROUTE_FORBIDDEN', 'A semantic decision cannot override capability or shape filters')
        return {**base, 'state':'SELECTED','selected_role':semantic_decision['role'],
                'decision_source':'host_semantic','semantic_decision':semantic_decision}
    if not base['candidates']:
        return {**base,'state':'NO_ELIGIBLE_ROLE'}
    a = base['candidates'][0]; second = base['candidates'][1]['score'] if len(base['candidates'])>1 else 0
    uncertain = a['score'] < 3 or a['score']-second < 3
    if intent['needs_semantic_resolution'] and intent['task_shape'] not in {'review','integrate'}:
        uncertain = True
    return {**base, 'state':'ROUTE_UNCERTAIN' if uncertain else 'SELECTED',
            'selected_role':None if uncertain else a['role']}

def validate_route(result: dict, intent: dict) -> None:
    ensure(isinstance(result,dict), 'ROUTE', 'Expected route object')
    expected = route(intent, host=result.get('host',''), available_tools=result.get('available_tools',[]),
                     semantic_decision=result.get('semantic_decision'))
    ensure(result == expected, 'ROUTE_TAMPERED', 'Frozen route does not reproduce from intent and reviewed profiles')
    ensure(result['state']=='SELECTED' and result['selected_role'] is not None,
           'ROUTE_UNRESOLVED', 'Resolve a single owner before compile/dispatch')
