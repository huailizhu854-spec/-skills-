#!/usr/bin/env python3
"""Offline labeled routing evaluation. Synthetic smoke data, not an external benchmark."""
from __future__ import annotations
import argparse
from pathlib import Path
import json
import hashlib
from collections import Counter
from intelligence_common import read_json,write_new
from intent_compiler import compile_intent
from agent_router import route

def evaluate(path: Path) -> dict:
    dataset=read_json(path);results=[];confusion=Counter()
    for case in dataset['cases']:
        intent=compile_intent(case['request'],case.get('hints'))
        actual=route(intent,host=case.get('host','fixture'),available_tools=case.get('available_tools',[]))
        ok=actual['state']==case['expected_state'] and actual['selected_role']==case.get('expected_role')
        expected=case.get('expected_role') or case['expected_state'];predicted=actual['selected_role'] or actual['state']
        confusion[expected+' -> '+predicted]+=1
        results.append({'id':case['id'],'passed':ok,'expected_state':case['expected_state'],
                        'expected_role':case.get('expected_role'),'actual_state':actual['state'],
                        'actual_role':actual['selected_role'],'decision_source':actual['decision_source']})
    positives=[r for r in results if r['expected_state']=='SELECTED']
    selected=[r for r in positives if r['actual_role'] is not None]
    negative=[r for r in results if r['expected_state']!='SELECTED']
    return {'schema_version':1,'dataset_kind':dataset['kind'],'dataset_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'cases':len(results),'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results),
        'positive_cases':len(positives),'positive_correct':sum(r['passed'] for r in positives),
        'positive_selection_coverage':len(selected)/len(positives) if positives else None,
        'selected_positive_precision':sum(r['passed'] for r in selected)/len(selected) if selected else None,
        'abstention_and_capability_cases':len(negative),'negative_correct':sum(r['passed'] for r in negative),
        'unsafe_selections_on_negative_cases':sum(r['actual_role'] is not None for r in negative),
        'confusion':dict(sorted(confusion.items())),'results':results,
        'real_model_calls':0,'external_benchmark':False,
        'baseline_comparison':'NOT_AVAILABLE: 3.2 has no comparable automatic router; no matched real-host experiment was run.',
        'limitations':['Author-created synthetic smoke cases, not independent or representative customer data.',
                      'Labels/lexical rules are not a guarantee for unseen or adversarial natural language.',
                      'No causal claim of improved model reasoning, token savings, or production success.']}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--dataset',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();r=evaluate(a.dataset);write_new(a.output,r)
    print(json.dumps({k:v for k,v in r.items() if k not in ('results','confusion')},ensure_ascii=False,indent=2))
