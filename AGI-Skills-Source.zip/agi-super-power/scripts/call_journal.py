"""Per-attempt durable event journal, fsynced BEFORE/AFTER each model call.
Private by default. Abrupt termination leaves CALL_STARTED without a completion,
which means UNKNOWN, never success. No background writer or model execution.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import time


class CallJournal:
    def __init__(self, directory: Path, secrets=()):
        self.path = directory / 'model-events.jsonl'
        self.secrets = tuple(x for x in secrets if x)
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0)
        self.fd = os.open(self.path, flags, 0o600)
        self.seq = 0
        self.previous = '0' * 64

    def append(self, event: str, **data):
        payload = {'seq': self.seq + 1, 'event': event, 'at': time.time(),
                   'previous_sha256': self.previous, **data}
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, allow_nan=False)
        for secret in self.secrets:
            raw = raw.replace(secret, '<redacted-credential>')
        encoded = (raw + '\n').encode('utf-8')
        view = memoryview(encoded)
        while view:
            written = os.write(self.fd, view)
            if written <= 0:
                raise OSError('Incomplete journal write')
            view = view[written:]
        os.fsync(self.fd)
        self.previous = hashlib.sha256(encoded).hexdigest()
        self.seq += 1

    def close(self):
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None
