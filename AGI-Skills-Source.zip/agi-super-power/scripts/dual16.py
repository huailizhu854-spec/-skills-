"""Strict 2-controller / 16-worker profile in the ORIGINAL TeamStore database.

This is an observation-driven scheduler, not a model provider. The host performs
spawn/resume/query; this module enforces authorization and checks recorded evidence.
JSON observations are NOT cryptographic provider attestation or an OS sandbox.
"""
from __future__ import annotations
import json
import time
import uuid
from pathlib import Path
from typing import Any
from kernel import local_file, load_json
from team_runtime import (TeamError, TeamStore, require, fields, identifier, text,
                          digest, canonical, write_json)

PROFILE = 'dual-controller-16'
CONTROLLERS = 2
WORKERS = 16
PER_CONTROLLER = 8
TOTAL = 18
NATIVE_HOSTS = {'codex_native', 'claude_code_native', 'workbuddy_mobile_cloud'}


def enabled(plan: dict) -> bool:
    return 'orchestration' in plan


def validate(plan: dict) -> None:
    """A user job contains 16 leaves TOTAL, not 16 recursive children per leaf."""
    if not enabled(plan):
        return
    require(plan['schema_version'] == 3, 'D16_SCHEMA', 'Dual16 requires schema 3')
    o = fields(plan['orchestration'], {'profile', 'controllers', 'workers_per_controller',
                                     'min_workers', 'on_insufficient_host', 'max_controller_turns'})
    require(o['profile'] == PROFILE, 'D16_PROFILE', 'Unknown orchestration profile')
    require(type(o['min_workers']) is int and o['min_workers'] == WORKERS and
            type(o['workers_per_controller']) is int and o['workers_per_controller'] == PER_CONTROLLER,
            'D16_SIZE', 'This release freezes 2 x 8 workers; never silently downsize')
    require(o['on_insufficient_host'] == 'BLOCK', 'D16_FALLBACK', 'No silent serial/inline fallback')
    require(type(o['max_controller_turns']) is int and 2 <= o['max_controller_turns'] <= 256,
            'D16_BUDGET', 'Bound controller turns per controller (2..256)')
    require(len(plan['tasks']) == WORKERS, 'D16_SIZE', 'Exactly 16 distinct leaf contracts required')
    require(plan['policy']['max_parallel'] >= WORKERS and plan['policy']['max_total_attempts'] >= WORKERS,
            'D16_BUDGET', 'Worker and initial-attempt budgets must fit all 16 leaves')
    controllers = o['controllers']
    require(isinstance(controllers, list) and len(controllers) == CONTROLLERS,
            'D16_CONTROLLERS', 'Exactly two real controller sessions required')
    tids = {t['id'] for t in plan['tasks']}
    members, cids = [], []
    for c in controllers:
        fields(c, {'id', 'mission', 'members'})
        identifier(c['id'], 'controller.id'); text(c['mission'], 'controller.mission')
        require(c['id'] not in cids and c['id'] not in tids, 'D16_ID', 'Controller IDs must be distinct from workers')
        require(isinstance(c['members'], list) and len(c['members']) == PER_CONTROLLER and
                all(isinstance(x, str) for x in c['members']), 'D16_MEMBERS', 'Each controller owns eight workers')
        cids.append(c['id']); members.extend(c['members'])
    require(len(set(members)) == WORKERS and set(members) == tids,
            'D16_MEMBERS', 'Every leaf must have exactly one controller; no orphan or overlap')
    require(len({c['mission'].strip().casefold() for c in controllers}) == CONTROLLERS,
            'D16_MISSION', 'Controllers must have distinct responsibilities')
    from verifier_registry import REGISTRY
    for t in plan['tasks']:
        require(all(c['method'] in REGISTRY and c['evidence_kind']=='RUNTIME_FACT' for c in t['acceptance']),
                'D16_VERIFIER','Register independent requirement verifiers before creating all 18 sessions')
        require(t['executor']['type']=='fixture' or all(c['method']!='dual16-shard-v1' for c in t['acceptance']),
                'D16_VERIFIER','The synthetic shard verifier must not be used for native business tasks')
    hosts = {t['executor']['type'] for t in plan['tasks']}
    require(len(hosts) == 1 and hosts <= NATIVE_HOSTS | {'fixture'},
            'D16_HOST', 'Use one observed native host; fixture is explicitly offline, never command/model/inline')
    owners = {t: c['id'] for c in controllers for t in c['members']}
    for t in plan['tasks']:
        require(t['reviewer'] in cids and t['reviewer'] != owners[t['id']],
                'D16_REVIEWER', 'The other controller reviews; a controller cannot accept its own team')
        require(not t['capabilities']['model_delegation'], 'D16_RECURSION', 'Leaves cannot recruit')


def create_schema(db, plan: dict, offline_fixture: bool) -> None:
    if not enabled(plan):
        return
    host = plan['tasks'][0]['executor']['type']
    require((host == 'fixture') is bool(offline_fixture), 'D16_FIXTURE_FLAG',
            'Fixture plans need offline_fixture=True; native plans may not use it')
    db.executescript('''
    CREATE TABLE d16_sessions(slot TEXT PRIMARY KEY, kind TEXT NOT NULL, controller TEXT,
      state TEXT NOT NULL, nonce TEXT UNIQUE, host_run_id TEXT UNIQUE, evidence TEXT,
      pending_turn TEXT, turns INTEGER NOT NULL DEFAULT 0, last_seen REAL);
    CREATE TABLE d16_grants(id TEXT PRIMARY KEY, controller TEXT NOT NULL, task TEXT NOT NULL,
      action TEXT NOT NULL, attempt INTEGER NOT NULL, result_digest TEXT,
      payload TEXT NOT NULL, consumed INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE d16_runtime(key TEXT PRIMARY KEY, value TEXT NOT NULL);
    ''')
    for c in plan['orchestration']['controllers']:
        db.execute("INSERT INTO d16_sessions(slot,kind,controller,state) VALUES (?,'controller',NULL,'NEW')", (c['id'],))
        for tid in c['members']:
            db.execute("INSERT INTO d16_sessions(slot,kind,controller,state) VALUES (?,'worker',?,'NEW')", (tid,c['id']))
    db.execute('INSERT INTO d16_runtime VALUES (?,?)', ('profile', canonical('fixture' if offline_fixture else 'native')))


def get(store: TeamStore, key: str, default=None):
    row=store.db.execute('SELECT value FROM d16_runtime WHERE key=?',(key,)).fetchone()
    return json.loads(row[0]) if row else default


def put(store: TeamStore, key: str, value: Any):
    store.db.execute('INSERT OR REPLACE INTO d16_runtime VALUES (?,?)',(key,canonical(value)))


def session(store: TeamStore, slot: str):
    row=store.db.execute('SELECT * FROM d16_sessions WHERE slot=?',(slot,)).fetchone()
    require(row is not None, 'D16_SLOT', 'Unknown session slot: '+str(slot))
    return row


def evidence(store: TeamStore, ref: dict) -> dict:
    fields(ref, {'path', 'sha256'})
    require(isinstance(ref['path'],str) and ref['path'].startswith('reviews/dual16/'),
            'D16_EVIDENCE', 'Evidence must live in reviews/dual16/')
    require(local_file(store.root,ref['path'])['sha256'] == ref['sha256'], 'D16_EVIDENCE', 'Evidence hash mismatch')
    raw=load_json(store.root/ref['path'])
    require(isinstance(raw,dict), 'D16_EVIDENCE', 'Expected a coordinator-normalized host observation object')
    return raw


def profile_kind(store: TeamStore):
    return get(store,'profile')


def _base(store, obj):
    require(obj.get('plan_digest') == store.meta('plan_digest') and obj.get('goal_digest') == store.meta('goal_digest'),
            'D16_STALE', 'Observation belongs to another plan/goal')
    require(obj.get('execution_kind') == profile_kind(store), 'D16_KIND', 'Fixture evidence cannot promote to native')


def register_probe(store: TeamStore, ref: dict) -> dict:
    with store.transaction():
        store.active(); probe=evidence(store,ref); _base(store,probe)
        require(get(store,'probe') is None,'D16_PROBE_FROZEN','Probe is immutable for this run')
        require(probe.get('host') == store.meta('plan')['tasks'][0]['executor']['type'], 'D16_HOST','Probe must match frozen executor')
        require(probe['host'] != 'workbuddy_mobile_cloud', 'D16_HOST_UNSUPPORTED',
                'Bundled WorkBuddy adapter is synchronous_terminal and cannot implement this persistent 18-session profile')
        require(type(probe.get('session_capacity')) is int and probe['session_capacity'] >= TOTAL,
                'D16_CAPACITY','Need capacity for 18 child sessions, excluding the chat/root coordinator')
        require(type(probe.get('worker_parallel_capacity')) is int and probe['worker_parallel_capacity'] >= WORKERS,
                'D16_CAPACITY','Need capacity for 16 workers; do not silently batch below the requirement')
        for key in ('persistent_sessions','resume','query','async_launch','cancel'):
            require(probe.get(key) is True,'D16_CAPABILITY','Host capability missing: '+key)
        text(probe.get('source'), 'probe.source')
        require(probe.get('authorized') is True,'D16_AUTHORIZATION','Explicit authorization for the 18-session run required')
        put(store,'probe',ref); store.event('D16_PREFLIGHT',execution_kind=profile_kind(store),evidence=ref)
    return {'ready_for_launch': True, 'agents_started': 0, 'provider_attested': False}


def reserve(store: TeamStore, slot: str) -> dict:
    """Exactly-once intent BEFORE spawn. Lost returns leave RESERVED; never retry blindly."""
    with store.transaction():
        store.active(); require(get(store,'probe') is not None,'D16_PROBE','Preflight first')
        evidence(store,get(store,'probe'))
        r=session(store,slot)
        require(r['state']=='NEW','D16_SPAWN_UNKNOWN','Already reserved/launched; query/cancel the original host, do not duplicate')
        nonce=uuid.uuid4().hex
        store.db.execute("UPDATE d16_sessions SET state='RESERVED',nonce=? WHERE slot=?",(nonce,slot))
        plan=store.meta('plan')
        members=[x[0] for x in store.db.execute('SELECT slot FROM d16_sessions WHERE controller=? ORDER BY slot',(slot,))]
        packet={'schema_version':1,'slot':slot,'kind':r['kind'],'controller':r['controller'],'members':members,
                'launch_nonce':nonce,'execution_kind':profile_kind(store),'plan_digest':store.meta('plan_digest'),
                'goal_digest':store.meta('goal_digest'),'goal':plan['goal'],
                'mission':(next(c['mission'] for c in plan['orchestration']['controllers'] if c['id']==slot) if r['kind']=='controller' else next(t['mission'] for t in plan['tasks'] if t['id']==slot)),
                'instruction':('Wait for ledger-bound task packets; never spawn children, never claim completion before executing your own contract.'
                  if r['kind']=='worker' else 'Control only your eight members via decision requests. The root only transports your decisions. Review the other team independently. Never edit the ledger or worker artifacts.'),
                'transport':'Host must launch a separate persistent model session; this packet is not execution evidence.'}
        path=f'reviews/dual16/launch-{slot}-{nonce}.json'; write_json(store.root/path,packet)
        store.event('D16_LAUNCH_RESERVED',slot,nonce=nonce,kind_of_session=r['kind'])
    return {**packet,'packet_path':str(store.root/path),'agents_started_by_this_command':0}


def observe_start(store: TeamStore, slot: str, ref: dict) -> dict:
    with store.transaction():
        store.active(); r=session(store,slot); raw=evidence(store,ref); _base(store,raw)
        require(r['state']=='RESERVED','D16_SESSION_STATE','Only the reserved launch can be bound once')
        require(raw.get('slot')==slot and raw.get('launch_nonce')==r['nonce'],'D16_NONCE','Launch identity mismatch')
        hid=text(raw.get('host_run_id'),'host_run_id')
        require(raw.get('state') in ('running','idle'),'D16_SESSION_STATE','Need a live separate session')
        require(hid not in {x[0] for x in store.db.execute('SELECT host_run_id FROM d16_sessions WHERE host_run_id IS NOT NULL')},
                'D16_DUPLICATE_SESSION','One real session cannot fill two roles')
        text(raw.get('native_tool'),'native_tool')
        require(isinstance(raw.get('raw_response'),str) and hid in raw['raw_response'],
                'D16_SOURCE','Preserve the original host response including its ID; worker self-report is insufficient')
        store.db.execute("UPDATE d16_sessions SET state='LIVE',host_run_id=?,evidence=?,last_seen=? WHERE slot=?",(hid,canonical(ref),time.time(),slot))
        store.event('D16_SESSION_BOUND',slot,host_run_id=hid,evidence=ref)
    return {'bound':True,'slot':slot,'host_run_id':hid,'provider_attested':False}


def barrier(store: TeamStore, ref: dict) -> dict:
    """One query snapshot of all 18 live sessions; cumulative launches do not suffice."""
    with store.transaction():
        store.active(); raw=evidence(store,ref); _base(store,raw)
        rows=list(store.db.execute('SELECT * FROM d16_sessions'))
        require(len(rows)==TOTAL and all(r['state']=='LIVE' for r in rows), 'D16_ROSTER','All 2+16 sessions must be live before work')
        seen=raw.get('sessions'); require(isinstance(seen,list) and len(seen)==TOTAL,'D16_ROSTER','Query must include exactly 18 sessions')
        expected={r['slot']:r['host_run_id'] for r in rows}
        require(len({x.get('slot') for x in seen})==TOTAL,'D16_ROSTER','Duplicate query entries')
        require({x.get('slot'):x.get('host_run_id') for x in seen}==expected and
                all(x.get('state') in ('running','idle') for x in seen),'D16_ROSTER','Query did not confirm the complete live roster')
        text(raw.get('native_tool'),'query.native_tool'); text(raw.get('raw_response'),'query.raw_response')
        require(all(h in raw['raw_response'] for h in expected.values()),'D16_SOURCE','Query response must bind all observed IDs')
        for r in rows: evidence(store,json.loads(r['evidence']))
        now=time.time(); put(store,'barrier',{'ref':ref,'at':now,'resident_sessions':TOTAL,'resident_workers':WORKERS})
        store.db.execute('UPDATE d16_sessions SET last_seen=?',(now,))
        store.event('D16_ROSTER_BARRIER',resident_sessions=TOTAL,resident_workers=WORKERS,evidence=ref)
    return {'barrier_passed':True,'resident_sessions':TOTAL,'resident_workers':WORKERS,
            'simultaneous_model_inference_proven':False,'provider_attested':False}


def require_barrier(store):
    b=get(store,'barrier'); require(b is not None,'D16_ROSTER','Observe all 18 live sessions before dispatch')
    require(time.time()-b['at'] <= 300,'D16_QUERY_STALE','Refresh the real host roster query (older than 300 seconds)')
    evidence(store,b['ref']); evidence(store,get(store,'probe'))
    require(all(r['state']=='LIVE' for r in store.db.execute('SELECT state FROM d16_sessions')),
            'D16_ROSTER','A controller or worker is no longer known-live; pause and reconcile')


def request_decision(store: TeamStore, controller: str) -> dict:
    with store.transaction():
        store.active(); require_barrier(store); r=session(store,controller)
        require(r['kind']=='controller','D16_CONTROLLER','Workers cannot issue control decisions')
        require(r['pending_turn'] is None,'D16_TURN_UNKNOWN','Unanswered turn: query the original controller; do not resend')
        limit=store.meta('plan')['orchestration']['max_controller_turns']
        require(r['turns'] < limit,'D16_TURN_BUDGET','Controller turn budget exhausted')
        rows=list(store.db.execute('SELECT * FROM tasks ORDER BY id'))
        members=[x[0] for x in store.db.execute('SELECT slot FROM d16_sessions WHERE controller=? ORDER BY slot',(controller,))]
        ready=set(store.ready())
        dispatch=[{'task_id':x['id'],'attempt':x['attempt']+1,'mission':json.loads(x['contract'])['mission']}
                  for x in rows if x['id'] in members and x['id'] in ready]
        reviews=[{'task_id':x['id'],'attempt':x['attempt'],'result_digest':digest(json.loads(x['result'])),
                  'packet':json.loads(x['packet']),'result':json.loads(x['result'])}
                 for x in rows if x['status']=='submitted' and json.loads(x['contract'])['reviewer']==controller]
        nonce=uuid.uuid4().hex
        packet={'controller':controller,'host_run_id':r['host_run_id'],'turn_nonce':nonce,
                'plan_digest':store.meta('plan_digest'),'goal_digest':store.meta('goal_digest'),
                'members':members,'ready':dispatch,'reviews':reviews,
                'states':[{k:x[k] for k in ('id','status','attempt')} for x in rows],
                'allowed_actions':['dispatch','accept','rework','block','wait'],
                'instruction':'Return strict JSON containing controller, turn_nonce, plan_digest, goal_digest copied from this request, and actions. Return actions only for your ready members or your assigned cross-team reviews. Read actual artifacts for review. Reasons must name the task-specific evidence. A PASS claim cannot bypass registered verifiers.'}
        store.db.execute('UPDATE d16_sessions SET pending_turn=?,turns=turns+1 WHERE slot=?',(canonical(packet),controller))
        write_json(store.root/f'reviews/dual16/turn-{nonce}.json',packet)
        store.event('D16_CONTROLLER_TURN',controller,nonce=nonce)
    return packet


def record_decision(store: TeamStore, controller: str, ref: dict) -> dict:
    """Record the controller's observed response as one-use, scope-bound grants."""
    with store.transaction():
        store.active(); require_barrier(store); r=session(store,controller)
        require(r['kind']=='controller' and r['pending_turn'] is not None,'D16_TURN','No pending controller turn')
        packet=json.loads(r['pending_turn']); raw=evidence(store,ref); _base(store,raw)
        require(raw.get('controller')==controller and raw.get('host_run_id')==r['host_run_id'] and
                raw.get('turn_nonce')==packet['turn_nonce'],'D16_TURN','Wrong controller identity or replayed turn')
        text(raw.get('raw_response'),'raw_response'); text(raw.get('native_tool'),'native_tool')
        # The adapter must preserve its parsed payload in raw_response. This is a
        # consistency check only, not a claim to authenticate arbitrary tool text.
        decision=raw.get('decision'); fields(decision,{'actions','controller','turn_nonce','plan_digest','goal_digest'})
        require(all(decision[k]==packet[k] for k in ('controller','turn_nonce','plan_digest','goal_digest')),
                'D16_TURN','Controller must echo this exact request identity in its own returned payload')
        require(isinstance(decision['actions'],list) and 1<=len(decision['actions'])<=16,'D16_ACTION','One to sixteen bounded actions required')
        require(raw.get('returned_payload_sha256')==digest(decision),'D16_SOURCE','Parsed controller output is hash-bound')
        from v3_protocol import strict_loads
        try:
            parsed=strict_loads(raw['raw_response'])
        except (ValueError,TypeError):
            raise TeamError('D16_SOURCE','Controller output must be strict JSON or a preserved JSON tool envelope')
        if isinstance(parsed,dict) and parsed.get('ok') is True and 'data' in parsed:
            parsed=parsed['data']
        require(parsed==decision,'D16_SOURCE','Parsed controller decision differs from the preserved raw response')
        ready={x['task_id']:x for x in packet['ready']}; reviews={x['task_id']:x for x in packet['reviews']}
        targets=set(); grants=[]
        for i,a in enumerate(decision['actions']):
            fields(a,{'action','task_id','reason'}); text(a['reason'],'action.reason')
            action=a['action']; tid=a['task_id']
            require(action in {'dispatch','accept','rework','block','wait'},'D16_ACTION','Unsupported controller action')
            if action=='wait':
                require(tid is None and len(decision['actions'])==1,'D16_ACTION','wait is a standalone non-task action')
                continue
            require(tid not in targets,'D16_DUPLICATE_ACTION','One action per task per turn'); targets.add(tid)
            row=store.row(tid)
            if action=='dispatch':
                require(tid in ready and session(store,tid)['controller']==controller,'D16_CROSS_TEAM','Cannot dispatch another controller\'s worker')
                require(tid in store.ready() and row['attempt']+1==ready[tid]['attempt'],'D16_STALE','Task is no longer ready')
                attempt=row['attempt']+1; rd=None
            else:
                require(tid in reviews and json.loads(row['contract'])['reviewer']==controller,'D16_REVIEWER','Only assigned cross-team reviews')
                require(row['status']=='submitted' and digest(json.loads(row['result']))==reviews[tid]['result_digest'],
                        'D16_STALE','Review result has changed')
                attempt=row['attempt']; rd=reviews[tid]['result_digest']
            require(not store.db.execute('SELECT 1 FROM d16_grants WHERE task=? AND consumed=0',(tid,)).fetchone(),
                    'D16_DUPLICATE_GRANT','A grant already exists; consume it, do not duplicate')
            gid='g-'+packet['turn_nonce']+'-'+str(i)
            payload={'action':a,'observation':ref,'controller':controller,'host_run_id':r['host_run_id'],
                     'turn_nonce':packet['turn_nonce'],'plan_digest':store.meta('plan_digest')}
            store.db.execute('INSERT INTO d16_grants VALUES (?,?,?,?,?,?,?,0)',(gid,controller,tid,action,attempt,rd,canonical(payload)))
            grants.append(gid)
        store.db.execute('UPDATE d16_sessions SET pending_turn=NULL WHERE slot=?',(controller,))
        store.event('D16_CONTROLLER_DECISION',controller,evidence=ref,grants=grants,decision=decision)
    return {'recorded':True,'grants':grants,'agents_started_by_this_command':0}


def _grant(store, tid, action, attempt, result_digest=None):
    row=store.db.execute('SELECT * FROM d16_grants WHERE task=? AND action=? AND attempt=? AND consumed=0',(tid,action,attempt)).fetchone()
    require(row is not None,'D16_GRANT','A real controller decision is required before '+action)
    require(row['result_digest']==result_digest,'D16_STALE','Grant targets another result')
    payload=json.loads(row['payload']); observed=evidence(store,payload['observation']); _base(store,observed)
    require(observed.get('host_run_id')==session(store,row['controller'])['host_run_id'], 'D16_CONTROLLER','Controller changed')
    return row


def guard_claim(store, tid, worker):
    if not enabled(store.meta('plan')): return
    require_barrier(store)
    require(worker==tid and session(store,worker)['kind']=='worker','D16_WORKER','Use the unique reserved worker slot for this task')
    row=_grant(store,tid,'dispatch',store.row(tid)['attempt']+1)
    require(row['controller']==session(store,tid)['controller'],'D16_CROSS_TEAM','Dispatch owner mismatch')
    store.db.execute('UPDATE d16_grants SET consumed=1 WHERE id=?',(row['id'],))


def guard_bind(store, tid, mode, host_run_id):
    if not enabled(store.meta('plan')): return
    require_barrier(store)
    require(mode==profile_kind(store),'D16_KIND','Mode must match the frozen profile')
    require(session(store,tid)['host_run_id']==host_run_id,'D16_SESSION_BIND','Resume the reserved worker session; do not spawn another')
    if mode=='native':
        from delivery_state import dispatch
        require(dispatch(store,store.row(tid)['token'])['guarded']==1,'D16_SUBMIT_INTENT',
                'Record delivery_cli begin-submit before sending the packet to the existing native session')


def guard_review(store, review):
    if not enabled(store.meta('plan')): return
    require_barrier(store)
    row=_grant(store,review['task_id'],review['decision'],store.row(review['task_id'])['attempt'],review['result_digest'])
    require(row['controller']==review['reviewer'],'D16_REVIEWER','Review must come from the designated controller')
    store.db.execute('UPDATE d16_grants SET consumed=1 WHERE id=?',(row['id'],))


def apply_review(store: TeamStore, grant_id: str) -> dict:
    row=store.db.execute('SELECT * FROM d16_grants WHERE id=? AND consumed=0',(grant_id,)).fetchone()
    require(row is not None and row['action'] in {'accept','rework','block'},'D16_GRANT','Expected an unused review grant')
    task=store.row(row['task']); result=json.loads(task['result']); payload=json.loads(row['payload'])
    rel=f'reviews/dual16/review-{grant_id}.json'
    if not (store.root/rel).exists(): write_json(store.root/rel,payload)
    require(digest(load_json(store.root/rel))==digest(payload),'D16_EVIDENCE','Review file changed')
    review={'task_id':row['task'],'reviewer':row['controller'],'decision':row['action'],
            'result_id':result['result_id'],'result_digest':digest(result),'goal_digest':store.meta('goal_digest'),
            'reason':payload['action']['reason'],'evidence_path':rel,
            'evidence_sha256':local_file(store.root,rel)['sha256']}
    return store.review(review)


def invalidate_grant(store: TeamStore, grant_id: str, reason: str) -> dict:
    """A rejected approval may be superseded, never turned into a successful one."""
    text(reason,'reason')
    with store.transaction():
        store.active(); row=store.db.execute('SELECT * FROM d16_grants WHERE id=? AND consumed=0',(grant_id,)).fetchone()
        require(row is not None,'D16_GRANT','No outstanding grant')
        require(row['action']=='accept' and store.row(row['task'])['status']=='submitted','D16_GRANT','Only a rejected, unconsumed acceptance may be withdrawn')
        # Recompute failure rather than accepting a user-supplied assertion.
        from verifier_registry import evaluate
        t=store.row(row['task']); verdict=evaluate(json.loads(t['packet']),json.loads(t['result']))
        require(not verdict['passed'],'D16_GRANT','Only independently failed acceptance can be withdrawn automatically')
        store.db.execute('UPDATE d16_grants SET consumed=1 WHERE id=?',(grant_id,))
        store.event('D16_APPROVAL_REJECTED',row['task'],grant=grant_id,reason=reason)
    return {'withdrawn':True,'task_status':'submitted','needs_new_controller_review':True}


def report(store: TeamStore) -> dict:
    rows=list(store.db.execute('SELECT * FROM d16_sessions'))
    errors=[]
    for r in rows:
        if r['evidence']:
            try: evidence(store,json.loads(r['evidence']))
            except (ValueError,OSError) as exc: errors.append(str(exc))
    for r in store.db.execute('SELECT payload FROM d16_grants'):
        try: evidence(store,json.loads(r[0])['observation'])
        except (ValueError,OSError) as exc: errors.append(str(exc))
    b=get(store,'barrier')
    for r in store.db.execute("SELECT value FROM d16_runtime WHERE key LIKE 'health-%'"):
        try: evidence(store,json.loads(r[0]))
        except (ValueError,OSError) as exc: errors.append(str(exc))
    for ref in [get(store,'probe'), b['ref'] if b else None]:
        if ref:
            try: evidence(store,ref)
            except (ValueError,OSError) as exc: errors.append(str(exc))
    c=[r for r in rows if r['kind']=='controller']; w=[r for r in rows if r['kind']=='worker']
    bound=sum(bool(r['host_run_id']) for r in rows)
    tasks=list(store.db.execute('SELECT * FROM tasks'))
    acted={x['slot']:store.db.execute("SELECT COUNT(*) FROM d16_grants WHERE controller=? AND action='dispatch' AND consumed=1",(x['slot'],)).fetchone()[0] for x in c}
    accepted=sum(t['status']=='accepted' for t in tasks)
    ok=(bound==TOTAL and b is not None and not errors and all(r['state']=='LIVE' for r in rows)
        and all(r['pending_turn'] is None for r in c)
        and all(v>=PER_CONTROLLER for v in acted.values()) and len(acted)==2)
    return {'profile':PROFILE,'execution_kind':profile_kind(store),'controllers_bound':sum(bool(r['host_run_id']) for r in c),
            'workers_bound':sum(bool(r['host_run_id']) for r in w),'workers_accepted':accepted,'controller_dispatches':acted,
            'roster_barrier_observed':b is not None,'topology_evidence_valid':ok,'evidence_errors':errors,
            'native_execution_observed':ok and accepted==WORKERS and profile_kind(store)=='native',
            'provider_identity_attested':False,'simultaneous_model_inference_proven':False,
            'note':'18 resident sessions is not proof of 18 simultaneous model inferences. Coordinator-supplied evidence requires host-side audit.'}


def observe_health(store: TeamStore, slot: str, ref: dict) -> dict:
    """Pause on ambiguous or stopped host state. No automatic replacement/restart."""
    with store.transaction():
        require(digest(load_json(store.root/'plan.json'))==store.meta('plan_digest'),'PLAN_TAMPERED','Frozen plan changed')
        r=session(store,slot); raw=evidence(store,ref); _base(store,raw)
        require(raw.get('slot')==slot and raw.get('host_run_id')==r['host_run_id'] and r['host_run_id'] is not None,
                'D16_SESSION_BIND','Health receipt must identify the existing session')
        state=raw.get('state'); require(state in {'running','idle','unknown','stopped'},'D16_SESSION_STATE','Unexpected observed state')
        require(isinstance(raw.get('raw_response'),str) and r['host_run_id'] in raw['raw_response'],
                'D16_SOURCE','Preserve the original query/cancel response')
        require(r['state']!='STOPPED','D16_SESSION_STATE','Stopped sessions are not resurrected; use a new run after confirmed cleanup')
        store.db.execute('UPDATE d16_sessions SET state=?,last_seen=? WHERE slot=?',
                         ('LIVE' if state in {'running','idle'} else 'STOPPED' if state=='stopped' else 'UNKNOWN',time.time(),slot))
        put(store,'health-'+slot,ref)
        store.event('D16_HEALTH',slot,observed_state=state,evidence=ref)
    return {'slot':slot,'known_live':state in {'running','idle'},'automatic_replacement':False}


def decorate_dispatch(job: Path, descriptor: dict) -> dict:
    """Prevent old adapter wording from creating a 19th session for a leased task."""
    with TeamStore(job) as store:
        if not enabled(store.meta('plan')): return descriptor
        row=session(store,descriptor['task_id'])
        return {**descriptor,'orchestration_profile':PROFILE,'dispatch_operation':'resume_existing_session',
                'expected_host_run_id':row['host_run_id'],'controller_id':row['controller'],
                'recommended_context':'The already reserved independent worker session; do not fork another session',
                'next':'Record delivery_cli begin-submit before sending this packet ONCE to expected_host_run_id via the actually available host resume/send tool. Do not spawn a replacement. Bind the same observed session ID, collect its new terminal task result, and wait for the opposite controller review.'}


def guard_revise(store):
    if not enabled(store.meta('plan')):return
    require(all(r['state'] in ('NEW','STOPPED') for r in store.db.execute('SELECT state FROM d16_sessions')),
            'D16_OLD_SESSIONS','Confirm termination of both controllers and all workers before creating a successor job')
