"""Reviewed host registry + evidence-bound capability snapshots, not a transport.

The current tool catalog must be inspected by the coordinator. Loading a probe
file does not discover a client, authenticate a host, or grant execution rights.
"""
from __future__ import annotations
import time
from pathlib import Path
from kernel import local_file
from team_runtime import require, fields, text
from host_registry import host_info

CAPABILITIES={'create','query','wait','cancel','confirm_stopped','artifacts','recover',
              'independent_context','workspace','tool_enforcement','shared_files',
              'model_settings','host_memory','usage','idempotent_create','nested_mapping'}
# Implementations are reviewed code, not dynamically imported from user JSON.
ADAPTERS={
 'codex_native':{'kind':'observation','module':'host_adapters.codex','live_transport':False},
 'claude_code_native':{'kind':'observation','module':'host_adapters.claude_code','live_transport':False},
 'workbuddy_mobile_cloud':{'kind':'observation','module':'host_adapters.workbuddy_mobile_cloud','live_transport':False},
 'fixture':{'kind':'offline_fixture','module':'team_runner','live_transport':False},
 'bounded_model':{'kind':'bounded_text_command','module':'model_worker','live_transport':False},
}
TARGET_PRODUCTS={'codex_native':'Codex','claude_code_native':'Claude Code',
                 'workbuddy_candidate':'WorkBuddy Desktop','fixture':'Offline fixture',
                 'workbuddy_mobile_cloud':'WorkBuddy Mobile Cloud',
                 'bounded_model':'Bounded text bridge'}

def blank_probe(host, *, product=None, version='UNKNOWN', os_name='UNKNOWN'):
    info=host_info(host); host=info['id']
    return {'schema_version':1,'host':host,'product':product or TARGET_PRODUCTS[host],
            'client_version':version,'os':os_name,'observed_at':None,'expires_at':None,
            'evidence_kind':'NOT_PROBED','capabilities':{k:{'status':'unknown','evidence':None} for k in sorted(CAPABILITIES)},
            'tool_permissions':'unknown','effort':'not_exposed','nested_scheduling':False}

def evaluate_probe(probe, evidence_root:Path, *, required=(), now=None, max_age_seconds=86400, allow_unknown_client=None, fixture_host=None):
    fields(probe,{'schema_version','host','product','client_version','os','observed_at','expires_at',
                   'evidence_kind','capabilities','tool_permissions','effort','nested_scheduling'})
    require(type(probe['schema_version']) is int and probe['schema_version']==1,'PROBE_SCHEMA','Expected probe schema 1')
    info=host_info(probe['host']);host=info['id']
    require(host==probe['host'],'PROBE_HOST','Use canonical host ID')
    require(probe['product']==TARGET_PRODUCTS[host],'PRODUCT_MISMATCH',
            'Desktop/CLI/IDE/mini-program capabilities cannot be substituted for one another')
    require(isinstance(probe['capabilities'],dict) and set(probe['capabilities'])==CAPABILITIES,'PROBE_CAPABILITIES','All capabilities must be explicit')
    require(probe['tool_permissions'] in ('host_enforced','instruction_only','unknown'),'PROBE_PERMISSION','Unknown permission enforcement')
    require(probe['effort'] in ('hint_only','setting_accepted','not_exposed'),'PROBE_EFFORT','Unknown effort setting status')
    require(type(probe['nested_scheduling']) is bool,'PROBE_NESTED','Expected boolean nested scheduling')
    require(set(required)<=CAPABILITIES,'PROBE_REQUIRED','Unknown requested capability')
    require(probe['evidence_kind'] in ('NOT_PROBED','CURRENT_TOOL_OBSERVATION','OFFLINE_FIXTURE'),'PROBE_SOURCE','Docs/catalogs are not current tool observations')
    for label in ('client_version','os'):
        require(isinstance(probe[label],str) and bool(probe[label].strip()) and probe[label]==probe[label].strip(),
                'PROBE_TARGET','Client version and OS must be nonempty strings; use UNKNOWN when unobservable')
    now=time.time() if now is None else now
    blockers=[];states={}
    if probe['evidence_kind']=='NOT_PROBED':
        require(probe['observed_at'] is None and probe['expires_at'] is None,'PROBE_TIME','Unprobed capabilities have no observed timestamp')
    else:
        require(type(probe['observed_at']) in (int,float) and type(probe['expires_at']) in (int,float)
                and 0<=probe['observed_at']<=now<probe['expires_at']
                and now-probe['observed_at']<=max_age_seconds,'PROBE_STALE','Capability observation expired, future-dated or missing')
        require((probe['client_version']!='UNKNOWN' or host==allow_unknown_client) and probe['os']!='UNKNOWN','PROBE_TARGET','Bind an observed client version and operating system')
        require(probe['evidence_kind']!='OFFLINE_FIXTURE' or host in ('fixture', fixture_host),'FIXTURE_NOT_LIVE','Fixture evidence cannot attest a real host')
    for key,cap in probe['capabilities'].items():
        fields(cap,{'status','evidence'})
        require(cap['status'] in ('supported','unsupported','unknown'),'PROBE_STATUS','Capability must be supported/unsupported/unknown')
        states[key]=cap['status']
        if cap['status']!='unknown':
            require(probe['evidence_kind']!='NOT_PROBED','PROBE_EVIDENCE','No support declaration without observation')
            fields(cap['evidence'],{'path','sha256'})
            actual=local_file(evidence_root,cap['evidence']['path'])
            require(actual['sha256']==cap['evidence']['sha256'],'PROBE_EVIDENCE','Capability evidence hash mismatch')
        else: require(cap['evidence'] is None,'PROBE_EVIDENCE','Unknown uses null evidence')
    for key in required:
        if states[key]!='supported': blockers.append('CAPABILITY_'+key.upper()+'_'+states[key].upper())
    if probe['nested_scheduling'] and states['nested_mapping']!='supported':blockers.append('UNOBSERVABLE_NESTED_SCHEDULING')
    if probe['tool_permissions']=='host_enforced' and states['tool_enforcement']!='supported':blockers.append('PERMISSION_DECLARATION_CONFLICT')
    if probe['effort']=='setting_accepted' and states['model_settings']!='supported':blockers.append('EFFORT_DECLARATION_CONFLICT')
    implemented=host in ADAPTERS
    if not implemented: blockers.append('NO_REVIEWED_ADAPTER')
    if probe['evidence_kind']=='NOT_PROBED':blockers.append('CURRENT_ENVIRONMENT_NOT_PROBED')
    return {'host':host,'product':probe['product'],'client_version':probe['client_version'],'os':probe['os'],
            'catalog':info,'reviewed_adapter':ADAPTERS.get(host),'capabilities':states,'blockers':blockers,
            'status':'HANDOFF_ONLY' if not implemented else ('BLOCKED' if blockers else 'OBSERVATION_CONTRACT_READY'),
            'execution':'NOT_EXECUTED','actual_run_evidence':None,'native_compatibility_proven':False,
            'note':'A passed probe is a coordinator-reviewed capability snapshot, not a successful host run'}
