"""Compile-time intelligence extension consumed by the existing v3 ledger.

No new task owner or host is launched here. The frozen plan remains the source of
truth; routing/memory/depth are hash-bound by the existing plan digest.
"""
from __future__ import annotations
import copy
import time
from intelligence_common import obj, ensure, digest
from intent_compiler import compile_intent, validate_intent
from agent_router import route, validate_route
from context_engine import capsule, validate_capsule, MemoryStore
from reasoning_depth import plan_depth, validate_depth

TOOL_ALIASES={'Read':'file.read','Write':'file.write','Edit':'file.write','Glob':'file.read',
              'Grep':'file.read','Bash':'shell','WebSearch':'web.read','WebFetch':'web.read'}

def logical_tools(tools: list[str]) -> list[str]:
    return sorted({TOOL_ALIASES.get(t,t) for t in tools})

def validate_extension(task: dict, goal: dict, policy: dict) -> None:
    x=task['intelligence']
    obj(x,{'schema_version','intent','route','reasoning','context','digest'})
    ensure(type(x['schema_version']) is int and x['schema_version']==1,'INTELLIGENCE','Unknown extension schema')
    ensure(x['digest']==digest({k:v for k,v in x.items() if k!='digest'}),'INTELLIGENCE_TAMPERED','Extension digest changed')
    intent=validate_intent(x['intent'])
    ensure(intent['request']==task['mission'] and intent['required_tools']==logical_tools(task['tools']) and
           intent['input_count']==len(task['reads']) and intent['requirement_count']==len(task['requirements']) and
           intent['dependency_count']==len(task['depends_on']),
           'INTENT_CONTRACT','Intent must match the actual frozen task and tool requirements')
    expected_constraints=list(dict.fromkeys(goal['constraints']+task['boundaries']))
    ensure(intent['constraints']==expected_constraints,'INTENT_CONTRACT','Intent cannot drop current boundaries')
    validate_route(x['route'],intent)
    ensure(x['route']['selected_role']==task['role'] and x['route']['host']==task['executor']['type'],
           'ROUTE_CONTRACT','Selected owner/host must match the task contract')
    validate_depth(x['reasoning'],intent)
    ensure(x['reasoning']['attempt_ceiling']<=policy['max_attempts'], 'DEPTH_BUDGET','Intelligence cannot raise the frozen policy ceiling')
    validate_capsule(x['context'],task,goal)
    from verifier_registry import REGISTRY
    ensure(all(c['method'] in REGISTRY and c['evidence_kind']=='RUNTIME_FACT' for c in task['acceptance']),
           'VERIFIER_UNAVAILABLE','Register/review a compatible acceptance verifier before dispatch; no generic semantic PASS fallback')

def ensure_context_fresh(context: dict, *, now: float | None=None) -> None:
    now=time.time() if now is None else now
    ensure(all(r.get('expires_at') is None or r['expires_at']>now for r in context['memory_records']),
           'CONTEXT_EXPIRED','A frozen memory item expired before dispatch; create a revised plan, do not silently replace it')

def enrich_plan(plan: dict, *, project_id: str, available_tools: list[str],
                hints_by_task: dict | None=None, semantic_by_task: dict | None=None,
                memory: MemoryStore | None=None, max_context_bytes: int=16384) -> dict:
    # Lazy import avoids a cycle with the kernel's extension validator.
    from team_runtime import compile_plan
    ensure(plan.get('schema_version')==3,'INTELLIGENCE_VERSION','Only schema 3 plans can opt into intelligence')
    ensure(all('intelligence' not in t for t in plan['tasks']),'INTELLIGENCE_IMMUTABLE','Enrich an unstarted copy, not an existing frozen extension')
    compile_plan(plan)
    hints_by_task={} if hints_by_task is None else hints_by_task
    semantic_by_task={} if semantic_by_task is None else semantic_by_task
    tids={t['id'] for t in plan['tasks']}
    ensure(set(hints_by_task)<=tids and set(semantic_by_task)<=tids,'INTELLIGENCE_TASK','Hints reference an unknown task')
    out=copy.deepcopy(plan); available_tools=logical_tools(available_tools)
    for task in out['tasks']:
        hints=dict(hints_by_task.get(task['id'],{}))
        # Never trust a hint which omits real required tools or alters boundaries.
        hints.update(required_tools=logical_tools(task['tools']),
                     constraints=list(dict.fromkeys(out['goal']['constraints']+task['boundaries'])),
                     input_count=len(task['reads']),requirement_count=len(task['requirements']),
                     dependency_count=len(task['depends_on']))
        intent=compile_intent(task['mission'],hints)
        decision=route(intent,host=task['executor']['type'],available_tools=available_tools,
                       semantic_decision=semantic_by_task.get(task['id']))
        ensure(decision['state']=='SELECTED',decision['state'],
               task['id']+': no unambiguous supported owner; supply bounded semantic decision or clarify output hints')
        task['role']=decision['selected_role']
        depth=plan_depth(intent,attempt_ceiling=out['policy']['max_attempts'])
        query=task['mission']+' '+' '.join(r['text'] for r in out['goal']['requirements'] if r['id'] in task['requirements'])
        selection=memory.retrieve(project_id,query,goal_id=out['goal']['id'],goal_version=out['goal']['version']) if memory else None
        x={'schema_version':1,'intent':intent,'route':decision,'reasoning':depth,
           'context':capsule(task,out['goal'],project_id=project_id,selection=selection,max_bytes=max_context_bytes)}
        x['digest']=digest(x);task['intelligence']=x
    compile_plan(out)
    return out
