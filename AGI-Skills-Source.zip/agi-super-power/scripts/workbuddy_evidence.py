#!/usr/bin/env python3
"""Record WorkBuddy call provenance without launching agents or authenticating a host.

Read-only access to the existing ledger; append-only evidence in each attempt.
Even a fully consistent record remains a coordinator assertion until host review.
"""
from __future__ import annotations
import argparse
from contextlib import closing, nullcontext
import datetime
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
from kernel import local_file
from team_runtime import digest, require
from workbuddy_bridge import normalize, write_new_json

INTENT = 'workbuddy-call-intent.json'
RECORD = 'workbuddy-call-record.json'


def snapshot(job, path):
    relative = Path(path).absolute().relative_to(job.absolute()).as_posix()
    info = local_file(job, relative)
    data = (job / relative).read_bytes()
    require(info['sha256'] == hashlib.sha256(data).hexdigest(), 'WB_EVIDENCE', 'File changed while reading')
    return {'path': relative, 'sha256': info['sha256']}, data


def checked(job, pin):
    actual, data = snapshot(job, job / pin['path'])
    require(actual == pin, 'WB_EVIDENCE', 'Pinned evidence changed: ' + pin['path'])
    return data


def context(job, packet_path, *, store=None):
    job = job.absolute()
    packet_pin, raw = snapshot(job, packet_path)
    packet = json.loads(raw)
    if store is None:
        local_file(job, 'team.sqlite3')
    else:
        require(store.root == job, 'WB_EVIDENCE', 'Ledger connection belongs to another job')
    connection = nullcontext(store.db) if store is not None else closing(sqlite3.connect((job / 'team.sqlite3').as_uri() + '?mode=ro', uri=True))
    with connection as db:
        db.row_factory = sqlite3.Row
        row = db.execute('SELECT * FROM tasks WHERE id=?', (packet['task_id'],)).fetchone()
        d = db.execute('SELECT * FROM dispatch34 WHERE token=?', (packet['lease_token'],)).fetchone()
        meta = {r['key']: json.loads(r['value']) for r in db.execute('SELECT * FROM meta')}
        require(row is not None and d is not None, 'WB_EVIDENCE', 'Unknown task or dispatch')
        row, d = dict(row), dict(d)
    require(json.loads(row['packet']) == packet and row['token'] == packet['lease_token'],
            'WB_EVIDENCE', 'Packet is not the current ledger packet')
    require(packet['contract']['executor']['type'] == 'workbuddy_mobile_cloud', 'WB_EVIDENCE', 'Wrong host')
    require(packet['plan_digest'] == meta['plan_digest'] == d['plan_digest'] == digest(meta['plan'])
            and packet['goal_digest'] == meta['goal_digest'] == d['goal_digest'] == digest(meta['plan']['goal']),
            'WB_EVIDENCE', 'Frozen plan or goal mismatch')
    require(Path(packet['packet_path']).absolute() == Path(packet_path).absolute(), 'WB_EVIDENCE', 'Wrong packet path')
    workspace = Path(packet['workspace'])
    require(workspace.absolute() / 'packet.json' == Path(packet_path).absolute(), 'WB_EVIDENCE', 'Wrong workspace')
    # local_file checks physical paths, including symlinked parent directories.
    snapshot(job, workspace / 'evidence/native-dispatch.json')
    return packet, packet_pin, row, d


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')


def identity(job, packet, dispatch):
    return {'job': str(job.absolute()), 'task_id': packet['task_id'],
            'lease_token': packet['lease_token'], 'plan_digest': packet['plan_digest'],
            'goal_digest': packet['goal_digest'], 'request_key': dispatch['request_key']}


def validate_tool_call_id(value, packet, dispatch):
    if value is not None:
        require(isinstance(value, str) and bool(value.strip()) and value == value.strip()
                and not value.startswith('agent-')
                and value not in (packet['lease_token'], packet['task_id'], dispatch['request_key']),
                'WB_EVIDENCE', 'Tool call ID must be independently observed; do not reuse Agent ID, task or token')


def validate_intent_files(job, packet, packet_pin, d, pins, native_tool, prompt_key):
    """Recheck meaning as well as hashes when creating AND reading an intent.

    Rehashed coordinator files are not attested, but they must still match this
    attempt's frozen delegation, authorization identity and submission key.
    """
    require(isinstance(native_tool, str) and native_tool.strip(), 'WB_EVIDENCE', 'Actual tool name required')
    require(isinstance(prompt_key, str) and prompt_key.strip(), 'WB_EVIDENCE', 'Actual prompt field required')
    required = {'packet', 'authorization', 'arguments', 'submission', 'delegation', 'dispatch'}
    require(isinstance(pins, dict) and required <= set(pins) <= required | {'authorization_source'},
            'WB_EVIDENCE', 'Intent must retain all required evidence pins')
    require(pins['packet'] == packet_pin, 'WB_EVIDENCE', 'Intent packet pin mismatch')
    values = {name: checked(job, pin) for name, pin in pins.items()}
    for name, filename in [('delegation', 'workbuddy-delegation.md'), ('dispatch', 'native-dispatch.json')]:
        expected, _ = snapshot(job, Path(packet['workspace']) / 'evidence' / filename)
        require(pins[name] == expected, 'WB_EVIDENCE', 'Intent must use this attempt ' + name)
    descriptor = json.loads(values['dispatch'])
    require(descriptor['packet_sha256'] == pins['packet']['sha256']
            and descriptor['delegation_sha256'] == pins['delegation']['sha256']
            and descriptor['task_id'] == packet['task_id'] and descriptor['lease_token'] == packet['lease_token'],
            'WB_EVIDENCE', 'Prepared dispatch, packet or delegation changed')
    auth, args, submit = (json.loads(values[n]) for n in ('authorization', 'arguments', 'submission'))
    require(type(auth['schema_version']) is int and auth['schema_version'] == 1 and auth['job'] == str(job.absolute())
            and auth['plan_digest'] == packet['plan_digest'], 'WB_EVIDENCE', 'Authorization record must name this new job and plan')
    require(isinstance(auth['instruction'], str) and bool(auth['instruction'].strip()), 'WB_EVIDENCE', 'Record actual user instruction')
    require(auth['source_kind'] in ('coordinator_transcription', 'conversation_export'), 'WB_EVIDENCE', 'Unknown source kind')
    for field in ('source_ref', 'message_time', 'previous_job'):
        require(auth[field] is None or (isinstance(auth[field], str) and bool(auth[field].strip())),
                'WB_EVIDENCE', 'Use null for unavailable ' + field)
    if auth.get('source_file') is not None:
        source_pin, _ = snapshot(job, job / auth['source_file'])
        require(pins.get('authorization_source') == source_pin,
                'WB_EVIDENCE', 'Authorization source reference and pin differ')
    else:
        require('authorization_source' not in pins, 'WB_EVIDENCE', 'Unexpected authorization source pin')
    require(auth['source_kind'] != 'conversation_export' or 'authorization_source' in pins,
            'WB_EVIDENCE', 'Claimed conversation export requires its actual file')
    require(isinstance(args, dict) and args.get(prompt_key) == values['delegation'].decode('utf-8'),
            'WB_EVIDENCE', 'Planned tool prompt must equal this attempt delegation verbatim')
    require(submit['request_key'] == d['request_key'] and submit['state'] == 'SUBMITTING'
            and submit['execution'] == 'NOT_EXECUTED', 'WB_EVIDENCE', 'Submission output does not match current reservation')


def record_intent(job, packet_path, authorization, arguments, submission, native_tool='Agent', prompt_key='prompt'):
    packet, packet_pin, row, d = context(job, packet_path)
    from team_runtime import TeamStore
    from workbuddy_policy import guard_writes, capabilities
    with TeamStore(job) as current:
        guard_writes(current)
        cap = capabilities(current, packet=packet)
        require(native_tool == cap['native_tool'], 'WB_CAPABILITY', 'Call tool differs from frozen capability')
    require(d['state'] == 'SUBMITTING' and d['guarded'] == 1 and row['host_run_id'] is None,
            'WB_EVIDENCE', 'Run begin-submit once before recording intent; never reserve again to retry')
    pins = {'packet': packet_pin}
    for name, path in [('authorization', authorization), ('arguments', arguments), ('submission', submission),
                       ('delegation', Path(packet['workspace']) / 'evidence/workbuddy-delegation.md'),
                       ('dispatch', Path(packet['workspace']) / 'evidence/native-dispatch.json')]:
        pins[name], _ = snapshot(job, path)
    auth = json.loads(checked(job, pins['authorization']))
    if auth.get('source_file') is not None:
        pins['authorization_source'], _ = snapshot(job, job / auth['source_file'])
    validate_intent_files(job, packet, packet_pin, d, pins, native_tool, prompt_key)
    result = {'schema_version': 1, 'kind': 'workbuddy_call_intent', 'identity': identity(job, packet, d),
              'recorded_at': stamp(), 'native_tool': native_tool, 'prompt_key': prompt_key, 'files': pins,
              'execution': 'NOT_ATTESTED', 'authorization_verdict': 'REQUIRES_SOURCE_REVIEW',
              'note': 'Coordinator record; neither new authorization nor proof that a tool call occurred.'}
    path = Path(packet['workspace']) / 'evidence' / INTENT
    write_new_json(path, result)
    return path, result


def load_intent(job, packet, packet_pin, d):
    path = Path(packet['workspace']) / 'evidence' / INTENT
    pin, raw = snapshot(job, path)
    intent = json.loads(raw)
    require(type(intent['schema_version']) is int and intent['schema_version'] == 1 and intent['kind'] == 'workbuddy_call_intent'
            and intent['identity'] == identity(job, packet, d) and intent['files']['packet'] == packet_pin,
            'WB_EVIDENCE', 'Intent belongs to another job, packet or lease')
    require(intent.get('execution') == 'NOT_ATTESTED'
            and intent.get('authorization_verdict') == 'REQUIRES_SOURCE_REVIEW',
            'WB_EVIDENCE', 'Intent cannot promote execution or authorization provenance')
    validate_intent_files(job, packet, packet_pin, d, intent['files'], intent['native_tool'], intent['prompt_key'])
    return pin, intent


def record_return(job, packet_path, raw_path, outcome, tool_call_id=None, host_trace=None):
    from team_runtime import TeamStore
    from workbuddy_policy import guard_writes
    with TeamStore(job) as current:
        guard_writes(current)
    packet, packet_pin, row, d = context(job, packet_path)
    intent_pin, intent = load_intent(job, packet, packet_pin, d)
    raw_pin, raw = snapshot(job, raw_path)
    relative = Path(raw_path).absolute().relative_to(Path(packet['workspace']).absolute())
    require(relative.parts[0] == 'evidence', 'WB_EVIDENCE', 'Raw return must belong to this attempt evidence/')
    n = normalize(raw.decode('utf-8'), outcome, native_tool=intent['native_tool'])
    require(row['host_run_id'] is None or row['host_run_id'] == n['agent_id'], 'WB_EVIDENCE', 'Raw ID differs from bound host ID')
    validate_tool_call_id(tool_call_id, packet, d)
    files = {'intent': intent_pin, 'raw_return': raw_pin}
    if host_trace is not None:
        files['host_trace'], _ = snapshot(job, host_trace)
    result = {'schema_version': 1, 'kind': 'workbuddy_call_record', 'identity': identity(job, packet, d),
              'recorded_at': stamp(), 'files': files, 'native_tool': intent['native_tool'],
              'tool_call_id': tool_call_id, 'host_run_id': n['agent_id'], 'host_task_id': None,
              'observed_outcome': outcome, 'normalized_status': n['status'], 'bind_eligible': n['bind_eligible'],
              'host_trace_status': 'ATTACHED_UNVERIFIED' if host_trace is not None else 'NOT_AVAILABLE',
              'real_host_verdict': 'REQUIRES_HOST_TRACE_REVIEW', 'authorization_verdict': 'REQUIRES_SOURCE_REVIEW',
              'note': 'A hash binds bytes, not sender identity, actual invocation or message timing. No Agent was launched.'}
    path = Path(packet['workspace']) / 'evidence' / RECORD
    write_new_json(path, result)
    return path, result


def check_record(job, packet_path, *, store=None):
    packet, packet_pin, row, d = context(job, packet_path, store=store)
    intent_pin, intent = load_intent(job, packet, packet_pin, d)
    _, data = snapshot(job, Path(packet['workspace']) / 'evidence' / RECORD)
    record = json.loads(data)
    require(type(record['schema_version']) is int and record['schema_version'] == 1 and record['kind'] == 'workbuddy_call_record'
            and record['identity'] == identity(job, packet, d) and record['files']['intent'] == intent_pin,
            'WB_EVIDENCE', 'Call record identity mismatch')
    require({'intent', 'raw_return'} <= set(record['files']) <= {'intent', 'raw_return', 'host_trace'},
            'WB_EVIDENCE', 'Call record must retain required evidence pins')
    for pin in record['files'].values():
        checked(job, pin)
    relative = (job / record['files']['raw_return']['path']).absolute().relative_to(Path(packet['workspace']).absolute())
    require(relative.parts[0] == 'evidence', 'WB_EVIDENCE', 'Raw return must belong to this attempt evidence/')
    validate_tool_call_id(record['tool_call_id'], packet, d)
    require(record['host_task_id'] is None and record['host_trace_status'] ==
            ('ATTACHED_UNVERIFIED' if 'host_trace' in record['files'] else 'NOT_AVAILABLE'),
            'WB_EVIDENCE', 'Unsupported host task ID or incorrect trace provenance')
    n = normalize(checked(job, record['files']['raw_return']).decode('utf-8'), record['observed_outcome'],
                  native_tool=intent['native_tool'])
    require(record['native_tool'] == intent['native_tool'] and record['host_run_id'] == n['agent_id']
            and record['normalized_status'] == n['status'] and record['bind_eligible'] == n['bind_eligible']
            and (row['host_run_id'] is None or row['host_run_id'] == n['agent_id']), 'WB_EVIDENCE', 'Call record differs from raw return')
    require(record['real_host_verdict'] == 'REQUIRES_HOST_TRACE_REVIEW'
            and record['authorization_verdict'] == 'REQUIRES_SOURCE_REVIEW', 'WB_EVIDENCE', 'Local records cannot promote provenance')
    return {'record_consistency_passed': True, 'host_run_id': n['agent_id'],
            'native_tool': record['native_tool'], 'raw_return': record['files']['raw_return'],
            'bind_eligible': n['bind_eligible'], 'real_agent_calls_by_this_checker': 0,
            'real_host_verdict': 'REQUIRES_HOST_TRACE_REVIEW', 'authorization_verdict': 'REQUIRES_SOURCE_REVIEW'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('intent', 'return', 'check'))
    parser.add_argument('--job', required=True, type=Path)
    parser.add_argument('--packet', required=True, type=Path)
    for arg in ('authorization', 'arguments', 'submission', 'raw-return', 'host-trace'):
        parser.add_argument('--' + arg + '-file', type=Path)
    parser.add_argument('--native-tool', default='Agent')
    parser.add_argument('--prompt-key', default='prompt')
    parser.add_argument('--observed-outcome', choices=('completed', 'failed', 'outcome_unknown'))
    parser.add_argument('--tool-call-id')
    a = parser.parse_args(argv)
    try:
        if a.action == 'intent':
            require(all((a.authorization_file, a.arguments_file, a.submission_file)), 'WB_EVIDENCE', 'Intent requires authorization, arguments and submission files')
            path, value = record_intent(a.job, a.packet, a.authorization_file, a.arguments_file,
                                        a.submission_file, a.native_tool, a.prompt_key)
        elif a.action == 'return':
            require(a.raw_return_file and a.observed_outcome, 'WB_EVIDENCE', 'Return requires raw file and observed outcome')
            path, value = record_return(a.job, a.packet, a.raw_return_file, a.observed_outcome,
                                        a.tool_call_id, a.host_trace_file)
        else:
            print(json.dumps(check_record(a.job, a.packet), ensure_ascii=False)); return 0
        print(json.dumps({'written': str(path), 'kind': value['kind'], 'real_agent_calls': 0}, ensure_ascii=False))
        return 0
    except (ValueError, OSError, KeyError, TypeError, sqlite3.Error) as exc:
        print(json.dumps({'error': 'WB_EVIDENCE', 'message': str(exc)}), file=sys.stderr); return 1


if __name__ == '__main__':
    raise SystemExit(main())
