#!/usr/bin/env python3
"""Beginner handoff and v3 intelligence compiler (stdlib only, no model calls)."""
from __future__ import annotations
import argparse
from contextlib import nullcontext
import json
from pathlib import Path
import sys
from intelligence_common import read_json, write_new, ensure
from intent_compiler import compile_intent
from agent_router import route
from reasoning_depth import plan_depth
from host_registry import host_info, preflight
from context_engine import MemoryStore
from intelligence_layer import enrich_plan, logical_tools
from route_feedback import FeedbackStore
from release_version import PACKAGE_VERSION

def tool_list(text: str) -> list[str]:
    return logical_tools([x.strip() for x in text.split(',') if x.strip()])

def main(argv=None) -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--version',action='version',version=PACKAGE_VERSION)
    sub=p.add_subparsers(dest='action',required=True)
    q=sub.add_parser('plan',help='Turn a current user request into a bounded handoff; does not execute')
    group=q.add_mutually_exclusive_group(required=True)
    group.add_argument('--request');group.add_argument('--request-file',type=Path)
    q.add_argument('--host',default='workbuddy');q.add_argument('--tools',default='')
    q.add_argument('--hints',type=Path);q.add_argument('--semantic-decision',type=Path)
    q.add_argument('--output',type=Path,required=True)
    q=sub.add_parser('enrich',help='Add intelligence to an unstarted schema-3 plan')
    q.add_argument('--plan',type=Path,required=True);q.add_argument('--project',required=True)
    q.add_argument('--tools',default='');q.add_argument('--hints',type=Path)
    q.add_argument('--semantic-decisions',type=Path);q.add_argument('--memory',type=Path)
    q.add_argument('--context-bytes',type=int,default=16384);q.add_argument('--output',type=Path,required=True)
    q=sub.add_parser('memory-put');q.add_argument('--store',type=Path,required=True)
    q.add_argument('--record',type=Path,required=True);q.add_argument('--approve-persist',action='store_true')
    q=sub.add_parser('memory-query');q.add_argument('--store',type=Path,required=True)
    q.add_argument('--project',required=True);q.add_argument('--query',required=True)
    q.add_argument('--goal');q.add_argument('--goal-version',type=int)
    q=sub.add_parser('memory-forget');q.add_argument('--store',type=Path,required=True)
    q.add_argument('--project',required=True);q.add_argument('--id',required=True)
    q.add_argument('--approve-delete',action='store_true')
    q=sub.add_parser('feedback');q.add_argument('--store',type=Path,required=True)
    q.add_argument('--job',type=Path)
    q=sub.add_parser('host');q.add_argument('host_name')
    a=p.parse_args(argv)
    try:
        if a.action=='plan':
            request=a.request if a.request is not None else a.request_file.read_text(encoding='utf-8')
            intent=compile_intent(request,read_json(a.hints) if a.hints else None)
            tools=tool_list(a.tools)
            decision=route(intent,host=a.host,available_tools=tools,
                           semantic_decision=read_json(a.semantic_decision) if a.semantic_decision else None)
            host=preflight(a.host,intent['required_tools'],tools)
            state=decision['state'] if decision['state']!='SELECTED' else host['status']
            answer={'package_version':PACKAGE_VERSION,'status':state,'execution':'NOT_EXECUTED',
                    'intent':intent,'route':decision,'reasoning':plan_depth(intent),'host_preflight':host,
                    'next':'Coordinator must inspect actual files/tools, freeze a v3 acceptance contract, then enrich/compile/init. Unresolved routes may not dispatch.',
                    'beginner_summary':{'goal':intent['request'],'assigned_role':decision['selected_role'],
                      'workflow_level':plan_depth(intent)['level'],
                      'blocking_note':None if state=='READY_FOR_HOST_PROBE' else state}}
            write_new(a.output,answer)
        elif a.action=='enrich':
            with (MemoryStore(a.memory) if a.memory else nullcontext(None)) as memory:
                answer=enrich_plan(read_json(a.plan),project_id=a.project,available_tools=tool_list(a.tools),
                        hints_by_task=read_json(a.hints) if a.hints else None,
                        semantic_by_task=read_json(a.semantic_decisions) if a.semantic_decisions else None,
                        memory=memory,max_context_bytes=a.context_bytes)
            write_new(a.output,answer)
            answer={'status':'COMPILED_NOT_EXECUTED','output':str(a.output),'tasks':len(answer['tasks']),
                    'next':'Use existing team_runtime.py init and actual supported host delegation.'}
        elif a.action=='memory-put':
            ensure(a.approve_persist,'MEMORY_OPT_IN','Use --approve-persist only after the user approves persistence')
            with MemoryStore(a.store) as memory: answer=memory.put(read_json(a.record),allow_persist=True)
        elif a.action=='memory-query':
            with MemoryStore(a.store) as memory: answer=memory.retrieve(a.project,a.query,goal_id=a.goal,goal_version=a.goal_version)
        elif a.action=='memory-forget':
            ensure(a.approve_delete,'MEMORY_OPT_IN','Explicit --approve-delete required')
            with MemoryStore(a.store) as memory: answer=memory.forget(a.project,a.id,allow_delete=True)
        elif a.action=='feedback':
            with FeedbackStore(a.store) as store:
                answer=store.record_job(a.job) if a.job else store.summary()
        else: answer=host_info(a.host_name)
        print(json.dumps(answer,ensure_ascii=False,indent=2));return 0
    except (ValueError,OSError,KeyError,TypeError) as exc:
        print(json.dumps({'error':getattr(exc,'code','INPUT'),'message':str(exc),'execution':'NOT_EXECUTED'},ensure_ascii=False),file=sys.stderr)
        return 2

if __name__=='__main__': raise SystemExit(main())
