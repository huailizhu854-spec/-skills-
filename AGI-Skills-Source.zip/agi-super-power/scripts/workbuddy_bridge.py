#!/usr/bin/env python3
"""WorkBuddy entry: Mobile Cloud observations and offline desktop probe evidence.

No command here creates an agent, queries a host, or fabricates identifiers.
The coordinator performs the single real Agent tool call itself, saves the
verbatim return, and feeds it to `normalize`. State rules (frozen v0 contract):

  A  terminal result + exactly one host-attached Agent ID  -> COMPLETED_SYNC
  B  the call failed with an explicit error               -> FAILED
  C  host/session interrupted, outcome unverifiable       -> EXECUTION_OUTCOME_UNKNOWN
  D  a real task_id appears someday                       -> record as capability
     candidate; v0 does NOT implement an async lifecycle.

ID_UNKNOWN: a completed return whose Agent ID footer cannot be parsed is kept
verbatim with agent_id=null; it can never be bound into the ledger.
"""
from __future__ import annotations
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import sys
from host_adapters.workbuddy_contract import (CANCEL_SUPPORTED, EXECUTION_MODE, HOST_ID,
                                              LIVE_RESUME_SUPPORTED, QUERY_SUPPORTED, parse_agent_ids,
                                              validate_sync_terminal_observation)
from kernel import local_file, load_json
from team_runtime import require

STATUSES = ('completed', 'failed', 'outcome_unknown')


def normalize(raw_text: str, observed_outcome: str, *, observed_by: str = 'coordinator',
              native_tool: str = 'Agent') -> dict:
    if observed_outcome not in STATUSES:
        raise ValueError('observed_outcome must be one of %s' % (STATUSES,))
    raw_sha = hashlib.sha256(raw_text.encode('utf-8')).hexdigest()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
    base = {
        'schema_version': 1,
        'host': HOST_ID,
        'execution_mode': EXECUTION_MODE,
        'agent_id': None,
        'agent_id_status': 'ID_UNKNOWN',
        'agent_id_source': 'host_attached_footer_of_create_return; children cannot observe it (WB-02)',
        'task_id': None,
        'task_id_note': 'WorkBuddy returns no task_id; the Agent ID must never be used as one',
        'terminal_result': raw_text,
        'terminal_result_sha256': raw_sha,
        'native_tool': native_tool,
        'observed_by': observed_by,
        'observed_at': now,
        'query_supported': QUERY_SUPPORTED,
        'cancel_supported': CANCEL_SUPPORTED,
        'live_resume_supported': LIVE_RESUME_SUPPORTED,
        'background_registry_observed': False,
    }
    if observed_outcome == 'completed':
        ids = parse_agent_ids(raw_text)
        if len(ids) == 1:
            try:
                validate_sync_terminal_observation(raw_text, ids[0])
            except ValueError as exc:
                base.update(status='COMPLETED_SYNC', bind_eligible=False,
                            validation_error=str(exc),
                            next_action='Malformed terminal evidence: preserve raw bytes; do not bind or recreate')
                return base
            base.update(status='COMPLETED_SYNC', agent_id=ids[0], agent_id_status='PARSED',
                        bind_eligible=True,
                        next_action='Bind/collect via native_host_bridge with this Agent ID as host_run_id')
        elif len(ids) == 0:
            base.update(status='COMPLETED_SYNC', bind_eligible=False,
                        next_action=('ID_UNKNOWN: keep raw return for audit; do NOT invent an ID; '
                                     'this attempt cannot enter the guarded ledger'))
        else:
            base.update(status='EXECUTION_OUTCOME_UNKNOWN', bind_eligible=False,
                        next_action=('Multiple Agent ID footers in one return are ambiguous; '
                                     'investigate before any further create'))
    elif observed_outcome == 'failed':
        base.update(status='FAILED', bind_eligible=False,
                    next_action='Keep the raw error; handle through the existing rework rules; no Agent ID exists')
    else:
        base.update(status='EXECUTION_OUTCOME_UNKNOWN', bind_eligible=False,
                    next_action=('No auto-recreate. Save checkpoint, wait for host-side evidence; '
                                 'the ledger stays SUBMITTING/UNKNOWN until reconciled'))
    return base


def terminal_event(packet_path: Path, raw_path: Path, observed_outcome: str,
                   native_tool: str = 'Agent') -> dict:
    """Build an observation from saved evidence, never dispatch or bind a task.

    Packet/lease authority is rechecked by the existing bind/collect commands.
    This is a convenience formatter, not independent provider attestation.
    """
    packet = load_json(packet_path)
    require(packet['contract'].get('executor', {}).get('type') == HOST_ID,
            'HOST_MISMATCH', 'Packet must belong to WorkBuddy Mobile Cloud')
    workspace = Path(packet['workspace'])
    # Do not resolve symlinks before local_file validates the actual input path.
    relative = raw_path.absolute().relative_to(workspace.absolute()).as_posix()
    require(relative.startswith('evidence/'), 'HOST_EVENT', 'Save the raw return under this attempt evidence/')
    info = local_file(workspace, relative)
    raw = raw_path.read_bytes()
    n = normalize(raw.decode('utf-8'), observed_outcome, native_tool=native_tool)
    require(info['sha256'] == hashlib.sha256(raw).hexdigest(), 'HOST_EVENT', 'Raw evidence changed while reading')
    require(n['bind_eligible'], 'WB_UNBINDABLE', n['next_action'])
    require(isinstance(native_tool, str) and bool(native_tool.strip()), 'HOST_EVENT', 'Actual native tool name required')
    return {'schema_version': 1, 'host': HOST_ID, 'event': 'finished',
            'host_run_id': n['agent_id'], 'task_id': packet['task_id'],
            'lease_token': packet['lease_token'], 'native_tool': native_tool,
            'raw_evidence_path': relative, 'raw_evidence_sha256': info['sha256'],
            'observed_by': 'coordinator'}


def write_new_json(path: Path, value: dict) -> None:
    """Never overwrite an original return, packet, or previous evidence file."""
    payload = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    with path.open('x', encoding='utf-8', newline='\n') as f:
        f.write(payload)


def contract() -> dict:
    return {
        'schema_version': 1, 'host': HOST_ID, 'execution_mode': EXECUTION_MODE,
        'create': 'Coordinator performs exactly ONE real Agent tool call after delivery_cli begin-submit; '
                  'the call blocks until terminal state and appends "[Agent ID: ...]" to the return',
        'task_id': None,
        'query_supported': QUERY_SUPPORTED,
        'cancel_supported': CANCEL_SUPPORTED,
        'live_resume_supported': LIVE_RESUME_SUPPORTED,
        'background_registry_observed': False,
        'evidence': ['WB-01 (2026-09-23)', 'WB-01B (2026-09-23, ~80 s run)', 'WB-02 (2026-09-23, serial pair)'],
        'forbidden_assumptions': [
            'task_id exists', 'Agent ID works as task_id', 'TaskOutput can query an Agent ID',
            'TaskStop can stop an Agent ID', 'run_in_background=true enters a background registry',
            'a running Agent can be resumed', 'a running Agent can be confirm-cancelled',
        ],
    }


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='action', required=True)
    n = sub.add_parser('normalize')
    n.add_argument('--raw-return-file', required=True, type=Path)
    n.add_argument('--observed-outcome', required=True, choices=list(STATUSES))
    n.add_argument('--native-tool', default='Agent')
    n.add_argument('--out', type=Path, help='write a NEW result file; never overwrite evidence; default stdout')
    e = sub.add_parser('event', help='Format saved terminal evidence for existing bind/collect; never launch')
    e.add_argument('--packet', required=True, type=Path)
    e.add_argument('--raw-return-file', required=True, type=Path)
    e.add_argument('--observed-outcome', required=True, choices=list(STATUSES))
    e.add_argument('--native-tool', default='Agent')
    e.add_argument('--out', required=True, type=Path)
    sub.add_parser('contract')
    desktop = sub.add_parser('desktop-probe', help='Prepare/check desktop probe evidence only; never dispatch')
    desktop.add_argument('probe_action', choices=('init', 'manifest', 'check'))
    desktop.add_argument('directory', type=Path)
    a = p.parse_args(argv)
    try:
        if a.action == 'desktop-probe':
            from workbuddy_desktop_probe import main as desktop_main
            return desktop_main([a.probe_action, str(a.directory)])
        if a.action == 'contract':
            out = contract()
        elif a.action == 'event':
            out = terminal_event(a.packet, a.raw_return_file, a.observed_outcome, a.native_tool)
            workspace = Path(load_json(a.packet)['workspace'])
            from team_runtime import TeamStore
            from workbuddy_policy import guard_writes
            from workbuddy_evidence import context
            job = workspace.parents[2]
            with TeamStore(job) as store:
                guard_writes(store)
                context(store.root, a.packet, store=store)
            relative = a.out.absolute().relative_to(workspace.absolute())
            require(relative.parts[0] == 'evidence' and '..' not in relative.parts,
                    'HOST_EVENT', 'Event output must stay in this attempt evidence/')
            require(a.out.parent.resolve() == (workspace / 'evidence').resolve(),
                    'HOST_EVENT', 'Event output must be directly in attempt evidence/')
            write_new_json(a.out, out)
        else:
            raw = a.raw_return_file.read_bytes().decode('utf-8')
            out = normalize(raw, a.observed_outcome, native_tool=a.native_tool)
            if a.out is not None:
                write_new_json(a.out, out)
        payload = json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False)
        if a.action == 'normalize' and a.out is not None:
            print(json.dumps({'written': str(a.out), 'status': out['status'],
                              'agent_id': out['agent_id'],
                              'terminal_result_sha256': out['terminal_result_sha256']}))
        else:
            print(payload)
        return 0
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print(json.dumps({'error': 'WB_INPUT', 'message': str(exc)}), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
