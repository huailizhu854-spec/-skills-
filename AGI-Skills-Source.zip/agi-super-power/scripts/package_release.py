#!/usr/bin/env python3
"""Build and verify deterministic skill ZIPs without executing their contents.

Python 3.10+, standard library only. All paths in the manifest are relative to the
single skill directory. SHA256SUMS.json excludes itself. A checksum verifies
integrity relative to that manifest, not publisher identity or safety.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import tempfile
import unicodedata
import zipfile
import zlib
from typing import Any


MANIFEST = "SHA256SUMS.json"
MAX_TOTAL_BYTES = 200 * 1024 * 1024
MAX_ARCHIVE_BYTES = MAX_TOTAL_BYTES + 4 * 1024 * 1024
MAX_MANIFEST_BYTES = 8 * 1024 * 1024
MAX_ENTRIES = 20_000
MAX_COMPRESSION_RATIO = 200
FIXED_TIME = (1980, 1, 1, 0, 0, 0)
NAME = re.compile(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*\Z")
SHA256 = re.compile(r"[0-9a-f]{64}\Z")
RESERVED_DEVICES = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}
EXTRA_INSTRUCTIONS = {"agents.md", "agent.md", "system_prompt.md", "claude.md", "gemini.md", ".cursorrules", "copilot-instructions.md"}
SKIP_DIRECTORIES = {".git", "__pycache__"}


class PackageError(ValueError):
    """An expected validation error; no archived code needs to run to detect it."""


class UTF8ZipInfo(zipfile.ZipInfo):
    def _encodeFilenameFlags(self):
        # zipfile resets flag_bits before writing. Override its encoding hook so
        # ASCII names also carry the same explicit UTF-8 flag as Unicode names.
        return self.filename.encode("utf-8"), self.flag_bits | 0x800


def canonical_key(value: str) -> str:
    return unicodedata.normalize("NFKC", value).casefold()


def safe_relative(value: Any) -> str:
    if not isinstance(value, str) or not value or value != value.strip():
        raise PackageError("Entry path must be a non-empty unpadded string.")
    if value.startswith("/") or "\\" in value:
        raise PackageError("Absolute and backslash entry paths are forbidden.")
    for part in value.split("/"):
        normalized = unicodedata.normalize("NFKC", part)
        if not normalized or normalized in {".", ".."} or normalized.endswith((".", " ")):
            raise PackageError("Entry path contains an empty, dot, parent, or ambiguous component.")
        if any(unicodedata.category(char).startswith("C") or char in '<>:"|?*\\/' for char in normalized):
            raise PackageError("Entry path contains a control character or a non-portable path character.")
        if normalized.split(".", 1)[0].casefold() in RESERVED_DEVICES:
            raise PackageError("Windows device paths are forbidden.")
    return value


def valid_root_name(value: Any) -> bool:
    return isinstance(value, str) and 0 < len(value) < 64 and NAME.fullmatch(value) is not None


def is_link(info: os.stat_result) -> bool:
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))


def physical_path(raw: str | Path, *, directory: bool) -> Path:
    target = Path(raw).absolute()
    for component in reversed((target, *target.parents)):
        if is_link(component.lstat()):
            raise PackageError("Filesystem paths must not contain symlinks or reparse points.")
    info = target.lstat()
    if directory and not stat.S_ISDIR(info.st_mode):
        raise PackageError("Expected an existing directory.")
    if not directory and not stat.S_ISREG(info.st_mode):
        raise PackageError("Expected an existing regular file.")
    return target.resolve(strict=True)


def check_payload_paths(paths: list[str]) -> None:
    folded: set[str] = set()
    skill_paths: list[str] = []
    for path in paths:
        safe_relative(path)
        key = canonical_key(path)
        if key in folded:
            raise PackageError("Duplicate or Unicode/case-colliding file paths are forbidden.")
        folded.add(key)
        basename = key.rsplit("/", 1)[-1]
        if basename == "skill.md":
            skill_paths.append(path)
        if basename in EXTRA_INSTRUCTIONS:
            raise PackageError("Additional host instruction entrypoints are forbidden: " + path)
    if skill_paths != ["SKILL.md"]:
        raise PackageError("Exactly one case-exact root SKILL.md is required.")
    for path in folded:
        parts = path.split("/")
        for index in range(1, len(parts)):
            if "/".join(parts[:index]) in folded:
                raise PackageError("A file path conflicts with a descendant path.")


def digest_file(path: Path) -> tuple[str, int]:
    digest = hashlib.sha256()
    total = 0
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
            total += len(chunk)
    return digest.hexdigest(), total


def read_source_file(root: Path, relative: str) -> bytes:
    target = root
    for component in safe_relative(relative).split("/"):
        target /= component
        if is_link(target.lstat()):
            raise PackageError("Source contains a symlink or reparse point.")
    target.resolve(strict=True).relative_to(root)
    before = target.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise PackageError("Source contains a non-regular file.")
    if before.st_size > MAX_TOTAL_BYTES:
        raise PackageError("A source file exceeds the 200 MiB limit.")
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    with os.fdopen(os.open(target, flags), "rb") as handle:
        opened = os.fstat(handle.fileno())
        if (before.st_dev, before.st_ino) != (opened.st_dev, opened.st_ino) or not stat.S_ISREG(opened.st_mode):
            raise PackageError("Source file identity changed while reading.")
        data = handle.read(MAX_TOTAL_BYTES + 1)
        after = os.fstat(handle.fileno())
    if len(data) > MAX_TOTAL_BYTES or (opened.st_size, opened.st_mtime_ns) != (after.st_size, after.st_mtime_ns) or len(data) != after.st_size:
        raise PackageError("Source file changed while reading or exceeds the size limit.")
    return data


def raise_walk_error(error: OSError) -> None:
    raise error


PRIVATE_PARTS = {'.private', 'private-evidence', 'jobs', 'runs', '.agi-memory', '.agi-feedback'}
RAW_EVIDENCE = {'packet.json','result.json','controller-result.json','model-events.jsonl',
                'model-transcript.json','private_evidence.json'}


def privacy_check(paths: list[str], hashes: dict[str,str], policy: dict | None) -> None:
    """Build/verify fail closed on unreviewed provenance and known forensic paths.
    This is NOT a universal PII scanner; arbitrary source comments still need review.
    """
    approved = (policy or {}).get('files', {})
    if not isinstance(approved, dict): raise PackageError('Invalid evidence allowlist')
    for relative in paths:
        parts = relative.casefold().split('/')
        if any(parts[-1].endswith(ext) for ext in ('.db', '.db-wal', '.db-shm', '.sqlite', '.sqlite3', '.sqlite3-wal', '.sqlite3-shm')):
            raise PackageError('Private memory/telemetry database is forbidden in release: ' + relative)
        if set(parts) & PRIVATE_PARTS or 'private_evidence.json' in parts:
            raise PackageError('Private forensic data is forbidden in release: ' + relative)
        sensitive = parts[0] == 'provenance' or parts[-1] in RAW_EVIDENCE
        if sensitive and approved.get(relative) != hashes[relative]:
            raise PackageError('Unreviewed evidence in release; export sanitized metadata or pin reviewed fixture hash: ' + relative)


def collect_source(root: Path) -> tuple[dict[str, bytes], list[str]]:
    payload: dict[str, bytes] = {}
    skipped: list[str] = []
    size = 0
    directory_keys: dict[str, str] = {}
    for current, directories, files in os.walk(root, topdown=True, followlinks=False, onerror=raise_walk_error):
        current_path = Path(current)
        allowed_directories: list[str] = []
        for name in sorted(directories):
            item = current_path / name
            relative = item.relative_to(root).as_posix()
            if is_link(item.lstat()):
                raise PackageError("Source contains a linked directory.")
            safe_relative(relative)
            if name.casefold() in SKIP_DIRECTORIES:
                skipped.append(relative + "/")
                continue
            key = canonical_key(relative)
            if key in directory_keys and directory_keys[key] != relative:
                raise PackageError("Source directory names collide after normalization and case folding.")
            directory_keys[key] = relative
            allowed_directories.append(name)
        directories[:] = allowed_directories
        for name in sorted(files):
            item = current_path / name
            relative = item.relative_to(root).as_posix()
            if is_link(item.lstat()):
                raise PackageError("Source contains a linked file.")
            safe_relative(relative)
            if name.casefold() == ".git" or name.casefold().endswith(".pyc") or relative == MANIFEST:
                skipped.append(relative)
                continue
            if canonical_key(relative) == canonical_key(MANIFEST):
                raise PackageError("Reserved manifest name has incorrect casing.")
            data = read_source_file(root, relative)
            size += len(data)
            if size > MAX_TOTAL_BYTES or len(payload) + 2 > MAX_ENTRIES:
                raise PackageError("Source exceeds the size or file-count limit.")
            payload[relative] = data
    check_payload_paths(sorted(payload))
    policy_raw = payload.get('release-evidence-allowlist.json')
    policy = json.loads(policy_raw, object_pairs_hook=unique_object, parse_constant=reject_constant) if policy_raw else None
    privacy_check(sorted(payload), {k:hashlib.sha256(v).hexdigest() for k,v in payload.items()}, policy)
    if not payload["SKILL.md"]:
        raise PackageError("SKILL.md must not be empty.")
    return payload, sorted(skipped)


def manifest_bytes(root_name: str, payload: dict[str, bytes]) -> bytes:
    records = [{"path": path, "sha256": hashlib.sha256(payload[path]).hexdigest(), "bytes": len(payload[path])} for path in sorted(payload)]
    document = {"schema_version": 1, "root": root_name, "files": records}
    return (json.dumps(document, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise PackageError("Manifest contains duplicate object keys.")
        result[key] = value
    return result


def reject_constant(_: str) -> Any:
    raise PackageError("Manifest contains a non-finite JSON number.")


def decode_manifest(raw: bytes, root_name: str) -> dict[str, dict[str, Any]]:
    if not raw or len(raw) > MAX_MANIFEST_BYTES:
        raise PackageError("Manifest size is invalid.")
    document = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_object, parse_constant=reject_constant)
    if not isinstance(document, dict) or set(document) != {"schema_version", "root", "files"}:
        raise PackageError("Manifest must have schema_version, root, and files fields only.")
    if type(document["schema_version"]) is not int or document["schema_version"] != 1 or document["root"] != root_name:
        raise PackageError("Manifest version or root is invalid.")
    records = document["files"]
    if not isinstance(records, list) or not records or len(records) >= MAX_ENTRIES:
        raise PackageError("Manifest file list is invalid.")
    result: dict[str, dict[str, Any]] = {}
    keys: set[str] = set()
    for record in records:
        if not isinstance(record, dict) or set(record) != {"path", "sha256", "bytes"}:
            raise PackageError("Manifest file record is malformed.")
        relative = safe_relative(record["path"])
        key = canonical_key(relative)
        if key == canonical_key(MANIFEST) or key in keys:
            raise PackageError("Manifest includes itself or contains colliding paths.")
        keys.add(key)
        if not isinstance(record["sha256"], str) or not SHA256.fullmatch(record["sha256"]):
            raise PackageError("Manifest SHA-256 must be lowercase hexadecimal.")
        if type(record["bytes"]) is not int or not 0 <= record["bytes"] <= MAX_TOTAL_BYTES:
            raise PackageError("Manifest byte count is invalid.")
        result[relative] = record
    check_payload_paths(sorted(result))
    return result


def stream_member(archive: zipfile.ZipFile, info: zipfile.ZipInfo, *, capture: bool = False) -> tuple[str, int, bytes | None]:
    digest = hashlib.sha256()
    size = 0
    pieces: list[bytes] = []
    with archive.open(info, "r") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > info.file_size or size > MAX_TOTAL_BYTES or (capture and size > MAX_MANIFEST_BYTES):
                raise PackageError("Expanded member exceeds its declared size or configured limit.")
            digest.update(chunk)
            if capture:
                pieces.append(chunk)
    if size != info.file_size:
        raise PackageError("Expanded member size does not match the ZIP directory.")
    return digest.hexdigest(), size, b"".join(pieces) if capture else None


def verify_archive(raw_path: str | Path) -> dict[str, Any]:
    path = physical_path(raw_path, directory=False)
    if path.stat().st_size > MAX_ARCHIVE_BYTES:
        raise PackageError("ZIP exceeds the archive size limit.")
    with zipfile.ZipFile(path, "r") as archive:
        entries = archive.infolist()
        if not entries or len(entries) > MAX_ENTRIES:
            raise PackageError("ZIP entry count is invalid.")
        names: set[str] = set()
        keys: set[str] = set()
        roots: set[str] = set()
        by_relative: dict[str, zipfile.ZipInfo] = {}
        expanded_total = 0
        for info in entries:
            name = safe_relative(info.orig_filename)
            if name != info.filename:
                raise PackageError("ZIP filename was truncated or normalized by the parser.")
            parts = name.split("/")
            if len(parts) < 2 or not valid_root_name(parts[0]):
                raise PackageError("ZIP must contain a single lowercase skill root directory.")
            roots.add(parts[0])
            if len(roots) != 1:
                raise PackageError("ZIP contains multiple roots.")
            key = canonical_key(name)
            if name in names or key in keys:
                raise PackageError("ZIP contains duplicate or Unicode/case-colliding entries.")
            names.add(name); keys.add(key)
            if info.is_dir():
                raise PackageError("Canonical skill ZIPs contain file entries only.")
            mode = (info.external_attr >> 16) & 0xFFFF
            kind = stat.S_IFMT(mode)
            if kind not in {0, stat.S_IFREG} or (info.create_system == 0 and info.external_attr & 0x400):
                raise PackageError("ZIP contains a symlink, reparse point, or special file.")
            if info.flag_bits & 1:
                raise PackageError("Encrypted entries are forbidden.")
            if info.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}:
                raise PackageError("Unsupported compression method.")
            if info.file_size < 0 or info.compress_size < 0 or (info.file_size and not info.compress_size):
                raise PackageError("ZIP member size is invalid.")
            if info.file_size > MAX_TOTAL_BYTES or info.file_size > max(1, info.compress_size) * MAX_COMPRESSION_RATIO:
                raise PackageError("ZIP member exceeds size or compression-ratio limits.")
            expanded_total += info.file_size
            if expanded_total > MAX_TOTAL_BYTES:
                raise PackageError("ZIP exceeds the 200 MiB expanded-size limit.")
            relative = "/".join(parts[1:])
            by_relative[relative] = info
        root_name = next(iter(roots))
        if MANIFEST not in by_relative:
            raise PackageError("SHA256SUMS.json is missing.")
        payload_paths = sorted(set(by_relative) - {MANIFEST})
        check_payload_paths(payload_paths)
        manifest_info = by_relative[MANIFEST]
        if manifest_info.file_size > MAX_MANIFEST_BYTES:
            raise PackageError("Manifest exceeds its size limit.")
        _, _, raw_manifest = stream_member(archive, manifest_info, capture=True)
        assert raw_manifest is not None
        records = decode_manifest(raw_manifest, root_name)
        if set(records) != set(payload_paths):
            raise PackageError("Manifest does not exactly cover all payload files.")
        policy = None
        if 'release-evidence-allowlist.json' in by_relative:
            _, _, policy_raw = stream_member(archive, by_relative['release-evidence-allowlist.json'], capture=True)
            policy = json.loads(policy_raw, object_pairs_hook=unique_object, parse_constant=reject_constant)
        privacy_check(payload_paths, {k:v['sha256'] for k,v in records.items()}, policy)
        for relative in payload_paths:
            info = by_relative[relative]
            expected = records[relative]
            if info.file_size != expected["bytes"]:
                raise PackageError("Payload byte count differs from its manifest: " + relative)
            actual_hash, actual_size, _ = stream_member(archive, info)
            if actual_hash != expected["sha256"] or actual_size != expected["bytes"]:
                raise PackageError("Payload hash differs from its manifest: " + relative)
        if records["SKILL.md"]["bytes"] == 0:
            raise PackageError("SKILL.md must not be empty.")
    digest, size = digest_file(path)
    return {
        "schema_version": 1, "command": "verify", "valid": True, "outcome": "PASS",
        "root": root_name, "sha256": digest, "size": size, "files": len(records),
        "zip_entries": len(entries), "expanded_bytes": expanded_total,
        "manifest": root_name + "/" + MANIFEST,
        "validation_scope": "archive_structure_and_manifest_integrity",
        "contents_executed": False, "network_requests": 0,
        "limitations": [
            "A checksum manifest is not a publisher signature, behavioral safety proof, or agent capability proof.",
            "Filesystem checks assume source and destination are not adversarially mutated during validation.",
        ],
    }


def build_archive(raw_root: str | Path, raw_output: str | Path) -> dict[str, Any]:
    root = physical_path(raw_root, directory=True)
    if not valid_root_name(root.name):
        raise PackageError("Root directory name must be a lowercase skill name of 1–63 characters.")
    requested_output = Path(raw_output).absolute()
    if requested_output.exists() or requested_output.is_symlink():
        raise PackageError("Output already exists; overwriting is forbidden.")
    parent = physical_path(requested_output.parent, directory=True)
    output = parent / requested_output.name
    try:
        output.relative_to(root)
    except ValueError:
        pass
    else:
        raise PackageError("Output must be outside the source root.")
    if output.suffix.casefold() != ".zip":
        raise PackageError("Output must use the .zip extension.")
    payload, skipped = collect_source(root)
    payload[MANIFEST] = manifest_bytes(root.name, payload)
    if sum(map(len, payload.values())) > MAX_TOTAL_BYTES or len(payload[MANIFEST]) > MAX_MANIFEST_BYTES:
        raise PackageError("Payload plus manifest exceeds the configured limits.")
    with tempfile.TemporaryDirectory(prefix=".agi-release-", dir=parent) as temporary:
        staged = Path(temporary) / "candidate.zip"
        with zipfile.ZipFile(staged, "x", compression=zipfile.ZIP_STORED, allowZip64=False) as archive:
            for relative in sorted(payload):
                info = UTF8ZipInfo(root.name + "/" + relative, FIXED_TIME)
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                info.compress_type = zipfile.ZIP_STORED
                archive.writestr(info, payload[relative])
        verify_archive(staged)
        # Exclusive creation protects against another process claiming the name
        # after the initial existence check; no rename/replace can overwrite it.
        created = False
        try:
            with output.open("xb") as destination, staged.open("rb") as source:
                created = True
                shutil.copyfileobj(source, destination, 1024 * 1024)
            result = verify_archive(output)
        except Exception:
            if created:
                output.unlink(missing_ok=True)
            raise
    result.update(command="build", compression="stored", fixed_timestamp="1980-01-01T00:00:00", unix_permissions="0644", skipped=skipped)
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    build = commands.add_parser("build")
    build.add_argument("--root", required=True)
    build.add_argument("--output", required=True)
    verify = commands.add_parser("verify")
    verify.add_argument("zip")
    args = parser.parse_args(argv)
    try:
        result = build_archive(args.root, args.output) if args.command == "build" else verify_archive(args.zip)
    except (OSError, ValueError, TypeError, RuntimeError, RecursionError, zipfile.BadZipFile, zipfile.LargeZipFile, zlib.error) as exc:
        result = {
            "schema_version": 1, "command": args.command, "valid": False, "outcome": "FAILED",
            "error": str(exc) if isinstance(exc, PackageError) else "Archive or filesystem input is malformed, inaccessible, or unsupported.",
            "contents_executed": False, "network_requests": 0,
            "validation_scope": "archive_structure_and_manifest_integrity",
        }
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    sys.exit(main())
