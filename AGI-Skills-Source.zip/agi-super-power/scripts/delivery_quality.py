"""Frozen human/main-thread quality gates in addition to existing auto verifiers.

Observations are coordinator-owned. Identity strings do not authenticate people
or prove an independent agent ran. Raw evidence and review scope stay explicit.
"""
from __future__ import annotations
import json
from kernel import local_file
from team_runtime import fields, require, identifier, text, digest

LAYERS={'integrity','requirements','business','visual','experience'}
KINDS={'main_thread_review','user_confirmation'}
STATUSES={'PASS','FAIL','UNVERIFIED','NEEDS_HUMAN'}

def validate_gates(task):
    gates=task.get('quality_gates',[])
    require(isinstance(gates,list) and len(gates)<=100,'QUALITY_GATES','Expected <=100 quality gates')
    ids=set()
    for g in gates:
        fields(g,{'id','requirement','layer','kind','description'})
        identifier(g['id'],'gate.id');text(g['description'],'gate.description')
        require(g['id'] not in ids,'QUALITY_DUPLICATE','Duplicate gate ID');ids.add(g['id'])
        require(g['requirement'] in task['requirements'],'QUALITY_REQUIREMENT','Gate requirement outside assigned scope')
        require(g['layer'] in LAYERS and g['kind'] in KINDS,'QUALITY_KIND','Unknown layer or manual-review type')

def record_review(store, record):
    fields(record,{'task_id','lease_token','goal_digest','plan_digest','result_digest','gate_id',
                  'reviewer','kind','status','evidence_path','evidence_sha256','note'})
    text(record['note'],'note')
    with store.transaction():
        row=store.bound(record['task_id'],record['lease_token'],states={'submitted'},fresh=False)
        task=json.loads(row['contract']); result=json.loads(row['result']);validate_gates(task)
        gates={g['id']:g for g in task.get('quality_gates',[])}
        require(record['gate_id'] in gates,'QUALITY_UNKNOWN','Cannot invent a gate after dispatch')
        gate=gates[record['gate_id']]
        require(record['goal_digest']==store.meta('goal_digest') and record['plan_digest']==store.meta('plan_digest')
                and record['result_digest']==digest(result),'QUALITY_BINDING','Review refers to another goal, plan or output')
        require(record['reviewer']==task['reviewer'] and record['reviewer']!=row['worker'],'SELF_REVIEW','Only designated non-worker coordinator may record a review')
        require(record['kind']==gate['kind'] and record['status'] in STATUSES,'QUALITY_STATUS','Unknown or mismatched review type')
        require(isinstance(record['evidence_path'],str) and record['evidence_path'].startswith('reviews/'),'QUALITY_EVIDENCE','Review evidence must be controller-owned')
        require(local_file(store.root,record['evidence_path'])['sha256']==record['evidence_sha256'],'QUALITY_EVIDENCE','Evidence missing/changed')
        store.event('QUALITY_REVIEWED',record['task_id'],record=record,
                    identity_assurance='coordinator_declaration_not_authentication')
        return {'recorded':True,'gate_id':record['gate_id'],'status':record['status'],
                'acceptance':'Not auto-approved; all auto-verifiers and all frozen gates must pass'}

def evaluate_quality(store, row, result):
    task=json.loads(row['contract']);gates=task.get('quality_gates',[]);validate_gates(task)
    findings=[]
    for gate in gates:
        latest=None
        for event in store.db.execute("SELECT detail FROM events WHERE kind='QUALITY_REVIEWED' AND task_id=? ORDER BY seq DESC",(row['id'],)):
            r=json.loads(event[0])['record']
            if r['gate_id']==gate['id'] and r['lease_token']==row['token']:
                latest=r;break
        status='UNVERIFIED';error=None
        if latest:
            valid=(latest['goal_digest']==store.meta('goal_digest') and latest['plan_digest']==store.meta('plan_digest')
                   and latest['result_digest']==digest(result) and latest['kind']==gate['kind']
                   and latest['reviewer']==task['reviewer'] and latest['reviewer']!=row['worker'])
            try: valid=valid and local_file(store.root,latest['evidence_path'])['sha256']==latest['evidence_sha256']
            except (ValueError,OSError):valid=False
            if valid: status=latest['status']
            else: error='Review binding or evidence changed'
        findings.append({'id':gate['id'],'requirement':gate['requirement'],'layer':gate['layer'],
                         'kind':gate['kind'],'status':status,'error':error})
    return {'passed':all(x['status']=='PASS' for x in findings),'findings':findings,
            'scope':'Only explicitly frozen gates. Missing business/visual gates are not proof of business/visual quality'}

def require_quality(store,row,result):
    from delivery_state import guard_context
    guard_context(store, row["id"])
    report=evaluate_quality(store,row,result)
    require(report['passed'],'QUALITY_GATE','Frozen manual quality gates failed/unverified: '+str(report['findings']))
