#!/usr/bin/env python3
"""Compare paired skill evaluations; never edit/promote an installed skill.

This evaluates explicit, locally bound reports, not the truth of their narrative.
A real-model promotion needs real-model reports. Fixture reports stay HOLD.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import sys

from kernel import checked_root, load_json, local_file, sha
from team_runtime import TeamStore, TeamError, array, fields, require, text


def validate_report(report: dict, root: Path) -> None:
    fields(report, {"schema_version", "suite_id", "suite_digest", "environment_digest", "candidate_digest", "mode", "cases"})
    require(type(report["schema_version"]) is int and report["schema_version"] == 1, "EVAL_VERSION", "Expected version 1")
    text(report["suite_id"], "suite_id")
    for name in ("suite_digest", "environment_digest", "candidate_digest"):
        require(sha(report[name]), "EVAL_HASH", name)
    require(report["mode"] in ("real-model", "software-runtime", "fixture"), "EVAL_MODE", "Unknown evaluation mode")
    ids = set()
    for case in array(report["cases"], "cases"):
        fields(case, {"id", "input_digest", "passed", "required", "hard_violation", "cost_units", "evidence_path", "evidence_sha256"})
        text(case["id"], "case.id")
        require(case["id"] not in ids, "EVAL_DUPLICATE", case["id"]); ids.add(case["id"])
        for flag in ("passed", "required", "hard_violation"):
            require(type(case[flag]) is bool, "EVAL_BOOLEAN", flag)
        require(sha(case["input_digest"]) and sha(case["evidence_sha256"]), "EVAL_HASH", case["id"])
        cost = case["cost_units"]
        require(cost is None or (type(cost) in (int, float) and math.isfinite(cost) and cost >= 0), "EVAL_COST", "Cost is null or a finite non-negative number")
        actual = local_file(root, case["evidence_path"])
        require(actual["sha256"] == case["evidence_sha256"], "EVAL_EVIDENCE", case["id"])


def compare(baseline: dict, candidate: dict, root: str | Path, *, max_cost_growth: float = 0.10) -> dict:
    require(type(max_cost_growth) in (int, float) and math.isfinite(max_cost_growth) and 0 <= max_cost_growth <= 1, "COST_LIMIT", "Cost growth must be 0..1")
    workspace = checked_root(root)
    validate_report(baseline, workspace); validate_report(candidate, workspace)
    for field in ("suite_id", "suite_digest", "environment_digest", "mode"):
        require(baseline[field] == candidate[field], "UNPAIRED_EVAL", field + " differs")
    require(baseline["candidate_digest"] != candidate["candidate_digest"], "SAME_CANDIDATE", "Compare different candidate versions")
    before = {c["id"]: c for c in baseline["cases"]}; after = {c["id"]: c for c in candidate["cases"]}
    require(before.keys() == after.keys(), "CASE_COVERAGE", "Do not drop regression cases")
    for cid in before:
        require(before[cid]["input_digest"] == after[cid]["input_digest"] and before[cid]["required"] == after[cid]["required"], "CRITERIA_DRIFT", cid)
    regressions = [cid for cid in before if before[cid]["passed"] and not after[cid]["passed"]]
    failures = [cid for cid in after if after[cid]["required"] and not after[cid]["passed"]]
    violations = [cid for cid in after if after[cid]["hard_violation"]]
    gains = [cid for cid in before if not before[cid]["passed"] and after[cid]["passed"]]
    known = all(c["cost_units"] is not None for c in [*before.values(), *after.values()])
    cost_before = sum(c["cost_units"] for c in before.values()) if known else None
    cost_after = sum(c["cost_units"] for c in after.values()) if known else None
    cost_regression = known and cost_after > cost_before * (1 + max_cost_growth)
    cost_gain = known and cost_after < cost_before
    reasons = []
    if regressions: reasons.append("passed cases regressed")
    if failures: reasons.append("required cases failed")
    if violations: reasons.append("hard boundary violations")
    if cost_regression: reasons.append("cost exceeded declared limit")
    if reasons:
        decision = "REJECT"
    elif candidate["mode"] == "fixture":
        decision = "HOLD"; reasons.append("fixture evidence cannot authorize real behavior promotion")
    elif not known:
        decision = "HOLD"; reasons.append("cost unmeasured; no automatic promotion")
    elif not gains and not cost_gain:
        decision = "HOLD"; reasons.append("no measured improvement")
    else:
        decision = "ELIGIBLE_FOR_REVIEW"; reasons.append("paired evidence gate passed; independent review and authorized deployment still required")
    return {"decision": decision, "scope": candidate["mode"], "reasons": reasons,
            "regressions": regressions, "required_failures": failures, "hard_violations": violations,
            "improved_cases": gains, "cost_before": cost_before, "cost_after": cost_after,
            "installed_skill_changed": False, "background_work_started": False}


def failure_candidates(job: str | Path) -> dict:
    with TeamStore(job) as store:
        rows = list(store.db.execute("SELECT task_id,kind,detail FROM events WHERE kind IN ('REVIEWED','HOST_UNCERTAIN','LEASE_UNCERTAIN') ORDER BY seq"))
        candidates = []
        for row in rows:
            detail = json.loads(row["detail"])
            if row["kind"] == "REVIEWED" and detail["decision"] == "accept": continue
            task = json.loads(store.row(row["task_id"])["contract"])
            candidates.append({"task_id": row["task_id"], "role": task["role"], "event": row["kind"],
                               "observation": detail.get("reason", "lease expired; cause not yet established"),
                               "status": "CANDIDATE_ONLY", "required_next": "root cause + counterexample + minimal patch + paired regression evidence"})
        return {"run_id": store.meta("plan")["run_id"], "candidates": candidates,
                "warning": "An observed failure is not automatically a reusable rule. Do not generalize one exception.", "installed_skill_changed": False}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    p = commands.add_parser("compare"); p.add_argument("--baseline", required=True); p.add_argument("--candidate", required=True); p.add_argument("--root", required=True); p.add_argument("--max-cost-growth", type=float, default=0.10)
    p = commands.add_parser("failures"); p.add_argument("--job", required=True)
    args = parser.parse_args(argv)
    try:
        result = failure_candidates(args.job) if args.command == "failures" else compare(load_json(args.baseline), load_json(args.candidate), args.root, max_cost_growth=args.max_cost_growth)
        print(json.dumps(result, ensure_ascii=False, indent=2)); return 0 if result.get("decision") not in ("HOLD", "REJECT") else 2
    except (ValueError, OSError, TypeError, KeyError) as exc:
        print(json.dumps({"error": getattr(exc, "code", "EVAL_INVALID"), "message": str(exc)}, ensure_ascii=False)); return 1


if __name__ == "__main__":
    raise SystemExit(main())
