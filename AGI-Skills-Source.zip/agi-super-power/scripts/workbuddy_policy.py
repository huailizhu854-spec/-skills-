"""WorkBuddy policy for new jobs; capability/evidence consistency, not host attestation."""
from __future__ import annotations
import json
import time
from pathlib import Path
from kernel import local_file, load_json
from team_runtime import require
from host_contract34 import blank_probe, evaluate_probe

HOST = 'workbuddy_mobile_cloud'
POLICY_VERSION = 1
REQUIRED = ('create', 'wait', 'artifacts', 'workspace', 'shared_files')

def has_workbuddy(store):
    return any(t.get('executor', {}).get('type') == HOST for t in store.meta('plan')['tasks'])

def meta_or(store, key, default=None):
    row = store.db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
    return default if row is None else json.loads(row[0])

def legacy(store):
    return has_workbuddy(store) and meta_or(store, 'workbuddy_policy_version') != POLICY_VERSION

def guard_writes(store):
    require(not legacy(store), 'WB_LEGACY_READ_ONLY',
            'Historical WorkBuddy job is read-only; reconcile its original host before creating a new job. Never backfill evidence.')

def template(store):
    return {'schema_version': 1, 'job': str(store.root), 'plan_digest': store.meta('plan_digest'),
            'host': HOST, 'entry': 'MOBILE_CLOUD', 'execution_mode': 'synchronous_terminal',
            'native_tool': None, 'probe': blank_probe(HOST),
            'file_tools': {k: {'status':'unknown','native_tool':None,'evidence':None} for k in ('file.read','file.write')}}

def _validate(store, value, *, now):
    require(type(value.get('schema_version')) is int and value['schema_version'] == 1 and value.get('job') == str(store.root)
            and value.get('plan_digest') == store.meta('plan_digest'), 'WB_CAPABILITY', 'Capability job/plan mismatch')
    require(value.get('host') == HOST and value.get('entry') == 'MOBILE_CLOUD'
            and value.get('execution_mode') == 'synchronous_terminal', 'WB_CAPABILITY', 'Wrong WorkBuddy entrance or mode')
    require(isinstance(value.get('native_tool'), str) and bool(value['native_tool'].strip()),
            'WB_CAPABILITY', 'Record the actual exposed native tool name')
    file_tools = value.get('file_tools')
    require(isinstance(file_tools,dict) and set(file_tools)=={'file.read','file.write'},'WB_CAPABILITY','Record both actual file tools')
    for logical, tool in file_tools.items():
        require(isinstance(tool,dict) and tool.get('status')=='supported'
                and isinstance(tool.get('native_tool'),str) and bool(tool['native_tool'].strip()),
                'WB_CAPABILITY','Required file tool unavailable: '+logical)
        evidence = tool.get('evidence')
        require(isinstance(evidence,dict) and set(evidence)=={'path','sha256'},'WB_CAPABILITY','File tool needs evidence: '+logical)
        require(local_file(store.root,evidence['path'])['sha256']==evidence['sha256'], 'WB_CAPABILITY','File tool evidence changed: '+logical)
    probe = value['probe']
    require(probe.get('host') == HOST, 'WB_CAPABILITY', 'Probe host mismatch')
    offline = meta_or(store, 'execution_profile') == 'offline_fixture'
    require(probe.get('evidence_kind') == ('OFFLINE_FIXTURE' if offline else 'CURRENT_TOOL_OBSERVATION'),
            'WB_CAPABILITY', 'Synthetic and live capability records must use separate job profiles')
    result = evaluate_probe(probe, store.root, required=REQUIRED, now=now,
                            allow_unknown_client=HOST, fixture_host=HOST if offline else None)
    require(not result['blockers'], 'WB_CAPABILITY', ', '.join(result['blockers']))
    return value

def freeze(store, record_path):
    with store.transaction():
        require(has_workbuddy(store), 'WB_CAPABILITY', 'This plan contains no WorkBuddy task')
        require(not meta_or(store, 'workbuddy_capabilities'), 'WB_CAPABILITY_FROZEN', 'Capability record is immutable')
        require(not store.db.execute('SELECT 1 FROM tasks WHERE attempt>0').fetchone(),
                'WB_CAPABILITY_FROZEN', 'Freeze capabilities before the first claim')
        rel = Path(record_path).absolute().relative_to(store.root).as_posix()
        require(rel.startswith('reviews/'), 'WB_CAPABILITY', 'Save current capability evidence in job/reviews')
        info = local_file(store.root, rel)
        value = _validate(store, load_json(store.root / rel), now=time.time())
        require(local_file(store.root, rel)['sha256'] == info['sha256'], 'WB_CAPABILITY', 'Capability changed while reading')
        pin = {'path': rel, 'sha256': info['sha256']}
        store.db.execute('INSERT INTO meta VALUES (?,?)', ('workbuddy_capabilities', json.dumps(pin)))
        return {'frozen': pin, 'execution': 'NOT_EXECUTED', 'execution_profile': meta_or(store, 'execution_profile'),
                'host_attestation': 'NOT_VERIFIED', 'native_tool': value['native_tool']}

def capabilities(store, *, fresh=True, packet=None):
    guard_writes(store)
    pin = meta_or(store, 'workbuddy_capabilities')
    require(isinstance(pin, dict), 'WB_CAPABILITY_MISSING', 'Freeze current mobile-cloud capabilities before prepare')
    info = local_file(store.root, pin['path'])
    require(info['sha256'] == pin['sha256'], 'WB_CAPABILITY_CHANGED', 'Frozen capability record changed')
    now = time.time()
    if packet is not None:
        policy = packet.get('workbuddy_policy')
        require(policy == {'version': POLICY_VERSION, 'capabilities': pin,
                           'execution_profile': meta_or(store, 'execution_profile')},
                'WB_CAPABILITY_CHANGED', 'Packet capability reference or policy changed')
        if not fresh:
            reservations = store.db.execute("SELECT at,detail FROM events WHERE task_id=? AND kind='SUBMISSION_RESERVED' ORDER BY seq",
                                            (packet['task_id'],)).fetchall()
            from delivery_state import dispatch
            d = dispatch(store, packet['lease_token'])
            times = [r['at'] for r in reservations if json.loads(r['detail'])['request_key'] == d['request_key']]
            require(len(times) == 1, 'WB_CAPABILITY', 'Exactly one reservation must bind this capability snapshot')
            now = times[0]
    return _validate(store, load_json(store.root / pin['path']), now=now)

def packet_policy(store):
    return {'version': POLICY_VERSION, 'capabilities': meta_or(store, 'workbuddy_capabilities'),
            'execution_profile': meta_or(store, 'execution_profile')}

def guard_success(store, row, run_id, observation=None, *, lifecycle=False):
    if json.loads(row['contract']).get('executor', {}).get('type') != HOST:
        return
    guard_writes(store)
    packet = json.loads(row['packet'])
    cap = capabilities(store, fresh=False, packet=packet)
    from workbuddy_evidence import check_record
    try:
        verified = check_record(store.root, Path(packet['packet_path']), store=store)
    except (ValueError, OSError, KeyError, TypeError) as exc:
        from team_runtime import TeamError
        raise TeamError('WB_CALL_RECORD', 'Required call evidence is missing or inconsistent: ' + str(exc)) from exc
    require(verified['bind_eligible'] and verified['host_run_id'] == run_id,
            'WB_CALL_RECORD', 'Current attempt needs its own completed call record')
    require(verified['native_tool'] == cap['native_tool'], 'WB_CALL_RECORD', 'Call tool differs from frozen capability')
    if observation is not None:
        raw = verified['raw_return']
        if lifecycle:
            require(observation['evidence_path'] == raw['path']
                    and observation['evidence_sha256'] == raw['sha256']
                    and observation['tool'] == verified['native_tool'],
                    'WB_CALL_RECORD', 'Lifecycle observation must reference the exact recorded raw return and tool')
        else:
            expected = (Path(packet['workspace']) / observation['raw_evidence_path']).relative_to(store.root).as_posix()
            require(expected == raw['path'] and observation['raw_evidence_sha256'] == raw['sha256']
                    and observation['native_tool'] == verified['native_tool'],
                    'WB_CALL_RECORD', 'Event must reference the exact recorded raw return and tool')
    return verified

def checkpoint_readonly(store):
    with store.transaction(readonly=True):
        row = store.db.execute('SELECT * FROM checkpoints34 ORDER BY seq DESC LIMIT 1').fetchone()
        return {'legacy_read_only': True, 'persisted': False,
                'checkpoint': dict(row) if row else None, 'status': store._status()}
