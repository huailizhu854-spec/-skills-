#!/usr/bin/env python3
"""Operate strict 2+16 jobs. This CLI NEVER creates model sessions itself."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from kernel import load_json, local_file
from team_runtime import TeamStore, require
import dual16


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['compile','init','probe','reserve','observe-start','barrier',
                                   'decision-request','decision-record','grants','review','withdraw-accept',
                                   'observe-health','status'])
    p.add_argument('--job',type=Path);p.add_argument('--plan',type=Path);p.add_argument('--inputs',type=Path)
    p.add_argument('--offline-fixture',action='store_true');p.add_argument('--slot');p.add_argument('--controller')
    p.add_argument('--evidence',help='Job-relative reviews/dual16/... JSON observation')
    p.add_argument('--grant');p.add_argument('--reason',default='Independent requirement verification rejected the approval')
    a=p.parse_args(argv)
    try:
        if a.action in ('compile','init'):
            require(a.plan is not None,'INPUT','--plan is required')
            plan=load_json(a.plan)
            require(dual16.enabled(plan),'D16_REQUIRED','New tasks must use the strict dual-controller-16 profile')
            from team_runtime import compile_plan
            answer=compile_plan(plan)
            if a.action=='init':
                require(a.job is not None and a.inputs is not None,'INPUT','--job and --inputs are required')
                answer=TeamStore.create(a.job,plan,a.inputs,offline_fixture=a.offline_fixture)
        else:
            require(a.job is not None,'INPUT','--job is required')
            with TeamStore(a.job) as store:
                require(dual16.enabled(store.meta('plan')),'D16_REQUIRED','Use a fresh strict-profile job, not a legacy ledger')
                ref=None
                if a.evidence:
                    info=local_file(store.root,a.evidence);ref={'path':a.evidence,'sha256':info['sha256']}
                if a.action in ('probe','observe-start','barrier','decision-record','observe-health'):
                    require(ref is not None,'INPUT','--evidence is required')
                if a.action=='probe': answer=dual16.register_probe(store,ref)
                elif a.action=='reserve': answer=dual16.reserve(store,a.slot)
                elif a.action=='observe-start': answer=dual16.observe_start(store,a.slot,ref)
                elif a.action=='barrier': answer=dual16.barrier(store,ref)
                elif a.action=='decision-request': answer=dual16.request_decision(store,a.controller)
                elif a.action=='decision-record': answer=dual16.record_decision(store,a.controller,ref)
                elif a.action=='review': answer=dual16.apply_review(store,a.grant)
                elif a.action=='withdraw-accept': answer=dual16.invalidate_grant(store,a.grant,a.reason)
                elif a.action=='observe-health': answer=dual16.observe_health(store,a.slot,ref)
                elif a.action=='grants':
                    answer={'grants':[dict(r) for r in store.db.execute('SELECT * FROM d16_grants WHERE consumed=0 ORDER BY rowid')]}
                else: answer=store.status()
        print(json.dumps(answer,ensure_ascii=False,indent=2));return 0
    except (ValueError,OSError,KeyError,TypeError) as exc:
        code=getattr(exc,'code','D16_INPUT')
        print(json.dumps({'error':code,'message':str(exc),'native_execution_claimed':False},ensure_ascii=False))
        return 2 if code in {'D16_CAPACITY','D16_CAPABILITY','D16_PROBE','D16_ROSTER','D16_QUERY_STALE'} else 1

if __name__=='__main__':raise SystemExit(main())
