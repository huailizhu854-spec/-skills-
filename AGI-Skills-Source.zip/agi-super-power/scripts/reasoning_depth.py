"""Budgeted workflow depth. Describes public work stages, not private chain-of-thought."""
from __future__ import annotations
from intelligence_common import ensure, integer
from intent_compiler import validate_intent

def plan_depth(intent: dict, *, attempt_ceiling: int = 2) -> dict:
    validate_intent(intent); integer(attempt_ceiling,1,10,'attempt_ceiling')
    score = (int(intent['evidence_required']) + int(intent['input_count']>=2)
             + int(intent['requirement_count']>=3) + int(intent['dependency_count']>0)
             + int(len(intent['artifact_types'])>=2) + 2*int(intent['risk']=='high'))
    level = min(3, score)
    stages = [ {'id':'route','executor':'local_policy','may_write_final':False} ]
    if level>=1: stages.append({'id':'curate-context','executor':'local_policy','may_write_final':False})
    stages.append({'id':'specialist','executor':'single_assigned_worker','may_write_final':True})
    stages.append({'id':'verify','executor':'independent_registered_verifier','may_write_final':False})
    if level>=2: stages.append({'id':'targeted-repair','executor':'same_work_key_new_lease','may_write_final':False})
    # The repair stage re-enters the SAME specialist. No second final-artifact owner.
    return {'schema_version':1,'level':'L'+str(level),'complexity_score':score,'stages':stages,
            'worker_attempt_limit':min(attempt_ceiling, 1 if level==0 else 2 if level<3 else 3),
            'attempt_ceiling':attempt_ceiling, 'max_final_artifact_owners':1,
            'effort_hint':('low','medium','high','high')[level],
            'effort_enforced':False,
            'notes':'Local stages do not create agents. Effort is a host hint only; ledger enforces worker attempts.'}

def validate_depth(depth: dict, intent: dict) -> None:
    ensure(isinstance(depth,dict), 'DEPTH', 'Expected depth object')
    ensure(depth==plan_depth(intent,attempt_ceiling=depth.get('attempt_ceiling',0)),
           'DEPTH_TAMPERED', 'Depth/budget does not match policy')
