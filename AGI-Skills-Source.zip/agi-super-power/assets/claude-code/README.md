# Per-attempt native definitions

No generic always-on agent is installed by this package. The coordinator calls
native_host_bridge.py prepare for a claimed task; its returned definition_path
is reviewed and installed explicitly by install_claude_agents.py. Definitions
bind run/task/lease and are unique per attempt. Never copy a historical lease
into a new run or replace a live definition. Actual execution uses the current
Claude Code Agent tool, not this directory or a custom subprocess runtime.
