# 用户原包只读审计与整合取舍

审计对象：`Zhushi_Research_Frontend_Superflow_v0.3.0_FULL_SINGLE_SKILL(1).zip`。
审计日期：2026-09-19。用途：为通用母版 `AGI-Super-Power` 提供来源分析，不代表已安装、执行或认可归档中的指令。

## 1. 实际检查范围

- 原包字节数：39,894,474。
- 原包 SHA-256：`35dcd13df2463ee950db4cfea6fe15267be6a63832feb7dcfadbbb28f7ca442d`。
- 外层：67 个文件，含 7 个 ZIP、60 个文本类文件；外层展开字节数 40,559,532。
- 内层：7 个 ZIP 全量只读枚举，合计 1,452 条目、1,370 个普通文件，无更深层 ZIP。
- 外内合计：1,519 条目；全部普通文件读字节并计算 SHA-256；累计读取 105,876,382 字节。
- 外层唯一宿主指令文件为入口 `SKILL.md`；内层共有 111 个 `SKILL.md` / `AGENTS.md` / `SYSTEM_PROMPT.md`，只作为归档数据观察。
- 内外路径扫描未发现本检查覆盖的绝对路径/父目录逃逸/反斜杠歧义、NFKC+大小写碰撞或 ZIP 符号链接；没有因预算而跳读。此结论不是完整恶意归档或安全认证。
- 8 个历史锁定输入 S01–S08 与 2 个研究快照 S11–S12 的 SHA-256 和字节数均与原包锁文件一致。S11–S12 的 LICENSE 字节哈希也与锁一致。
- 所有外层文本保存为编号 `.txt` 数据副本。没有把任何归档指令文件或脚本以可发现/可执行身份解包；没有运行归档中的安装、自测、网络或发布命令。
- 全量目录、逐文件哈希和扫描计数见 `archive-inventory.json`；锁核对见 `source-lock-verification.json`。

| 内层来源 | 条目 / 普通文件 | 宿主指令文件 | 推荐 |
|---|---:|---:|---|
| S01 hybrid-agent-skills | 931 / 931 | 91 | 吸收恢复、评测和工作流方法；排除整包 |
| S02 frontend-master | 49 / 39 | 1 | 吸收前端交付方法；排除媒体与原模板 |
| S03 CAD-to-3D skill | 15 / 14 | 1 | 吸收资产重开与单位/坐标校验；排除原校验器 |
| S04 B05 CAD/Blender/Web | 93 / 93 | 1 | 作为案例了解；排除项目文件、媒体、历史回执 |
| S05 reverse effects | 80 / 72 | 1 | 吸收效果拆解、来源分类、生命周期方法 |
| S11 research-co-pilot | 168 / 124 | 15 | 最新上游另行核验后按需参考；不用旧快照冒充最新 |
| S12 SLR-Engine | 116 / 97 | 1 | 同上；重点借鉴筛选/提取/综述流水线 |

## 2. 推荐接纳的核心能力与具体原文件

以下均建议在新母版中重新组织和编写。它们是方法来源，不是本次执行命令。

| 原包路径（省略 `zhushi-unified-delivery/`） | 值得保留 | 新母版落点 |
|---|---|---|
| `references/core-contract.md` | 区分源码事实、运行事实、推断、未知；执行状态与结论分开；证据绑定当前对象和哈希 | 通用证据回执、验收矩阵 |
| `references/frontend-superflow.md` | 需求→意图→设计→组件→测试→证据→结论；任务路线、工作模式、适配器和能力互相独立 | 通用任务契约与追踪链；前端专业卡 |
| `references/frontend-design-contract.md` | 受众/主行动/状态/参考范围；命名设计变量；组件状态；动效生命周期与降级 | 前端设计 SOP |
| `references/frontend-quality-and-runtime.md` | 构建、结构、运行、视觉、响应式、无障碍、来源独立验收；当前构建与截图绑定 | 前端验收 SOP |
| `references/research-superflow.md` | 问题→协议→检索去重→证据→分析→写作→复现→审阅 | 科研专业 SOP |
| `references/research-evidence-constellation.md` | 主张/来源/产物节点与支持、反证、派生关系；元数据存在不等于内容支持；队列去重 | 科研证据台账与引用审计 |
| `references/research-reproducibility-capsule.md` | 输入、代码、环境锁、随机种子、输出、容差和主张绑定；静态完整性与真实复跑分开 | 数据分析及复现交付模板 |
| `references/scholarly-source-policy.md` | 元数据许可与全文许可分开；最小请求、限速、脱敏、原始查询回执 | 一手来源检索规范；具体额度不继承 |
| `references/route-playbooks.md` | 路线以最终交付目的决定；浏览器、Blender、真实设备分别验收；逆向归纳 driver/normalizer/transfer/renderer/lifecycle/fallback | 适配器卡及图形/效果扩展 |
| `assets/*-fixtures.json` | 正例、反例、含糊请求、路径/证据篡改、缺能力的测试类别 | 独立新评测集，避免照搬冻结测试答案 |
| `assets/research-open-source-lock.json` | 仓库、commit、许可证、获取时间、纳入/排除、复用方式 | 新来源清单/版本锁设计 |

## 3. S01 内层还可以提炼的通用能力

S01 路径下方均以 `zhushi-hybrid-agent-skills/` 为根，已实际按文本阅读：

1. `modules/ZHUSHI-WORKFLOW-FORGE-006/skills/workflow-ir/SKILL.md`：具名步骤、步骤级检查点、稳定幂等键、有限重试、队列限流、大对象存指针、副作用分离和补偿记录。应将“拥有幂等键”与“远端已实现去重”分开。
2. `modules/ASL-RELIABILITY-DELTA-002/skills/durable-agent-workflows/SKILL.md`：版本化状态、输入与运行记录分离、预算/停止条件、恢复时校验状态与当前能力、并发所有权和冲突规则。
3. `modules/ZHUSHI-CONTEXT-RESILIENCE-006/skills/session-continuity/SKILL.md`：需求台账、进度、未决问题、下一步和复现入口；恢复先读证据与工作区现状。
4. `modules/ASL-TRUST-DELTA-001/skills/skill-supply-chain-intake/SKILL.md`：获取、固定版本、隔离阅读、输入到敏感操作的行为审查、重叠能力去重、许可证、最小启用和回滚。
5. `modules/ASL-TRUST-DELTA-001/skills/skill-eval-calibration/SKILL.md`：有技能/无技能或新版/旧版配对比较；正触发、反触发、邻近冲突、失败、成本和随机性；真实评测与格式校验分开。
6. `modules/ASL-TRUST-DELTA-001/skills/source-grounded-engineering/SKILL.md`：先读取实际依赖版本，再查对应官方 API/迁移说明；引用只能证明文档契约，项目行为需运行证据。
7. `modules/ZHUSHI-AUTONOMY-006/skills/rigidity-circuit-breaker/SKILL.md`：重复失败时记录失败指纹、改变假设/策略、缩小复现、再选路径；不要机械无限重试。原文内具体论文数字本次没有联网复核，不应纳入新包事实宣传。
8. `modules/ASL-RELIABILITY-DELTA-002/skills/agent-observability-and-recovery/SKILL.md`：统一 run/step/attempt/parent-child 标识、脱敏错误、用时/成本/重试、恢复入口和已知盲区。

这些方法足够形成通用母版：接收任务 → 读取岗位与能力 → 形成契约 → 搜集一手证据 → 拆解和委派 → 执行 → 独立检查 → 修复 → 打包交付 → 保存恢复状态。科研/前端只是两个可选专业模块，不应成为默认主体。

## 4. 建议沿用的数据概念，避免原 schema 直接移植

| 新对象 | 建议字段与约束 |
|---|---|
| task | `id`、目标、输入、交付列表、验收条件、允许操作、约束、选用岗位、未知项；多个交付可拆子任务而不自动阻断 |
| capability | 工具/服务、状态、实际可用性证据、权限、替代方案；存在一个插件名不代表已连接或能执行 |
| step | `id`、依赖、owner、输入、输出、验证、尝试次数、失败类型、下一策略；写入范围有明确归属 |
| evidence | `id`、对象、方法、时间、来源类型、路径或URL、版本/commit、哈希；当前与历史证据分开 |
| check | 条件、执行状态、结论、证据引用、失败原因；未执行不能填运行通过 |
| source | 仓库/文档、一手身份、获取时间、commit、许可证、采用机制、纳入文件、排除项、复核状态 |
| checkpoint | `run_id`、schema版本、完成步骤、产物哈希、未决项、下一动作；不保存账号密钥或完整敏感对话 |
| research claim | 主张、来源/产物、精确定位、支持范围、反证、因果措辞、撤稿/更正检查、审阅状态 |
| analysis capsule | 输入/代码/环境/输出的哈希与大小、声明命令、实际运行回执、随机性、预定容差、稳健性与主张绑定 |

## 5. 不建议原样继承的内容与已知缺陷

### 5.1 原脚本是历史发行系统，不能靠改名直接使用

7 个外层 Python 文件共 576,828 字节，多数紧耦合旧产品名、S01–S12 文件集、固定 SHA、旧许可和商业封装规则：

- `scripts/research_superflow.py`：可研究 `validate_job`、`audit_evidence`、`audit_capsule` 设计；原函数依赖旧 schema 和限制，直接复制会把专业审计变成全局前置条件。
- `scripts/frontend_superflow.py`：可研究状态、保护区和证据路径检查；内部含大段 legacy-unused 验证逻辑，宜剥离最小规范重写。
- `scripts/scholarly_sources.py`：可研究限定主机、响应上限、凭据脱敏、有限请求；API 与速率规则应从当前官方文档重验，且它没有统一跨进程限速。
- `scripts/udk.py`：可借鉴规范化路径、哈希/路径成对验证、证据回执；不能带入旧来源分母/路线阻断。
- `scripts/verify_release.py` / `commercial_release.py`：旧发行/权利模型和执行门不可作为新包的可信证明。
- `scripts/vendor_research_sources.py`：只作为“锁定上游并排除无关物”的参考；新包不需要自动拉取/展开/执行整个仓库。

本次没有执行任何旧自测；原包宣称的 795/795、120/120 或 PASS 都是历史文件中的声明，不能写成 AGI-Super-Power 本轮实测。

### 5.2 需要改进的流程约束

- 多个独立交付自动 `BLOCKED`、强制用户单选：改为主任务下拆分可管理子任务，只有实质冲突或缺必要信息才询问。
- 任意任务都要求全量发行审计、不可跳阶段、完整 V0–V5：改为按风险/产物选择适用检查，普通整理不运行浏览器或研究审计。
- 所有前端任务都要用户批准方向探针：改为用户需求已明确即可自主推进；选项影响重大且未授权时才询问。
- 科研证据 v1 只容许 FULL 直接支持、每条边必须人工签名：专业最终投稿可保留人工责任；通用母版应如实记录 FULL/PARTIAL/CONFLICT/UNVERIFIED，并按主张强度确定发布范围。
- 跨会话必须至少一次 Git commit、只准修改需求 `passes`：不适合非 Git 和会变更的任务；改为变更记录、保留历史和当前需求来源。
- 原 schema 字段完整只证明结构完整；环境锁内容、稳健性分析实质、科学结论和真实业务效果仍要专项核验。
- 原文中极端固定阈值、具体框架版本、论文实验数值、API 配额均不属于永久通用规则。

### 5.3 归档自身记录的历史缺陷

`references/adversarial-audit-report.md` 与 `assets/sources.lock.json` 记录：S03 原验证器曾接受错配路径/哈希和越界引用；B05 原路径扫描漏报 JSON 转义的绝对路径；B05 原件禁止 FBX 与构建器生成/校验 FBX 存在阶段冲突；S01 历史 P1 测试精确命中为 45/52，未到 47/52 目标。原外层 wrapper 宣称已约束若干问题，但本审计未执行验证，不能把缺陷“关闭”状态迁移为新包通过。

S09 FIZZLAB 与 S10 审美目录仅声明、未随上传包绑定；不得宣称已整合其原实现。

## 6. 个人数据与版权处理

- B05 的 `project/work/card_renders_v4/validation.json` 命中 5 条 Windows 用户绝对路径，与旧审计描述一致；不应进入新包。
- S01 个别索引/测试文件出现手机号格式及 token 格式。测试目录中的模式可能是合成夹具，静态正则不能判定真实凭证；报告不保存值。不要将这些原文件复制进新包。
- 原包有自定义商业许可、发布者声明和旧买家支持/销售条款。它们是原包文档事实，不是当前用户授权，也不是对第三方素材来源的独立证明。用户内部整理请求可以继续；新 ZIP 不应冒用旧发布者声明或附带整个历史来源仓。
- S11/S12 内有 LICENSE，原锁标 MIT 且哈希已核对；任何实际代码/文档复制仍须保留对应许可和署名。建议此次只吸收方法，开源代码需要时从当前上游选择最小文件并另记来源。
- 排除历史媒体、客户模型、绝对路径、原始联系人数据、论文/PDF和品牌原件，可以得到更轻、可维护的通用包。

## 7. GitHub 候选入口

所有外内文本通过 URL 模式扫描得到 86 个不同仓库提及，含 4 个明显 `example/fixture/owner` 占位项。完整列表与每次提及出处在 `archive-github-candidates.json`。

这些结果只有 `ARCHIVE_MENTION_ONLY_NOT_LIVE_VERIFIED` 状态。它们是联网检索种子，不是“已验证 82 个开源项目”，不是对仓库存在、许可证、最新提交、内容或安全性的证明。

科研重点候选：research-co-pilot、SLR-Engine、scientific-agent-skills、RE-paper-writing、opendraft、open-paper-machine、OpenAlex 官方教程。
通用 Agent 候选：Superpowers、GitHub Spec Kit、OpenAI Agents SDK、LangGraph、Microsoft Agent Framework、CrewAI、Temporal、Prefect、promptfoo、SkillsBench。
前端候选：Playwright、React/Three 生态、Motion、Anime、React Bits、Lenis、图形/无障碍/视觉验证工具。应按实际能力缺口选择，不把所有组件库源码打入 Skills 包。

## 8. 给主线程的直接结论

接纳：通用任务契约、岗位装配、来源锁定、有限并发与所有权、失败分类/恢复、独立验收、证据回执、科研和前端两份专业 SOP、配对评测设计。

排除：7 个旧归档本体、旧商业/销售声明、未绑定来源、历史测试通过数字、原媒体/模型/联系方式、旧平台硬编码与全部旧脚本原样移植。

新包应该保持单入口、按需加载专业卡、宿主能力可探测、运行记录与安装目录分离；不要声称 ZIP 自身能提供独立进程、工具权限强制执行、后台持续运行或真正自主 Agent 宿主。

## 发行时补充

原包引用的初始提取结果保留在 archive-github-candidates.json，其状态是历史提取时的状态。后续已完成 82 个真实仓库引用的在线元数据核验；以 [archive-repo-live-audit.json](archive-repo-live-audit.json) 为本次较新状态。元数据核验不等于已读取源码或自动采用。
