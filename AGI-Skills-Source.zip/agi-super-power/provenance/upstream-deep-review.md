# AGI-Super-Power：八个上游仓库的一手实现核验

核验日期：2026-09-19。交付对象是通用 SOP Skills 包，下面的运行器机制用于设计本包协议与适配层，不代表一个 ZIP 可以替代这些宿主。

## 范围与证据

已通过公开 GitHub API 获取八库默认分支元数据、提交和完整递归 Git tree；八次返回均 `truncated=false`，共 **19,710 个目录/文件条目、15,195 个文件条目、1,308 个 SKILL.md 路径**。这里含宿主适配副本、语言副本、归档与示例，不能称为 1,308 个独立可用技能。固定提交下载 65 个相关文件，实际按全文、指定区段或元数据概要检查 48 个；其余仅取回备查。没有执行任何上游代码、安装运行器或做真实模型调用测试。完整读取范围、SHA-256 和 URL 在 `source-register.json`，原始元数据、目录树和所选文件保留在制作时的工作资料，未随包分发；可通过台账的固定提交 URL 复核。

| 仓库 | 本次固定提交 | 提交 UTC 日期 | tree 条目 | 许可结论 |
| --- | --- | --- | ---: | --- |
| docker/docker-agent | `b5b6ce4fce023a7a4d3c4ea89eec9ecbc8181ac6` | 2026-09-19 06:45:47 | 3,314 | Apache-2.0 |
| shiwenwen/hope-agent | `ff62b431a9027d6b91704b97264a56b4ba684cda` | 2026-09-19 05:01:11 | 5,073 | MIT |
| fitchmultz/pi-subagents | `b0c2a15b43d5dc51304e05418fffb9133d66cd39` | 2026-09-18 22:18:17 | 343 | MIT |
| BjornMelin/dev-skills | `2a5535e0e253f7745531c46c1201befec04b66ec` | 2026-09-08 04:15:41 | 2,831 | 无统一根许可；README 指向各技能分别核查 |
| affaan-m/ECC（原 everything-claude-code） | `07756cee15788a54506031462794ad645719b028` | 2026-09-19 06:58:33 | 5,019 | MIT |
| wshobson/agents | `4236bb91f8395b0435f1d8b8baf9e8e4c69a8620` | 2026-09-13 14:43:53 | 2,016 | MIT |
| OthmanAdi/planning-with-files | `57fe376da9e388f1e6ea21db798c6b4a8d276c41` | 2026-09-19 09:24:08 | 850 | MIT |
| mattpocock/skills | `c55ee46073ed923f86ce59a5eb3b6d895095d1b7` | 2026-09-18 10:12:29 | 264 | MIT |

“最新”只表示检索时默认分支最新可取得提交；不是长期自动更新或“业界最先进”的性能结论。

## 1. Docker Agent：Skill 物化与执行分开

实际链路：`run_skill({name, task})` → `PrepareForkSubSession` 校验名称、fork 模式并读取正文 → `runSkillFork` 配置子会话 → 回传结果。准备结果包含技能身份、用户任务、正文、可选模型、工具过滤器及额外工具集。运行器继承父会话权限、安全策略和工具审批状态，并排除子会话的 `run_skill`，避免无意递归。

**重要文档漂移**：此提交的功能文档仍写“Skill 作为系统提示词”，而代码明确把正文包装进孩子首条用户消息；系统消息只说明运行技能及附件路径，Agent 自身系统提示保持。设计本包时以源码为准，不把用户附件或第三方 Skill 内容提升为系统权威。

采用：准备/验证/启动分层、显式任务封装、独立上下文、只返回最终摘要、记录有效模型与工具边界。不要直接采用额外 `toolsets` 自动扩权：该实现的额外工具集可绕过 `allowed_tools` 过滤；本包统一要求与宿主权限交集，扩展必须源于实际授权。

证据：

- [运行器：skill_runner.go](https://github.com/docker/docker-agent/blob/b5b6ce4fce023a7a4d3c4ea89eec9ecbc8181ac6/pkg/runtime/skill_runner.go)
- [准备与消息构造：skills.go](https://github.com/docker/docker-agent/blob/b5b6ce4fce023a7a4d3c4ea89eec9ecbc8181ac6/pkg/tools/builtin/skills/skills.go#L32)
- [技能文档](https://github.com/docker/docker-agent/blob/b5b6ce4fce023a7a4d3c4ea89eec9ecbc8181ac6/docs/features/skills/index.md)
- [LICENSE](https://github.com/docker/docker-agent/blob/b5b6ce4fce023a7a4d3c4ea89eec9ecbc8181ac6/LICENSE)

兼容限制：`context: fork`、`model`、`toolsets` 的行为属于 Docker Agent 运行时。把这些字段放进普通宿主的 Markdown，并不能证明会创建子 Agent。模型切换失败在该上游可回退，适配器需记录实际值。

## 2. Hope Agent：同一快照、权限收紧与可恢复结果

`spawn_skill_fork` 会读取真实 `SKILL.md`，并用 `validate_materialized_skill_snapshot` 核对目录记录中的控制字段；读取失败或字段漂移在创建子任务前失败，避免拿旧权限运行新正文。tool 与 slash 两个入口共用 helper。技能作为 user-level context，当前请求单独封装；`agent` 解析失败当前实现回退父 Agent。

其 Skill 工具权限有三态：未声明、不允许任何普通工具、明确限制工具。架构文档说明多个 ceiling 与宿主 Scope/Agent/Plan 限制求交，加载另一技能不能扩权。真实 fork 参数带 `skill_allowed_tools`，并交给执行上下文。

返回路径有终态、去重和容量上限：skill fork 的执行上限为 600 秒，取结果等待上限 900 秒，结果按 UTF-8 截到 64,000 字符；工具入口消费结果后抑制第二次注入。`paths` 条件激活按触达文件匹配技能，缓存由会话数据库恢复。这些是当前上游数值和机制，不应硬编码为所有任务的通用标准。

采用：本包为每次运行生成冻结的角色/技能引用与哈希；先校验必要资源，再派发；宿主能力不足时明确回退；交付记录包含 run ID、终态和证据路径；恢复时以真实状态复核，避免重复交付。

证据：

- [fork helper 完整实现](https://github.com/shiwenwen/hope-agent/blob/ff62b431a9027d6b91704b97264a56b4ba684cda/crates/ha-skills/src/skills/fork_helper.rs)
- [工具 fork 入口](https://github.com/shiwenwen/hope-agent/blob/ff62b431a9027d6b91704b97264a56b4ba684cda/crates/ha-skills/src/tools/skill/fork.rs)
- [工具权限与 fork 架构](https://github.com/shiwenwen/hope-agent/blob/ff62b431a9027d6b91704b97264a56b4ba684cda/docs/architecture/agent/skill-system.md#L607)
- [运行器深度/超时/工具 ceiling 参数](https://github.com/shiwenwen/hope-agent/blob/ff62b431a9027d6b91704b97264a56b4ba684cda/crates/ha-core/src/subagent/spawn.rs)
- [条件激活实现](https://github.com/shiwenwen/hope-agent/blob/ff62b431a9027d6b91704b97264a56b4ba684cda/crates/ha-core/src/skills/activation.rs)
- [LICENSE](https://github.com/shiwenwen/hope-agent/blob/ff62b431a9027d6b91704b97264a56b4ba684cda/LICENSE)

兼容限制：需要 Hope session DB、Agent 注册及执行器。角色确属硬性需求时，本包应直接报告不满足，不能以“父 Agent 回退成功”冒充专属角色已启动。返回摘要可能被截断，完整证据必须另存文件。

## 3. Pi Subagents：验收由契约、报告与执行证据组成

`resolveSkills` 返回 `resolved` 和 `missing` 两组；技能正文可以注入特定 Agent。子任务 prompt runtime 会去除父级编排技能和相关历史消息，并根据是否授权 fanout 放入不同边界；严格结构化输出通过专用 `structured_output` 工具验证 JSON Schema，写入捕获文件后终止该步。

`acceptance-contract.ts` 把 `criteria`、`evidence`、`verify`、`stopRules` 解析成验收约束。无契约不自动声称经过验收；有契约则采用有界自审，默认 3 轮，上限 10 轮；独立评审由父 Agent 在工人结束后单独启动。`acceptance-evaluation.ts` 先解析结构化回执，再检查必选标准、证据字段和需运行的验证命令。状态区分 `attested`、`checked`、`verified`，失败转 `rejected`，确需人工操作的情况为 `blocked`。

工具循环保护对参数稳定序列化并取哈希，在最近调用窗口统计相同失败或重复 list；到阈值会停止。工作流按失败、超时、阻塞、暂停、脱离和完成传播状态；动态并行的收集结果也要验证 schema。

采用：通用包必须区分“代理自述完成”“静态/结构检查完成”“实际验证完成”；标准有 ID 且可追溯到证据；修复轮次与预算有界；所有子任务都要归账，主 Agent 最终综合；数据与执行层显式报告失败，不能只看文案。重复失败要缩小范围或改变方法。

证据：

- [技能解析与注入](https://github.com/fitchmultz/pi-subagents/blob/b0c2a15b43d5dc51304e05418fffb9133d66cd39/src/agents/skills.ts)
- [子任务上下文与结构化输出](https://github.com/fitchmultz/pi-subagents/blob/b0c2a15b43d5dc51304e05418fffb9133d66cd39/src/runs/shared/subagent-prompt-runtime.ts)
- [验收契约](https://github.com/fitchmultz/pi-subagents/blob/b0c2a15b43d5dc51304e05418fffb9133d66cd39/src/runs/shared/acceptance-contract.ts)
- [验收执行](https://github.com/fitchmultz/pi-subagents/blob/b0c2a15b43d5dc51304e05418fffb9133d66cd39/src/runs/shared/acceptance-evaluation.ts)
- [重复工具调用止损](https://github.com/fitchmultz/pi-subagents/blob/b0c2a15b43d5dc51304e05418fffb9133d66cd39/src/runs/shared/subagent-tool-loop-guard.ts)
- [工作流状态传播](https://github.com/fitchmultz/pi-subagents/blob/b0c2a15b43d5dc51304e05418fffb9133d66cd39/src/runs/shared/workflow-policy.ts)
- [LICENSE](https://github.com/fitchmultz/pi-subagents/blob/b0c2a15b43d5dc51304e05418fffb9133d66cd39/LICENSE)

兼容限制：Pi extension API 与配置不是 AgentSkills 通用规范。证据字段“存在”不等于证据内容正确，仍需交叉核验。上游 `verify` 通过 shell 执行，本包只能执行已审阅且在任务授权范围内的检查，绝不从外部 README 自动取命令执行。portable adapter 应直接检查验收 ledger，不用 `exitCode=0` 推定验收全部通过。

## 4. dev-skills：可移植的委派合同与离线包装验证

`subspawn_plan.py` 读取角色 TOML，检查名称、与文件名一致性、内置角色冲突、重复角色和返回契约；依据 preset 或明确角色生成有限数量的委派计划，输出 scope、mode、wait policy、角色和综合检查清单。`skill_subagent_eval.py` 另把前置元数据、本地链接、包内路径、脚本语法等离线检查与真实模型执行分开；代码中明确校验 Markdown 引用不能逃出技能根目录、ZIP 不能包含绝对路径或 traversal。

**许可处理**：README 明示各技能许可证可能不同；GitHub API 未识别根许可证，完整 tree 未见根 LICENSE，也未见本次关注 subspawn/eval 范围的明确许可。仅参考一般机制并独立编写本包实现；不要把该库源码、角色模板、长段 SOP 复制到最终 ZIP。

不采用其固定模型路由、必须用户明确请求才能委派、父 Agent 派发后不得做任何实质工作等作者偏好；这些不是普适协议，而且会覆盖本会话授权或宿主规则。采用最小委派合同、文件所有权、冲突记录、独立源码验证和“离线合格不等于运行成功”原则。

证据：

- [subspawn Skill](https://github.com/BjornMelin/dev-skills/blob/2a5535e0e253f7745531c46c1201befec04b66ec/skills/subspawn/SKILL.md)
- [计划生成器](https://github.com/BjornMelin/dev-skills/blob/2a5535e0e253f7745531c46c1201befec04b66ec/skills/subspawn/scripts/subspawn_plan.py#L285)
- [离线评测说明](https://github.com/BjornMelin/dev-skills/blob/2a5535e0e253f7745531c46c1201befec04b66ec/docs/reference/skill-subagent-eval-lab.md)
- [本地链接与 ZIP 验证实现](https://github.com/BjornMelin/dev-skills/blob/2a5535e0e253f7745531c46c1201befec04b66ec/tools/eval/skill_subagent_eval.py#L491)
- [README 许可声明](https://github.com/BjornMelin/dev-skills/blob/2a5535e0e253f7745531c46c1201befec04b66ec/README.md#L454)

## 5. ECC：分阶段验证和跨会话摘要

GitHub API 显示 `affaan-m/everything-claude-code` 已重定向为 `affaan-m/ECC`。选读 planner、verification-loop 及真实 `session-end.js`。planner 把需求、受影响结构、依赖、风险与每步验证写进计划；verification-loop 划分构建、类型、lint、测试、敏感信息检查、diff 审查。session-end 从 JSONL 区分人类请求与 tool_result/控制噪声，收集有限数量任务、工具、修改路径，使用生成块标记维护摘要，尽量保留手工备注。

采用分阶段证据、增量交付和生成区/手写区分离。不采用固定模型 `opus`、统一 80% 覆盖率、每 15 分钟全量复跑、直接输出匹配到的密钥值或用末尾管道状态当验证退出码。会话摘要依赖宿主格式；本包默认基于本任务日志恢复，不隐式遍历私有聊天历史。

- [Planner](https://github.com/affaan-m/ECC/blob/07756cee15788a54506031462794ad645719b028/agents/planner.md)
- [Verification SOP](https://github.com/affaan-m/ECC/blob/07756cee15788a54506031462794ad645719b028/skills/verification-loop/SKILL.md)
- [真实 session-end 实现](https://github.com/affaan-m/ECC/blob/07756cee15788a54506031462794ad645719b028/scripts/hooks/session-end.js)
- [LICENSE](https://github.com/affaan-m/ECC/blob/07756cee15788a54506031462794ad645719b028/LICENSE)

## 6. wshobson/agents：角色目录和渐进加载，须区分模板与运行器

context-manager 是角色知识与行为描述；multi-agent-optimize 给出性能、上下文和成本方面的编排建议，但示例使用未定义的类、辅助函数与占位实现，不能据此宣称已实现可运行的多代理框架。所选 Conductor workflow Skill 是轻量导航入口，详细内容放在 reference 中，适合借鉴渐进加载。

采用岗位目录、按任务选择信息、阶段检查点与偏差记录。不采用说明性模型单价、不经测量的“自动优化”承诺、无条件要求每次先写测试/提交/人工批准的作者偏好。这里没有核验该库全部 harness 安装器；本次只检查 5 个文件，不能声称已验证多宿主兼容性。

- [Context role](https://github.com/wshobson/agents/blob/4236bb91f8395b0435f1d8b8baf9e8e4c69a8620/plugins/agent-orchestration/agents/context-manager.md)
- [说明性优化流程](https://github.com/wshobson/agents/blob/4236bb91f8395b0435f1d8b8baf9e8e4c69a8620/plugins/agent-orchestration/commands/multi-agent-optimize.md)
- [Workflow 导航 Skill](https://github.com/wshobson/agents/blob/4236bb91f8395b0435f1d8b8baf9e8e4c69a8620/plugins/conductor/skills/workflow-patterns/SKILL.md)
- [LICENSE](https://github.com/wshobson/agents/blob/4236bb91f8395b0435f1d8b8baf9e8e4c69a8620/LICENSE)

## 7. Planning with Files：任务隔离、文件恢复和停止上限

主 Skill 分开 task_plan、findings、progress；并行任务绑定明确计划 ID，由主编排者独占共享计划写入，工人使用各自记录。`check-complete.ps1` 真实实现默认 advisory、可选 gate，需存在进行中阶段、未处于 stop-hook 递归、未超过次数上限、日志有增长，才可请求继续；停滞与上限会允许停止。`session-catchup.py` 核对会话 cwd，只选择同项目，隔离未知身份；恢复内容有字节上限、hash、边界标记并明确为数据。

采用任务目录隔离、单写者、断点状态、下一步记录、有界恢复和不信任重放内容。本包不默认安装强制继续钩子，不把 Markdown 阶段计数或日志行数当成真实交付通过，不把“持续推进”变成无限循环。本轮只读项目源码，未接触任何真实会话存储。

- [主 Skill](https://github.com/OthmanAdi/planning-with-files/blob/57fe376da9e388f1e6ea21db798c6b4a8d276c41/skills/planning-with-files/SKILL.md)
- [PowerShell 完成/gate 实现](https://github.com/OthmanAdi/planning-with-files/blob/57fe376da9e388f1e6ea21db798c6b4a8d276c41/scripts/check-complete.ps1)
- [恢复数据处理实现](https://github.com/OthmanAdi/planning-with-files/blob/57fe376da9e388f1e6ea21db798c6b4a8d276c41/scripts/session-catchup.py#L183)
- [LICENSE](https://github.com/OthmanAdi/planning-with-files/blob/57fe376da9e388f1e6ea21db798c6b4a8d276c41/LICENSE)

## 8. Matt Pocock Skills：小步骤组合与引用式交接

`to-spec` 从已讨论上下文提炼问题、方案、用户故事、实现决策、测试决策与范围；`implement` 围绕事先约定的测试边界实施，再做评审；`handoff` 要求引用已有 spec/plan/ADR/issue/commit 而非重复整份内容，并列建议技能与敏感信息脱敏。

采用通用母版的“小步骤组合”、面向外部行为的验收和引用式交接。上游 spec 会要求发布 issue、implement 会要求提交代码；这些不能变成本包的外发授权。默认完成本地可审阅结果，发布、发消息或提交仍按本任务与宿主的授权边界。临时目录偏好、固定标签和安装命令也不写入通用规则。

- [Specification Skill](https://github.com/mattpocock/skills/blob/c55ee46073ed923f86ce59a5eb3b6d895095d1b7/skills/engineering/to-spec/SKILL.md)
- [Implementation Skill](https://github.com/mattpocock/skills/blob/c55ee46073ed923f86ce59a5eb3b6d895095d1b7/skills/engineering/implement/SKILL.md)
- [Handoff Skill](https://github.com/mattpocock/skills/blob/c55ee46073ed923f86ce59a5eb3b6d895095d1b7/skills/productivity/handoff/SKILL.md)
- [LICENSE](https://github.com/mattpocock/skills/blob/c55ee46073ed923f86ce59a5eb3b6d895095d1b7/LICENSE)

## 建议合并进本包的自有协议

1. **冻结任务合同**：目标、输入、范围、交付物、证据标准、已授权动作、未知项。
2. **能力探测**：native-subagent / inline-sop 两种模式都可执行流程；报告真实模式，禁止把角色扮演称为独立进程。
3. **物化与核验**：只加载相关角色、SOP 和参考资源；检查缺失/版本/控制字段，失败不伪装成功。
4. **有界派发**：明确子任务、只读或写入所有权、工具边界、预算、返回 schema；并行仅用于独立任务。
5. **执行记录**：run ID、输入/输出路径、状态、观察证据、失败原因、恢复位置；授权和审批仍由当前宿主落实。
6. **两层验收**：先任务/规范符合性，再质量与领域检查；区分 claimed / inspected / executed，失败修复后只重跑受影响检查。
7. **综合与交付**：逐一核对子任务，解决冲突和许可，生成清单与哈希；按真实证据说明验证覆盖面。

建议协议最小字段：`run_id, skill_version, execution_mode, objective, allowed_scope, inputs, expected_outputs, acceptance_criteria, evidence, status, failures, next_action`。这些由本项目独立设计，不绑定上游类型名或模型名。

本次产物是可追溯设计研究，不是八库全源码合并；任何采用后的适配器还须各自在相应宿主运行测试。
