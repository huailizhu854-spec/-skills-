# Final v3.0.0 local verification

All new runtime evidence here is from local deterministic fixtures, simulated native tool observations or mocked HTTP responses. Real model calls: 0. Actual native subagent runs: NOT_EXECUTED. Do not combine these results with the inherited provenance/v3 model-run to claim the final code was run on a real model.

baseline-tests.txt: uploaded candidate before modifications, 275 tests.
unit-tests-final.txt: integrated source, 354 tests.
adversarial-final.txt: original 11 attack classes, 45 tests (unittest method count).
new-regressions-final.txt: 79 new final-integration tests, including native simulated contracts, uncertain semaphores, failures and privacy.
specialists-final.json: 8 role ZIPs compiled and independently verified; no agent started.
fixture-summary.json: schema 2 offline subprocess flow, 2/1/1 batches.
command-stub-summary.json: schema 3 local Python stub through command provider, 4 calls, no real model.
sanitized-stub/: actual default exporter output (hashes and minimum metadata only).

Source checks record relative Python-file hashes. Packaging/ZIP self-hash, reproducible build and unpacked recheck are in the external release verification JSON to avoid a self-referential ZIP hash. Earlier incomplete tool-window runs and one harness target-lookup error are not counted as passing tests. Final complete test logs above determine the result.
