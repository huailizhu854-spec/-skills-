# v3 证据：真模型命令桥（阶段一）

本轮只做一件事：把 v2 里 `real_model_agents: NOT_EXECUTED` 这个空洞填上。
入口是 `validation-summary.json`，五道验收门逐条对应一个证据文件。

## 本轮新增了什么

| 文件 | 作用 |
|---|---|
| `scripts/model_worker.py` | argv 包装器。读 packet → 用 `contract` 组装提示词 → 调一个模型 → 把返回文本写进 `contract.outputs` 指定的路径 → 自己对产物做确定性校验 → 写 `result.json` |
| `scripts/host_bridge_model_demo.py` | 总控。用同一份 `examples/team-demo/plan.json` 跑四任务，逐单做独立复核，写 `demo-report.json` |
| `scripts/host_bridge_export_evidence.py` | 把跑完的 job 目录导出成本文件夹，并附 `MANIFEST.json` |
| `tests/test_model_worker.py` | 用脚本化假模型测包装器（畸形输出、截断、拒答、超时、越界、预算、密钥）。不消耗 token |
| `tests/test_adversarial_regression.py` | 11 类对抗用例常驻回归（A1–A11） |
| `examples/team-demo/adapters.model.json` | 真模型 adapters 配置模板 |

`kernel.py`、`package_release.py`、`team_runtime.py`、`team_runner.py`、
`run_demo.py`、`fixture_worker.py`、`provenance/`（v2 及以前）一个字节都没动。
`frozen-file-verification.json` 是逐文件哈希比对的结果：70 个冻结文件零漂移，
除 `SHA256SUMS.json`（G5 要求重建）外没有任何已有文件被修改。

## 这次真跑了什么

`model-run/` 是一次完整实跑的原始材料，不是摘要：

- `event-log.json` / `task-table.json`：账本事件与任务终态
- `published/`：四份已验收产物（模型写的，不是桩）
- `reviews/`：总控逐单复核证据，分 `checked`（拦板）/ `observed_not_gating`（只记录）/ `not_checked`（没验）
- `workers/*/`：每次尝试的 packet、evidence、`model-transcript.json`（完整提示词与原始回复）、宿主回执、`result.json`
- `demo-report.json`：`real_model_agents` 从 `NOT_EXECUTED` 变成实测记录

实测数字见 `demo-report.json`：provider、模型标识、调用次数、按任务分布、
不可解析回复数、模型耗时、模型 CLI 自报费用。其中 `audit` 第一次回复没有按
信封格式返回（直接返回了审计 JSON），包装器判为 `MODEL_SCHEMA`、重问一次后通过——
这一次失败和重试都留在 `model-transcript.json` 里，没有抹掉。

## 复核时请注意这几条

1. **检查项是包装器自己跑出来的，不是模型自述。** `worker-checks.json` 里的
   `findings` 全部由 `model_worker.py` 对磁盘上的字节执行：UTF-8、结构语法、
   输出集合恰好等于声明集合、输入快照未被改动、产物里没有租约令牌/工作区路径/密钥。
   模型说"我检查过了"只会进 `model_notes_untrusted`，不影响 `outcome`。
2. **总控复核按需求写，不按桩的形状写。** 例如 R3 只要求"引用前两份产物组装静态
   HTML"，所以用 `<li>` 列提纲和用 `<p>` 一样通过；拦板的是标题、提纲每一行是否
   出现在可见文本里、是否带上了已验收 facts 产物里的值。
3. **字符数只记录不拦板。** plan 没有规定字符数的口径（含不含换行、按码点还是字节），
   所以 `character_count_matches_a_coordinator_reading` 标了 `blocking: false`：
   本次模型报 46，总控自己算出的两种口径是 44 和 47，差异照实记在 review 里。
4. **模式是 `command`，不是 `native`。** 本会话没有发现宿主的真实委派工具，
   按 `references/host-bridge.md` 的规定，`native_subagents` 保持 `NOT_EXECUTED`，
   没有用多段自述或多个函数冒充多个 Agent。

## 没验的事

一次成功不是稳定性证明，也不是模型能力评测。`validation-summary.json` 的
`not_verified` 列了全部未验项：原生子 Agent、模型能力、产物可复现性、
费用与限流的长期表现、页面的浏览器渲染、本环境以外的平台。

运行环境为 Linux + CPython 3.11；SHA-256 清单只用于内容一致性，不是签名或安全认证。
