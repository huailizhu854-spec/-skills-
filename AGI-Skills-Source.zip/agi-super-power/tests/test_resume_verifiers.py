"""Counter-tests for the resume-clinic verifiers.

Every verifier gets at least one honest case that must PASS and one forged case that must
FAIL. These verifiers only prove "nothing fabricated, nothing omitted" — no test here claims
the advice is any good, and none of them calls a model.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from verifier_registry import REGISTRY, evaluate  # noqa: E402

CLINIC = ROOT / 'examples/resume-clinic'
RESUME = (CLINIC / 'resume.txt').read_text(encoding='utf-8')
JD = (CLINIC / 'jd.txt').read_text(encoding='utf-8')

HONEST_PARSE = {
    'name': '林向晚',
    'target_role': '后端开发工程师',
    'education': [{'period': '2016.09-2020.06', 'school': '南岭大学', 'major': '计算机科学与技术', 'degree': '本科'}],
    'experience': [{'period': '2020.07-2023.03', 'company': '云梯科技', 'title': '后端开发工程师'},
                   {'period': '2023.04-2025.08', 'company': '澜图数据', 'title': '高级后端开发工程师'}],
    'skills': ['Python', 'Go', 'MySQL', 'Redis', 'Docker', 'Kubernetes'],
}
HONEST_DIAG = {'problems': [
    {'id': 'D-1', 'line': 10, 'quote': '负责公司核心交易系统的开发和维护工作', 'issue': '只写职责，没有结果。'},
    {'id': 'D-2', 'line': 11, 'quote': '积累了丰富的经验', 'issue': '空泛自评。'},
    {'id': 'D-3', 'line': 16, 'quote': '效果显著', 'issue': '没有量化指标。'},
]}
HONEST_MATCH = {'requirements': [
    {'id': 'JD-1', 'conclusion': '命中', 'basis': '技能列出 Python、Go。'},
    {'id': 'JD-2', 'conclusion': '部分', 'basis': '只写了熟悉分布式系统。'},
    {'id': 'JD-3', 'conclusion': '缺口', 'basis': '原文只写了解 Kubernetes。'},
    {'id': 'JD-4', 'conclusion': '缺口', 'basis': '效果显著没有口径。'},
    {'id': 'JD-5', 'conclusion': '部分', 'basis': '有带领小组，无跨团队。'},
]}
HONEST_REWRITE = {'suggestions': [
    {'diagnosis_id': 'D-1', 'suggestion': '补上模块与规模。'},
    {'diagnosis_id': 'D-2', 'suggestion': '换成一个具体项目。'},
    {'diagnosis_id': 'D-3', 'suggestion': '补上优化前后的数字。'},
]}
HONEST_REPORT = ('# 简历体检报告\n\n## 诊断\n- **D-1**：补上模块与规模。\n- **D-2**：换成一个具体项目。\n'
                 '- **D-3**：补上优化前后的数字。\n\n## JD 对标\n'
                 '- **JD-1**：命中\n- **JD-2**：部分\n- **JD-3**：缺口\n- **JD-4**：缺口\n- **JD-5**：部分\n')


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dumps(value) -> str:
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2) + '\n'


class ResumeVerifierCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.workspace = Path(self.tmp.name)
        (self.workspace / 'outputs').mkdir()

    def run_verifier(self, *, task, method, reads, out_id, out_name, body):
        snapshots = []
        for aid, filename, content in reads:
            path = self.workspace / 'inputs' / aid / filename
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(dumps(content), encoding='utf-8', newline='\n')
            snapshots.append({'id': aid, 'path': str(path), 'sha256': sha(path)})
        target = self.workspace / 'outputs' / out_name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(dumps(body), encoding='utf-8', newline='\n')
        packet = {'workspace': str(self.workspace), 'output_root': str(self.workspace / 'outputs'),
                  'task_id': task, 'lease_token': 'a' * 32, 'goal_digest': 'b' * 64, 'plan_digest': 'c' * 64,
                  'input_snapshots': snapshots,
                  'contract': {'id': task, 'reads': [a for a, _, _ in reads],
                               'outputs': [{'id': out_id, 'path': out_name}],
                               'acceptance': [{'id': f'{task}-check', 'requirement': 'R', 'method': method,
                                               'evidence_kind': 'RUNTIME_FACT',
                                               'subject': {'scope': 'artifact', 'artifact_id': out_id},
                                               'params': {}}]}}
        result = {'artifacts': [{'id': out_id, 'path': out_name, 'sha256': sha(target)}]}
        return evaluate(packet, result)

    def failures(self, report):
        return [f['check'] for c in report['checks'] for f in c['findings'] if not f['ok']]

    # ---- helpers that pin each task's wiring in one place ----
    def parse(self, body):
        return self.run_verifier(task='parse', method='resume-parse-v1',
                                 reads=[('resume', 'resume.txt', RESUME)],
                                 out_id='parse-json', out_name='parse/resume.json', body=body)

    def diag(self, body):
        return self.run_verifier(task='diag', method='resume-diag-v1',
                                 reads=[('resume', 'resume.txt', RESUME)],
                                 out_id='diag-json', out_name='diagnosis/problems.json', body=body)

    def match(self, body):
        return self.run_verifier(task='match', method='resume-match-v1',
                                 reads=[('jd', 'jd.txt', JD)],
                                 out_id='match-json', out_name='match/jd-match.json', body=body)

    def rewrite(self, body, diag=None):
        return self.run_verifier(task='rewrite', method='resume-rewrite-v1',
                                 reads=[('diag-json', 'problems.json', diag or HONEST_DIAG)],
                                 out_id='rewrite-json', out_name='rewrite/suggestions.json', body=body)

    def report(self, body, rewrite=None, match=None):
        return self.run_verifier(task='report', method='resume-report-v1',
                                 reads=[('rewrite-json', 'suggestions.json', rewrite or HONEST_REWRITE),
                                        ('match-json', 'jd-match.json', match or HONEST_MATCH)],
                                 out_id='report-md', out_name='report/resume-report.md', body=body)

    def qa(self, body, report=None, diag=None):
        return self.run_verifier(task='qa', method='resume-qa-v1',
                                 reads=[('report-md', 'resume-report.md', report or HONEST_REPORT),
                                        ('diag-json', 'problems.json', diag or HONEST_DIAG)],
                                 out_id='qa-json', out_name='qa/coverage.json', body=body)


class RegistryWiring(ResumeVerifierCase):
    def test_six_new_methods_are_registered_and_callable(self):
        for method in ('resume-parse-v1', 'resume-diag-v1', 'resume-match-v1',
                       'resume-rewrite-v1', 'resume-report-v1', 'resume-qa-v1'):
            with self.subTest(method=method):
                self.assertTrue(callable(REGISTRY[method]))

    def test_existing_eight_methods_are_untouched(self):
        for method in ('demo-facts-v3', 'demo-outline-v3', 'demo-page-v3', 'demo-audit-v3',
                       'json-values-v1', 'text-contains-v1', 'file-sha256-v1', 'equal-bytes-v1'):
            with self.subTest(method=method):
                self.assertTrue(callable(REGISTRY[method]))


class ParseGrounding(ResumeVerifierCase):
    def test_honest_parse_passes(self):
        self.assertTrue(self.parse(HONEST_PARSE)['passed'])

    def test_invented_employer_fails(self):
        forged = json.loads(json.dumps(HONEST_PARSE))
        forged['experience'].append({'period': '2019.01-2020.06', 'company': '字节跳动', 'title': '后端实习生'})
        report = self.parse(forged)
        self.assertFalse(report['passed'])
        self.assertIn('every_value_quoted_from_resume', self.failures(report))

    def test_plausible_but_absent_title_fails(self):
        forged = json.loads(json.dumps(HONEST_PARSE))
        forged['experience'][0]['title'] = '技术负责人'   # never written in the resume
        self.assertFalse(self.parse(forged)['passed'])

    def test_non_text_leaf_is_refused_rather_than_silently_skipped(self):
        forged = json.loads(json.dumps(HONEST_PARSE))
        forged['years_of_experience'] = 5
        report = self.parse(forged)
        self.assertFalse(report['passed'])
        self.assertIn('all_leaves_are_text', self.failures(report))

    def test_empty_parse_cannot_pass_vacuously(self):
        self.assertFalse(self.parse({})['passed'])


class DiagnosisAnchoring(ResumeVerifierCase):
    def test_honest_diagnosis_passes(self):
        self.assertTrue(self.diag(HONEST_DIAG)['passed'])

    def test_line_beyond_end_of_resume_fails(self):
        forged = json.loads(json.dumps(HONEST_DIAG))
        forged['problems'][0]['line'] = len(RESUME.splitlines()) + 1
        report = self.diag(forged)
        self.assertFalse(report['passed'])
        self.assertIn('line_numbers_within_resume', self.failures(report))

    def test_quote_on_the_wrong_line_fails(self):
        forged = json.loads(json.dumps(HONEST_DIAG))
        forged['problems'][2]['line'] = 15          # '效果显著' really lives on line 16
        report = self.diag(forged)
        self.assertFalse(report['passed'])
        self.assertIn('quotes_are_substrings_of_their_line', self.failures(report))

    def test_quote_absent_from_the_resume_entirely_fails(self):
        forged = json.loads(json.dumps(HONEST_DIAG))
        forged['problems'][1]['quote'] = '主导了三次架构升级'
        self.assertFalse(self.diag(forged)['passed'])

    def test_duplicate_ids_fail(self):
        forged = json.loads(json.dumps(HONEST_DIAG))
        forged['problems'][1]['id'] = 'D-1'
        report = self.diag(forged)
        self.assertFalse(report['passed'])
        self.assertIn('unique_problem_ids', self.failures(report))


class JdCoverage(ResumeVerifierCase):
    def test_honest_match_passes(self):
        self.assertTrue(self.match(HONEST_MATCH)['passed'])

    def test_dropped_requirement_fails(self):
        forged = {'requirements': [r for r in HONEST_MATCH['requirements'] if r['id'] != 'JD-5']}
        report = self.match(forged)
        self.assertFalse(report['passed'])
        self.assertIn('every_jd_requirement_has_a_conclusion', self.failures(report))

    def test_off_vocabulary_conclusion_fails(self):
        forged = json.loads(json.dumps(HONEST_MATCH))
        forged['requirements'][0]['conclusion'] = '基本符合'
        report = self.match(forged)
        self.assertFalse(report['passed'])
        self.assertIn('conclusions_use_the_fixed_vocabulary', self.failures(report))

    def test_invented_requirement_fails(self):
        forged = json.loads(json.dumps(HONEST_MATCH))
        forged['requirements'].append({'id': 'JD-6', 'conclusion': '命中', 'basis': '无中生有'})
        report = self.match(forged)
        self.assertFalse(report['passed'])
        self.assertIn('no_invented_requirements', self.failures(report))


class RewriteTraceability(ResumeVerifierCase):
    def test_honest_rewrite_passes(self):
        self.assertTrue(self.rewrite(HONEST_REWRITE)['passed'])

    def test_suggestion_without_a_diagnosis_fails(self):
        forged = json.loads(json.dumps(HONEST_REWRITE))
        forged['suggestions'].append({'diagnosis_id': 'D-99', 'suggestion': '补一段领导力描述。'})
        report = self.rewrite(forged)
        self.assertFalse(report['passed'])
        self.assertIn('no_suggestion_without_a_diagnosis', self.failures(report))

    def test_dropped_diagnosis_fails(self):
        forged = {'suggestions': [s for s in HONEST_REWRITE['suggestions'] if s['diagnosis_id'] != 'D-2']}
        report = self.rewrite(forged)
        self.assertFalse(report['passed'])
        self.assertIn('no_diagnosis_left_unaddressed', self.failures(report))

    def test_two_suggestions_for_one_diagnosis_is_not_one_to_one(self):
        forged = json.loads(json.dumps(HONEST_REWRITE))
        forged['suggestions'].append({'diagnosis_id': 'D-1', 'suggestion': '再补一句。'})
        report = self.rewrite(forged)
        self.assertFalse(report['passed'])
        self.assertIn('one_suggestion_per_diagnosis', self.failures(report))


class ReportCompleteness(ResumeVerifierCase):
    def test_honest_report_passes(self):
        self.assertTrue(self.report(HONEST_REPORT)['passed'])

    def test_report_missing_a_diagnosis_fails(self):
        forged = '\n'.join(l for l in HONEST_REPORT.splitlines() if 'D-3' not in l) + '\n'
        report = self.report(forged)
        self.assertFalse(report['passed'])
        self.assertIn('report_carries_every_diagnosis_id', self.failures(report))

    def test_report_missing_a_jd_requirement_fails(self):
        forged = '\n'.join(l for l in HONEST_REPORT.splitlines() if 'JD-4' not in l) + '\n'
        report = self.report(forged)
        self.assertFalse(report['passed'])
        self.assertIn('report_carries_every_jd_requirement_id', self.failures(report))

    def test_jd_id_does_not_satisfy_a_bare_diagnosis_id(self):
        """Regression: 'D-3' is a substring of 'JD-3'. A dropped D-3 must not look present."""
        forged = '\n'.join(l for l in HONEST_REPORT.splitlines() if not l.startswith('- **D-3**')) + '\n'
        self.assertIn('JD-3', forged)
        report = self.report(forged)
        self.assertFalse(report['passed'])
        self.assertIn('report_carries_every_diagnosis_id', self.failures(report))


class QaHonesty(ResumeVerifierCase):
    def test_honest_qa_passes(self):
        self.assertTrue(self.qa({'coverage_complete': True, 'missing_diagnosis_ids': []})['passed'])

    def test_claiming_complete_while_a_diagnosis_is_missing_fails(self):
        partial = '\n'.join(l for l in HONEST_REPORT.splitlines() if not l.startswith('- **D-2**')) + '\n'
        report = self.qa({'coverage_complete': True, 'missing_diagnosis_ids': []}, report=partial)
        self.assertFalse(report['passed'])
        self.assertIn('completeness_claim_matches_reality', self.failures(report))

    def test_under_reporting_the_gap_fails(self):
        partial = '\n'.join(l for l in HONEST_REPORT.splitlines()
                            if not l.startswith('- **D-2**') and not l.startswith('- **D-3**')) + '\n'
        report = self.qa({'coverage_complete': False, 'missing_diagnosis_ids': ['D-2']}, report=partial)
        self.assertFalse(report['passed'])
        self.assertIn('declared_gaps_match_reality', self.failures(report))

    def test_accurately_declared_gap_passes(self):
        partial = '\n'.join(l for l in HONEST_REPORT.splitlines() if not l.startswith('- **D-2**')) + '\n'
        self.assertTrue(self.qa({'coverage_complete': False, 'missing_diagnosis_ids': ['D-2']},
                                report=partial)['passed'])

    def test_inventing_a_gap_that_is_not_there_fails(self):
        self.assertFalse(self.qa({'coverage_complete': False, 'missing_diagnosis_ids': ['D-1']})['passed'])

    def test_non_boolean_claim_is_a_failure_not_a_crash(self):
        report = self.qa({'coverage_complete': 'yes', 'missing_diagnosis_ids': []})
        self.assertFalse(report['passed'])
        self.assertEqual(report['checks'][0]['execution'], 'EXECUTED')


class ScopeDiscipline(ResumeVerifierCase):
    def test_verifier_cannot_read_an_undeclared_artifact(self):
        """The report verifier must not reach for diag-json when its task never declared it."""
        report = self.run_verifier(
            task='report', method='resume-report-v1',
            reads=[('rewrite-json', 'suggestions.json', HONEST_REWRITE)],   # match-json withheld
            out_id='report-md', out_name='report/resume-report.md', body=HONEST_REPORT)
        self.assertFalse(report['passed'])
        self.assertEqual(report['checks'][0]['outcome'], 'FAILED')

    def test_producer_cannot_pass_by_declaring_a_non_runtime_evidence_kind(self):
        packet_report = self.run_verifier(task='parse', method='resume-parse-v1',
                                          reads=[('resume', 'resume.txt', RESUME)],
                                          out_id='parse-json', out_name='parse/resume.json', body=HONEST_PARSE)
        self.assertTrue(packet_report['passed'])
        self.assertEqual(packet_report['checks'][0]['evidence_kind'], 'RUNTIME_FACT')


if __name__ == '__main__':
    unittest.main()
