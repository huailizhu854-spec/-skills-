"""Synthetic local fixtures only; none of these tests exercise WorkBuddy."""
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from fs_test_support import make_symlink_or_skip

ROOT = Path(__file__).resolve().parents[1]
KIT = ROOT / "examples/workbuddy-desktop"
SCRIPT = ROOT / "scripts/workbuddy_desktop_probe.py"
spec = importlib.util.spec_from_file_location("evidence_tool", SCRIPT)
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "evidence"
        self.root.mkdir()
        for name in tool.PINNED:
            (self.root / name).write_bytes((KIT / name).read_bytes())
        self.report = json.loads((KIT / "report.template.json").read_text())

    def file(self, name, data):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(data, encoding="utf-8")

    def seal(self):
        self.file("report.json", json.dumps(self.report))
        (self.root / "manifest.json").unlink(missing_ok=True)
        tool.manifest(self.root)

    def success(self):
        for name in ("env.txt", "inventory.txt", "auth.txt", "raw.txt"):
            self.file(name, "SYNTHETIC LOCAL FIXTURE; not a WorkBuddy observation")
        self.file("prompt.txt", (KIT / "child-prompt.txt").read_text())
        self.file("args.json", json.dumps({"input": {"prompt": (KIT / "child-prompt.txt").read_text()}}))
        self.file("result.json", json.dumps({"items": [{"item": k, "line_total": v}
                                                    for k, v in {"A": 36, "B": 14, "C": 20}.items()], "total": 70}))
        attempt = json.loads((KIT / "attempt.template.json").read_text())
        attempt.update(tool_name="fixture_native_tool", prompt_ref="prompt.txt", create_request_ref="args.json",
                       prompt_json_pointer="/input/prompt", create_return_ref="raw.txt", terminal_return_ref="raw.txt",
                       response_mode="SYNC_TERMINAL", result_ref="result.json", result_source="RETURN_TRANSCRIPTION",
                       result_source_ref="raw.txt")
        self.report.update(entry="DESKTOP_NATIVE", execution_location="fixture desktop",
                           environment_ref="env.txt", inventory_ref="inventory.txt", status="OBSERVED_TERMINAL",
                           declared_create_calls=1, attempts=[attempt])
        self.report["authorization"].update(source_kind="COORDINATOR_TRANSCRIPTION", record_ref="auth.txt")
        return attempt

    def invalid(self, pattern):
        self.seal()
        with self.assertRaisesRegex(ValueError, pattern):
            tool.inspect(self.root)

    def test_success_is_never_host_or_skill_pass(self):
        self.success()
        self.seal()
        before = tool.scan(self.root)
        result = tool.inspect(self.root)
        self.assertTrue(result["ready_for_host_review"])
        self.assertEqual(result["host_verdict"], "REQUIRES_HOST_TRACE_REVIEW")
        self.assertEqual(result["authorization_verdict"], "REQUIRES_SOURCE_REVIEW")
        self.assertEqual(result["skill_integration_verdict"], "NOT_TESTED")
        self.assertEqual(result["desktop_adapter_status"], "HANDOFF_ONLY")
        self.assertEqual(before, tool.scan(self.root))

    def test_original_trace_still_needs_review(self):
        self.success()
        self.report["trace"] = {"kind": "ORIGINAL_HOST_EXPORT", "ref": "raw.txt"}
        self.seal()
        self.assertEqual(tool.inspect(self.root)["host_verdict"], "REQUIRES_HOST_TRACE_REVIEW")

    def test_stop_exit_two(self):
        self.seal()
        run = subprocess.run([sys.executable, str(SCRIPT), "check", str(self.root)], capture_output=True)
        self.assertEqual(run.returncode, 2)
        self.assertEqual(json.loads(run.stdout)["verdict"], "VALID_STOP_REPORT")

    def test_unknown_attempt_without_return_remains_stopped(self):
        attempt = self.success()
        self.report.update(status="OUTCOME_UNKNOWN", reason="fixture timeout")
        attempt.update(create_return_ref=None, terminal_return_ref=None, response_mode="UNKNOWN",
                       result_ref=None, result_source="NOT_AVAILABLE", result_source_ref=None)
        self.seal()
        self.assertFalse(tool.inspect(self.root)["ready_for_host_review"])

    def test_manifest_never_overwritten(self):
        self.seal()
        original = (self.root / "manifest.json").read_bytes()
        with self.assertRaises(FileExistsError):
            tool.manifest(self.root)
        self.assertEqual(original, (self.root / "manifest.json").read_bytes())

    def test_rehashed_frozen_contract_still_rejected(self):
        self.file("probe-contract.json", "{}")
        self.invalid("frozen input changed")

    def test_tampered_and_extra_files_rejected(self):
        self.seal()
        self.file("extra.txt", "unlisted")
        with self.assertRaisesRegex(ValueError, "coverage"):
            tool.inspect(self.root)

    def test_second_create_rejected(self):
        attempt = self.success()
        self.report["attempts"].append(copy.deepcopy(attempt))
        self.report["declared_create_calls"] = 2
        self.invalid("budget")

    def test_boolean_count_rejected(self):
        self.success()
        self.report["declared_create_calls"] = True
        self.invalid("count mismatch")

    def test_wrong_entry_rejected(self):
        self.success()
        self.report["entry"] = "MOBILE_TO_DESKTOP"
        self.invalid("desktop entry")

    def test_continue_after_setup_error_rejected(self):
        self.success()
        self.report["continued_after_failure"] = True
        self.invalid("out-of-scope")

    def test_hidden_failure_cannot_report_terminal(self):
        self.success()
        self.report["failures"] = [{"stage": "setup", "detail": "JOB_EXISTS", "evidence_ref": "raw.txt"}]
        self.invalid("no failures")

    def test_prompt_argument_mismatch_rejected(self):
        self.success()
        self.file("args.json", json.dumps({"input": {"prompt": "different task"}}))
        self.invalid("differ from child prompt")

    def test_missing_source_in_prompt_rejected(self):
        self.success()
        self.file("prompt.txt", "different task")
        self.invalid("frozen source")

    def test_wrong_arithmetic_rejected_for_terminal(self):
        self.success()
        result = json.loads((self.root / "result.json").read_text())
        result["total"] = 71
        self.file("result.json", json.dumps(result))
        self.invalid("incorrect arithmetic")

    def test_duplicate_json_keys_rejected(self):
        self.success()
        self.file("result.json", '{"total":70,"total":71}')
        self.invalid("duplicate JSON key")

    def test_missing_source_for_identifier_rejected(self):
        attempt = self.success()
        attempt["host_ids"]["task_id"] = "fixture-id"
        self.invalid("required evidence reference")

    def test_id_namespaces_not_assumed(self):
        attempt = self.success()
        attempt["host_ids"] = {"tool_call_id": "same-format-1", "agent_id": "same-format-1", "task_id": None}
        attempt["identifier_basis_ref"] = "raw.txt"
        self.seal()
        self.assertTrue(tool.inspect(self.root)["ready_for_host_review"])

    def test_async_followup_budget(self):
        attempt = self.success()
        attempt["response_mode"] = "ASYNC_TERMINAL"
        attempt["followup_reads"] = [{"tool_name": "fixture_wait", "requested_wait_seconds": 61,
                                       "request_ref": "args.json", "return_ref": "raw.txt"}]
        self.invalid("wait budget")

    def test_path_traversal_rejected(self):
        self.success()
        self.report["environment_ref"] = "../outside.txt"
        self.invalid("unsafe evidence path")

    def test_symlink_rejected(self):
        make_symlink_or_skip(self, self.root / "link.txt", KIT / "source.csv")
        with self.assertRaisesRegex(ValueError, "symlinks"):
            tool.manifest(self.root)

    def test_main_bridge_initializes_once_without_dispatch(self):
        run_dir = Path(self.temp.name) / 'new-run'
        cmd = [sys.executable, '-B', str(ROOT / 'scripts/workbuddy_bridge.py'),
               'desktop-probe', 'init', str(run_dir)]
        first = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(first.returncode, 0, first.stderr)
        response = json.loads(first.stdout)
        self.assertEqual(response['real_agent_calls'], 0)
        self.assertEqual(response['desktop_adapter_status'], 'HANDOFF_ONLY')
        self.assertEqual((run_dir / 'evidence/source.csv').read_bytes(), (KIT / 'source.csv').read_bytes())
        self.assertFalse(list(run_dir.rglob('team.sqlite3')))
        before = tool.scan(run_dir / 'evidence')
        again = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(again.returncode, 1)
        self.assertEqual(tool.scan(run_dir / 'evidence'), before)

    def test_initializer_rejects_skill_and_existing_job(self):
        with self.assertRaisesRegex(ValueError, 'outside the skill'):
            tool.initialize(ROOT / 'forbidden-probe-run')
        old_job = Path(self.temp.name) / 'old-job'
        old_job.mkdir(); (old_job / 'team.sqlite3').write_bytes(b'fixture sentinel')
        with self.assertRaisesRegex(ValueError, 'outside existing task jobs'):
            tool.initialize(old_job / 'nested-probe')
        self.assertFalse((old_job / 'nested-probe').exists())

    def test_main_bridge_propagates_stop_exit_code(self):
        self.seal()
        cmd = [sys.executable, '-B', str(ROOT / 'scripts/workbuddy_bridge.py'),
               'desktop-probe', 'check', str(self.root)]
        run = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(run.returncode, 2)
        self.assertFalse(json.loads(run.stdout)['ready_for_host_review'])


if __name__ == "__main__":
    unittest.main(verbosity=2)
