"""A simulated client worklog left in the package directory must stop the build.

Real client resumes must never reach a release ZIP or provenance/. package_release.py
already fails closed on the known forensic directory names and on unreviewed provenance;
these tests pin that behaviour so a future refactor cannot quietly loosen it.

This is a fail-closed check on KNOWN paths, NOT a general PII scanner: a client name pasted
into a source comment would still get through, and that still needs human review.
"""
from __future__ import annotations

import importlib.util
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("agi_package_release", ROOT / "scripts" / "package_release.py")
assert SPEC and SPEC.loader
package = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(package)

CLIENT_RESUME = "王某某\n电话：13800000000\n现就职于某某银行，负责核心系统。\n"


class ClientWorklogIsNotPackageable(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.root = self.base / "agi-super-power"
        self.root.mkdir()
        (self.root / "SKILL.md").write_text(
            "---\nname: agi-super-power\ndescription: Test fixture\n---\n# Test\n", encoding="utf-8")
        (self.root / "references").mkdir()
        (self.root / "references" / "guide.md").write_text("A bounded SOP.\n", encoding="utf-8")
        self.output = self.base / "test.zip"

    def build(self):
        return package.build_archive(self.root, self.output)

    def plant(self, relative: str, text: str = CLIENT_RESUME):
        target = self.root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
        return target

    def test_clean_package_still_builds(self):
        """Control: without a planted worklog the same fixture packages fine."""
        self.assertTrue(self.build()["sha256"])

    def test_client_job_directory_is_refused(self):
        self.plant("jobs/acme-2026-03/sources/resume/resume.txt")
        with self.assertRaisesRegex(package.PackageError, "Private forensic data"):
            self.build()
        self.assertFalse(self.output.exists(), "no archive may be produced")

    def test_runs_directory_is_refused(self):
        self.plant("runs/client-42/published/report/resume-report.md")
        with self.assertRaisesRegex(package.PackageError, "Private forensic data"):
            self.build()

    def test_private_evidence_directory_is_refused(self):
        self.plant("examples/resume-clinic/private-evidence/client-resume.txt")
        with self.assertRaisesRegex(package.PackageError, "Private forensic data"):
            self.build()

    def test_dot_private_directory_is_refused(self):
        self.plant(".private/client-resume.txt")
        with self.assertRaisesRegex(package.PackageError, "Private forensic data"):
            self.build()

    def test_private_evidence_json_is_refused_anywhere(self):
        self.plant("examples/resume-clinic/private_evidence.json", '{"resume":"王某某"}\n')
        with self.assertRaisesRegex(package.PackageError, "Private forensic data"):
            self.build()

    def test_refusal_is_case_insensitive(self):
        """Casing must not be an escape hatch on a case-folding filesystem."""
        self.plant("Jobs/Acme-2026-03/resume.txt")
        with self.assertRaisesRegex(package.PackageError, "Private forensic data"):
            self.build()

    def test_raw_worker_packet_needs_an_explicit_reviewed_hash(self):
        """A leaked packet/result carries the client's text; it may ship only if pinned."""
        for name in ("packet.json", "result.json", "controller-result.json"):
            with self.subTest(name=name):
                target = self.plant(f"examples/resume-clinic/{name}", '{"resume":"王某某"}\n')
                with self.assertRaisesRegex(package.PackageError, "Unreviewed evidence"):
                    self.build()
                target.unlink()

    def test_unreviewed_provenance_file_is_refused(self):
        self.plant("provenance/client-run/report.md", CLIENT_RESUME)
        with self.assertRaisesRegex(package.PackageError, "Unreviewed evidence"):
            self.build()


if __name__ == "__main__":
    unittest.main()
