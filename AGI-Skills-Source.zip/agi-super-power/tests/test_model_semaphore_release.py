"""Actual SQLite contention regressions; no model or host is called."""
from __future__ import annotations
from contextlib import closing
from pathlib import Path
import sqlite3
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from model_semaphore import ConcurrencyGate, SemaphoreError


class ReleaseContentionTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix='release-tests-')
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)

    def gate(self, wait=1):
        gate = ConcurrencyGate(1, self.root, wait)
        gate.__enter__()
        return gate

    def state(self, gate, token):
        with closing(sqlite3.connect(str(gate.path))) as db:
            return db.execute('SELECT state FROM slots WHERE token=?', (token,)).fetchone()[0]

    def contended_release(self, body_error=False):
        gate = self.gate()
        token = gate.held
        lock = sqlite3.connect(str(gate.path), isolation_level=None)
        lock.execute('BEGIN IMMEDIATE')
        self.addCleanup(lock.close)
        attempted, finished = threading.Event(), threading.Event()
        errors = []
        original_connect = gate._connect

        def observed_connection():
            db = original_connect()
            db.set_trace_callback(lambda sql: attempted.set() if sql == 'BEGIN IMMEDIATE' else None)
            return db

        def release():
            try:
                gate.__exit__(RuntimeError if body_error else None,
                              RuntimeError('fixture unknown outcome') if body_error else None, None)
            except BaseException as exc:
                errors.append(exc)
            finally:
                finished.set()

        with patch.object(gate, '_connect', side_effect=observed_connection):
            worker = threading.Thread(target=release)
            worker.start()
            try:
                self.assertTrue(attempted.wait(2), 'Real SQLite write transaction was never attempted')
                time.sleep(.15)  # Exceeds the old single-attempt 100 ms timeout.
                self.assertFalse(finished.is_set(), 'Release abandoned a recoverable writer lock')
                self.assertEqual(gate.held, token)
            finally:
                lock.rollback()
                worker.join(2)
            self.assertFalse(worker.is_alive(), 'Release retry exceeded its configured bound')
        self.assertEqual(errors, [])
        self.assertIsNone(gate.held)
        self.assertEqual(self.state(gate, token), 'uncertain' if body_error else 'released')
        if body_error:
            with self.assertRaises(SemaphoreError) as caught:
                with ConcurrencyGate(1, self.root, 0):
                    self.fail('Uncertain outcome must still consume capacity')
            self.assertEqual(caught.exception.code, 'CONCURRENCY_WAIT')
        else:
            with ConcurrencyGate(1, self.root, 0):
                pass

    def test_release_waits_for_real_sqlite_lock_then_commits(self):
        self.contended_release()

    def test_uncertain_outcome_waits_then_still_consumes_capacity(self):
        self.contended_release(body_error=True)

    def test_expired_release_keeps_owner_and_durable_running_state(self):
        gate = self.gate(wait=.06)
        token = gate.held
        with closing(sqlite3.connect(str(gate.path), isolation_level=None)) as lock:
            lock.execute('BEGIN IMMEDIATE')
            started = time.monotonic()
            with self.assertRaises(SemaphoreError) as caught:
                gate.__exit__(None, None, None)
            self.assertEqual(caught.exception.code, 'CONCURRENCY_RELEASE_WAIT')
            self.assertLess(time.monotonic() - started, 1)
            self.assertEqual(gate.held, token)
            self.assertEqual(lock.execute('SELECT state FROM slots WHERE token=?', (token,)).fetchone()[0], 'running')
            lock.rollback()
        self.assertEqual(self.state(gate, token), 'running')
        gate.__exit__(None, None, None)
        self.assertIsNone(gate.held)
        self.assertEqual(self.state(gate, token), 'released')

    def test_zero_release_budget_retains_slot_on_busy_database(self):
        gate = self.gate(wait=0)
        token = gate.held
        with closing(sqlite3.connect(str(gate.path), isolation_level=None)) as lock:
            lock.execute('BEGIN IMMEDIATE')
            with patch('model_semaphore.time.sleep', side_effect=AssertionError('Zero budget must not retry')):
                with self.assertRaises(SemaphoreError) as caught:
                    gate.__exit__(None, None, None)
            self.assertEqual(caught.exception.code, 'CONCURRENCY_RELEASE_WAIT')
            self.assertEqual(gate.held, token)
            lock.rollback()
        self.assertEqual(self.state(gate, token), 'running')

    def test_unexpected_database_error_is_not_retried_or_hidden(self):
        gate = self.gate()
        token = gate.held
        with closing(sqlite3.connect(str(gate.path))) as db:
            db.execute('DROP TABLE slots')
            db.commit()
        with patch('model_semaphore.time.sleep', side_effect=AssertionError('Non-lock error must not retry')):
            with self.assertRaisesRegex(sqlite3.OperationalError, 'no such table'):
                gate.__exit__(None, None, None)
        self.assertEqual(gate.held, token)

    def test_missing_owned_running_row_cannot_claim_release(self):
        gate = self.gate()
        token = gate.held
        with closing(sqlite3.connect(str(gate.path))) as db:
            db.execute("UPDATE slots SET state='uncertain' WHERE token=?", (token,))
            db.commit()
        with self.assertRaises(SemaphoreError) as caught:
            gate.__exit__(None, None, None)
        self.assertEqual(caught.exception.code, 'CONCURRENCY_RELEASE_STATE')
        self.assertEqual(gate.held, token)
        self.assertEqual(self.state(gate, token), 'uncertain')


if __name__ == '__main__':
    unittest.main()
