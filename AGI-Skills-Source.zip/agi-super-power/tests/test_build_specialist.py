"""Meaningful compiler invariants; no host, network, or third-party packages."""

import copy
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "build_specialist.py"
SPEC = importlib.util.spec_from_file_location("build_specialist", SCRIPT)
builder = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(builder)


class SpecialistCompilerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        refs = self.root / "references"
        refs.mkdir()
        for filename in builder.CORE_REFERENCES:
            (refs / filename).write_text("# Core\n\n[Evidence](evidence.md)\n", encoding="utf-8")
        self.role = {
            "schema_version": 1, "name": "office-specialist", "title": "办公交付",
            "mission": "交付可核验的工作簿", "trigger": "用户要求制作表格时",
            "inputs": ["源数据"], "outputs": ["工作簿", "验证记录"],
            "steps": ["检查输入", "制作并回读", "验证结果"],
            "acceptance": [{"id": "A1", "requirement": "数据正确", "method": "独立核对总计",
                            "evidence_kind": "SOURCE_FACT"}],
            "tools": ["spreadsheet.create"], "boundaries": ["不外发"],
            "sources": ["https://example.org/source"],
        }
        self.role_path = self.root / "role.json"
        self.save_role()

    def save_role(self):
        self.role_path.write_text(json.dumps(self.role, ensure_ascii=False), encoding="utf-8")

    def test_valid_content_and_manifest(self):
        data = builder.build_archive(self.role, "office-agent", self.root)
        builder.verify_zip_bytes(data, "office-agent")
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            stored = json.loads(archive.read("office-agent/assets/role.json"))
            self.assertEqual(stored, self.role)
            manifest = json.loads(archive.read("office-agent/SHA256SUMS.json"))
            self.assertEqual(set(manifest), {"schema_version", "root", "files"})
            self.assertEqual(manifest["schema_version"], 1)
            self.assertEqual(manifest["root"], "office-agent")
            self.assertIsInstance(manifest["files"], list)
            for record in manifest["files"]:
                self.assertEqual(set(record), {"path", "sha256", "bytes"})
                self.assertFalse(record["path"].startswith("office-agent/"))
                self.assertNotEqual(record["path"], "SHA256SUMS.json")
            playbook = archive.read("office-agent/references/role-playbook.md").decode()
            for key in ("title", "mission", "trigger"):
                self.assertIn(self.role[key], playbook)
            for key in ("inputs", "outputs", "steps", "tools", "boundaries", "sources"):
                for value in self.role[key]:
                    self.assertIn(builder.markdown_literal(value), playbook)
            for value in self.role["acceptance"][0].values():
                self.assertIn(builder.markdown_literal(value), playbook)
            skill = archive.read("office-agent/SKILL.md").decode()
            self.assertIn("SKILL.md 不授予工具权限", skill)
            self.assertIn("不会自行创建", skill)
            self.assertNotIn("context: fork", skill)
            self.assertNotIn("allowed-tools:", skill)
            ui = archive.read("office-agent/agents/openai.yaml").decode()
            self.assertIn("$office-agent", ui)

    def test_generated_specialist_inherits_leaf_guardrails(self):
        entry = builder.render_skill(self.role, "office-agent")
        self.assertIn("goal_digest", entry)
        self.assertIn("不得递归创建子 Agent", entry)
        self.assertIn("不重做队友工作", entry)
        self.assertIn("child-protocol.md", builder.CORE_REFERENCES)

    def test_deterministic_bytes(self):
        first = builder.build_archive(self.role, "office-agent", self.root)
        second = builder.build_archive(copy.deepcopy(self.role), "office-agent", self.root)
        self.assertEqual(first, second)

    def test_compiled_zip_passes_release_cli_verification(self):
        # A real cross-script check, not another assertion against this compiler.
        # Repetitive text also guards against the verifier's ratio limit.
        self.role["steps"].append("重复检查" * 5000)
        self.save_role()
        output = self.root / "release-compatible.zip"
        builder.compile_role(self.role_path, "office-agent", output, self.root)
        result = subprocess.run(
            [sys.executable, "-B", str(SCRIPT.parent / "package_release.py"),
             "verify", str(output)],
            capture_output=True, text=True, encoding="utf-8", check=False,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        receipt = json.loads(result.stdout)
        self.assertTrue(receipt["valid"])
        self.assertEqual(receipt["root"], "office-agent")
        self.assertEqual(receipt["files"], len(builder.CORE_REFERENCES) + 4)
        self.assertFalse(receipt["contents_executed"])
        self.assertEqual(receipt["network_requests"], 0)

    def test_generated_entry_preserves_hard_runtime_requirement(self):
        entry = builder.render_skill(self.role, "office-agent")
        self.assertIn("是用户硬要求", entry)
        self.assertIn("只准备可移交任务并报告能力缺口", entry)
        self.assertIn("不得在主会话代做被要求独立执行的工作", entry)
        self.assertIn("没有上述硬要求时", entry)
        self.assertNotIn("否则在当前会话顺序执行", entry)

    def test_evidence_kind_matches_shared_evidence_contract(self):
        for kind in ("reconciliation", "PASS", "NOT_A_DEFINED_EVIDENCE_KIND"):
            altered = copy.deepcopy(self.role)
            altered["acceptance"][0]["evidence_kind"] = kind
            with self.subTest(kind=kind), self.assertRaises(builder.BuildError):
                builder.build_archive(altered, "office-agent", self.root)
        for kind in builder.EVIDENCE_KINDS:
            altered = copy.deepcopy(self.role)
            altered["acceptance"][0]["evidence_kind"] = kind
            builder.validate_role(altered)

    def test_malicious_names_rejected(self):
        for name in ("../x", "x/y", "x\\y", "C:tmp", "/tmp", "x..y", "x y",
                     "con", "lpt1", "UPPER", "a--b", "a-", "", "x" * 64):
            with self.subTest(name=name), self.assertRaises(builder.BuildError):
                builder.build_archive(self.role, name, self.root)

    def test_required_fields_and_types(self):
        for key in builder.ROLE_FIELDS:
            altered = copy.deepcopy(self.role)
            del altered[key]
            with self.subTest(missing=key), self.assertRaises(builder.BuildError):
                builder.validate_role(altered)
        for key, value in (("schema_version", True), ("inputs", "source"),
                           ("steps", [1]), ("mission", []), ("acceptance", []),
                           ("acceptance", ["wrong"]), ("boundaries", [])):
            altered = copy.deepcopy(self.role)
            altered[key] = value
            with self.subTest(field=key, value=value), self.assertRaises(builder.BuildError):
                builder.validate_role(altered)

    def test_acceptance_contract(self):
        for key in ("id", "requirement", "method", "evidence_kind"):
            altered = copy.deepcopy(self.role)
            del altered["acceptance"][0][key]
            with self.subTest(missing=key), self.assertRaises(builder.BuildError):
                builder.validate_role(altered)
        altered = copy.deepcopy(self.role)
        altered["acceptance"] *= 2
        with self.assertRaises(builder.BuildError):
            builder.validate_role(altered)

    def test_role_arrays_and_name_match_kernel_contract(self):
        for field in ("inputs", "outputs", "steps", "tools", "boundaries", "sources"):
            altered = copy.deepcopy(self.role)
            altered[field] = ["duplicate", "duplicate"]
            with self.subTest(field=field), self.assertRaises(builder.BuildError):
                builder.validate_role(altered)
        altered = copy.deepcopy(self.role)
        altered["inputs"] = []
        altered["name"] = "x" * 63
        builder.validate_role(altered)
        altered["name"] = "x" * 64
        with self.assertRaises(builder.BuildError):
            builder.validate_role(altered)

    def test_duplicate_json_keys_and_nonfinite_constants_are_rejected(self):
        payload = json.dumps(self.role)
        invalid_payloads = [payload[:-1] + ', "name": "different"}',
                            payload[:-1] + ', "extra": NaN}']
        for index, invalid in enumerate(invalid_payloads):
            self.role_path.write_text(invalid, encoding="utf-8")
            with self.subTest(payload=invalid), self.assertRaises(builder.BuildError):
                builder.compile_role(self.role_path, "office-agent", self.root / f"invalid-{index}.zip", self.root)
            self.assertFalse((self.root / f"invalid-{index}.zip").exists())

    def test_missing_reference_fails_before_zip_creation(self):
        (self.root / "references" / "core-sop.md").unlink()
        output = self.root / "missing.zip"
        with self.assertRaises(builder.BuildError):
            builder.compile_role(self.role_path, "office-agent", output, self.root)
        self.assertFalse(output.exists())

    def test_existing_zip_is_never_overwritten(self):
        output = self.root / "existing.zip"
        output.write_bytes(b"original")
        with self.assertRaises(builder.BuildError):
            builder.compile_role(self.role_path, "office-agent", output, self.root)
        self.assertEqual(output.read_bytes(), b"original")

    def test_compile_output_and_missing_json(self):
        output = self.root / "new.zip"
        result = builder.compile_role(self.role_path, "office-agent", output, self.root)
        self.assertTrue(output.is_file())
        self.assertFalse(result["agent_started"])
        self.assertEqual(result["mode"], "compiled_skill_only")
        with self.assertRaises(builder.BuildError):
            builder.compile_role(self.root / "absent.json", "office-agent", self.root / "bad.zip", self.root)
        self.assertFalse((self.root / "bad.zip").exists())

    def test_copied_core_bad_links_rejected(self):
        path = self.root / "references" / "core-sop.md"
        for link in ("../missing.json", "../../../escape.md", "/absolute.md", "%2e%2e/absent.md"):
            path.write_text(f"[bad]({link})", encoding="utf-8")
            with self.subTest(link=link), self.assertRaises(builder.BuildError):
                builder.build_archive(self.role, "office-agent", self.root)

    def test_role_payload_is_data_not_code_or_links(self):
        marker = self.root / "executed.txt"
        payload = f"[payload](../../escape.md)\n```python\nopen({str(marker)!r},'w').write('oops')\n```\n$(whoami)"
        self.role["steps"] = [payload]
        self.role["title"] = "名称\nname: injected"
        data = builder.build_archive(self.role, "office-agent", self.root)
        self.assertFalse(marker.exists())
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            raw = json.loads(archive.read("office-agent/assets/role.json"))
            self.assertEqual(raw["steps"], [payload])
            ui = archive.read("office-agent/agents/openai.yaml").decode()
            self.assertIn('\\nname: injected', ui)
            self.assertNotIn('\nname: injected', ui)

    def test_archive_paths_and_tampering(self):
        for path in ("../x", "office-agent/../x", "office-agent/a\\b", "other/a",
                     "office-agent/C:drive", "office-agent//x"):
            with self.subTest(path=path), self.assertRaises(builder.BuildError):
                builder.safe_archive_path(path, "office-agent")
        original = builder.build_archive(self.role, "office-agent", self.root)
        altered = io.BytesIO()
        with zipfile.ZipFile(io.BytesIO(original)) as source, zipfile.ZipFile(altered, "w") as target:
            for info in source.infolist():
                payload = source.read(info.filename)
                if info.filename.endswith("SKILL.md"):
                    payload += b"changed"
                target.writestr(info, payload)
        with self.assertRaises(builder.BuildError):
            builder.verify_zip_bytes(altered.getvalue(), "office-agent")


if __name__ == "__main__":
    unittest.main()
