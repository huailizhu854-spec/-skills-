"""Replay/rehash regressions for the main 3.4 package; no host invocations."""
import hashlib
import json
from pathlib import Path
import unittest
import test_workbuddy_rc3 as prior
from team_runtime import TeamError
from workbuddy_evidence import check_record, record_return, INTENT, RECORD


class WorkBuddyRC4Tests(unittest.TestCase):
    setUp = prior.WorkBuddyRC3Tests.setUp
    prepare = prior.WorkBuddyRC3Tests.prepare
    begin_submit = prior.WorkBuddyRC3Tests.begin_submit
    raw_evidence = prior.WorkBuddyRC3Tests.raw_evidence
    setup_call = prior.WorkBuddyRC3Tests.setup_call
    intent = prior.WorkBuddyRC3Tests.intent

    def complete_fixture(self):
        self.setup_call()
        self.intent()
        record_return(self.job, self.packet_path, self.raw_evidence(), 'completed')

    def reseal(self, transform=None):
        """An unsigned coordinator can recompute hashes: meaning must be checked."""
        ip = self.evidence / INTENT
        intent = json.loads(ip.read_text())
        if transform:
            transform(intent)
        for pin in intent['files'].values():
            pin['sha256'] = hashlib.sha256((self.job / pin['path']).read_bytes()).hexdigest()
        ip.write_text(json.dumps(intent))
        rp = self.evidence / RECORD
        record = json.loads(rp.read_text())
        record['files']['intent']['sha256'] = hashlib.sha256(ip.read_bytes()).hexdigest()
        rp.write_text(json.dumps(record))

    def test_rehashed_wrong_prompt_cannot_pass_record_check(self):
        self.complete_fixture()
        self.args.write_text(json.dumps({'prompt': 'another task'}))
        self.reseal()
        with self.assertRaisesRegex(TeamError, 'prompt'):
            check_record(self.job, self.packet_path)

    def test_rehashed_other_job_authorization_rejected(self):
        self.complete_fixture()
        value = json.loads(self.auth.read_text()); value['job'] += '-other'
        self.auth.write_text(json.dumps(value)); self.reseal()
        with self.assertRaisesRegex(TeamError, 'Authorization record'):
            check_record(self.job, self.packet_path)

    def test_rehashed_submission_key_rejected(self):
        self.complete_fixture()
        value = json.loads(self.submit.read_text()); value['request_key'] = 'other-request'
        self.submit.write_text(json.dumps(value)); self.reseal()
        with self.assertRaisesRegex(TeamError, 'Submission output'):
            check_record(self.job, self.packet_path)

    def test_rehashed_missing_required_pin_rejected(self):
        self.complete_fixture()
        self.reseal(lambda intent: intent['files'].pop('arguments'))
        with self.assertRaisesRegex(TeamError, 'required evidence pins'):
            check_record(self.job, self.packet_path)

    def test_rehashed_intent_cannot_promote_authorization(self):
        self.complete_fixture()
        self.reseal(lambda intent: intent.update(authorization_verdict='PASS'))
        with self.assertRaisesRegex(TeamError, 'cannot promote'):
            check_record(self.job, self.packet_path)

    def test_rehashed_intent_cannot_claim_execution(self):
        self.complete_fixture()
        self.reseal(lambda intent: intent.update(execution='EXECUTED'))
        with self.assertRaisesRegex(TeamError, 'cannot promote'):
            check_record(self.job, self.packet_path)

    def test_rehashed_export_claim_without_source_rejected(self):
        self.complete_fixture()
        value = json.loads(self.auth.read_text()); value['source_kind'] = 'conversation_export'
        self.auth.write_text(json.dumps(value)); self.reseal()
        with self.assertRaisesRegex(TeamError, 'requires its actual file'):
            check_record(self.job, self.packet_path)

    def test_copied_delegation_elsewhere_rejected(self):
        self.complete_fixture()
        copy_path = self.job / 'reviews/copied-delegation.md'
        copy_path.write_bytes((self.evidence / 'workbuddy-delegation.md').read_bytes())
        self.reseal(lambda intent: intent['files']['delegation'].update(path='reviews/copied-delegation.md'))
        with self.assertRaisesRegex(TeamError, 'this attempt delegation'):
            check_record(self.job, self.packet_path)

    def test_raw_return_outside_attempt_rejected(self):
        self.complete_fixture()
        outside = self.job / 'reviews/other-raw.txt'
        outside.write_bytes((self.evidence / 'workbuddy-raw-return.txt').read_bytes())
        rp = self.evidence / RECORD
        record = json.loads(rp.read_text())
        record['files']['raw_return'] = {'path': 'reviews/other-raw.txt', 'sha256': hashlib.sha256(outside.read_bytes()).hexdigest()}
        rp.write_text(json.dumps(record))
        with self.assertRaises(ValueError):
            check_record(self.job, self.packet_path)

    def test_rc3_schema_valid_evidence_remains_readable(self):
        self.complete_fixture()
        before = (self.job / 'team.sqlite3').read_bytes()
        result = check_record(self.job, self.packet_path)
        self.assertTrue(result['record_consistency_passed'])
        self.assertEqual(result['real_host_verdict'], 'REQUIRES_HOST_TRACE_REVIEW')
        self.assertEqual(before, (self.job / 'team.sqlite3').read_bytes())


if __name__ == '__main__':
    unittest.main()
