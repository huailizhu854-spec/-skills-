"""3.4 offline adversarial checks; NOT WorkBuddy/Windows real-host proof."""
from __future__ import annotations
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from fs_test_support import make_symlink_or_skip, require_long_paths_or_skip
from concurrent.futures import ThreadPoolExecutor

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from kernel import local_file,contained_file,load_json,ContractError
from team_runtime import TeamStore,TeamError,compile_plan,digest,write_json
from delivery_state import (begin_submission,dispatch,observe,request_cancel,resume_plan,usage_summary,
                            save_checkpoint,invalidate_memory,guard_context)
from host_contract34 import blank_probe,evaluate_probe,CAPABILITIES
from delivery_quality import record_review,evaluate_quality
from delivery_brief import brief,brief_markdown,change_impact
from host_adapters.codex import CodexAdapter
from verifier_registry import Context

class JobCase(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='agi34-');self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.job=self.root/'中文 job'
        self.inputs=ROOT/'examples/team-demo';self.plan=load_json(self.inputs/'plan.codex-v3.json')
        self.packet=None;self.counter=0
    def create(self):
        TeamStore.create(self.job,self.plan,self.inputs)
    def claim(self):
        self.create()
        with TeamStore(self.job) as s:self.packet=s.claim('facts','worker')
        return self.packet
    def start(self):
        self.claim()
        with TeamStore(self.job) as s:return begin_submission(s,'facts',self.packet['lease_token'])
    def event(self,kind='started',run_id='fixture-host-1',eid=None):
        self.counter+=1
        with TeamStore(self.job) as s:d=dict(dispatch(s,self.packet['lease_token']))
        relative='reviews/host-'+str(self.counter)+'.json';p=self.job/relative
        write_json(p,{'OFFLINE_FIXTURE_NOT_REAL_HOST':True,'request_key':d['request_key'],'run_id':run_id,'state':kind})
        return {'id':eid or 'event'+str(self.counter),'task_id':'facts','lease_token':d['token'],
                'request_key':d['request_key'],'goal_digest':d['goal_digest'],'plan_digest':d['plan_digest'],
                'event':kind,'host_run_id':run_id,'tool':'offline-fixture',
                'evidence_path':relative,'evidence_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    def observed(self,kind='started',run_id='fixture-host-1'):
        e=self.event(kind,run_id)
        with TeamStore(self.job) as s:return observe(s,e)
    def recovery(self,termination='confirmed_stopped',action='retry'):
        relative='reviews/recover-'+str(self.counter)+'.json';p=self.job/relative
        write_json(p,{'task_id':'facts','lease_token':self.packet['lease_token'],'termination':termination})
        return {'task_id':'facts','lease_token':self.packet['lease_token'],'termination':termination,
                'evidence_path':relative,'evidence_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                'reason':'offline recovery test','action':action}

class LifecycleTests(JobCase):
    def test_prepare_checkpoint_and_no_spawn(self):
        self.claim()
        with TeamStore(self.job) as s:
            self.assertEqual(dispatch(s,self.packet['lease_token'])['state'],'PREPARED')
            self.assertIsNone(s.row('facts')['host_run_id'])
            self.assertEqual(s.db.execute('SELECT COUNT(*) FROM checkpoints34').fetchone()[0],2)
    def test_begin_is_single_use(self):
        self.start()
        with TeamStore(self.job) as s:
            with self.assertRaises(TeamError):begin_submission(s,'facts',self.packet['lease_token'])
    def test_creation_receipt_lost_never_retries(self):
        self.start();self.observed('unknown',None)
        with TeamStore(self.job) as s:
            self.assertEqual(resume_plan(s)['actions'][0]['action'],'QUERY_ORIGINAL_HOST')
            with self.assertRaises(TeamError):s.claim('facts','worker2')
            with self.assertRaises(TeamError):s.recover(self.recovery())
    def test_concurrent_begin_has_one_winner(self):
        self.claim()
        def run(_):
            try:
                with TeamStore(self.job) as s:begin_submission(s,'facts',self.packet['lease_token']);return True
            except TeamError:return False
        with ThreadPoolExecutor(max_workers=6) as pool:self.assertEqual(sum(pool.map(run,range(6))),1)
    def test_started_binds_exact_host(self):
        self.start();self.observed()
        with TeamStore(self.job) as s:self.assertEqual(s.row('facts')['host_run_id'],'fixture-host-1')
    def test_cross_run_collision(self):
        self.start();self.observed();e=self.event('running','other')
        with TeamStore(self.job) as s:
            with self.assertRaises(TeamError):observe(s,e)
    def test_duplicate_observation_consumed_once(self):
        self.start();e=self.event()
        with TeamStore(self.job) as s:
            observe(s,e);self.assertTrue(observe(s,e)['duplicate'])
            self.assertEqual(s.db.execute('SELECT COUNT(*) FROM observations34').fetchone()[0],1)
    def test_same_event_id_different_payload_rejected(self):
        self.start();e=self.event()
        with TeamStore(self.job) as s:
            observe(s,e);e['tool']='changed'
            with self.assertRaises(TeamError):observe(s,e)
    def test_wrong_goal_rejected(self):
        self.start();e=self.event();e['goal_digest']='0'*64
        with TeamStore(self.job) as s:
            with self.assertRaises(TeamError):observe(s,e)
    def test_wrong_request_rejected(self):
        self.start();e=self.event();e['request_key']='wrong'
        with TeamStore(self.job) as s:
            with self.assertRaises(TeamError):observe(s,e)
    def test_wrong_lease_rejected(self):
        self.start();e=self.event();e['lease_token']='wrong'
        with TeamStore(self.job) as s:
            with self.assertRaises(TeamError):observe(s,e)
    def test_corrupted_raw_observation_rejected(self):
        self.start();e=self.event();(self.job/e['evidence_path']).write_text('changed')
        with TeamStore(self.job) as s:
            with self.assertRaises(TeamError):observe(s,e)
    def test_cancel_request_is_not_stop_confirmation(self):
        self.start();self.observed()
        with TeamStore(self.job) as s:
            result=request_cancel(s,'facts',self.packet['lease_token']);self.assertFalse(result['stop_confirmed'])
            with self.assertRaises(TeamError):s.recover(self.recovery())
    def test_running_cannot_undo_cancel(self):
        self.start();self.observed()
        with TeamStore(self.job) as s:request_cancel(s,'facts',self.packet['lease_token'])
        self.assertEqual(self.observed('running')['state'],'CANCEL_REQUESTED')
    def test_cancel_then_confirmed_stop_allows_recovery(self):
        self.start();self.observed()
        with TeamStore(self.job) as s:request_cancel(s,'facts',self.packet['lease_token'])
        self.observed('cancelled')
        with TeamStore(self.job) as s:
            self.assertEqual(s.recover(self.recovery())['status'],'pending')
            new=s.claim('facts','worker');self.assertNotEqual(new['lease_token'],self.packet['lease_token'])
    def test_no_creation_proof_has_distinct_recovery(self):
        self.start();self.observed('not_created',None)
        with TeamStore(self.job) as s:
            self.assertEqual(s.recover(self.recovery('confirmed_not_started'))['status'],'pending')
    def test_not_created_after_started_is_contradiction(self):
        self.start();self.observed()
        with TeamStore(self.job) as s:
            with self.assertRaises(TeamError):observe(s,self.event('not_created',None))
    def test_failure_not_adoptable_success(self):
        self.start();self.observed('failed')
        with TeamStore(self.job) as s:
            with self.assertRaises(TeamError):s.recover(self.recovery(action='adopt_finished'))
    def test_late_success_requires_adopt_and_review(self):
        self.start();self.observed('unknown',None);self.observed('succeeded')
        with TeamStore(self.job) as s:
            self.assertEqual(s.recover(self.recovery(action='adopt_finished'))['status'],'leased')
            self.assertFalse(s.status()['completed'])
    def test_stale_running_cannot_regress_terminal(self):
        self.start();self.observed('succeeded');self.assertEqual(self.observed('running')['state'],'SUCCEEDED')
    def test_contradictory_terminal_is_rejected(self):
        self.start();self.observed('succeeded')
        with TeamStore(self.job) as s:
            with self.assertRaises(TeamError):observe(s,self.event('cancelled'))
    def test_terminal_evidence_rehashed_on_recovery(self):
        self.start();e=self.event('failed')
        with TeamStore(self.job) as s:observe(s,e)
        (self.job/e['evidence_path']).write_text('changed')
        with TeamStore(self.job) as s:
            with self.assertRaises(TeamError):s.recover(self.recovery())
    def test_superseded_run_cannot_bind_or_accept_new_work(self):
        self.start();self.observed()
        with TeamStore(self.job) as s:
            s.supersede('f'*64,'changed requirement')
            with self.assertRaises(TeamError):s.claim('outline','worker')
        self.observed('cancelled')
        with TeamStore(self.job) as s:self.assertEqual(s.recover(self.recovery())['status'],'cancelled')
    def test_reopen_uses_ledger_not_auto_retry(self):
        self.start()
        with TeamStore(self.job) as s:
            r=resume_plan(s);self.assertEqual(r['host_queries_executed'],0);self.assertFalse(r['actions'][0]['retry_authorized'])
    def test_checkpoint_tamper_is_visible(self):
        self.start()
        with TeamStore(self.job) as s:
            s.db.execute("UPDATE checkpoints34 SET payload_hash=?",('0'*64,))
            self.assertIn('CHECKPOINT_TAMPERED',resume_plan(s)['blockers'])
    def test_external_material_change_requires_revision(self):
        self.start();inputs=self.root/'materials';shutil.copytree(self.inputs,inputs)
        (inputs/'brief.txt').write_text('different',encoding='utf-8')
        with TeamStore(self.job) as s:self.assertIn('EXTERNAL_MATERIAL_CHANGED',resume_plan(s,inputs)['blockers'])
    def test_usage_never_invents_model_tokens(self):
        self.start()
        with TeamStore(self.job) as s:
            r=usage_summary(s);self.assertEqual(r['worker_attempts'],1);self.assertIsNone(r['tokens']);self.assertIsNone(r['actual_host_concurrency'])
    def test_legacy_database_is_not_migrated(self):
        self.create()
        with TeamStore(self.job) as s:
            s.db.execute('DROP TABLE dispatch34')
            self.packet=s.claim('facts','worker')
            with self.assertRaises(TeamError):begin_submission(s,'facts',self.packet['lease_token'])
            self.assertIsNone(s.db.execute("SELECT name FROM sqlite_master WHERE name='dispatch34'").fetchone())
    def test_output_alias_different_work_keys_rejected(self):
        self.plan['tasks'][1]['outputs'][0]['path']=self.plan['tasks'][0]['outputs'][0]['path'].upper()
        with self.assertRaises(TeamError):compile_plan(self.plan)
    def test_checks_do_not_store_complete_conversation(self):
        self.claim()
        with TeamStore(self.job) as s:
            cp=json.loads(s.db.execute('SELECT payload FROM checkpoints34 ORDER BY seq DESC LIMIT 1').fetchone()[0])
            self.assertNotIn('conversation',cp);self.assertNotIn('memory_records',cp)

class ProbeTests(JobCase):
    def probe(self,host='fixture'):
        p=blank_probe(host,version='test-only',os_name='Offline fixture');p.update(observed_at=time.time()-1,expires_at=time.time()+60,evidence_kind='OFFLINE_FIXTURE')
        (self.root/'probe.txt').write_text('offline capability fixture')
        ref={'path':'probe.txt','sha256':hashlib.sha256((self.root/'probe.txt').read_bytes()).hexdigest()}
        for cap in p['capabilities'].values():cap.update(status='supported',evidence=ref)
        return p
    def test_workbuddy_catalog_never_grants_execution(self):
        r=evaluate_probe(blank_probe('workbuddy'),self.root,required=['create'])
        self.assertEqual(r['status'],'HANDOFF_ONLY');self.assertFalse(r['native_compatibility_proven'])
    def test_cli_cannot_masquerade_as_desktop(self):
        p=blank_probe('workbuddy');p['product']='CodeBuddy Code CLI'
        with self.assertRaises(TeamError):evaluate_probe(p,self.root)
    def test_complete_fixture_probe_is_not_real_run(self):
        r=evaluate_probe(self.probe(),self.root,required=['create']);self.assertEqual(r['status'],'OBSERVATION_CONTRACT_READY');self.assertEqual(r['execution'],'NOT_EXECUTED')
    def test_fixture_cannot_attest_real_host(self):
        with self.assertRaises(TeamError):evaluate_probe(self.probe('codex_native'),self.root)
    def test_expired_probe_rejected(self):
        p=self.probe();p['expires_at']=time.time()-1
        with self.assertRaises(TeamError):evaluate_probe(p,self.root)
    def test_unknown_required_capability_blocks(self):
        p=self.probe();p['capabilities']['cancel']={'status':'unknown','evidence':None}
        self.assertIn('CAPABILITY_CANCEL_UNKNOWN',evaluate_probe(p,self.root,required=['cancel'])['blockers'])
    def test_unsupported_capability_blocks(self):
        p=self.probe();p['capabilities']['cancel']['status']='unsupported'
        self.assertIn('CAPABILITY_CANCEL_UNSUPPORTED',evaluate_probe(p,self.root,required=['cancel'])['blockers'])
    def test_changed_probe_evidence_rejected(self):
        p=self.probe();(self.root/'probe.txt').write_text('changed')
        with self.assertRaises(TeamError):evaluate_probe(p,self.root)
    def test_unobservable_nested_schedule_blocks(self):
        p=self.probe();p['nested_scheduling']=True;p['capabilities']['nested_mapping']={'status':'unknown','evidence':None}
        self.assertIn('UNOBSERVABLE_NESTED_SCHEDULING',evaluate_probe(p,self.root)['blockers'])
    def test_permission_claim_cannot_override_probe(self):
        p=self.probe();p['tool_permissions']='host_enforced';p['capabilities']['tool_enforcement']['status']='unsupported'
        self.assertIn('PERMISSION_DECLARATION_CONFLICT',evaluate_probe(p,self.root)['blockers'])
    def test_unknown_operation_fails_closed(self):
        with self.assertRaises(TeamError):evaluate_probe(self.probe(),self.root,required=['invented_spawn'])

class PathTests(JobCase):
    def test_relative_root_is_normalized(self):
        (self.root/'x.txt').write_text('fixture')
        self.assertTrue(local_file(self.root/'..'/self.root.name,'x.txt')['sha256'])
    def test_unicode_space_path(self):
        p=self.root/'中文 空格';p.mkdir();(p/'材料.txt').write_text('测试',encoding='utf-8')
        self.assertEqual(contained_file(p,p/'材料.txt')[1]['bytes'],6)
    def test_real_escape_rejected(self):
        p=self.root/'inside';p.mkdir();outside=self.root/'outside.txt';outside.write_text('fixture')
        with self.assertRaises(ContractError):contained_file(p,outside)
    def test_symlink_not_resolved_away(self):
        p=self.root/'x.txt';p.write_text('fixture');alias=self.root/'alias.txt'
        make_symlink_or_skip(self, alias, p)
        with self.assertRaises(ContractError):contained_file(self.root,alias)
        with self.assertRaises(ContractError):local_file(self.root,'alias.txt')
    def test_long_path(self):
        require_long_paths_or_skip(self, self.root)
        p=self.root
        for i in range(8):p=p/('long-component-'+str(i)+'-'+'x'*20);p.mkdir()
        f=p/'材料.txt';self.assertGreater(len(str(f)),260)
        f.write_text('fixture');self.assertTrue(contained_file(self.root,f)[1]['sha256'])
    @unittest.skipUnless(os.name=='nt','Windows 8.3 alias requires real Windows filesystem; Linux is NOT verification')
    def test_windows_83_real_alias(self):
        import ctypes
        p=self.root/'Long Directory With Spaces';p.mkdir();(p/'file.txt').write_text('fixture')
        buf=ctypes.create_unicode_buffer(32768);fn=ctypes.windll.kernel32.GetShortPathNameW
        fn.argtypes=[ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_uint32];fn.restype=ctypes.c_uint32
        n=fn(str(p),buf,len(buf))
        if not n or n>=len(buf) or '~' not in buf.value:self.skipTest('8.3 aliases disabled/unavailable; must retest in alias-enabled Windows')
        self.assertEqual(local_file(Path(buf.value),'file.txt')['sha256'],local_file(p,'file.txt')['sha256'])
        self.assertEqual(contained_file(Path(buf.value),p/'file.txt')[1]['sha256'],local_file(p,'file.txt')['sha256'])

class BriefTests(JobCase):
    def test_requirement_trace_complete(self):
        b=brief(self.plan);self.assertEqual(len(b['requirement_trace']),4);self.assertTrue(all(x['auto_checks'] for x in b['requirement_trace']))
    def test_assumption_never_becomes_user_fact(self):
        b=brief(self.plan,assumptions=['20分钟按估算']);self.assertEqual(b['assumptions'][0]['status'],'UNCONFIRMED_NOT_USER_FACT');self.assertIn('不是用户事实',brief_markdown(b))
    def test_change_propagates_through_dependencies(self):
        new=copy.deepcopy(self.plan);new['goal']['version']+=1;new['goal']['requirements'][0]['text']+=' changed'
        r=change_impact(self.plan,new);self.assertIn('facts',r['affected_tasks']);self.assertIn('page',r['affected_tasks']);self.assertIn('outline',r['reuse_candidates']);self.assertFalse(r['automatic_reuse_authorized'])
    def test_constraint_change_conservatively_invalidates_all(self):
        new=copy.deepcopy(self.plan);new['goal']['version']+=1;new['goal']['constraints'].append('New hard constraint')
        self.assertEqual(len(change_impact(self.plan,new)['affected_tasks']),4)
    def test_unknown_semantic_impact_id_rejected(self):
        new=copy.deepcopy(self.plan);new['goal']['version']+=1
        with self.assertRaises(TeamError):change_impact(self.plan,new,declared_impacted=['wrong'])

if __name__=='__main__':unittest.main()
