"""Offline adversarial tests. All 'host' observations here are synthetic fixtures.
Nothing in this module proves provider identity, real model calls, or live support.
"""
from __future__ import annotations
import copy
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'));sys.path.insert(0,str(ROOT/'examples/dual16'))
from kernel import local_file
from team_runtime import TeamStore,TeamError,compile_plan,write_json,digest,canonical
import dual16
from make_plan import make_plan
from run_demo import collect_fixture

class Dual16Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        self.source=self.root/'source';self.plan=make_plan(self.source);self.job=self.root/'job';self.n=0
    def bad(self,fn,code=None):
        with self.assertRaises(TeamError) as ctx:fn()
        if code:self.assertEqual(ctx.exception.code,code)
    def create(self,kind='fixture'):
        if kind!='fixture':
            for t in self.plan['tasks']:
                t['executor']={'type':kind,'transport_network':True};t['tools']=['file.read','file.write']
                t['acceptance'][0]['method']='json-values-v1';t['acceptance'][0]['params']={'equals':{'ok':True}}
        TeamStore.create(self.job,self.plan,self.source,offline_fixture=kind=='fixture')
        self.store=TeamStore(self.job);self.addCleanup(self.store.close);return self.store
    def raw(self,**extras):
        return {'plan_digest':self.store.meta('plan_digest'),'goal_digest':self.store.meta('goal_digest'),
                'execution_kind':dual16.profile_kind(self.store),**extras}
    def save(self,obj):
        self.n+=1;rel=f'reviews/dual16/unit-{self.n}.json';write_json(self.job/rel,obj)
        return {'path':rel,'sha256':local_file(self.job,rel)['sha256']}
    def probe(self,**extras):
        raw=self.raw(host=self.plan['tasks'][0]['executor']['type'],session_capacity=18,worker_parallel_capacity=16,
            persistent_sessions=True,resume=True,query=True,async_launch=True,cancel=True,authorized=True,
            source='SYNTHETIC UNIT TEST, NOT HOST EVIDENCE')
        raw.update(extras);return dual16.register_probe(self.store,self.save(raw))
    def start(self,slot,hid=None):
        packet=dual16.reserve(self.store,slot);hid=hid or 'synthetic-'+slot
        raw=self.raw(slot=slot,launch_nonce=packet['launch_nonce'],host_run_id=hid,state='idle',
                     native_tool='SYNTHETIC',raw_response=canonical({'host_run_id':hid,'synthetic':True}))
        return dual16.observe_start(self.store,slot,self.save(raw))
    def live(self,kind='fixture'):
        self.create(kind);self.probe()
        for slot in ['control-a','control-b']+[f'w{i:02d}' for i in range(1,17)]:self.start(slot)
        self.barrier();return self.store
    def barrier_raw(self):
        sessions=[{'slot':r['slot'],'host_run_id':r['host_run_id'],'state':'idle'} for r in self.store.db.execute('SELECT * FROM d16_sessions')]
        return self.raw(sessions=sessions,native_tool='SYNTHETIC QUERY',raw_response=canonical(sessions))
    def barrier(self):return dual16.barrier(self.store,self.save(self.barrier_raw()))
    def decision(self,cid,actions,**extras):
        packet=dual16.request_decision(self.store,cid)
        d={**{k:packet[k] for k in ('controller','turn_nonce','plan_digest','goal_digest')},'actions':actions};raw=self.raw(controller=cid,host_run_id='synthetic-'+cid,turn_nonce=packet['turn_nonce'],
            decision=d,returned_payload_sha256=digest(d),native_tool='SYNTHETIC DECISION',raw_response=canonical(d))
        raw.update(extras);ref=self.save(raw);return dual16.record_decision(self.store,cid,ref)
    def dispatch(self,tid='w01',cid='control-a'):
        self.decision(cid,[{'action':'dispatch','task_id':tid,'reason':'Synthetic distinct shard assignment'}])
        return self.store.claim(tid,tid)
    def produce(self,packet,wrong=False):
        import hashlib
        vals=json.loads((self.source/'numbers.json').read_text())['numbers'];i=packet['contract']['acceptance'][0]['params']['shard'];nums=vals[i::16]
        out=Path(packet['output_root'])/packet['contract']['outputs'][0]['path'];out.parent.mkdir(parents=True)
        out.write_text(json.dumps({'shard':i,'count':len(nums),'total':sum(nums)+(1 if wrong else 0),
                      'sum_squares':sum(x*x for x in nums),'source_sha256':hashlib.sha256((self.source/'numbers.json').read_bytes()).hexdigest()}))
        tid=packet['task_id'];hid='synthetic-'+tid;self.store.bind(tid,packet['lease_token'],'fixture',hid)
        collect_fixture(self.store,packet,SimpleNamespace(hid=hid,p=SimpleNamespace(pid=123)),{'synthetic':True})
    def test_valid_topology(self):self.assertTrue(compile_plan(self.plan)['valid'])
    def test_fifteen_workers_rejected(self):
        self.plan['tasks'].pop();self.bad(lambda:compile_plan(self.plan),'D16_SIZE')
    def test_seventeen_workers_rejected(self):
        t=copy.deepcopy(self.plan['tasks'][-1]);t.update(id='w17',work_key='shard-17',scope='unique-17')
        t['outputs']=[{'id':'out-w17','path':'shards/w17.json'}];t['acceptance'][0]['subject']['artifact_id']='out-w17'
        self.plan['tasks'].append(t);self.bad(lambda:compile_plan(self.plan),'D16_SIZE')
    def test_one_controller_rejected(self):
        self.plan['orchestration']['controllers'].pop();self.bad(lambda:compile_plan(self.plan),'D16_CONTROLLERS')
    def test_three_controllers_rejected(self):
        self.plan['orchestration']['controllers'].append({'id':'third','mission':'third','members':[]});self.bad(lambda:compile_plan(self.plan),'D16_CONTROLLERS')
    def test_nine_seven_split_rejected(self):
        a,b=self.plan['orchestration']['controllers'];a['members'].append(b['members'].pop());self.bad(lambda:compile_plan(self.plan),'D16_MEMBERS')
    def test_overlapping_members_rejected(self):
        self.plan['orchestration']['controllers'][1]['members'][0]='w01';self.bad(lambda:compile_plan(self.plan),'D16_MEMBERS')
    def test_duplicate_controller_rejected(self):
        self.plan['orchestration']['controllers'][1]['id']='control-a';self.bad(lambda:compile_plan(self.plan),'D16_ID')
    def test_self_team_review_rejected(self):
        self.plan['tasks'][0]['reviewer']='control-a';self.bad(lambda:compile_plan(self.plan),'D16_REVIEWER')
    def test_parallel_budget_fifteen_rejected(self):
        self.plan['policy']['max_parallel']=15;self.bad(lambda:compile_plan(self.plan),'D16_BUDGET')
    def test_attempt_budget_fifteen_rejected(self):
        self.plan['policy']['max_total_attempts']=15;self.bad(lambda:compile_plan(self.plan),'D16_BUDGET')
    def test_no_silent_fallback(self):
        self.plan['orchestration']['on_insufficient_host']='serial';self.bad(lambda:compile_plan(self.plan),'D16_FALLBACK')
    def test_worker_recursion_rejected(self):
        self.plan['tasks'][0]['capabilities']['model_delegation']=True;self.bad(lambda:compile_plan(self.plan),'V3_CONTRACT')
    def test_output_ownership_conflict_rejected(self):
        self.plan['tasks'][1]['outputs'][0]['path']='shards/w01.json';self.bad(lambda:compile_plan(self.plan),'OUTPUT_OWNERSHIP')
    def test_same_work_key_rejected(self):
        self.plan['tasks'][1]['work_key']=self.plan['tasks'][0]['work_key'];self.bad(lambda:compile_plan(self.plan),'DUPLICATE_WORK')
    def test_explicit_fixture_flag_required(self):
        self.bad(lambda:TeamStore.create(self.job,self.plan,self.source),'D16_FIXTURE_FLAG');self.assertFalse(self.job.exists())
    def test_host_capacity_seventeen_blocked(self):
        self.create();self.bad(lambda:self.probe(session_capacity=17),'D16_CAPACITY')
    def test_worker_capacity_fifteen_blocked(self):
        self.create();self.bad(lambda:self.probe(worker_parallel_capacity=15),'D16_CAPACITY')
    def test_boolean_not_capacity(self):
        self.create();self.bad(lambda:self.probe(session_capacity=True),'D16_CAPACITY')
    def test_unknown_query_blocked(self):
        self.create();self.bad(lambda:self.probe(query=None),'D16_CAPABILITY')
    def test_synchronous_host_blocked(self):
        self.create();self.bad(lambda:self.probe(async_launch=False),'D16_CAPABILITY')
    def test_missing_authorization_blocked(self):
        self.create();self.bad(lambda:self.probe(authorized=False),'D16_AUTHORIZATION')
    def test_workbuddy_old_adapter_not_upgraded_by_booleans(self):
        self.create('workbuddy_mobile_cloud');self.bad(lambda:self.probe(),'D16_HOST_UNSUPPORTED')
    def test_fixture_cannot_be_native_evidence(self):
        self.create();self.bad(lambda:self.probe(execution_kind='native'),'D16_KIND')
    def test_no_launch_before_probe(self):
        self.create();self.bad(lambda:dual16.reserve(self.store,'w01'),'D16_PROBE')
    def test_lost_create_return_never_blindly_retried(self):
        self.create();self.probe();dual16.reserve(self.store,'w01');self.bad(lambda:dual16.reserve(self.store,'w01'),'D16_SPAWN_UNKNOWN')
    def test_two_roles_cannot_share_host_session(self):
        self.create();self.probe();self.start('control-a','same');self.bad(lambda:self.start('w01','same'),'D16_DUPLICATE_SESSION')
    def test_wrong_start_nonce_rejected(self):
        self.create();self.probe();dual16.reserve(self.store,'w01')
        raw=self.raw(slot='w01',launch_nonce='wrong',host_run_id='x',state='idle',native_tool='synthetic',raw_response='x')
        self.bad(lambda:dual16.observe_start(self.store,'w01',self.save(raw)),'D16_NONCE')
    def test_partial_roster_blocked(self):
        self.create();self.probe();self.start('control-a');self.bad(lambda:self.barrier(),'D16_ROSTER')
    def test_duplicate_query_slots_blocked(self):
        self.live();raw=self.barrier_raw();raw['sessions'][-1]=raw['sessions'][0]
        self.bad(lambda:dual16.barrier(self.store,self.save(raw)),'D16_ROSTER')
    def test_stale_query_blocks_claim(self):
        self.live();b=dual16.get(self.store,'barrier');b['at']=time.time()-301;dual16.put(self.store,'barrier',b)
        self.bad(lambda:self.store.claim('w01','w01'),'D16_QUERY_STALE')
    def test_no_dispatch_without_controller_decision(self):
        self.live();self.bad(lambda:self.store.claim('w01','w01'),'D16_GRANT')
    def test_worker_cannot_be_controller(self):
        self.live();self.bad(lambda:dual16.request_decision(self.store,'w01'),'D16_CONTROLLER')
    def test_wrong_group_dispatch_blocked(self):
        self.live();self.bad(lambda:self.decision('control-a',[{'action':'dispatch','task_id':'w09','reason':'illegal'}]),'D16_CROSS_TEAM')
    def test_controller_cannot_replace_worker_identity(self):
        self.live();self.decision('control-a',[{'action':'dispatch','task_id':'w01','reason':'assigned'}])
        self.bad(lambda:self.store.claim('w01','control-a'),'D16_WORKER')
    def test_duplicate_actions_rejected_atomically(self):
        self.live();a={'action':'dispatch','task_id':'w01','reason':'assigned'}
        self.bad(lambda:self.decision('control-a',[a,a]),'D16_DUPLICATE_ACTION')
        self.assertEqual(self.store.db.execute('SELECT COUNT(*) FROM d16_grants').fetchone()[0],0)
    def test_controller_output_must_match_preserved_response(self):
        self.live();self.bad(lambda:self.decision('control-a',[{'action':'dispatch','task_id':'w01','reason':'x'}],raw_response='{}'),'D16_SOURCE')
    def test_unanswered_controller_turn_not_resent(self):
        self.live();dual16.request_decision(self.store,'control-a');self.bad(lambda:dual16.request_decision(self.store,'control-a'),'D16_TURN_UNKNOWN')
    def test_grant_cannot_be_used_twice(self):
        self.live();self.dispatch();self.bad(lambda:self.store.claim('w01','w01'),'ALREADY_CLAIMED')
    def test_wrong_worker_session_cannot_bind(self):
        self.live();p=self.dispatch();self.bad(lambda:self.store.bind('w01',p['lease_token'],'fixture','synthetic-w02'),'D16_SESSION_BIND')
    def test_native_mode_cannot_bind_fixture_plan(self):
        self.live();p=self.dispatch();self.bad(lambda:self.store.bind('w01',p['lease_token'],'native','synthetic-w01'),'HOST_MISMATCH')
    def test_independent_review_rejects_false_success(self):
        self.live();p=self.dispatch();self.produce(p,wrong=True)
        a=self.decision('control-b',[{'action':'accept','task_id':'w01','reason':'INTENTIONALLY FALSE test claim'}])
        self.bad(lambda:dual16.apply_review(self.store,a['grants'][0]),'GATE_FAILED')
        self.assertEqual(self.store.row('w01')['status'],'submitted')
        dual16.invalidate_grant(self.store,a['grants'][0],'verification failed')
        a=self.decision('control-b',[{'action':'rework','task_id':'w01','reason':'sum is incorrect'}]);dual16.apply_review(self.store,a['grants'][0])
        self.assertEqual(self.store.row('w01')['status'],'pending')
    def test_own_group_cannot_approve_output(self):
        self.live();p=self.dispatch();self.produce(p)
        self.bad(lambda:self.decision('control-a',[{'action':'accept','task_id':'w01','reason':'self approve'}]),'D16_REVIEWER')
    def test_valid_cross_review_accepts_one_not_entire_job(self):
        self.live();p=self.dispatch();self.produce(p)
        a=self.decision('control-b',[{'action':'accept','task_id':'w01','reason':'verified numeric source'}]);dual16.apply_review(self.store,a['grants'][0])
        self.assertEqual(self.store.row('w01')['status'],'accepted');self.assertFalse(self.store.status()['completed'])
    def test_raw_decision_tamper_fences_claim(self):
        self.live();self.decision('control-a',[{'action':'dispatch','task_id':'w01','reason':'assigned'}])
        g=self.store.db.execute('SELECT payload FROM d16_grants').fetchone();ref=json.loads(g[0])['observation']
        (self.job/ref['path']).write_text('{}');self.bad(lambda:self.store.claim('w01','w01'),'D16_EVIDENCE')
    def test_health_unknown_stops_dispatch_without_new_worker(self):
        self.live();raw=self.raw(slot='control-a',host_run_id='synthetic-control-a',state='unknown',raw_response='synthetic-control-a query timed out')
        dual16.observe_health(self.store,'control-a',self.save(raw));self.bad(lambda:self.store.claim('w01','w01'),'D16_ROSTER')
        self.bad(lambda:dual16.reserve(self.store,'control-a'),'D16_SPAWN_UNKNOWN')
    def test_stopped_session_is_not_resurrected(self):
        self.live();raw=self.raw(slot='w01',host_run_id='synthetic-w01',state='stopped',raw_response='synthetic-w01 stopped')
        dual16.observe_health(self.store,'w01',self.save(raw));raw['state']='idle'
        self.bad(lambda:dual16.observe_health(self.store,'w01',self.save(raw)),'D16_SESSION_STATE')
    def test_supersede_lists_both_controllers_and_all_workers(self):
        self.live();result=self.store.supersede('a'*64,'new requirement');self.assertEqual(len(result['dual16_sessions_to_stop']),18)
        self.bad(lambda:dual16.guard_revise(self.store),'D16_OLD_SESSIONS')
        raw=self.raw(slot='control-a',host_run_id='synthetic-control-a',state='stopped',raw_response='synthetic-control-a stopped')
        dual16.observe_health(self.store,'control-a',self.save(raw))
        self.assertEqual(dual16.session(self.store,'control-a')['state'],'STOPPED')
    def test_native_prepare_resumes_existing_session_not_spawn(self):
        self.live('codex_native');self.decision('control-a',[{'action':'dispatch','task_id':'w01','reason':'assigned'}])
        from host_adapters.codex import CodexAdapter
        d=CodexAdapter(self.job).prepare('w01','w01')
        self.assertEqual(d['dispatch_operation'],'resume_existing_session');self.assertEqual(d['expected_host_run_id'],'synthetic-w01')
        self.assertEqual(d['execution'],'NOT_EXECUTED')
    def test_unknown_verifier_blocked_before_launch(self):
        self.plan['tasks'][0]['acceptance'][0]['method']='unimplemented-magic'
        self.bad(lambda:compile_plan(self.plan),'D16_VERIFIER')
    def test_source_fact_without_verifier_not_accepted_as_runtime(self):
        self.plan['tasks'][0]['acceptance'][0]['evidence_kind']='SOURCE_FACT'
        self.bad(lambda:compile_plan(self.plan),'D16_VERIFIER')
    def test_concurrent_claims_consume_only_one_grant(self):
        from concurrent.futures import ThreadPoolExecutor
        self.live();self.decision('control-a',[{'action':'dispatch','task_id':'w01','reason':'one assigned worker'}])
        def claim():
            with TeamStore(self.job) as other:
                try:other.claim('w01','w01');return 'ok'
                except TeamError as exc:return exc.code
        with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda _:claim(),range(2)))
        self.assertEqual(results.count('ok'),1);self.assertEqual(results.count('ALREADY_CLAIMED'),1)
    def test_native_bind_requires_submission_intent(self):
        self.live('codex_native');p=self.dispatch()
        self.bad(lambda:self.store.bind('w01',p['lease_token'],'native','synthetic-w01'),'D16_SUBMIT_INTENT')
        from delivery_state import begin_submission
        begin_submission(self.store,'w01',p['lease_token'])
        self.assertTrue(self.store.bind('w01',p['lease_token'],'native','synthetic-w01')['bound'])
    def test_old_completed_snapshot_cannot_finish_new_native_attempt(self):
        self.live('codex_native');p=self.dispatch()
        from delivery_state import begin_submission
        begin_submission(self.store,'w01',p['lease_token']);self.store.bind('w01',p['lease_token'],'native','synthetic-w01')
        from host_adapters.codex import CodexAdapter
        rel='evidence/old-finish.json';target=Path(p['workspace'])/rel
        write_json(target,{'agents':[{'agent_name':'synthetic-w01','agent_status':'completed'}]})
        event={'schema_version':1,'host':'codex_native','event':'finished','host_run_id':'synthetic-w01',
               'task_id':'w01','lease_token':p['lease_token'],'native_tool':'SYNTHETIC status query',
               'raw_evidence_path':rel,'raw_evidence_sha256':local_file(Path(p['workspace']),rel)['sha256'],'observed_by':'coordinator'}
        self.bad(lambda:CodexAdapter(self.job).collect_observed(event),'D16_ATTEMPT_OBSERVATION')
    def test_controller_payload_must_echo_current_nonce(self):
        self.live();packet=dual16.request_decision(self.store,'control-a')
        d={**{k:packet[k] for k in ('controller','turn_nonce','plan_digest','goal_digest')},
           'actions':[{'action':'wait','task_id':None,'reason':'test'}]};d['turn_nonce']='old-nonce'
        raw=self.raw(controller='control-a',host_run_id='synthetic-control-a',turn_nonce=packet['turn_nonce'],
            decision=d,returned_payload_sha256=digest(d),native_tool='SYNTHETIC',raw_response=canonical(d))
        self.bad(lambda:dual16.record_decision(self.store,'control-a',self.save(raw)),'D16_TURN')
    def test_old_demo_plan_remains_compatibility_only(self):
        p=json.loads((ROOT/'examples/team-demo/plan.json').read_text());self.assertFalse(dual16.enabled(p));self.assertTrue(compile_plan(p)['valid'])

if __name__=='__main__':unittest.main()
