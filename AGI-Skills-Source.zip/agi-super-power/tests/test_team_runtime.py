"""v2 behavioral invariants of the ledger. No API calls or real LLM workers."""
from __future__ import annotations
import copy
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from fs_test_support import make_symlink_or_skip

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from kernel import ContractError, load_json
from team_runtime import TeamStore, TeamError, compile_plan, digest, write_json

spec = importlib.util.spec_from_file_location("fixture_worker_v2", ROOT / "examples/team-demo/fixture_worker.py")
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class PlanTests(unittest.TestCase):
    def setUp(self):
        self.plan = load_json(ROOT / "examples/team-demo/plan.json")

    def test_reserved_generated_ids_and_invisible_keys_are_rejected(self):
        changed = copy.deepcopy(self.plan); changed["tasks"][0]["id"] = "CON"
        with self.assertRaises(TeamError): compile_plan(changed)
        changed = copy.deepcopy(self.plan); changed["tasks"][0]["work_key"] = "demo/\u200bfacts"
        with self.assertRaises(TeamError): compile_plan(changed)
        changed = copy.deepcopy(self.plan); changed["tasks"][0]["role"] = "Repo-Research"
        with self.assertRaises(TeamError): compile_plan(changed)

    def test_valid_plan_has_disjoint_owners_and_dependency_waves(self):
        result = compile_plan(self.plan)
        self.assertEqual(result["waves"], [["facts", "outline"], ["page"], ["audit"]])
        self.assertEqual(len(result["owners"]), 4)

    def test_renamed_duplicate_key_is_rejected(self):
        self.plan["tasks"][1]["work_key"] = "  ＤＥＭＯ/ＦＡＣＴＳ  "
        with self.assertRaisesRegex(TeamError, "One owner"):
            compile_plan(self.plan)

    def test_renamed_key_with_same_role_scope_and_inputs_is_rejected(self):
        first, second = self.plan["tasks"][:2]
        second["role"], second["scope"] = first["role"], first["scope"]
        with self.assertRaisesRegex(TeamError, "Same role"):
            compile_plan(self.plan)

    def test_output_alias_and_ancestor_conflicts(self):
        for path in ("research/facts.json", "RESEARCH/FACTS.JSON", "research", "research/facts.json/extra"):
            plan = copy.deepcopy(self.plan)
            plan["tasks"][1]["outputs"][0]["path"] = path
            with self.subTest(path=path), self.assertRaises(TeamError):
                compile_plan(plan)

    def test_sequential_tasks_cannot_take_over_same_output(self):
        self.plan["tasks"][2]["outputs"][0]["path"] = "research/facts.json"
        with self.assertRaises(TeamError): compile_plan(self.plan)

    def test_shared_readonly_inputs_are_allowed(self):
        self.assertEqual(self.plan["tasks"][0]["reads"], self.plan["tasks"][1]["reads"])
        self.assertTrue(compile_plan(self.plan)["valid"])

    def test_duplicate_artifact_ids_are_rejected(self):
        self.plan["tasks"][1]["outputs"][0]["id"] = "facts-data"
        with self.assertRaises(TeamError): compile_plan(self.plan)

    def test_all_goal_requirements_must_be_assigned(self):
        self.plan["goal"]["requirements"].append({"id": "R5", "text": "unassigned"})
        with self.assertRaisesRegex(TeamError, "Unassigned"): compile_plan(self.plan)

    def test_task_and_acceptance_requirements_are_bound(self):
        for action in ("unknown", "unchecked", "empty"):
            plan = copy.deepcopy(self.plan)
            if action == "unknown": plan["tasks"][0]["requirements"] = ["X"]
            elif action == "unchecked": plan["tasks"][0]["acceptance"][0]["requirement"] = "R2"
            else: plan["tasks"][0]["acceptance"] = []
            with self.subTest(action=action), self.assertRaises(TeamError): compile_plan(plan)

    def test_declared_input_dependency_is_required(self):
        self.plan["tasks"][2]["depends_on"] = ["facts"]
        with self.assertRaisesRegex(TeamError, "directly depend"): compile_plan(self.plan)

    def test_missing_dependency_and_cycle_are_rejected(self):
        for dep in ("missing", "audit"):
            plan = copy.deepcopy(self.plan)
            plan["tasks"][0]["depends_on"] = [dep]
            with self.subTest(dep=dep), self.assertRaises(TeamError): compile_plan(plan)

    def test_nonportable_paths_and_reserved_devices_are_rejected(self):
        for path in ("../escape", "/tmp/escape", "x\\y", "CON", "x//y", "x/../y", "x. ", ""):
            plan = copy.deepcopy(self.plan); plan["tasks"][0]["outputs"][0]["path"] = path
            with self.subTest(path=path), self.assertRaises((TeamError, ContractError)):
                compile_plan(plan)

    def test_policy_fields_are_bounded_and_strict(self):
        for field, value in (("max_parallel", True), ("max_attempts", 0), ("max_total_attempts", 1001), ("lease_seconds", 1)):
            plan = copy.deepcopy(self.plan); plan["policy"][field] = value
            with self.subTest(field=field), self.assertRaises(TeamError): compile_plan(plan)

    def test_unexpected_fields_do_not_silently_expand_authority(self):
        self.plan["tasks"][0]["shell_command"] = "echo never-run"
        with self.assertRaises(TeamError): compile_plan(self.plan)

    def test_goal_version_and_all_hashes_affect_identity(self):
        a = compile_plan(self.plan)
        self.plan["goal"]["version"] += 1
        b = compile_plan(self.plan)
        self.assertNotEqual(a["goal_digest"], b["goal_digest"])
        self.assertNotEqual(a["plan_digest"], b["plan_digest"])


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name); self.job = self.base / "job"
        self.plan = load_json(ROOT / "examples/team-demo/plan.json")
        TeamStore.create(self.job, self.plan, ROOT / "examples/team-demo")
        self.store = TeamStore(self.job); self.addCleanup(self.store.close)

    def result(self, tid="facts", packet=None):
        packet = packet or self.store.claim(tid, "worker-" + tid)
        self.store.bind(tid, packet["lease_token"], "fixture", "fixture-host-" + packet["lease_token"])
        result = fixture.run(packet)
        receipt = {"host_run_id": "fixture-host-" + packet["lease_token"], "mode": "fixture", "finished": True,
                   "task_id": tid, "lease_token": packet["lease_token"]}
        path = Path(packet["workspace"]) / "evidence" / "host.json"; write_json(path, receipt)
        result["host_run_id"] = receipt["host_run_id"]
        result["host_receipt"] = {"path": "evidence/host.json", "sha256": file_sha(path)}
        return packet, result

    def review(self, tid, result, decision="accept"):
        relative = "reviews/" + tid + "-" + result["result_id"] + ".txt"
        if not (self.job / relative).exists():
            (self.job / relative).write_text("Unit test fixture review only; no model quality claim.", encoding="utf-8")
        return {"task_id": tid, "result_id": result["result_id"], "result_digest": digest(result), "goal_digest": self.store.meta("goal_digest"),
                "reviewer": "coordinator", "decision": decision, "reason": "fixture review", "evidence_path": relative,
                "evidence_sha256": file_sha(self.job / relative)}

    def accept(self, tid="facts"):
        packet, result = self.result(tid); self.store.submit(result); self.store.review(self.review(tid, result)); return packet, result

    def expire(self, tid="facts"):
        self.store.db.execute("UPDATE tasks SET lease_until=0 WHERE id=?", (tid,))
        return self.store.reconcile()

    def recovery(self, packet, termination="confirmed_stopped", action="retry"):
        relative = "reviews/termination-" + packet["lease_token"] + ".json"
        ack = {"task_id": packet["task_id"], "lease_token": packet["lease_token"], "termination": termination}
        write_json(self.job / relative, ack)
        return {**ack, "evidence_path": relative, "evidence_sha256": file_sha(self.job / relative), "reason": "fixture termination confirmed", "action": action}

    def test_init_never_overwrites_existing_job(self):
        with self.assertRaises(TeamError): TeamStore.create(self.job, self.plan, ROOT / "examples/team-demo")
        self.assertTrue((self.job / "team.sqlite3").exists())

    def test_wrong_input_hash_fails_before_creating_state(self):
        plan = copy.deepcopy(self.plan); plan["inputs"][0]["sha256"] = "0" * 64
        with self.assertRaises(TeamError): TeamStore.create(self.base / "bad", plan, ROOT / "examples/team-demo")
        self.assertFalse((self.base / "bad").exists())

    def test_double_claim_is_rejected(self):
        self.store.claim("facts", "worker-a")
        with self.assertRaises(TeamError): self.store.claim("facts", "worker-b")

    def test_concurrent_claims_have_one_winner(self):
        def attempt(i):
            with TeamStore(self.job) as store:
                try: store.claim("facts", "worker-" + str(i)); return True
                except TeamError: return False
        with ThreadPoolExecutor(max_workers=12) as pool:
            results = list(pool.map(attempt, range(24)))
        self.assertEqual(sum(results), 1)
        self.assertEqual(self.store.row("facts")["attempt"], 1)

    def test_process_claim_race_has_one_winner(self):
        args = [sys.executable, "-B", str(ROOT / "scripts/team_runtime.py"), "claim", "--job", str(self.job), "--task", "facts", "--worker"]
        procs = [subprocess.Popen([*args, "process-" + str(i)], stdout=subprocess.PIPE, stderr=subprocess.PIPE) for i in range(6)]
        codes = []
        for proc in procs:
            proc.communicate(timeout=15); codes.append(proc.returncode)
        self.assertEqual(codes.count(0), 1)

    def test_downstream_waits_for_acceptance_not_just_completion(self):
        for tid in ("facts", "outline"):
            _, result = self.result(tid); self.store.submit(result)
        self.assertNotIn("page", self.store.ready())
        with self.assertRaises(TeamError): self.store.claim("page", "worker-page")
        for tid in ("facts", "outline"):
            result = json.loads(self.store.row(tid)["result"])
            self.store.review(self.review(tid, result))
        self.assertIn("page", self.store.ready())

    def test_claim_freezes_goal_contract_and_inputs(self):
        packet = self.store.claim("facts", "worker-a")
        self.assertEqual(packet["goal"], self.plan["goal"])
        self.assertEqual(packet["contract"], self.plan["tasks"][0])
        self.assertEqual(file_sha(packet["input_snapshots"][0]["path"]), self.plan["inputs"][0]["sha256"])
        self.assertIn("re-delegate or publish externally", packet["do_not"])

    def test_capacity_counts_uncertain_workers(self):
        # Two allowed slots; a lost worker must retain its slot.
        self.store.claim("facts", "worker-a"); self.store.claim("outline", "worker-b")
        self.expire("facts")
        self.assertEqual(self.store.row("facts")["status"], "uncertain")
        self.assertNotIn("facts", self.store.ready())
        self.assertEqual(self.store.status()["metrics"]["attempts"], 2)

    def test_heartbeat_requires_live_matching_token(self):
        packet = self.store.claim("facts", "worker-a")
        self.store.heartbeat("facts", packet["lease_token"])
        with self.assertRaises(TeamError): self.store.heartbeat("facts", "wrong")
        self.expire()
        with self.assertRaises(TeamError): self.store.heartbeat("facts", packet["lease_token"])

    def test_expiry_does_not_auto_requeue(self):
        packet = self.store.claim("facts", "worker-a")
        self.assertEqual(self.expire()["auto_requeued"], 0)
        with self.assertRaises(TeamError): self.store.claim("facts", "worker-b")
        self.store.recover(self.recovery(packet))
        replacement = self.store.claim("facts", "worker-b")
        self.assertNotEqual(packet["lease_token"], replacement["lease_token"])
        with self.assertRaises(TeamError): self.store.heartbeat("facts", packet["lease_token"])

    def test_recovery_needs_bound_termination_evidence(self):
        packet = self.store.claim("facts", "worker-a"); self.expire()
        request = self.recovery(packet); request["termination"] = "unknown"
        with self.assertRaises(TeamError): self.store.recover(request)
        request["termination"] = "confirmed_not_started"
        with self.assertRaises(TeamError): self.store.recover(request)

    def test_late_result_can_be_adopted_without_reexecution(self):
        packet, result = self.result(); self.expire()
        with self.assertRaises(TeamError): self.store.submit(result)
        self.store.recover(self.recovery(packet, action="adopt_finished"))
        self.store.submit(result); self.store.review(self.review("facts", result))
        self.assertEqual(self.store.row("facts")["attempt"], 1)

    def test_duplicate_result_is_idempotent_but_conflicting_payload_rejected(self):
        _, result = self.result(); self.store.submit(result)
        self.assertTrue(self.store.submit(result)["duplicate"])
        changed = copy.deepcopy(result); changed["concerns"] = ["changed"]
        with self.assertRaises(TeamError): self.store.submit(changed)
        self.store.review(self.review("facts", result))
        self.assertTrue(self.store.submit(result)["duplicate"])
        self.assertEqual(self.store.row("facts")["attempt"], 1)

    def test_old_goal_and_plan_digests_are_rejected(self):
        _, result = self.result()
        for field in ("goal_digest", "plan_digest"):
            altered = copy.deepcopy(result); altered[field] = "0" * 64
            with self.subTest(field=field), self.assertRaises(TeamError): self.store.submit(altered)

    def test_mutating_plan_file_blocks_dispatch(self):
        changed = copy.deepcopy(self.plan); changed["goal"]["objective"] = "drift"
        (self.job / "plan.json").write_text(json.dumps(changed), encoding="utf-8")
        with self.assertRaises(TeamError): self.store.claim("facts", "worker-a")
        self.assertFalse(self.store.status()["plan_integrity"])

    def test_input_snapshot_mutation_is_detected(self):
        packet, result = self.result()
        Path(packet["input_snapshots"][0]["path"]).write_text("tampered", encoding="utf-8")
        with self.assertRaisesRegex(TeamError, "brief"): self.store.submit(result)

    def test_central_input_artifact_mutation_blocks_claim(self):
        row = self.store.db.execute("SELECT storage FROM artifacts WHERE id='brief'").fetchone()
        (self.job / row[0]).write_text("changed", encoding="utf-8")
        with self.assertRaises(TeamError): self.store.claim("facts", "worker-a")

    def test_missing_extra_and_renamed_output_are_rejected(self):
        _, result = self.result()
        for action in ("missing", "extra", "renamed"):
            altered = copy.deepcopy(result)
            if action == "missing": altered["artifacts"] = []
            elif action == "extra": altered["artifacts"].append({"id": "not-owned", "path": "other.txt", "sha256": "0" * 64})
            else: altered["artifacts"][0]["path"] = "other.txt"
            with self.subTest(action=action), self.assertRaises(TeamError): self.store.submit(altered)

    def test_undeclared_file_on_disk_is_rejected(self):
        packet, result = self.result()
        (Path(packet["output_root"]) / "unassigned.txt").write_text("extra", encoding="utf-8")
        with self.assertRaises(TeamError): self.store.submit(result)

    def test_nonempty_output_does_not_substitute_for_current_hash(self):
        _, result = self.result(); result["artifacts"][0]["sha256"] = "0" * 64
        with self.assertRaises(TeamError): self.store.submit(result)

    def test_checks_cannot_be_omitted_or_claim_pass_without_execution(self):
        _, result = self.result()
        for action in ("omit", "not-executed", "stale", "evidence"):
            changed = copy.deepcopy(result)
            if action == "omit": changed["checks"] = []
            elif action == "not-executed": changed["checks"][0]["execution"] = "NOT_EXECUTED"
            elif action == "stale": changed["checks"][0]["subject_sha256"] = "0" * 64
            else: changed["checks"][0]["evidence_sha256"] = "0" * 64
            with self.subTest(action=action), self.assertRaises(TeamError): self.store.submit(changed)

    def test_host_receipt_must_belong_to_finished_bound_attempt(self):
        packet, result = self.result()
        path = Path(packet["workspace"]) / "evidence/host.json"
        receipt = load_json(path); receipt["finished"] = False
        path.write_text(json.dumps(receipt), encoding="utf-8")
        result["host_receipt"]["sha256"] = file_sha(path)
        with self.assertRaises(TeamError): self.store.submit(result)

    def test_no_external_side_effects_are_accepted(self):
        _, result = self.result(); result["external_actions"] = ["sent email"]
        with self.assertRaises(TeamError): self.store.submit(result)

    def test_worker_cannot_accept_own_work(self):
        _, result = self.result(); self.store.submit(result)
        review = self.review("facts", result); review["reviewer"] = "worker-facts"
        with self.assertRaises(TeamError): self.store.review(review)
        with self.assertRaises(TeamError): self.store.claim("outline", "coordinator")

    def test_stale_review_and_review_hash_rejected(self):
        _, result = self.result(); self.store.submit(result)
        for field in ("result_digest", "goal_digest", "evidence_sha256"):
            review = self.review("facts", result); review[field] = "0" * 64
            with self.subTest(field=field), self.assertRaises(TeamError): self.store.review(review)

    def test_failed_checks_and_unresolved_concerns_block_acceptance(self):
        _, result = self.result(); result["checks"][0]["outcome"] = "FAILED"
        self.store.submit(result)
        with self.assertRaises(TeamError): self.store.review(self.review("facts", result))
        self.store.review(self.review("facts", result, "rework"))
        _, second = self.result(); second["concerns"] = ["unresolved"]
        self.store.submit(second)
        with self.assertRaises(TeamError): self.store.review(self.review("facts", second))

    def test_changed_evidence_between_submit_and_review_is_rejected(self):
        packet, result = self.result(); self.store.submit(result)
        (Path(packet["workspace"]) / "evidence/worker-checks.json").write_text("changed", encoding="utf-8")
        with self.assertRaises(TeamError): self.store.review(self.review("facts", result))

    def test_rework_retains_ownership_changes_token_and_has_attempt_limit(self):
        tokens = []
        for _ in range(2):
            packet, result = self.result(); tokens.append(packet["lease_token"])
            self.store.submit(result); self.store.review(self.review("facts", result, "rework"))
        self.assertNotEqual(*tokens)
        self.assertEqual(self.store.row("facts")["status"], "blocked")
        with self.assertRaises(TeamError): self.store.claim("facts", "worker-more")

    def test_downstream_uses_accepted_artifacts_and_not_parent_history(self):
        self.accept("facts"); self.accept("outline")
        packet = self.store.claim("page", "worker-page")
        self.assertEqual({i["id"] for i in packet["input_snapshots"]}, {"facts-data", "outline-data"})
        self.assertNotIn("brief", {i["id"] for i in packet["input_snapshots"]})

    def test_tampered_published_artifact_blocks_completion_and_readers(self):
        self.accept("facts"); self.accept("outline")
        (self.job / "published/research/facts.json").write_text("tampered", encoding="utf-8")
        self.assertFalse(self.store.status()["completed"])
        self.assertTrue(self.store.status()["changed_artifacts"])
        with self.assertRaises(TeamError): self.store.claim("page", "worker-page")

    def test_symlink_output_is_not_accepted(self):
        packet, result = self.result()
        target = Path(packet["output_root"]) / result["artifacts"][0]["path"]
        original = target.read_bytes(); external = self.base / "outside.json"; external.write_bytes(original)
        target.unlink(); make_symlink_or_skip(self, target, external)
        with self.assertRaises((TeamError, ContractError)): self.store.submit(result)

    def test_goal_revision_fences_old_workers_and_requires_termination(self):
        packet, result = self.result()
        new = copy.deepcopy(self.plan); new["run_id"] = "second-run"; new["goal"]["version"] = 2
        self.store.supersede(digest(new["goal"]), "changed requirement")
        with self.assertRaises(TeamError): self.store.submit(result)
        with self.assertRaises(TeamError): self.store.claim("outline", "worker-outline")
        with self.assertRaises(TeamError): self.store.revise(self.base / "next", new, ROOT / "examples/team-demo")
        self.store.recover(self.recovery(packet))
        created = self.store.revise(self.base / "next", new, ROOT / "examples/team-demo")
        self.assertEqual(created["goal_digest"], digest(new["goal"]))
        with self.assertRaises(TeamError): self.store.revise(self.base / "again", new, ROOT / "examples/team-demo")

    def test_claim_and_launch_binding_are_distinct(self):
        packet = self.store.claim("facts", "worker-a")
        self.assertIsNone(self.store.row("facts")["host_run_id"])
        self.store.bind("facts", packet["lease_token"], "inline", "inline-explicit")
        with self.assertRaises(TeamError): self.store.bind("facts", packet["lease_token"], "native", "fake-second-host")

    def test_nonzero_host_exit_cannot_submit_success(self):
        packet, result = self.result()
        path = Path(packet["workspace"]) / "evidence/host.json"
        host = load_json(path); host["exit_code"] = 1
        path.write_text(json.dumps(host), encoding="utf-8")
        result["host_receipt"]["sha256"] = file_sha(path)
        with self.assertRaises(TeamError): self.store.submit(result)

    def test_post_acceptance_evidence_tampering_blocks_next_claim(self):
        packet, result = self.accept("facts"); self.accept("outline")
        (Path(packet["workspace"]) / "evidence/worker-checks.json").write_text("changed after acceptance", encoding="utf-8")
        self.assertTrue(self.store.status()["changed_evidence"])
        self.assertEqual(self.store.status()["ready"], [])
        with self.assertRaises(TeamError): self.store.claim("page", "page-worker")

    def test_post_acceptance_review_tampering_is_detected(self):
        _, result = self.accept("facts"); self.accept("outline")
        review = self.review("facts", result)
        (self.job / review["evidence_path"]).write_text("changed review", encoding="utf-8")
        self.assertTrue(self.store.status()["changed_evidence"])
        with self.assertRaises(TeamError): self.store.claim("page", "page-worker")

    def test_published_parent_symlink_cannot_write_outside_job(self):
        packet, result = self.result(); self.store.submit(result)
        outside = self.base / "outside"; outside.mkdir()
        make_symlink_or_skip(self, self.job / "published/research", outside, target_is_directory=True)
        with self.assertRaises((TeamError, ContractError)): self.store.review(self.review("facts", result))
        self.assertEqual(list(outside.iterdir()), [])

    def test_metrics_do_not_invent_cost_or_model_usage(self):
        metrics = self.store.status()["metrics"]
        self.assertIsNone(metrics["model_tokens"]); self.assertIsNone(metrics["model_cost"])
        self.assertEqual(metrics["attempts"], 0)


if __name__ == "__main__": unittest.main()
