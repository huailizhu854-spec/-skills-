"""Actual ledger-entry regression; synthetic host observations, never real calls."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import test_workbuddy_bridge as baseline
from team_runtime import TeamStore, TeamError, write_json
from delivery_state import begin_submission, dispatch, observe, resume_plan
from workbuddy_policy import freeze, checkpoint_readonly
from workbuddy_evidence import INTENT, RECORD, record_intent, record_return, check_record
from workbuddy_test_support import seed_capabilities, attach_call_evidence

class WorkBuddyRC5Tests(unittest.TestCase):
    setUp = baseline.WorkBuddyBridgeTests.setUp
    prepare = baseline.WorkBuddyBridgeTests.prepare
    begin_submit = baseline.WorkBuddyBridgeTests.begin_submit
    raw_evidence = baseline.WorkBuddyBridgeTests.raw_evidence
    event = baseline.WorkBuddyBridgeTests.event
    output = baseline.WorkBuddyBridgeTests.output
    review = baseline.WorkBuddyBridgeTests.review
    guarded_happy_path = baseline.WorkBuddyBridgeTests.guarded_happy_path

    def prepared(self):
        self.prepare();self.reservation=self.begin_submit()
        self.folder=Path(self.packet['workspace'])/'evidence'
        return self

    def assert_unbound(self):
        with TeamStore(self.job) as s:
            self.assertIsNone(s.row('impl')['mode'])
            self.assertEqual(dispatch(s,self.packet['lease_token'])['state'],'SUBMITTING')

    def lifecycle(self, event='succeeded', *, complete=True):
        if complete:
            n=self.event();raw=Path(self.packet['workspace'])/n['raw_evidence_path']
            ident=n['host_run_id'];tool=n['native_tool']
        else:
            raw=self.job/'reviews/unknown.txt';raw.write_bytes(self.reservation['request_key'].encode())
            ident=None;tool='Agent'
        return {'id':'life-'+event,'task_id':'impl','lease_token':self.packet['lease_token'],
            'request_key':self.reservation['request_key'],'goal_digest':self.packet['goal_digest'],
            'plan_digest':self.packet['plan_digest'],'event':event,'host_run_id':ident,'tool':tool,
            'evidence_path':raw.relative_to(self.job).as_posix(),'evidence_sha256':hashlib.sha256(raw.read_bytes()).hexdigest()}

    def test_missing_capability_rejected_before_claim(self):
        TeamStore.create(self.job,self.plan,self.inputs,offline_fixture=True)
        from host_adapters.workbuddy_mobile_cloud import WorkBuddyMobileCloudAdapter
        with self.assertRaisesRegex(TeamError,'Freeze current'):
            WorkBuddyMobileCloudAdapter(self.job).prepare('impl','worker')
        with TeamStore(self.job) as s:self.assertEqual(s.row('impl')['attempt'],0)
        self.assertEqual(list((self.job/'workers').iterdir()),[])

    def test_missing_record_rejected_by_direct_bind_without_state_change(self):
        self.prepared()
        with TeamStore(self.job) as s:
            with self.assertRaisesRegex(TeamError,'Required call evidence'):
                s.bind('impl',self.packet['lease_token'],'native','agent-direct')
        self.assert_unbound()

    def test_missing_intent_rejected_before_adapter_bind(self):
        self.prepared();e=self.event();(self.folder/INTENT).unlink()
        with self.assertRaisesRegex(TeamError,'Required call evidence'):self.adapter.bind_observed(e)
        self.assert_unbound()

    def test_missing_record_rejected_by_success_observe(self):
        self.prepared();e=self.lifecycle();(self.folder/RECORD).unlink()
        with TeamStore(self.job) as s:
            with self.assertRaisesRegex(TeamError,'Required call evidence'):observe(s,e)
        self.assert_unbound()

    def test_event_cannot_reference_copy_of_recorded_raw(self):
        self.prepared();e=self.event()
        copy=self.folder/'copied-return.txt';copy.write_bytes((self.folder/'workbuddy-raw-return.txt').read_bytes())
        e['raw_evidence_path']='evidence/copied-return.txt'
        with self.assertRaisesRegex(TeamError,'exact recorded raw'):self.adapter.bind_observed(e)
        self.assert_unbound()

    def test_event_cannot_change_tool_name(self):
        self.prepared();e=self.event();e['native_tool']='DifferentTool'
        with self.assertRaisesRegex(TeamError,'exact recorded raw'):self.adapter.bind_observed(e)
        self.assert_unbound()

    def test_success_observe_can_collect_but_does_not_claim_host_bound_event(self):
        self.prepared();e=self.lifecycle()
        with TeamStore(self.job) as s:
            self.assertEqual(observe(s,e)['state'],'SUCCEEDED')
            self.assertEqual(s.db.execute("SELECT COUNT(*) FROM events WHERE kind='HOST_BOUND'").fetchone()[0],0)
        self.output();result=self.adapter.collect_observed(self.event())
        self.assertTrue(result['submitted']);self.review()

    def test_duplicate_observe_rechecks_deleted_record(self):
        self.prepared();e=self.lifecycle()
        with TeamStore(self.job) as s:observe(s,e)
        (self.folder/RECORD).unlink()
        with TeamStore(self.job) as s:
            with self.assertRaisesRegex(TeamError,'Required call evidence'):observe(s,e)

    def test_duplicate_submit_rechecks_deleted_record(self):
        self.guarded_happy_path()
        with TeamStore(self.job) as s:result=json.loads(s.row('impl')['result'])
        (Path(self.packet['workspace'])/'evidence'/RECORD).unlink()
        with TeamStore(self.job) as s:
            with self.assertRaisesRegex(TeamError,'Required call evidence'):s.submit(result)
            self.assertEqual(s.db.execute("SELECT COUNT(*) FROM events WHERE kind='DUPLICATE_RECEIPT'").fetchone()[0],0)

    def test_accept_rechecks_record_and_does_not_publish_on_failure(self):
        self.guarded_happy_path();(Path(self.packet['workspace'])/'evidence'/RECORD).unlink()
        with self.assertRaisesRegex(TeamError,'Required call evidence'):self.review()
        self.assertFalse((self.job/'published/result.json').exists())
        with TeamStore(self.job) as s:self.assertEqual(s.row('impl')['status'],'submitted')

    def test_unknown_outcome_can_be_recorded_without_success_record(self):
        self.prepared()
        with TeamStore(self.job) as s:
            result=observe(s,self.lifecycle('unknown',complete=False))
            self.assertEqual(result['state'],'UNKNOWN')
            self.assertEqual(s.row('impl')['status'],'uncertain')
            self.assertEqual(s.row('impl')['token'],self.packet['lease_token'])
        self.assertFalse((self.folder/RECORD).exists())

    def test_failed_outcome_can_be_recorded_without_success_record(self):
        self.prepared();raw=self.job/'reviews/failure.txt';raw.write_text('agent-failed: synthetic failure',encoding='utf-8')
        e=self.lifecycle('unknown',complete=False);e.update(id='failure',event='failed',host_run_id='agent-failed',
            evidence_path=raw.relative_to(self.job).as_posix(),evidence_sha256=hashlib.sha256(raw.read_bytes()).hexdigest())
        with TeamStore(self.job) as s:self.assertEqual(observe(s,e)['state'],'FAILED')

    def test_expired_capabilities_block_begin_without_reservation(self):
        self.prepare()
        with patch('workbuddy_policy.time',SimpleNamespace(time=lambda:time.time()+7200)):
            with self.assertRaisesRegex(TeamError,'expired'):self.begin_submit()
        with TeamStore(self.job) as s:self.assertEqual(dispatch(s,self.packet['lease_token'])['guarded'],0)

    def test_capability_expiry_does_not_invalidate_accepted_result(self):
        self.guarded_happy_path();self.review()
        with patch('workbuddy_policy.time',SimpleNamespace(time=lambda:time.time()+7200)):
            with TeamStore(self.job) as s:self.assertEqual(s.status()['changed_evidence'],[])

    def test_capabilities_cannot_change_after_claim(self):
        self.prepare();p=self.job/'reviews/offline-capabilities.json';v=json.loads(p.read_bytes());v['native_tool']='changed';p.write_text(json.dumps(v))
        with self.assertRaisesRegex(TeamError,'Frozen capability record changed'):self.begin_submit()

    def test_profile_and_instructions_never_authorize_live_call_for_fixture(self):
        self.prepared()
        self.assertEqual(self.desc['execution_profile'],'offline_fixture')
        self.assertIn('no real host',self.desc['next'])
        self.assertIn('do not call a real host',self.reservation['authorization'])
        self.assertTrue((self.folder/'workbuddy-delegation.md').read_bytes().startswith(b'OFFLINE SYNTHETIC'))
        with TeamStore(self.job) as s:self.assertEqual(s.status()['execution_profile'],'offline_fixture')

    def test_new_delegation_is_lf_and_exact_prompt_roundtrip(self):
        self.prepared();raw=(self.folder/'workbuddy-delegation.md').read_bytes()
        self.assertNotIn(b'\r\n',raw);self.assertIn(b'\n',raw)
        self.event();self.assertTrue(check_record(self.job,Path(self.desc['packet_path']))['record_consistency_passed'])

    def test_existing_crlf_delegation_is_readable_without_rewriting(self):
        self.prepared()
        # Construct an old-style *synthetic* Windows dispatch before its initial
        # intent. This is not a migration of existing evidence.
        path=self.folder/'workbuddy-delegation.md';data=path.read_bytes().replace(b'\n',b'\r\n');path.write_bytes(data)
        dp=self.folder/'native-dispatch.json';d=json.loads(dp.read_bytes());d['delegation_sha256']=hashlib.sha256(data).hexdigest();dp.write_text(json.dumps(d))
        self.event();self.assertTrue(check_record(self.job,Path(self.desc['packet_path']))['record_consistency_passed'])
        self.assertEqual(path.read_bytes(),data)

    def test_changed_whitespace_is_not_normalized_away(self):
        self.prepared();self.event();args=self.folder/'fixture-arguments.json';v=json.loads(args.read_bytes());v['prompt']+=' '
        args.write_text(json.dumps(v));ip=self.folder/INTENT;i=json.loads(ip.read_bytes())
        i['files']['arguments']['sha256']=hashlib.sha256(args.read_bytes()).hexdigest();ip.write_text(json.dumps(i))
        rp=self.folder/RECORD;r=json.loads(rp.read_bytes());r['files']['intent']['sha256']=hashlib.sha256(ip.read_bytes()).hexdigest();rp.write_text(json.dumps(r))
        with self.assertRaisesRegex(TeamError,'prompt'):check_record(self.job,Path(self.desc['packet_path']))

    def test_valid_call_inside_existing_sqlite_transaction(self):
        self.prepared();self.event()
        with TeamStore(self.job) as s:
            with s.transaction():
                # Uncommitted event visible to checker without opening a second DB.
                s.db.execute("UPDATE dispatch34 SET updated=updated+1 WHERE token=?",(self.packet['lease_token'],))
                self.assertTrue(check_record(self.job,Path(self.desc['packet_path']),store=s)['record_consistency_passed'])

    def test_historical_job_is_readonly_across_business_writes(self):
        self.prepared();self.event()
        with TeamStore(self.job) as s:s.db.execute("DELETE FROM meta WHERE key='workbuddy_policy_version'")
        before=(self.job/'team.sqlite3').read_bytes()
        with TeamStore(self.job) as s:
            calls=[lambda:s.claim('audit','worker'),lambda:s.bind('impl',self.packet['lease_token'],'native','agent-old'),
                s.reconcile,lambda:s.heartbeat('impl',self.packet['lease_token']),
                lambda:s.event('FORGED'),lambda:begin_submission(s,'impl',self.packet['lease_token'])]
            for call in calls:
                with self.subTest(call=call),self.assertRaisesRegex(TeamError,'read-only'):call()
            self.assertTrue(s.status()['workbuddy_legacy_read_only'])
            self.assertFalse(checkpoint_readonly(s)['persisted'])
            self.assertEqual(resume_plan(s)['host_queries_executed'],0)
        self.assertEqual((self.job/'team.sqlite3').read_bytes(),before)
        # Read-only provenance checks remain available, writes cannot backfill.
        self.assertTrue(check_record(self.job,Path(self.desc['packet_path']))['record_consistency_passed'])
        with self.assertRaisesRegex(TeamError,'read-only'):
            record_return(self.job,Path(self.desc['packet_path']),self.folder/'workbuddy-raw-return.txt','completed')

    def test_event_cli_cannot_write_into_historical_job(self):
        self.prepared();self.event()
        with TeamStore(self.job) as store:
            store.db.execute("DELETE FROM meta WHERE key='workbuddy_policy_version'")
        before=(self.job/'team.sqlite3').read_bytes()
        target=self.folder/'forbidden-new-event.json'
        run=subprocess.run([sys.executable,'-B',str(baseline.ROOT/'scripts/workbuddy_bridge.py'),
            'event','--packet',self.desc['packet_path'],'--raw-return-file',str(self.folder/'workbuddy-raw-return.txt'),
            '--observed-outcome','completed','--out',str(target)],capture_output=True,text=True)
        self.assertNotEqual(run.returncode,0)
        self.assertIn('read-only',run.stderr)
        self.assertFalse(target.exists())
        self.assertEqual((self.job/'team.sqlite3').read_bytes(),before)

    def test_capability_target_requires_nonempty_os(self):
        self.prepare()
        from host_contract34 import evaluate_probe
        p=json.loads((self.job/'reviews/offline-capabilities.json').read_bytes())['probe']
        for value in [None,'',[],{},'UNKNOWN']:
            with self.subTest(value=value):
                bad=dict(p);bad['os']=value
                with self.assertRaisesRegex(TeamError,'operating system|nonempty strings'):
                    evaluate_probe(bad,self.job,allow_unknown_client='workbuddy_mobile_cloud',fixture_host='workbuddy_mobile_cloud')

    def test_live_job_cannot_freeze_fixture_capabilities(self):
        TeamStore.create(self.job,self.plan,self.inputs)
        with self.assertRaisesRegex(TeamError,'separate job profiles'):seed_capabilities(self.job)
        with TeamStore(self.job) as s:self.assertEqual(s.row('impl')['attempt'],0)

    def test_file_tools_need_actual_evidence(self):
        self.prepare()
        from workbuddy_policy import _validate
        v=json.loads((self.job/'reviews/offline-capabilities.json').read_bytes())
        v['file_tools']['file.write']['status']='unknown'
        with TeamStore(self.job) as s:
            with self.assertRaisesRegex(TeamError,'file.write'):_validate(s,v,now=time.time())

if __name__=='__main__':unittest.main()
