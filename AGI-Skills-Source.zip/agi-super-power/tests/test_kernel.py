"""Behavioral and adversarial checks for the local contract kernel."""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from fs_test_support import make_symlink_or_skip
from unittest.mock import patch


KERNEL_PATH = Path(__file__).resolve().parents[1] / "scripts" / "kernel.py"
SPEC = importlib.util.spec_from_file_location("agi_super_power_kernel", KERNEL_PATH)
assert SPEC and SPEC.loader
kernel = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(kernel)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def role() -> dict:
    return {
        "schema_version": 1, "name": "general-specialist", "title": "General specialist",
        "mission": "Deliver an evidence-backed result", "trigger": "A bounded task needs a repeatable SOP",
        "inputs": ["request"], "outputs": ["deliverable"], "steps": ["Execute", "Verify"],
        "acceptance": [{"id": "A1", "requirement": "Output exists", "method": "Inspect artifact", "evidence_kind": "SOURCE_FACT"}],
        "tools": [], "boundaries": ["Respect the task scope"], "sources": [],
    }


def plan(*tasks: dict) -> dict:
    return {"tasks": list(tasks)}


def task(name: str, dependencies: list[str] | None = None, writes: list[str] | None = None) -> dict:
    return {"id": name, "depends_on": dependencies or [], "writes": writes or []}


class ContractTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        (self.root / "result.txt").write_bytes(b"current deliverable\n")
        (self.root / "evidence.txt").write_bytes(b"local inspection receipt\n")
        self.artifact_hash = digest((self.root / "result.txt").read_bytes())
        self.run = {
            "schema_version": 1, "task_id": "TASK-1", "role": "general-specialist",
            "objective": "Deliver the requested file", "mode": "inline", "status": "completed",
            "agent_id": None, "requirements": [{"id": "REQ-1", "required": True}],
            "artifacts": [{"path": "result.txt", "sha256": self.artifact_hash}],
            "gates": [{"id": "GATE-1", "requirement_id": "REQ-1", "required": True,
                       "execution": "EXECUTED", "outcome": "PASS", "evidence_kind": "SOURCE_FACT",
                       "subject_sha256": self.artifact_hash, "evidence_path": "evidence.txt",
                       "method": "Read and compare with requirement", "executed_at": "2026-09-19T01:00:00Z"}],
            "blockers": [], "external_actions": [], "next_action": None,
        }

    def check_run(self, value: dict | None = None) -> dict:
        return kernel.validate_run(self.run if value is None else value, self.root)

    def assert_code(self, report: dict, code: str) -> None:
        self.assertFalse(report["valid"], report)
        self.assertIn(code, [error["code"] for error in report["errors"]], report)

    def test_valid_role(self) -> None:
        self.assertTrue(kernel.validate_role(role())["valid"])

    def test_role_empty_arrays_and_name(self) -> None:
        for field, value, code in [("steps", [], "STRING_LIST_REQUIRED"), ("name", "A Role", "ROLE_NAME"), ("name", "a" * 64, "ROLE_NAME"), ("schema_version", True, "SCHEMA_VERSION")]:
            with self.subTest(field=field, value=value):
                candidate = role(); candidate[field] = value
                self.assert_code(kernel.validate_role(candidate), code)

    def test_role_nested_malformed_types(self) -> None:
        for value in (None, 1, {}, [None], [{"id": [], "requirement": 1, "method": [], "evidence_kind": {}}]):
            with self.subTest(value=value):
                candidate = role(); candidate["acceptance"] = value
                self.assertFalse(kernel.validate_role(candidate)["valid"])

    def test_role_duplicate_acceptance_ids(self) -> None:
        candidate = role(); candidate["acceptance"] *= 2
        self.assert_code(kernel.validate_role(candidate), "DUPLICATE_ID")

    def test_valid_completed_run(self) -> None:
        report = self.check_run()
        self.assertTrue(report["valid"], report)
        self.assertEqual(report["checked_artifacts"][0]["sha256"], self.artifact_hash)
        self.assertEqual(report["covered_required_requirements"], ["REQ-1"])

    def test_valid_delegated_run_records_identifier_without_claiming_startup(self) -> None:
        self.run.update(mode="delegated", agent_id="observed-host-agent-1")
        report = self.check_run()
        self.assertTrue(report["valid"], report)
        self.assertTrue(any("startup" in note for note in report["limitations"]))

    def test_delegation_requires_agent_id(self) -> None:
        self.run["mode"] = "delegated"
        self.assert_code(self.check_run(), "DELEGATION_UNBOUND")

    def test_pass_requires_executed(self) -> None:
        for value in ("NOT_EXECUTED", "SKIPPED", "NOT_APPLICABLE"):
            with self.subTest(value=value):
                self.run["gates"][0]["execution"] = value
                self.assert_code(self.check_run(), "PASS_NOT_EXECUTED")

    def test_inference_or_unknown_cannot_pass(self) -> None:
        for kind in ("INFERENCE", "UNKNOWN"):
            with self.subTest(kind=kind):
                self.run["gates"][0]["evidence_kind"] = kind
                self.assert_code(self.check_run(), "PASS_WITHOUT_FACT")

    def test_runtime_method_is_required_but_not_semantically_certified(self) -> None:
        self.run["gates"][0].update(evidence_kind="RUNTIME_FACT", method="")
        self.assert_code(self.check_run(), "PASS_WITHOUT_METHOD")

    def test_stale_artifact_and_old_gate_are_rejected(self) -> None:
        (self.root / "result.txt").write_bytes(b"different artifact")
        report = self.check_run()
        self.assert_code(report, "ARTIFACT_HASH_MISMATCH")
        self.assert_code(report, "STALE_SUBJECT")

    def test_gate_old_hash_rejected_after_manifest_update(self) -> None:
        (self.root / "result.txt").write_bytes(b"new build")
        self.run["artifacts"][0]["sha256"] = digest(b"new build")
        self.assert_code(self.check_run(), "STALE_SUBJECT")

    def test_missing_empty_or_directory_evidence(self) -> None:
        for path in ("missing.txt", "empty.txt", "folder"):
            with self.subTest(path=path):
                (self.root / "empty.txt").write_bytes(b"")
                (self.root / "folder").mkdir(exist_ok=True)
                self.run["gates"][0]["evidence_path"] = path
                self.assert_code(self.check_run(), "FILE_BINDING_INVALID")

    def test_empty_artifact(self) -> None:
        (self.root / "result.txt").write_bytes(b"")
        self.run["artifacts"][0]["sha256"] = digest(b"")
        self.assert_code(self.check_run(), "FILE_BINDING_INVALID")

    def test_traversal_absolute_ads_and_device_paths(self) -> None:
        invalid = ["../outside.txt", "/outside.txt", "C:/outside.txt", "a\\b", "a/../b", "a//b", "result.txt:stream", "NUL.txt", "aux/file", "x./file", "./result.txt", "../", "a/\u202eb"]
        for value in invalid:
            with self.subTest(value=value):
                self.run["gates"][0]["evidence_path"] = value
                self.assert_code(self.check_run(), "FILE_BINDING_INVALID")

    def test_file_symlink_is_rejected(self) -> None:
        link = self.root / "link.txt"
        make_symlink_or_skip(self, link, self.root / "evidence.txt")
        self.run["gates"][0]["evidence_path"] = "link.txt"
        self.assert_code(self.check_run(), "FILE_BINDING_INVALID")

    def test_directory_symlink_cannot_escape_root(self) -> None:
        outside = tempfile.TemporaryDirectory(); self.addCleanup(outside.cleanup)
        (Path(outside.name) / "secret.txt").write_bytes(b"never read through link")
        make_symlink_or_skip(self, self.root / "linked", outside.name, target_is_directory=True)
        self.run["gates"][0]["evidence_path"] = "linked/secret.txt"
        self.assert_code(self.check_run(), "FILE_BINDING_INVALID")

    def test_simulated_link_or_reparse_evidence_is_rejected_before_open(self) -> None:
        # Exercises rejection on hosts unable to create links. This is a simulated
        # filesystem check, not a substitute for the two real-link tests above.
        original_lstat = Path.lstat
        target = self.root / "evidence.txt"
        for is_reparse in (False, True):
            with self.subTest(is_reparse=is_reparse):
                def fake_lstat(path, *args, **kwargs):
                    actual = original_lstat(path, *args, **kwargs)
                    if path == target:
                        return SimpleNamespace(st_mode=actual.st_mode if is_reparse else kernel.stat.S_IFLNK,
                                               st_file_attributes=0x400 if is_reparse else 0)
                    return actual
                with patch.object(Path, "lstat", fake_lstat), patch.object(kernel.os, "open", side_effect=AssertionError("Unsafe file must not be opened")):
                    with self.assertRaises(kernel.ContractError):
                        kernel.local_file(self.root, "evidence.txt")

    def test_case_variant_parent_escape_and_unc_are_rejected_before_open(self) -> None:
        for value in ("../ROOT/result.txt", "//server/share/file", "\\\\server\\share\\file", "c:relative.txt", "C:/Root/../outside.txt"):
            with self.subTest(value=value):
                with patch.object(kernel.os, "open", side_effect=AssertionError("Unsafe file must not be opened")):
                    with self.assertRaises(kernel.ContractError):
                        kernel.local_file(self.root, value)

    def test_artifact_path_collision(self) -> None:
        self.run["artifacts"].append(copy.deepcopy(self.run["artifacts"][0]))
        self.assert_code(self.check_run(), "PATH_COLLISION")

    def test_completed_requires_artifact_and_requirement_coverage(self) -> None:
        self.run["artifacts"] = []; self.run["gates"] = []
        report = self.check_run()
        self.assert_code(report, "COMPLETED_WITHOUT_ARTIFACT")
        self.assert_code(report, "REQUIREMENT_UNCOVERED")

    def test_optional_gate_does_not_cover_required_requirement(self) -> None:
        self.run["gates"][0]["required"] = False
        self.assert_code(self.check_run(), "REQUIREMENT_UNCOVERED")

    def test_required_gate_cannot_be_waived_for_completion(self) -> None:
        for outcome in ("FAILED", "BLOCKED", "UNVERIFIED", "ACCEPTED_RISK"):
            with self.subTest(outcome=outcome):
                self.run["gates"][0]["outcome"] = outcome
                self.assert_code(self.check_run(), "REQUIRED_GATE_NOT_PASS")

    def test_duplicate_ids_unknown_requirement_and_real_boolean(self) -> None:
        self.run["requirements"].append({"id": "REQ-1", "required": 1})
        self.run["gates"][0]["requirement_id"] = "missing"
        report = self.check_run()
        for code in ("DUPLICATE_ID", "UNKNOWN_REQUIREMENT", "BOOLEAN_REQUIRED"):
            self.assert_code(report, code)

    def test_malformed_run_fields_do_not_crash(self) -> None:
        for field, value in [("mode", []), ("status", {}), ("role", 4), ("requirements", [None]), ("artifacts", [5]), ("gates", [{"id": [], "required": [], "execution": {}, "outcome": [], "evidence_kind": []}]), ("blockers", 1), ("external_actions", [None]), ("next_action", {})]:
            with self.subTest(field=field):
                candidate = copy.deepcopy(self.run); candidate[field] = value
                self.assertFalse(self.check_run(candidate)["valid"])

    def test_timestamps_are_utc_and_calendar_valid(self) -> None:
        for value in (None, "2026-09-19", "2026-09-19T01:00:00+08:00", "2026-02-30T01:00:00Z", "2026-09-19T01:00:00", "2026-09-19T25:00:00Z"):
            with self.subTest(value=value):
                self.run["gates"][0]["executed_at"] = value
                self.assert_code(self.check_run(), "PASS_WITHOUT_TIME")

    def test_unexecuted_planned_gate_can_be_honest(self) -> None:
        self.run.update(status="planned", artifacts=[], next_action="Create deliverable")
        self.run["gates"][0].update(execution="NOT_EXECUTED", outcome="UNVERIFIED", evidence_kind="UNKNOWN", subject_sha256=None, evidence_path=None, method=None, executed_at=None)
        self.assertTrue(self.check_run()["valid"])

    def test_completed_with_blockers_fails(self) -> None:
        self.run["blockers"] = ["Missing final review"]
        self.assert_code(self.check_run(), "COMPLETED_WITH_BLOCKERS")

    def test_root_invalid(self) -> None:
        self.assert_code(kernel.validate_run(self.run, self.root / "missing"), "ROOT_INVALID")

    def test_dag_independent_and_ordered_writes(self) -> None:
        candidate = plan(task("a", writes=["src/"]), task("b", ["a"], ["src/main.py"]), task("c", writes=["docs/"]))
        report = kernel.check_dag(candidate)
        self.assertTrue(report["valid"], report)
        self.assertEqual(report["waves"], [["a", "c"], ["b"]])
        self.assertEqual(report["tasks_executed"], 0)

    def test_dag_missing_dependency(self) -> None:
        self.assert_code(kernel.check_dag(plan(task("a", ["absent"]))), "DEPENDENCY_MISSING")

    def test_dag_cycle_and_self_cycle(self) -> None:
        for candidate in (plan(task("a", ["b"]), task("b", ["a"])), plan(task("a", ["a"]))):
            self.assert_code(kernel.check_dag(candidate), "DEPENDENCY_CYCLE")

    def test_dag_duplicate_id_and_malformed_fields(self) -> None:
        self.assert_code(kernel.check_dag(plan(task("a"), task("a"))), "DUPLICATE_ID")
        for candidate in (None, [], {"tasks": None}, plan(None), plan({"id": {}, "depends_on": {}, "writes": [None]})):
            self.assertFalse(kernel.check_dag(candidate)["valid"])

    def test_dag_case_and_ancestor_write_conflicts(self) -> None:
        for left, right in [("src/main.py", "SRC/Main.py"), ("src", "src/main.py"), ("src/main.py", "src/"), ("cafe\u0301.txt", "caf\u00e9.txt")]:
            with self.subTest(left=left, right=right):
                self.assert_code(kernel.check_dag(plan(task("a", writes=[left]), task("b", writes=[right]))), "WRITE_CONFLICT")

    def test_dag_prefix_without_separator_does_not_conflict(self) -> None:
        report = kernel.check_dag(plan(task("a", writes=["src"]), task("b", writes=["src-old/main.py"])))
        self.assertTrue(report["valid"], report)

    def test_dag_write_escape(self) -> None:
        self.assert_code(kernel.check_dag(plan(task("a", writes=["../outside"]))), "WRITE_PATH_INVALID")

    def test_cli_duplicate_keys_and_nan_return_json_failure(self) -> None:
        for text in ('{"tasks":[],"tasks":[]}', '{"tasks": NaN}', '{bad', 'null', '[]'):
            with self.subTest(text=text):
                source = self.root / "input.json"; source.write_text(text, encoding="utf-8")
                process = subprocess.run([sys.executable, "-B", str(KERNEL_PATH), "check-dag", str(source)], capture_output=True, text=True)
                self.assertEqual(process.returncode, 1)
                self.assertFalse(json.loads(process.stdout)["valid"])
                self.assertNotIn("Traceback", process.stderr)

    def test_cli_valid_run_returns_hash_bound_receipt(self) -> None:
        source = self.root / "run.json"; source.write_text(json.dumps(self.run), encoding="utf-8")
        process = subprocess.run([sys.executable, "-B", str(KERNEL_PATH), "validate-run", str(source), "--root", str(self.root)], capture_output=True, text=True)
        self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
        self.assertEqual(json.loads(process.stdout)["outcome"], "PASS")


if __name__ == "__main__":
    unittest.main(verbosity=2)
