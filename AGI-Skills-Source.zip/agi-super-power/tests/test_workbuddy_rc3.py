"""Offline provenance regressions. No host calls or historical evidence edits."""
import json
from pathlib import Path
import subprocess
import sys
import unittest
import test_workbuddy_bridge as baseline
from team_runtime import TeamError
from workbuddy_evidence import record_intent, record_return, check_record, INTENT, RECORD


class WorkBuddyRC3Tests(unittest.TestCase):
    setUp = baseline.WorkBuddyBridgeTests.setUp
    prepare = baseline.WorkBuddyBridgeTests.prepare
    begin_submit = baseline.WorkBuddyBridgeTests.begin_submit
    raw_evidence = baseline.WorkBuddyBridgeTests.raw_evidence

    def setup_call(self, reserve=True):
        self.prepare()
        self.packet_path = Path(self.desc['packet_path'])
        self.evidence = Path(self.packet['workspace']) / 'evidence'
        self.auth = self.evidence / 'authorization.json'
        self.args = self.evidence / 'call-arguments.json'
        self.submit = self.evidence / 'begin-submit.json'
        self.auth.write_text(json.dumps({'schema_version': 1, 'job': str(self.job),
            'plan_digest': self.packet['plan_digest'], 'instruction': 'Offline test fixture only.',
            'source_kind': 'coordinator_transcription', 'source_ref': None, 'message_time': None,
            'previous_job': None, 'source_file': None}))
        self.args.write_text(json.dumps({'prompt': (self.evidence / 'workbuddy-delegation.md').read_bytes().decode('utf-8'),
                                         'description': 'Offline fixture'}))
        self.submit.write_text(json.dumps(self.begin_submit() if reserve else {}))

    def intent(self):
        return record_intent(self.job, self.packet_path, self.auth, self.args, self.submit)

    def test_successful_record_is_not_host_or_authorization_attestation(self):
        self.setup_call(); before = (self.job / 'team.sqlite3').read_bytes()
        self.intent(); raw = self.raw_evidence()
        _, value = record_return(self.job, self.packet_path, raw, 'completed')
        report = check_record(self.job, self.packet_path)
        self.assertTrue(report['record_consistency_passed'])
        self.assertEqual(report['real_host_verdict'], 'REQUIRES_HOST_TRACE_REVIEW')
        self.assertEqual(report['authorization_verdict'], 'REQUIRES_SOURCE_REVIEW')
        self.assertEqual(value['host_trace_status'], 'NOT_AVAILABLE')
        self.assertIsNone(value['tool_call_id']); self.assertIsNone(value['host_task_id'])
        self.assertEqual((self.job / 'team.sqlite3').read_bytes(), before)

    def test_missing_reservation_fails(self):
        self.setup_call(reserve=False)
        with self.assertRaises(TeamError): self.intent()

    def test_changed_planned_prompt_rejected(self):
        self.setup_call(); self.args.write_text(json.dumps({'prompt': 'Wrong or old delegation'}))
        with self.assertRaisesRegex(TeamError, 'Planned tool prompt'): self.intent()

    def test_changed_delegation_and_matching_args_still_rejected(self):
        self.setup_call()
        (self.evidence / 'workbuddy-delegation.md').write_text('Changed after prepare')
        self.args.write_text(json.dumps({'prompt': 'Changed after prepare'}))
        with self.assertRaisesRegex(TeamError, 'Prepared dispatch'): self.intent()

    def test_wrong_job_authorization_rejected(self):
        self.setup_call(); value = json.loads(self.auth.read_text()); value['job'] += '-old'
        self.auth.write_text(json.dumps(value))
        with self.assertRaisesRegex(TeamError, 'Authorization record'): self.intent()

    def test_mismatched_submission_key_rejected(self):
        self.setup_call(); value = json.loads(self.submit.read_text()); value['request_key'] = 'wrong'
        self.submit.write_text(json.dumps(value))
        with self.assertRaisesRegex(TeamError, 'Submission output'): self.intent()

    def test_export_claim_requires_source_file(self):
        self.setup_call(); value = json.loads(self.auth.read_text()); value['source_kind'] = 'conversation_export'
        self.auth.write_text(json.dumps(value))
        with self.assertRaisesRegex(TeamError, 'requires its actual file'): self.intent()

    def test_attached_trace_never_promotes_provenance(self):
        self.setup_call(); self.intent(); trace = self.evidence / 'fixture-trace.txt'
        trace.write_text('Offline trace fixture, not a real tool invocation')
        _, value = record_return(self.job, self.packet_path, self.raw_evidence(), 'completed',
                                 'call-fixture', trace)
        self.assertEqual(value['host_trace_status'], 'ATTACHED_UNVERIFIED')
        self.assertEqual(check_record(self.job, self.packet_path)['real_host_verdict'], 'REQUIRES_HOST_TRACE_REVIEW')

    def test_agent_id_token_and_request_key_cannot_be_tool_call_id(self):
        self.setup_call(); _, intent = self.intent(); raw = self.raw_evidence()
        for value in ['agent-670eea937b1a42ed', self.packet['lease_token'], intent['identity']['request_key'], 'impl']:
            with self.subTest(value=value), self.assertRaises(TeamError):
                record_return(self.job, self.packet_path, raw, 'completed', value)

    def test_write_once_files_prevent_rewriting_history(self):
        self.setup_call(); path, _ = self.intent(); original = path.read_bytes()
        with self.assertRaises(FileExistsError): self.intent()
        self.assertEqual(path.read_bytes(), original)
        raw = self.raw_evidence(); path, _ = record_return(self.job, self.packet_path, raw, 'completed')
        original = path.read_bytes()
        with self.assertRaises(FileExistsError): record_return(self.job, self.packet_path, raw, 'completed')
        self.assertEqual(path.read_bytes(), original)

    def test_mutated_arguments_and_raw_evidence_rejected(self):
        self.setup_call(); self.intent(); raw = self.raw_evidence()
        record_return(self.job, self.packet_path, raw, 'completed')
        original = self.args.read_bytes(); self.args.write_text('{}')
        with self.assertRaises(TeamError): check_record(self.job, self.packet_path)
        self.args.write_bytes(original); raw.write_text('Altered return')
        with self.assertRaises(TeamError): check_record(self.job, self.packet_path)

    def test_raw_crlf_is_preserved(self):
        self.setup_call(); self.intent(); raw = self.raw_evidence()
        raw.write_bytes(b'Fixture return\r\n[Agent ID: agent-fixture]\r\n')
        original = raw.read_bytes(); record_return(self.job, self.packet_path, raw, 'completed')
        self.assertTrue(check_record(self.job, self.packet_path)['bind_eligible'])
        self.assertEqual(raw.read_bytes(), original)

    def test_unknown_outcome_is_recorded_without_bind_or_new_id(self):
        self.setup_call(); self.intent()
        _, value = record_return(self.job, self.packet_path, self.raw_evidence('Connection interrupted'), 'outcome_unknown')
        self.assertFalse(value['bind_eligible']); self.assertIsNone(value['host_run_id'])
        self.assertEqual(value['normalized_status'], 'EXECUTION_OUTCOME_UNKNOWN')
        self.assertFalse(check_record(self.job, self.packet_path)['bind_eligible'])

    def test_missing_id_remains_unbindable(self):
        self.setup_call(); self.intent()
        _, value = record_return(self.job, self.packet_path, self.raw_evidence('Fixture finished without footer'), 'completed')
        self.assertFalse(value['bind_eligible']); self.assertIsNone(value['host_run_id'])

    def test_outside_file_rejected_without_symlink_privilege(self):
        self.setup_call(); outside = Path(self.temp.name) / 'outside-only.json'; outside.write_bytes(self.auth.read_bytes())
        with self.assertRaises(ValueError):
            record_intent(self.job, self.packet_path, outside, self.args, self.submit)

    def test_symlink_and_outside_file_rejected(self):
        self.setup_call(); outside = Path(self.temp.name) / 'outside.json'; outside.write_bytes(self.auth.read_bytes())
        with self.assertRaises(ValueError):
            record_intent(self.job, self.packet_path, outside, self.args, self.submit)
        self.auth.unlink()
        from fs_test_support import make_symlink_or_skip
        make_symlink_or_skip(self, self.auth, outside)
        with self.assertRaises(ValueError): self.intent()

    def test_forged_local_pass_is_rejected(self):
        self.setup_call(); self.intent()
        path, value = record_return(self.job, self.packet_path, self.raw_evidence(), 'completed')
        value['real_host_verdict'] = 'PASS'; path.write_text(json.dumps(value))
        with self.assertRaises(TeamError): check_record(self.job, self.packet_path)

    def test_record_rechecks_identifier_and_trace_status(self):
        self.setup_call(); self.intent()
        path, value = record_return(self.job, self.packet_path, self.raw_evidence(), 'completed')
        for key, altered in [('tool_call_id', value['host_run_id']), ('host_task_id', 'made-up'),
                             ('host_trace_status', 'VERIFIED')]:
            bad = dict(value); bad[key] = altered; path.write_text(json.dumps(bad))
            with self.subTest(key=key), self.assertRaises(TeamError):
                check_record(self.job, self.packet_path)

    def test_cli_records_and_checks_without_host_tools(self):
        self.setup_call()
        base = [sys.executable, '-B', str(baseline.ROOT / 'scripts/workbuddy_evidence.py')]
        common = ['--job', str(self.job), '--packet', str(self.packet_path)]
        commands = [base + ['intent'] + common + ['--authorization-file', str(self.auth),
                    '--arguments-file', str(self.args), '--submission-file', str(self.submit)],
                    base + ['return'] + common + ['--raw-return-file', str(self.raw_evidence()), '--observed-outcome', 'completed'],
                    base + ['check'] + common]
        for cmd in commands:
            result = subprocess.run(cmd, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIsInstance(json.loads(result.stdout), dict)


if __name__ == '__main__': unittest.main()
