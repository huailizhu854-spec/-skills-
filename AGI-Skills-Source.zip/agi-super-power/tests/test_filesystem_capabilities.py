"""Filesystem capability reporting tests; real protection coverage stays separate."""
from __future__ import annotations
import errno
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import filesystem_capabilities as fs
from fs_test_support import make_symlink_or_skip, require_long_paths_or_skip
from kernel import ContractError, contained_file, local_file
from team_runtime import TeamError, safe_parent
from run_offline_tests import skip_record


class FilesystemCapabilityTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix='fs-tests-')
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)

    def test_symlink_supported_probe_does_not_claim_security(self):
        with patch.object(Path, 'symlink_to'), patch.object(Path, 'is_symlink', return_value=True):
            value = fs.probe_symlink_support(self.root, target_is_directory=True)
        self.assertEqual(value['status'], 'AVAILABLE')
        self.assertEqual(value['capability'], 'directory_symlink')
        self.assertFalse(value['security_protection_verified'])

    def test_symlink_privilege_failure_is_environment_blocked(self):
        error = OSError('fixture privilege unavailable'); error.winerror = 1314
        with patch.object(Path, 'symlink_to', side_effect=error):
            value = fs.probe_symlink_support(self.root)
        self.assertEqual(value['status'], 'ENVIRONMENT_BLOCKED')
        self.assertEqual(value['winerror'], 1314)
        self.assertFalse(value['security_protection_verified'])

    def test_unexpected_symlink_error_is_not_converted_to_skip(self):
        error = FileNotFoundError(errno.ENOENT, 'fixture missing parent')
        with patch.object(Path, 'symlink_to', side_effect=error):
            with self.assertRaises(FileNotFoundError):
                fs.probe_symlink_support(self.root)
            with self.assertRaises(FileNotFoundError):
                make_symlink_or_skip(self, self.root / 'link', self.root / 'target')

    def test_fixture_helper_only_skips_known_restrictions(self):
        errors = [PermissionError(errno.EPERM, 'fixture permission'),
                  OSError(errno.ENOTSUP, 'fixture unsupported'), NotImplementedError('fixture')]
        for error in errors:
            with self.subTest(error=type(error).__name__):
                with patch.object(Path, 'symlink_to', side_effect=error):
                    with self.assertRaisesRegex(unittest.SkipTest, 'ENVIRONMENT_BLOCKED:SYMLINK'):
                        make_symlink_or_skip(self, self.root / 'link', self.root / 'target')

    def test_sharing_violation_is_not_mislabeled_as_permission(self):
        error = PermissionError(errno.EACCES, 'fixture sharing violation'); error.winerror = 32
        self.assertFalse(fs.symlink_unavailable(error))
        with patch.object(Path, 'symlink_to', side_effect=error):
            with self.assertRaises(PermissionError):
                make_symlink_or_skip(self, self.root / 'link', self.root / 'target')

    def test_fixture_helper_preserves_directory_argument(self):
        target, link = self.root / 'target', self.root / 'link'
        with patch.object(Path, 'symlink_to') as call:
            make_symlink_or_skip(self, link, target, target_is_directory=True)
        call.assert_called_once_with(target, target_is_directory=True)

    def test_actual_long_path_probe_reports_observed_capability(self):
        value = fs.probe_long_path_support(self.root)
        self.assertIn(value['status'], {'AVAILABLE', 'ENVIRONMENT_BLOCKED'})
        self.assertEqual(value['io_mode'], 'ordinary_paths')
        self.assertFalse(value['security_protection_verified'])
        if value['status'] == 'AVAILABLE':
            self.assertGreater(value['tested_path_length'], 260)
        else:
            self.assertGreaterEqual(value['attempted_path_length'], 248)
            self.assertTrue(value['reason'])

    def test_long_path_probe_rejects_short_substitute(self):
        with self.assertRaisesRegex(ValueError, 'exceed 260'):
            fs.probe_long_path_support(self.root, minimum_length=260)

    def test_unexpected_long_path_permission_error_propagates(self):
        with patch.object(Path, 'mkdir', side_effect=PermissionError(errno.EACCES, 'fixture permission')):
            with self.assertRaises(PermissionError):
                fs.probe_long_path_support(self.root)

    def test_long_path_missing_parent_is_not_assumed_to_be_max_path(self):
        error = FileNotFoundError('fixture path missing'); error.winerror = 3
        with patch.object(fs, 'os', SimpleNamespace(name='nt')):
            self.assertFalse(fs._long_path_unavailable(error, self.root / 'missing' / ('x' * 200)))
            self.assertFalse(fs._long_path_unavailable(error, self.root / 'short'))
            self.assertTrue(fs._long_path_unavailable(error, self.root / ('x' * 260)))

    def test_long_path_fixture_preserves_visible_skip(self):
        with patch('fs_test_support.probe_long_path_support', return_value={
                'status': 'ENVIRONMENT_BLOCKED', 'reason': 'fixture long-path restriction'}):
            with self.assertRaisesRegex(unittest.SkipTest, 'ENVIRONMENT_BLOCKED:LONG_PATH'):
                require_long_paths_or_skip(self, self.root)

    def test_skip_report_separates_environment_from_other_skips(self):
        test = Mock(); test.id.return_value = 'fixture.test'
        blocked = skip_record(test, 'ENVIRONMENT_BLOCKED:SYMLINK fixture restriction')
        self.assertEqual(blocked['classification'], 'ENVIRONMENT_BLOCKED')
        self.assertEqual(blocked['capability'], 'SYMLINK')
        self.assertEqual(skip_record(test, 'Windows-only coverage')['classification'], 'NOT_EXECUTED')


@unittest.skipUnless(os.name == 'nt', 'Windows junction requires a real Windows filesystem')
class WindowsJunctionTests(unittest.TestCase):
    def test_actual_junction_is_rejected_without_reading_or_writing_target(self):
        powershell = shutil.which('powershell.exe')
        if not powershell:
            self.skipTest('ENVIRONMENT_BLOCKED:JUNCTION Windows PowerShell unavailable')
        with tempfile.TemporaryDirectory(prefix='junction-test-') as temporary:
            root = Path(temporary)
            target, link = root / 'outside', root / 'junction'
            target.mkdir()
            marker = target / 'evidence.txt'
            marker.write_bytes(b'unchanged outside fixture')
            environment = dict(os.environ, AGI_PROBE_JUNCTION_LINK=str(link), AGI_PROBE_JUNCTION_TARGET=str(target))
            result = subprocess.run([powershell, '-NoProfile', '-NonInteractive', '-Command',
                'New-Item -ItemType Junction -Path $env:AGI_PROBE_JUNCTION_LINK '
                '-Target $env:AGI_PROBE_JUNCTION_TARGET -ErrorAction Stop | Out-Null'],
                env=environment, capture_output=True, text=True, timeout=30,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            self.assertEqual(result.returncode, 0, result.stderr)
            try:
                self.assertTrue(getattr(link.lstat(), 'st_file_attributes', 0) & 0x400)
                with self.assertRaises(ContractError):
                    local_file(root, 'junction/evidence.txt')
                with self.assertRaises(ContractError):
                    contained_file(root, link / 'evidence.txt')
                with self.assertRaises(TeamError):
                    safe_parent(link / 'new-directory' / 'output.txt')
                self.assertEqual(marker.read_bytes(), b'unchanged outside fixture')
                self.assertFalse((target / 'new-directory').exists())
            finally:
                # Remove only the link entry, never recursively traverse its target.
                if link.exists():
                    os.rmdir(link)


if __name__ == '__main__':
    unittest.main()
