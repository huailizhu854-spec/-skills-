"""Foreground command adapter integration tests; all workers are fixtures."""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from kernel import load_json
from team_runtime import TeamError, TeamStore
from team_runner import run_batch, validate_adapters

spec = importlib.util.spec_from_file_location("team_demo_v2", ROOT / "examples/team-demo/run_demo.py")
demo = importlib.util.module_from_spec(spec); spec.loader.exec_module(demo)


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name); self.job = self.base / "job"
        self.plan = load_json(ROOT / "examples/team-demo/plan.json")
        TeamStore.create(self.job, self.plan, ROOT / "examples/team-demo")
        self.config = {"schema_version": 1, "adapters": {t["role"]: {"argv": [sys.executable, "-B", str(ROOT / "examples/team-demo/fixture_worker.py")], "mode": "fixture", "timeout_seconds": 10} for t in self.plan["tasks"]}}

    def test_commands_require_explicit_authorization(self):
        with self.assertRaises(TeamError): run_batch(self.job, self.config)
        with TeamStore(self.job) as store: self.assertEqual(store.status()["metrics"]["attempts"], 0)

    def test_absolute_executable_and_bounded_timeout_required(self):
        for key, value in (("argv", ["python"]), ("mode", "native"), ("timeout_seconds", True), ("timeout_seconds", 0)):
            config = json.loads(json.dumps(self.config)); config["adapters"]["repo-research"][key] = value
            with self.subTest(key=key), self.assertRaises(TeamError): validate_adapters(config)

    def test_real_process_batch_does_not_auto_accept(self):
        result = run_batch(self.job, self.config, allow_commands=True)
        self.assertEqual(len(result["batch"]), 2)
        self.assertFalse(result["automatic_acceptance"])
        with TeamStore(self.job) as store:
            states = {r["id"]: r["status"] for r in store.status()["tasks"]}
            self.assertEqual(states["facts"], "submitted"); self.assertEqual(states["outline"], "submitted")
            self.assertEqual(states["page"], "pending"); self.assertEqual(store.ready(), [])
            hosts = [r[0] for r in store.db.execute("SELECT host_run_id FROM tasks WHERE status='submitted'")]
            self.assertEqual(len(set(hosts)), 2)

    def test_repeated_batch_does_not_repeat_submitted_work(self):
        run_batch(self.job, self.config, allow_commands=True)
        result = run_batch(self.job, self.config, allow_commands=True)
        self.assertEqual(result["batch"], [])
        with TeamStore(self.job) as store: self.assertEqual(store.status()["metrics"]["attempts"], 2)

    def test_two_schedulers_share_single_claim_authority(self):
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(run_batch, self.job, self.config, allow_commands=True) for _ in range(2)]
            results = [f.result(timeout=20) for f in futures]
        with TeamStore(self.job) as store:
            self.assertEqual(store.status()["metrics"]["attempts"], 2)
            self.assertEqual(store.row("facts")["attempt"], 1)
            self.assertEqual(store.row("outline")["attempt"], 1)
        submitted = sum(bool(r.get("submitted")) for batch in results for r in batch["batch"])
        self.assertEqual(submitted, 2)

    def test_missing_role_adapter_is_reported_not_invented(self):
        del self.config["adapters"]["office-delivery"]
        result = run_batch(self.job, self.config, allow_commands=True)
        self.assertEqual(result["missing_adapters"], ["outline"])
        with TeamStore(self.job) as store: self.assertEqual(store.row("outline")["attempt"], 0)

    def test_failing_adapter_is_uncertain_not_automatically_retried(self):
        self.config["adapters"] = {"repo-research": {"argv": [sys.executable, "-c", "raise SystemExit(3)"], "mode": "fixture", "timeout_seconds": 5}}
        result = run_batch(self.job, self.config, allow_commands=True)
        self.assertEqual(result["batch"][0]["status"], "uncertain")
        again = run_batch(self.job, self.config, allow_commands=True)
        self.assertEqual(again["batch"], [])
        with TeamStore(self.job) as store: self.assertEqual(store.row("facts")["attempt"], 1)

    def test_timeout_is_uncertain_and_does_not_release_ownership(self):
        self.config["adapters"] = {"repo-research": {"argv": [sys.executable, "-c", "import time; time.sleep(5)"], "mode": "fixture", "timeout_seconds": 1}}
        result = run_batch(self.job, self.config, allow_commands=True)
        self.assertEqual(result["batch"][0]["status"], "uncertain")
        with TeamStore(self.job) as store:
            self.assertEqual(store.row("facts")["status"], "uncertain")
            with self.assertRaises(TeamError): store.claim("facts", "replacement")

    def test_complete_demo_uses_four_fixture_workers_in_three_batches(self):
        report = demo.run(self.base / "complete")
        self.assertTrue(report["final"]["completed"])
        self.assertEqual([len(x["batch"]) for x in report["batches"]], [2, 1, 1])
        self.assertEqual(report["final"]["metrics"]["attempts"], 4)
        self.assertEqual(report["real_model_agents"], "NOT_EXECUTED")
        self.assertTrue(report["duplicate_receipt"]["duplicate"])
        self.assertTrue((self.base / "complete/published/site/index.html").is_file())


if __name__ == "__main__": unittest.main()
