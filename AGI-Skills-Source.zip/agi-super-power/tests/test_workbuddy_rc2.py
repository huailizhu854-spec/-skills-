"""WorkBuddy rc.2 boundary regressions. All returns here are offline fixtures."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import unittest
import test_workbuddy_bridge as baseline
RAW_OK, ROOT = baseline.RAW_OK, baseline.ROOT
from team_runtime import TeamStore, TeamError
from host_adapters.workbuddy_contract import validate_sync_terminal_observation

class WorkBuddyRC2Tests(unittest.TestCase):
    setUp = baseline.WorkBuddyBridgeTests.setUp
    prepare = baseline.WorkBuddyBridgeTests.prepare
    begin_submit = baseline.WorkBuddyBridgeTests.begin_submit
    raw_evidence = baseline.WorkBuddyBridgeTests.raw_evidence
    event = baseline.WorkBuddyBridgeTests.event
    output = baseline.WorkBuddyBridgeTests.output
    review = baseline.WorkBuddyBridgeTests.review
    guarded_happy_path = baseline.WorkBuddyBridgeTests.guarded_happy_path

    def test_body_id_is_not_a_terminal_footer(self):
        with self.assertRaises(TeamError):
            validate_sync_terminal_observation('[Agent ID: agent-example]\nMore body text', 'agent-example')

    def test_footer_without_terminal_message_rejected(self):
        with self.assertRaises(TeamError):
            validate_sync_terminal_observation('[Agent ID: agent-example]', 'agent-example')

    def test_direct_bind_requires_submit_authorization(self):
        self.prepare()
        with TeamStore(self.job) as s:
            with self.assertRaises(TeamError):
                s.bind('impl', self.packet['lease_token'], 'native', 'agent-example')

    def test_legacy_ledger_cannot_bind_mobile_cloud(self):
        self.prepare()
        with TeamStore(self.job) as s:
            s.db.execute('DROP TABLE dispatch34')
            s.db.commit()
        with self.assertRaises(TeamError):
            self.adapter.bind_observed(self.event())

    def test_same_host_id_cannot_be_reused_for_second_agent(self):
        self.guarded_happy_path();self.review()
        self.desc=self.adapter.prepare('audit','wbmc-reviewer')
        from kernel import load_json
        from delivery_state import begin_submission
        self.packet=load_json(self.desc['packet_path'])
        with TeamStore(self.job) as s:
            begin_submission(s,'audit',self.packet['lease_token'])
            with self.assertRaises(TeamError):
                s.bind('audit',self.packet['lease_token'],'native','agent-670eea937b1a42ed')

    def test_lifecycle_observe_cannot_reuse_another_agents_id(self):
        from kernel import load_json
        from delivery_state import begin_submission, observe
        self.guarded_happy_path();self.review()
        self.desc=self.adapter.prepare('audit','wbmc-reviewer')
        self.packet=load_json(self.desc['packet_path'])
        raw=self.job/'reviews'/'second-host-return.txt';raw.write_text(RAW_OK)
        with TeamStore(self.job) as store:
            d=begin_submission(store,'audit',self.packet['lease_token'])
            e={'id':'audit-terminal','task_id':'audit','lease_token':self.packet['lease_token'],
               'request_key':d['request_key'],'goal_digest':self.packet['goal_digest'],
               'plan_digest':self.packet['plan_digest'],'event':'succeeded',
               'host_run_id':'agent-670eea937b1a42ed','tool':'Agent',
               'evidence_path':'reviews/second-host-return.txt',
               'evidence_sha256':hashlib.sha256(raw.read_bytes()).hexdigest()}
            with self.assertRaises(TeamError):observe(store,e)

    def test_normalizer_preserves_crlf_bytes(self):
        raw=Path(self.temp.name)/'raw.txt'
        data=RAW_OK.replace('\n','\r\n').encode()
        raw.write_bytes(data)
        r=subprocess.run([sys.executable,'-B',str(ROOT/'scripts/workbuddy_bridge.py'),
                          'normalize','--raw-return-file',str(raw),'--observed-outcome','completed'],
                          capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stderr)
        n=json.loads(r.stdout)
        self.assertEqual(n['terminal_result_sha256'],hashlib.sha256(data).hexdigest())
        self.assertEqual(n['terminal_result'].encode(),data)

    def test_event_formatter_uses_exact_raw_bytes_and_packet(self):
        from workbuddy_bridge import terminal_event
        self.prepare()
        raw=self.raw_evidence()
        raw.write_bytes(RAW_OK.replace('\n','\r\n').encode())
        e=terminal_event(Path(self.desc['packet_path']),raw,'completed')
        self.assertEqual(e['task_id'],'impl')
        self.assertEqual(e['lease_token'],self.packet['lease_token'])
        self.assertEqual(e['raw_evidence_sha256'],hashlib.sha256(raw.read_bytes()).hexdigest())
        with self.assertRaises(TeamError):self.adapter.bind_observed(e)
        self.begin_submit()
        from workbuddy_test_support import attach_call_evidence
        attach_call_evidence(self.job,Path(self.desc['packet_path']),raw)
        self.adapter.bind_observed(e)

    def test_event_formatter_rejects_unknown_outcome_and_wrong_location(self):
        from workbuddy_bridge import terminal_event
        self.prepare();raw=self.raw_evidence()
        with self.assertRaises(TeamError):terminal_event(Path(self.desc['packet_path']),raw,'outcome_unknown')
        other=Path(self.temp.name)/'outside.txt';other.write_text(RAW_OK)
        with self.assertRaises(ValueError):terminal_event(Path(self.desc['packet_path']),other,'completed')

    def test_cli_never_overwrites_raw_return(self):
        raw=Path(self.temp.name)/'raw.txt';raw.write_text(RAW_OK)
        before=raw.read_bytes()
        r=subprocess.run([sys.executable,'-B',str(ROOT/'scripts/workbuddy_bridge.py'),
                          'normalize','--raw-return-file',str(raw),'--observed-outcome','completed','--out',str(raw)],
                          capture_output=True,text=True)
        self.assertNotEqual(r.returncode,0)
        self.assertEqual(raw.read_bytes(),before)

    def test_submission_revalidates_mobile_terminal_evidence(self):
        self.guarded_happy_path()
        with TeamStore(self.job) as store:
            row=store.row('impl');result=json.loads(row['result'])
            receipt_path=Path(self.packet['workspace'])/result['host_receipt']['path']
            receipt=json.loads(receipt_path.read_text())
            raw=Path(self.packet['workspace'])/receipt['observation']['raw_evidence_path']
            raw.write_text('body mentions agent-670eea937b1a42ed but no host footer')
            receipt['observation']['raw_evidence_sha256']=hashlib.sha256(raw.read_bytes()).hexdigest()
            receipt_path.write_text(json.dumps(receipt))
            result['host_receipt']['sha256']=hashlib.sha256(receipt_path.read_bytes()).hexdigest()
            with self.assertRaises(TeamError):store._validate_result(result,row)

    def test_auditor_packet_contains_independent_reference(self):
        from kernel import load_json
        self.guarded_happy_path();self.review()
        desc=self.adapter.prepare('audit','wbmc-reviewer')
        packet=load_json(desc['packet_path'])
        snapshots={x['id']:x for x in packet['input_snapshots']}
        self.assertEqual(set(snapshots),{'result-data','frozen-req'})
        self.assertNotEqual(snapshots['result-data']['path'],snapshots['frozen-req']['path'])
        self.assertEqual(Path(snapshots['frozen-req']['path']).read_bytes(),
                         (self.inputs/'expected-result.json').read_bytes())

    def test_offline_pair_report_never_certifies_real_host(self):
        from workbuddy_bridge import terminal_event
        from kernel import load_json
        from delivery_state import begin_submission
        sys.path.insert(0,str(ROOT/'examples/workbuddy-mc'))
        from check_integration import check_job
        self.guarded_happy_path();self.review()
        partial=check_job(self.job)
        self.assertFalse(partial['local_evidence_checks_passed'])
        self.desc=self.adapter.prepare('audit','wbmc-reviewer')
        self.packet=load_json(self.desc['packet_path'])
        with TeamStore(self.job) as store:begin_submission(store,'audit',self.packet['lease_token'])
        raw=self.raw_evidence('Offline audit fixture completed.\n[Agent ID: agent-fixture-audit]')
        e=terminal_event(Path(self.desc['packet_path']),raw,'completed')
        from workbuddy_test_support import attach_call_evidence
        attach_call_evidence(self.job,Path(self.desc['packet_path']),raw)
        self.adapter.bind_observed(e)
        output=Path(self.packet['output_root'])/'review.json'
        output.write_text(json.dumps({'verdict':'PASS','checks':{'name':True,'version':True,'status':True,'no_extra_fields':True}}))
        self.adapter.collect_observed(e);self.review('audit')
        before=(self.job/'team.sqlite3').read_bytes()
        report=check_job(self.job)
        self.assertTrue(report['local_evidence_checks_passed'],report)
        self.assertTrue(report['provenance_records_passed'])  # Explicit offline records, never real-host attestation.
        self.assertEqual(report['real_host_verdict'],'REQUIRES_HOST_TRACE_REVIEW')
        self.assertEqual(report['real_agent_calls_by_this_checker'],0)
        self.assertEqual((self.job/'team.sqlite3').read_bytes(),before)
        (self.job/'published/result.json').write_text('{}')
        self.assertFalse(check_job(self.job)['local_evidence_checks_passed'])

if __name__=='__main__':unittest.main()
