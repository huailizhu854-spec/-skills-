"""Offline regression fixtures; these tests do not create real agents."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from kernel import load_json
from team_runtime import TeamStore, TeamError, digest, write_json
from host_adapters.codex import CodexAdapter, validate_finished_observation
from host_adapters.claude_code import ClaudeCodeAdapter
from v3_protocol import validate_task

class CodexBridgeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.job=Path(self.temp.name)/'job'
        self.inputs=ROOT/'examples/team-demo'
        self.plan=load_json(self.inputs/'plan.codex-v3.json')
    def prepare(self):
        TeamStore.create(self.job,self.plan,self.inputs)
        self.adapter=CodexAdapter(self.job)
        self.desc=self.adapter.prepare('facts','codex-worker')
        self.packet=load_json(self.desc['packet_path'])
        return self.desc
    def event(self,event='started',status='completed',host='codex_native',ident='test-agent'):
        path=Path(self.packet['workspace'])/'evidence'/('observed-'+event+'.json')
        write_json(path,{'fixture':True,'agents':[{'agent_name':ident,'agent_status':status}]})
        return {'schema_version':1,'host':host,'event':event,'host_run_id':'test-agent',
                'task_id':'facts','lease_token':self.packet['lease_token'],'native_tool':'fixture-only',
                'raw_evidence_path':path.relative_to(Path(self.packet['workspace'])).as_posix(),
                'raw_evidence_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'observed_by':'coordinator'}
    def output(self,wrong=False):
        raw=(self.inputs/'brief.txt').read_bytes();text=raw.decode('utf-8')
        p=Path(self.packet['output_root'])/'research/facts.json';p.parent.mkdir()
        write_json(p,{'lines':-1 if wrong else len(text.splitlines()),'characters':len(text),'brief_sha256':hashlib.sha256(raw).hexdigest()})
    def review(self):
        with TeamStore(self.job) as s:
            r=json.loads(s.row('facts')['result'])
            p=self.job/'reviews/actual-check.json';write_json(p,{'method':'independent registry execution on accept'})
            return s.review({'task_id':'facts','result_id':r['result_id'],'result_digest':digest(r),
                'goal_digest':r['goal_digest'],'reviewer':'coordinator','decision':'accept','reason':'Validate exact facts from input',
                'evidence_path':'reviews/actual-check.json','evidence_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    def test_prepare_is_not_launch_and_does_not_install_claude_files(self):
        d=self.prepare();self.assertEqual(d['execution'],'NOT_EXECUTED')
        self.assertNotIn('definition_path',d);self.assertTrue(Path(d['delegation_path']).is_file())
        self.assertFalse(list(self.job.rglob('.claude')))
    def test_no_duplicate_claim(self):
        self.prepare()
        with self.assertRaises(TeamError):self.adapter.prepare('facts','another')
    def test_codex_requires_correct_host(self):
        self.plan=load_json(self.inputs/'plan.native-v3.json')
        with self.assertRaises(TeamError):self.prepare()
    def test_claude_does_not_accept_codex_plan(self):
        TeamStore.create(self.job,self.plan,self.inputs)
        with self.assertRaises(TeamError):ClaudeCodeAdapter(self.job).prepare('facts','worker')
    def test_no_transport_authorization_rejected(self):
        self.plan['tasks'][0]['executor']['transport_network']=False
        with self.assertRaises(ValueError):validate_task(self.plan['tasks'][0])
    def test_shell_capability_conflict_before_claim(self):
        self.plan['tasks'][0]['capabilities']['shell']=False
        with self.assertRaises(TeamError):self.prepare()
        with TeamStore(self.job) as s:self.assertEqual(s.row('facts')['status'],'pending')
    def test_unknown_verifier_rejected_before_claim(self):
        self.plan['tasks'][0]['acceptance'][0]['method']='not-registered'
        with self.assertRaises(TeamError):self.prepare()
        with TeamStore(self.job) as s:self.assertEqual(s.row('facts')['status'],'pending')
    def test_observation_host_cannot_cross(self):
        self.prepare()
        with self.assertRaises(TeamError):self.adapter.bind_observed(self.event(host='claude_code_native'))
    def test_wrong_lease_rejected(self):
        self.prepare();e=self.event();e['lease_token']='other'
        with self.assertRaises(TeamError):self.adapter.bind_observed(e)
    def test_observation_changed_rejected(self):
        self.prepare();e=self.event();e['raw_evidence_sha256']='0'*64
        with self.assertRaises(TeamError):self.adapter.bind_observed(e)
    def test_running_or_idle_or_wrong_agent_never_finishes(self):
        for status in ['running','idle','interrupted','failed']:
            with self.subTest(status=status),self.assertRaises(TeamError):
                validate_finished_observation({'agents':[{'agent_name':'a','agent_status':status}]},'a')
        with self.assertRaises(TeamError):validate_finished_observation({'agents':[{'agent_name':'b','agent_status':'completed'}]},'a')
    def test_collect_before_bind_fails(self):
        self.prepare()
        with self.assertRaises(TeamError):self.adapter.collect_observed(self.event('finished'))
    def test_actual_codex_terminal_snapshot_shape(self):
        validate_finished_observation({'agents':[{'agent_name':'a','agent_status':{'completed':'Artifact path returned'}}]},'a')
        with self.assertRaises(TeamError):validate_finished_observation({'agents':[{'agent_name':'a','agent_status':{'running':'not finished'}}]},'a')
    def test_independent_review_accepts_correct_output_and_unlocks(self):
        self.prepare();self.adapter.bind_observed(self.event());self.output()
        self.assertTrue(self.adapter.collect_observed(self.event('finished'))['submitted'])
        with TeamStore(self.job) as s:
            r=json.loads(s.row('facts')['result']);self.assertEqual(r['checks'][0]['outcome'],'UNVERIFIED')
        self.review()
        with TeamStore(self.job) as s:self.assertEqual(s.row('facts')['status'],'accepted')
    def test_structure_success_cannot_accept_wrong_content(self):
        self.prepare();self.adapter.bind_observed(self.event());self.output(wrong=True)
        self.adapter.collect_observed(self.event('finished'))
        with self.assertRaises(TeamError):self.review()
        with TeamStore(self.job) as s:self.assertEqual(s.row('facts')['status'],'submitted')
    def test_cli_selects_frozen_codex_host_and_rejects_override(self):
        TeamStore.create(self.job,self.plan,self.inputs)
        cmd=[sys.executable,'-B',str(ROOT/'scripts/native_host_bridge.py'),'prepare','--job',str(self.job),'--task','facts','--worker','cli-worker']
        bad=subprocess.run(cmd+['--host','claude_code_native'],capture_output=True,text=True)
        self.assertNotEqual(bad.returncode,0)
        good=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8')
        self.assertEqual(good.returncode,0,good.stdout+good.stderr)
        self.assertEqual(json.loads(good.stdout)['host'],'codex_native')

if __name__=='__main__':unittest.main()
