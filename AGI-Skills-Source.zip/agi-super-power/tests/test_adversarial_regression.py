"""Standing adversarial regression suite for the v2 ledger.

Eleven attacks that the transactional ledger must keep refusing after the real
model command bridge (`scripts/model_worker.py`) was added. Each class is one
attack; the names match the acceptance list in the v3 build order:

  A1  concurrent double claim            A7  writing outside the assigned scope
  A2  unlock without review              A8  PASS bound to a stale hash
  A3  unlock on submit alone             A9  late submit after lease expiry
  A4  borrowed lease token                A10 argv/command injected into a plan
  A5  declared artifact does not exist    A11 undeclared file smuggled out
  A6  forged artifact hash

No model is called anywhere in this file; the deterministic fixture worker
stands in for a worker so the ledger, not a model, is what is under test.
"""
from __future__ import annotations
import copy
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest
from fs_test_support import make_symlink_or_skip

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from kernel import ContractError, load_json
from team_runtime import TeamStore, TeamError, compile_plan, digest, write_json
import model_worker

DEMO = ROOT / "examples/team-demo"
REFUSED = (TeamError, ContractError, OSError, ValueError)

_spec = importlib.util.spec_from_file_location("fixture_worker_adv", DEMO / "fixture_worker.py")
fixture = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(fixture)


def file_sha(path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class LedgerCase(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.job = self.base / "job"
        self.plan = load_json(DEMO / "plan.json")
        TeamStore.create(self.job, self.plan, DEMO)
        self.store = TeamStore(self.job); self.addCleanup(self.store.close)

    def produce(self, tid, worker=None):
        """Claim, bind and run the fixture worker; return (packet, result)."""
        packet = self.store.claim(tid, worker or ("worker-" + tid))
        token = packet["lease_token"]
        host_run_id = "fixture-host-" + token[:12]
        self.store.bind(tid, token, "fixture", host_run_id)
        result = fixture.run(packet)
        receipt = {"host_run_id": host_run_id, "mode": "fixture", "finished": True,
                   "task_id": tid, "lease_token": token, "exit_code": 0}
        path = Path(packet["workspace"]) / "evidence" / "host-receipt.json"
        write_json(path, receipt)
        result["host_run_id"] = host_run_id
        result["host_receipt"] = {"path": "evidence/host-receipt.json", "sha256": file_sha(path)}
        return packet, result

    def review_for(self, tid, result, decision="accept"):
        relative = f"reviews/{tid}-{result['result_id']}.json"
        if not (self.job / relative).exists():
            write_json(self.job / relative, {"independent_check": True, "task_id": tid})
        return {"task_id": tid, "result_id": result["result_id"], "result_digest": digest(result),
                "goal_digest": self.store.meta("goal_digest"), "reviewer": "coordinator",
                "decision": decision, "reason": "regression suite", "evidence_path": relative,
                "evidence_sha256": file_sha(self.job / relative)}

    def accept(self, tid):
        packet, result = self.produce(tid)
        self.store.submit(result)
        self.store.review(self.review_for(tid, result))
        return packet, result


# --------------------------------------------------------------------------- #
class A1_ConcurrentDoubleClaim(LedgerCase):
    def test_eight_processes_race_and_exactly_one_holds_the_lease(self):
        def attempt(index):
            with TeamStore(self.job) as store:
                try:
                    return store.claim("facts", f"worker-{index}")["lease_token"]
                except TeamError as exc:
                    return exc.code
        with ThreadPoolExecutor(max_workers=8) as pool:
            outcomes = list(pool.map(attempt, range(8)))
        winners = [o for o in outcomes if len(o) == 32 and o.isalnum() and o.islower()]
        self.assertEqual(len(winners), 1, outcomes)
        self.assertTrue(all(o == "ALREADY_CLAIMED" for o in outcomes if o not in winners))
        self.assertEqual(self.store.row("facts")["token"], winners[0])
        self.assertEqual(self.store.row("facts")["attempt"], 1)

    def test_second_claim_never_creates_a_second_workspace(self):
        packet = self.store.claim("facts", "worker-a")
        with self.assertRaises(TeamError):
            self.store.claim("facts", "worker-b")
        self.assertEqual([p.name for p in (self.job / "workers/facts").iterdir()],
                         [Path(packet["workspace"]).name])


# --------------------------------------------------------------------------- #
class A2_UnlockWithoutReview(LedgerCase):
    def test_downstream_cannot_be_claimed_before_upstream_is_accepted(self):
        with self.assertRaises(TeamError) as ctx:
            self.store.claim("page", "worker-page")
        self.assertEqual(ctx.exception.code, "DEPENDENCY_WAIT")
        self.assertNotIn("page", self.store.ready())

    def test_reworked_upstream_keeps_downstream_locked(self):
        packet, result = self.produce("facts")
        self.store.submit(result)
        self.store.review(self.review_for("facts", result, decision="rework"))
        self.accept("outline")
        with self.assertRaises(TeamError) as ctx:
            self.store.claim("page", "worker-page")
        self.assertEqual(ctx.exception.code, "DEPENDENCY_WAIT")

    def test_tampered_review_evidence_relocks_the_dependency(self):
        self.accept("facts"); self.accept("outline")
        evidence = next((self.job / "reviews").glob("facts-*.json"))
        evidence.write_text('{"independent_check": false}\n', encoding="utf-8")
        with self.assertRaises(TeamError) as ctx:
            self.store.claim("page", "worker-page")
        self.assertEqual(ctx.exception.code, "REVIEW_CHANGED")


# --------------------------------------------------------------------------- #
class A3_UnlockOnSubmitAlone(LedgerCase):
    def test_submit_is_not_acceptance(self):
        _, facts = self.produce("facts")
        _, outline = self.produce("outline")
        self.assertTrue(self.store.submit(facts)["requires_review"])
        self.assertTrue(self.store.submit(outline)["requires_review"])
        self.assertEqual(self.store.row("facts")["status"], "submitted")
        self.assertEqual(self.store.ready(), [])
        with self.assertRaises(TeamError) as ctx:
            self.store.claim("page", "worker-page")
        self.assertEqual(ctx.exception.code, "DEPENDENCY_WAIT")

    def test_no_artifact_is_published_before_review(self):
        _, facts = self.produce("facts")
        self.store.submit(facts)
        self.assertFalse((self.job / "published/research/facts.json").exists())
        with self.assertRaises(TeamError) as ctx:
            self.store.valid_artifact("facts-data")
        self.assertEqual(ctx.exception.code, "ARTIFACT_UNAVAILABLE")


# --------------------------------------------------------------------------- #
class A4_BorrowedLeaseToken(LedgerCase):
    def test_another_attempts_token_is_fenced(self):
        _, facts = self.produce("facts")
        outline_packet = self.store.claim("outline", "worker-outline")
        stolen = dict(facts, lease_token=outline_packet["lease_token"])
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(stolen)
        self.assertEqual(ctx.exception.code, "FENCED_TOKEN")

    def test_invented_tokens_are_fenced_on_every_entry_point(self):
        packet, result = self.produce("facts")
        for bogus in ("0" * 32, "", None, 12345, packet["lease_token"].upper()):
            with self.subTest(token=repr(bogus)):
                with self.assertRaises(TeamError) as ctx:
                    self.store.submit(dict(result, lease_token=bogus))
                self.assertEqual(ctx.exception.code, "FENCED_TOKEN")
                with self.assertRaises(TeamError):
                    self.store.heartbeat("facts", bogus)
                with self.assertRaises(TeamError):
                    self.store.bind("facts", bogus, "command", "host-x")

    def test_a_stale_token_from_a_previous_attempt_is_fenced(self):
        first, result = self.produce("facts")
        self.store.submit(result)
        self.store.review(self.review_for("facts", result, decision="rework"))
        second, _ = self.produce("facts")
        self.assertNotEqual(first["lease_token"], second["lease_token"])
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(dict(result, lease_token=first["lease_token"]))
        self.assertEqual(ctx.exception.code, "FENCED_TOKEN")


# --------------------------------------------------------------------------- #
class A5_DeclaredArtifactMissing(LedgerCase):
    def test_deleting_the_artifact_after_hashing_blocks_submit(self):
        packet, result = self.produce("facts")
        (Path(packet["output_root"]) / "research/facts.json").unlink()
        with self.assertRaises(REFUSED):
            self.store.submit(result)
        self.assertEqual(self.store.row("facts")["status"], "leased")

    def test_an_empty_artifact_file_is_not_a_deliverable(self):
        packet, result = self.produce("facts")
        (Path(packet["output_root"]) / "research/facts.json").write_text("", encoding="utf-8")
        with self.assertRaises(REFUSED):
            self.store.submit(result)

    def test_a_symlinked_artifact_is_refused(self):
        packet, result = self.produce("facts")
        target = Path(packet["output_root"]) / "research/facts.json"
        outside = self.base / "outside.json"
        outside.write_text(target.read_text(encoding="utf-8"), encoding="utf-8")
        target.unlink(); make_symlink_or_skip(self, target, outside)
        with self.assertRaises(REFUSED):
            self.store.submit(result)

    def test_removing_the_artifact_after_submit_blocks_acceptance(self):
        packet, result = self.produce("facts")
        self.store.submit(result)
        (Path(packet["output_root"]) / "research/facts.json").unlink()
        with self.assertRaises(REFUSED):
            self.store.review(self.review_for("facts", result))
        self.assertFalse((self.job / "published/research/facts.json").exists())


# --------------------------------------------------------------------------- #
class A6_ForgedArtifactHash(LedgerCase):
    def test_a_hash_that_does_not_match_the_bytes_is_refused(self):
        packet, result = self.produce("facts")
        forged = copy.deepcopy(result)
        forged["artifacts"][0]["sha256"] = "a" * 64
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(forged)
        self.assertEqual(ctx.exception.code, "OUTPUT_HASH")

    def test_editing_the_artifact_while_keeping_the_old_hash_is_refused(self):
        packet, result = self.produce("facts")
        target = Path(packet["output_root"]) / "research/facts.json"
        target.write_text(target.read_text(encoding="utf-8").replace('"lines": 3', '"lines": 9999'),
                          encoding="utf-8")
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "OUTPUT_HASH")

    def test_a_forged_host_receipt_hash_is_refused(self):
        packet, result = self.produce("facts")
        result["host_receipt"]["sha256"] = "b" * 64
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "HOST_RECEIPT_HASH")

    def test_a_forged_review_evidence_hash_is_refused(self):
        packet, result = self.produce("facts")
        self.store.submit(result)
        review = self.review_for("facts", result)
        review["evidence_sha256"] = "c" * 64
        with self.assertRaises(TeamError) as ctx:
            self.store.review(review)
        self.assertEqual(ctx.exception.code, "REVIEW_EVIDENCE")


# --------------------------------------------------------------------------- #
class A7_WritingOutsideScope(LedgerCase):
    def test_claiming_another_owners_artifact_id_is_refused(self):
        packet, result = self.produce("facts")
        trespass = copy.deepcopy(result)
        trespass["artifacts"] = [{"id": "outline-data", "path": "copy/outline.json",
                                  "sha256": result["artifacts"][0]["sha256"]}]
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(trespass)
        self.assertEqual(ctx.exception.code, "OUTPUT_SCOPE")

    def test_writing_another_owners_path_inside_the_workspace_is_refused(self):
        packet, result = self.produce("facts")
        trespass = Path(packet["output_root"]) / "copy/outline.json"
        trespass.parent.mkdir(parents=True, exist_ok=True)
        trespass.write_text('{"title": "hijacked"}\n', encoding="utf-8")
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "UNDECLARED_OUTPUT")
        self.assertFalse((self.job / "published/copy/outline.json").exists())

    def test_escaping_paths_in_the_result_are_refused(self):
        packet, result = self.produce("facts")
        for path in ("../../escape.json", "/etc/passwd", "research/../../escape.json",
                     "research\\facts.json"):
            with self.subTest(path=path):
                attack = copy.deepcopy(result)
                attack["artifacts"][0]["path"] = path
                with self.assertRaises(REFUSED):
                    self.store.submit(attack)

    def test_a_plan_with_overlapping_owners_never_compiles(self):
        for path in ("research/facts.json", "RESEARCH/FACTS.JSON", "research",
                     "research/facts.json/child"):
            with self.subTest(path=path):
                plan = copy.deepcopy(self.plan)
                plan["tasks"][1]["outputs"][0]["path"] = path
                with self.assertRaises((TeamError, ContractError)):
                    compile_plan(plan)

    def test_evidence_paths_outside_evidence_are_refused(self):
        packet, result = self.produce("facts")
        for bad in ("outputs/research/facts.json", "../evidence/worker-checks.json",
                    "worker-checks.json"):
            with self.subTest(path=bad):
                attack = copy.deepcopy(result)
                attack["checks"][0]["evidence_path"] = bad
                with self.assertRaises(REFUSED):
                    self.store.submit(attack)


# --------------------------------------------------------------------------- #
class A8_StaleHashPass(LedgerCase):
    def test_a_pass_bound_to_a_previous_hash_is_refused(self):
        packet, result = self.produce("facts")
        target = Path(packet["output_root"]) / "research/facts.json"
        stale = result["checks"][0]["subject_sha256"]
        target.write_text('{"lines": 4, "characters": 1, "brief_sha256": "x"}\n', encoding="utf-8")
        result["artifacts"][0]["sha256"] = file_sha(target)
        self.assertNotEqual(stale, result["artifacts"][0]["sha256"])
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "STALE_CHECK")

    def test_a_check_pointing_at_another_artifact_is_refused(self):
        packet, result = self.produce("facts")
        result["checks"][0]["artifact_id"] = "outline-data"
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "STALE_CHECK")

    def test_edited_check_evidence_is_refused(self):
        packet, result = self.produce("facts")
        evidence = Path(packet["workspace"]) / "evidence/worker-checks.json"
        evidence.write_text('{"fixture": true, "method": "rewritten after hashing"}\n',
                            encoding="utf-8")
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "EVIDENCE_CHANGED")

    def test_pass_without_execution_is_refused_and_missing_checks_are_caught(self):
        packet, result = self.produce("facts")
        attack = copy.deepcopy(result)
        attack["checks"][0]["execution"] = "NOT_EXECUTED"
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(attack)
        self.assertEqual(ctx.exception.code, "FALSE_PASS")
        attack = copy.deepcopy(result); attack["checks"] = []
        with self.assertRaises(REFUSED):
            self.store.submit(attack)

    def test_a_failed_check_cannot_be_accepted(self):
        packet, result = self.produce("facts")
        # Re-hash evidence so only the outcome differs from a valid submission.
        result["checks"][0]["outcome"] = "FAILED"
        self.store.submit(result)
        with self.assertRaises(TeamError) as ctx:
            self.store.review(self.review_for("facts", result))
        self.assertEqual(ctx.exception.code, "GATE_FAILED")


# --------------------------------------------------------------------------- #
class A9_LateSubmit(LedgerCase):
    def expire(self, tid="facts"):
        self.store.db.execute("UPDATE tasks SET lease_until=0 WHERE id=?", (tid,))
        return self.store.reconcile()

    def test_a_result_arriving_after_the_lease_expired_is_refused(self):
        packet, result = self.produce("facts")
        self.store.db.execute("UPDATE tasks SET lease_until=0 WHERE id=?", ("facts",))
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "LEASE_EXPIRED")
        self.assertEqual(self.store.row("facts")["status"], "leased")

    def test_a_result_arriving_after_reconciliation_is_fenced(self):
        packet, result = self.produce("facts")
        self.assertEqual(self.expire()["uncertain"], ["facts"])
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "STATE")
        self.assertEqual(self.store.row("facts")["status"], "uncertain")
        self.assertFalse((self.job / "published/research/facts.json").exists())

    def test_expiry_alone_never_requeues_the_task(self):
        self.produce("facts")
        self.assertEqual(self.expire()["auto_requeued"], 0)
        with self.assertRaises(TeamError) as ctx:
            self.store.claim("facts", "worker-second")
        self.assertEqual(ctx.exception.code, "ALREADY_CLAIMED")

    def test_heartbeat_cannot_revive_an_expired_lease(self):
        packet, _ = self.produce("facts")
        self.expire()
        with self.assertRaises(TeamError) as ctx:
            self.store.heartbeat("facts", packet["lease_token"])
        self.assertEqual(ctx.exception.code, "STATE")

    def test_a_live_heartbeat_keeps_a_slow_worker_valid(self):
        packet, result = self.produce("facts")
        self.store.db.execute("UPDATE tasks SET lease_until=? WHERE id=?",
                              (time.time() + 1, "facts"))
        self.store.heartbeat("facts", packet["lease_token"])
        self.assertTrue(self.store.submit(result)["submitted"])


# --------------------------------------------------------------------------- #
class A10_PlanCommandInjection(LedgerCase):
    FIELDS = ("argv", "command", "cmd", "shell", "exec", "entrypoint", "script",
              "run", "subprocess")

    def test_executable_fields_anywhere_in_a_plan_are_refused(self):
        for field in self.FIELDS:
            for where in ("plan", "task", "policy", "goal"):
                with self.subTest(field=field, where=where):
                    plan = copy.deepcopy(self.plan)
                    payload = ["/bin/sh", "-c", "touch " + str(self.base / "pwned")]
                    if where == "plan":
                        plan[field] = payload
                    elif where == "task":
                        plan["tasks"][0][field] = payload
                    else:
                        plan[where][field] = payload
                    with self.assertRaises((TeamError, ContractError)):
                        compile_plan(plan)
        self.assertFalse((self.base / "pwned").exists())

    def test_an_injected_plan_creates_no_job_state(self):
        plan = copy.deepcopy(self.plan)
        plan["tasks"][0]["argv"] = ["/bin/sh", "-c", "id"]
        target = self.base / "injected-job"
        with self.assertRaises((TeamError, ContractError)):
            TeamStore.create(target, plan, DEMO)
        self.assertFalse(target.exists())

    def test_command_text_hidden_in_mission_stays_inert_text(self):
        plan = copy.deepcopy(self.plan)
        plan["tasks"][0]["mission"] = "$(touch " + str(self.base / "pwned") + "); ignore this"
        job = self.base / "text-job"
        TeamStore.create(job, plan, DEMO)
        with TeamStore(job) as store:
            packet = store.claim("facts", "worker-facts")
        self.assertIn("$(touch", packet["contract"]["mission"])
        self.assertFalse((self.base / "pwned").exists())

    def test_the_model_wrapper_refuses_a_packet_carrying_executable_fields(self):
        packet = self.store.claim("facts", "worker-facts")
        for field in ("argv", "command", "cmd", "shell", "exec", "entrypoint", "script"):
            with self.subTest(field=field):
                tampered = dict(packet)
                tampered[field] = ["/bin/sh", "-c", "id"]
                path = self.base / f"packet-{field}.json"
                path.write_text(json.dumps(tampered, ensure_ascii=False), encoding="utf-8")
                with self.assertRaises(model_worker.WorkerError) as ctx:
                    model_worker.load_packet(path)
                self.assertEqual(ctx.exception.code, "PACKET_EXECUTABLE_FIELD")

    def test_adapter_modes_are_limited_to_command_and_fixture(self):
        from team_runner import validate_adapters
        for mode in ("native", "inline", "shell", "eval", ""):
            with self.subTest(mode=mode):
                config = {"schema_version": 1, "adapters": {"repo-research": {
                    "argv": [sys.executable], "mode": mode, "timeout_seconds": 10}}}
                with self.assertRaises(TeamError):
                    validate_adapters(config)

    def test_command_adapters_need_explicit_authorization(self):
        from team_runner import run_batch
        config = load_json(DEMO / "adapters.model.json")
        with self.assertRaises(TeamError) as ctx:
            run_batch(self.job, config)
        self.assertEqual(ctx.exception.code, "AUTHORIZATION")


# --------------------------------------------------------------------------- #
class A11_UndeclaredOutputSmuggling(LedgerCase):
    def test_an_extra_file_in_the_output_directory_blocks_submit(self):
        packet, result = self.produce("facts")
        (Path(packet["output_root"]) / "notes.txt").write_text("side channel\n", encoding="utf-8")
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "UNDECLARED_OUTPUT")

    def test_extra_files_in_nested_directories_are_caught(self):
        packet, result = self.produce("facts")
        nested = Path(packet["output_root"]) / "research/private/leak.json"
        nested.parent.mkdir(parents=True, exist_ok=True)
        nested.write_text("{}\n", encoding="utf-8")
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "UNDECLARED_OUTPUT")

    def test_a_dangling_symlink_counts_as_an_undeclared_output(self):
        packet, result = self.produce("facts")
        make_symlink_or_skip(self, Path(packet["output_root"]) / "shortcut", self.base / "nowhere")
        with self.assertRaises(REFUSED):
            self.store.submit(result)

    def test_declaring_an_extra_artifact_is_refused(self):
        packet, result = self.produce("facts")
        extra = Path(packet["output_root"]) / "notes.txt"
        extra.write_text("side channel\n", encoding="utf-8")
        result["artifacts"].append({"id": "sneaky", "path": "notes.txt",
                                    "sha256": file_sha(extra)})
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "OUTPUT_SCOPE")

    def test_external_actions_are_never_accepted(self):
        packet, result = self.produce("facts")
        result["external_actions"] = [{"kind": "http_post", "url": "https://example.invalid"}]
        with self.assertRaises(TeamError) as ctx:
            self.store.submit(result)
        self.assertEqual(ctx.exception.code, "SIDE_EFFECT")


# --------------------------------------------------------------------------- #
class CoverageGuard(unittest.TestCase):
    """The eleven attacks must stay in this file; deleting one fails the suite."""

    def test_every_attack_class_is_present_and_populated(self):
        expected = ["A1_ConcurrentDoubleClaim", "A2_UnlockWithoutReview",
                    "A3_UnlockOnSubmitAlone", "A4_BorrowedLeaseToken",
                    "A5_DeclaredArtifactMissing", "A6_ForgedArtifactHash",
                    "A7_WritingOutsideScope", "A8_StaleHashPass", "A9_LateSubmit",
                    "A10_PlanCommandInjection", "A11_UndeclaredOutputSmuggling"]
        module = sys.modules[__name__]
        for name in expected:
            with self.subTest(attack=name):
                case = getattr(module, name, None)
                self.assertIsNotNone(case, name + " was removed")
                tests = [m for m in dir(case) if m.startswith("test_")]
                self.assertTrue(tests, name + " has no tests left")


if __name__ == "__main__":
    unittest.main()
