"""Shared filesystem fixture helpers; blocked real tests remain visibly skipped."""
from pathlib import Path
import sys
SCRIPTS = str(Path(__file__).resolve().parents[1] / 'scripts')
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)
from filesystem_capabilities import probe_long_path_support, symlink_unavailable


def make_symlink_or_skip(testcase, link, target, target_is_directory=False):
    try:
        link.symlink_to(target, target_is_directory=target_is_directory)
    except (OSError, NotImplementedError) as exc:
        if not symlink_unavailable(exc):
            raise
        testcase.skipTest('ENVIRONMENT_BLOCKED:SYMLINK real link test not executed: ' + str(exc))


def require_long_paths_or_skip(testcase, root):
    result = probe_long_path_support(root)
    if result['status'] == 'ENVIRONMENT_BLOCKED':
        testcase.skipTest('ENVIRONMENT_BLOCKED:LONG_PATH real >260-character test not executed: '
                          + result['reason'])
    return result
