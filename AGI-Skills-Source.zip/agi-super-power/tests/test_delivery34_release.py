"""CLI, release metadata and atomic ledger integration checks."""
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from kernel import load_json
from team_runtime import TeamStore,TeamError
from release_version import PACKAGE_VERSION,RUNTIME_VERSION

class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
    def test_version_sources_agree(self):
        v=load_json(ROOT/'VERSION.json');self.assertEqual(PACKAGE_VERSION,v['package_version']);self.assertEqual(RUNTIME_VERSION,v['runtime_version'])
        self.assertEqual(PACKAGE_VERSION,'3.4.0-rc.7')
    def test_release_does_not_claim_native_success(self):
        v=load_json(ROOT/'VERSION.json');self.assertEqual(v['release_status'],'OFFLINE_CANDIDATE_NOT_NATIVE_VALIDATED')
        self.assertIn('HANDOFF_ONLY',v['workbuddy'])
    def test_cli_doctor_is_not_host_probe(self):
        r=subprocess.run([sys.executable,'-B',str(ROOT/'scripts/delivery_cli.py'),'doctor'],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stderr);d=json.loads(r.stdout)
        self.assertFalse(d['native_compatibility_proven']);self.assertEqual(d['real_agent_calls'],0)
    def test_probe_handoff_exit_code_is_nonzero(self):
        from host_contract34 import blank_probe
        p=self.root/'probe.json';p.write_text(json.dumps(blank_probe('workbuddy')))
        r=subprocess.run([sys.executable,'-B',str(ROOT/'scripts/delivery_cli.py'),'probe-check','--probe',str(p),'--evidence-root',str(self.root)],capture_output=True,text=True)
        self.assertEqual(r.returncode,2,r.stderr);self.assertEqual(json.loads(r.stdout)['status'],'HANDOFF_ONLY')
    def test_missing_job_not_created(self):
        job=self.root/'missing'
        r=subprocess.run([sys.executable,'-B',str(ROOT/'scripts/delivery_cli.py'),'resume','--job',str(job)],capture_output=True,text=True)
        self.assertEqual(r.returncode,1);self.assertFalse(job.exists())
    def test_checkpoint_failure_rolls_back_claim(self):
        p=load_json(ROOT/'examples/team-demo/plan.codex-v3.json');job=self.root/'job';TeamStore.create(job,p,ROOT/'examples/team-demo')
        with TeamStore(job) as s:
            with patch('delivery_state.save_checkpoint',side_effect=RuntimeError('injected checkpoint failure')):
                with self.assertRaises(RuntimeError):s.claim('facts','worker')
            self.assertEqual(s.row('facts')['status'],'pending');self.assertEqual(s.row('facts')['attempt'],0)
            self.assertEqual(s.db.execute('SELECT COUNT(*) FROM dispatch34').fetchone()[0],0)
    def test_adding_quality_gate_after_freeze_is_tampering(self):
        p=load_json(ROOT/'examples/team-demo/plan.codex-v3.json');job=self.root/'job';TeamStore.create(job,p,ROOT/'examples/team-demo')
        p['tasks'][0]['quality_gates']=[];(job/'plan.json').write_text(json.dumps(p))
        with TeamStore(job) as s:
            with self.assertRaises(TeamError):s.claim('facts','worker')

if __name__=='__main__':unittest.main()
