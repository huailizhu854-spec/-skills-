"""Adversarial tests for the deterministic package builder and verifier."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import struct
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import warnings
import zipfile


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "package_release.py"
SPEC = importlib.util.spec_from_file_location("agi_super_power_package_release", SCRIPT)
assert SPEC and SPEC.loader
package = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(package)


class PackageTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.root = self.base / "agi-super-power"
        self.root.mkdir()
        (self.root / "SKILL.md").write_text("---\nname: agi-super-power\ndescription: Test fixture\n---\n# Test\n", encoding="utf-8")
        (self.root / "references").mkdir()
        (self.root / "references" / "guide.md").write_text("A bounded SOP.\n", encoding="utf-8")
        self.output = self.base / "test.zip"

    def build(self) -> dict:
        return package.build_archive(self.root, self.output)

    def rewrite(self, *, change: dict[str, bytes] | None = None, append: list[tuple[str, bytes]] | None = None, remove: set[str] | None = None) -> Path:
        target = self.base / "tampered.zip"
        change, append, remove = change or {}, append or [], remove or set()
        with zipfile.ZipFile(self.output) as source, zipfile.ZipFile(target, "w") as destination:
            for entry in source.infolist():
                if entry.filename not in remove:
                    destination.writestr(entry, change.get(entry.filename, source.read(entry)))
            for path, payload in append:
                destination.writestr(path, payload)
        return target

    def test_normal_package_and_manifest_coverage(self) -> None:
        result = self.build()
        self.assertTrue(result["valid"])
        self.assertEqual(result["files"], 2)
        self.assertEqual(result["zip_entries"], 3)
        self.assertEqual(result["sha256"], hashlib.sha256(self.output.read_bytes()).hexdigest())
        self.assertFalse(result["contents_executed"])
        with zipfile.ZipFile(self.output) as archive:
            manifest = json.loads(archive.read("agi-super-power/SHA256SUMS.json"))
            self.assertEqual({item["path"] for item in manifest["files"]}, {"SKILL.md", "references/guide.md"})
        self.assertTrue(package.verify_archive(self.output)["valid"])
        self.assertFalse((self.root / "SHA256SUMS.json").exists())

    def test_reproducible_bytes_and_fixed_metadata(self) -> None:
        self.build()
        second = self.base / "second.zip"
        package.build_archive(self.root, second)
        self.assertEqual(self.output.read_bytes(), second.read_bytes())
        with zipfile.ZipFile(self.output) as archive:
            self.assertEqual(archive.namelist(), sorted(archive.namelist()))
            for entry in archive.infolist():
                self.assertEqual(entry.date_time, (1980, 1, 1, 0, 0, 0))
                self.assertEqual((entry.external_attr >> 16) & 0o777, 0o644)
                self.assertTrue(entry.flag_bits & 0x800)

    def test_unicode_filename_is_preserved(self) -> None:
        (self.root / "references" / "流程.md").write_text("工作流程", encoding="utf-8")
        self.build()
        with zipfile.ZipFile(self.output) as archive:
            self.assertEqual(archive.read("agi-super-power/references/流程.md").decode("utf-8"), "工作流程")

    def test_output_not_overwritten(self) -> None:
        self.output.write_bytes(b"existing user file")
        with self.assertRaisesRegex(package.PackageError, "overwriting"):
            self.build()
        self.assertEqual(self.output.read_bytes(), b"existing user file")

    def test_output_inside_root_is_rejected(self) -> None:
        with self.assertRaisesRegex(package.PackageError, "outside"):
            package.build_archive(self.root, self.root / "release.zip")

    def test_reserved_manifest_is_regenerated_without_mutating_source(self) -> None:
        previous = self.root / "SHA256SUMS.json"; previous.write_text("old", encoding="utf-8")
        result = self.build()
        self.assertIn("SHA256SUMS.json", result["skipped"])
        self.assertEqual(previous.read_text(encoding="utf-8"), "old")

    def test_cache_and_git_skipped(self) -> None:
        for name in (".git", "__pycache__"):
            (self.root / name).mkdir()
            (self.root / name / "discard.txt").write_text("cache", encoding="utf-8")
        (self.root / "discard.pyc").write_bytes(b"compiled cache")
        self.assertEqual(self.build()["files"], 2)

    def test_payload_tampering(self) -> None:
        self.build()
        tampered = (self.root / "references" / "guide.md").read_bytes().replace(b"bounded", b"changed")
        corrupt = self.rewrite(change={"agi-super-power/references/guide.md": tampered})
        with self.assertRaisesRegex(package.PackageError, "hash"):
            package.verify_archive(corrupt)

    def test_manifest_extra_and_missing_files(self) -> None:
        self.build()
        for modification in ({"append": [("agi-super-power/extra.txt", b"extra")]}, {"remove": {"agi-super-power/references/guide.md"}}):
            with self.subTest(modification=modification):
                corrupt = self.rewrite(**modification)
                with self.assertRaisesRegex(package.PackageError, "exactly cover"):
                    package.verify_archive(corrupt)

    def test_duplicate_zip_entry(self) -> None:
        self.build()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            corrupt = self.rewrite(append=[("agi-super-power/SKILL.md", b"duplicate")])
        with self.assertRaisesRegex(package.PackageError, "duplicate"):
            package.verify_archive(corrupt)

    def test_archive_traversal_absolute_backslash_device_ads(self) -> None:
        self.build()
        names = ["../outside", "/absolute", "C:/outside", "agi-super-power/../outside", "agi-super-power/a\\b", "agi-super-power/NUL.txt", "agi-super-power/file:stream", "agi-super-power/a//b"]
        for name in names:
            with self.subTest(name=name):
                with self.assertRaises(package.PackageError):
                    package.verify_archive(self.rewrite(append=[(name, b"bad")]))

    def test_archive_case_and_unicode_collision(self) -> None:
        self.build()
        for additions in [[("agi-super-power/skill.md", b"different case")], [("agi-super-power/cafe\u0301.txt", b"one"), ("agi-super-power/caf\u00e9.txt", b"two")]]:
            with self.subTest(additions=additions):
                with self.assertRaisesRegex(package.PackageError, "colliding"):
                    package.verify_archive(self.rewrite(append=additions))

    def test_nul_in_original_filename_is_rejected(self) -> None:
        self.build()
        original = b"agi-super-power/references/guide.md"
        corrupt = self.base / "nul.zip"
        corrupt.write_bytes(self.output.read_bytes().replace(original, original[:-1] + b"\x00"))
        with self.assertRaises(package.PackageError):
            package.verify_archive(corrupt)

    def test_multiple_roots_and_file_directory_conflict(self) -> None:
        self.build()
        for additions in [[("second-root/file.txt", b"outside")], [("agi-super-power/references", b"file")]]:
            with self.subTest(additions=additions):
                with self.assertRaises(package.PackageError):
                    package.verify_archive(self.rewrite(append=additions))

    def test_source_missing_or_extra_instruction_entry(self) -> None:
        for name in ("AGENTS.md", "SYSTEM_PROMPT.md", "CLAUDE.md", "SKILL.md"):
            with self.subTest(name=name):
                entry = self.root / "references" / name
                entry.write_text("untrusted instruction", encoding="utf-8")
                with self.assertRaises(package.PackageError):
                    self.build()
                entry.unlink()
        (self.root / "SKILL.md").unlink()
        with self.assertRaisesRegex(package.PackageError, "SKILL"):
            self.build()

    def test_archived_symlink_and_special_file(self) -> None:
        self.build()
        for file_type in (stat.S_IFLNK, stat.S_IFIFO):
            with self.subTest(file_type=file_type):
                corrupt = self.rewrite()
                with zipfile.ZipFile(corrupt, "a") as archive:
                    entry = zipfile.ZipInfo("agi-super-power/linked")
                    entry.create_system = 3
                    entry.external_attr = (file_type | 0o644) << 16
                    archive.writestr(entry, b"../outside")
                with self.assertRaisesRegex(package.PackageError, "special file"):
                    package.verify_archive(corrupt)

    def test_simulated_source_reparse_point_rejected(self) -> None:
        actual_lstat = Path.lstat
        target = self.root.resolve() / "references"
        def fake_lstat(path, *args, **kwargs):
            actual = actual_lstat(path, *args, **kwargs)
            return SimpleNamespace(st_mode=actual.st_mode, st_file_attributes=0x400) if path == target else actual
        with patch.object(Path, "lstat", fake_lstat):
            with self.assertRaisesRegex(package.PackageError, "linked directory"):
                self.build()
        self.assertFalse(self.output.exists())

    def test_bomb_ratio_and_total_limit_before_payload_read(self) -> None:
        bomb = self.base / "bomb.zip"
        with zipfile.ZipFile(bomb, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("agi-super-power/SKILL.md", b"a" * 500_000)
        with self.assertRaisesRegex(package.PackageError, "compression-ratio"):
            package.verify_archive(bomb)
        self.build()
        with patch.object(package, "MAX_TOTAL_BYTES", 8):
            with self.assertRaisesRegex(package.PackageError, "size"):
                package.verify_archive(self.output)

    def test_malformed_manifest_types_and_self_inclusion(self) -> None:
        self.build()
        invalid = [None, [], {"schema_version": True, "root": "agi-super-power", "files": []}, {"schema_version": 1, "root": "agi-super-power", "files": [None]}, {"schema_version": 1, "root": "agi-super-power", "files": [{"path": "SHA256SUMS.json", "sha256": "0" * 64, "bytes": 0}]}]
        for value in invalid:
            with self.subTest(value=value):
                corrupt = self.rewrite(change={"agi-super-power/SHA256SUMS.json": json.dumps(value).encode()})
                with self.assertRaises(package.PackageError):
                    package.verify_archive(corrupt)

    def test_manifest_boolean_size_duplicate_keys_and_malformed_json(self) -> None:
        self.build()
        with zipfile.ZipFile(self.output) as archive:
            manifest = json.loads(archive.read("agi-super-power/SHA256SUMS.json"))
        manifest["files"][0]["bytes"] = True
        for raw in (json.dumps(manifest).encode(), b'{"root":1,"root":2}', b'{bad'):
            with self.subTest(raw=raw[:30]):
                corrupt = self.rewrite(change={"agi-super-power/SHA256SUMS.json": raw})
                with self.assertRaises((package.PackageError, ValueError)):
                    package.verify_archive(corrupt)

    def test_cli_invalid_archive_has_json_error_without_traceback(self) -> None:
        self.output.write_bytes(b"not a ZIP")
        process = subprocess.run([sys.executable, "-B", str(SCRIPT), "verify", str(self.output)], capture_output=True, text=True)
        self.assertEqual(process.returncode, 1)
        self.assertFalse(json.loads(process.stdout)["valid"])
        self.assertNotIn("Traceback", process.stderr)

    def test_cli_corrupt_deflate_has_json_error_without_traceback(self) -> None:
        self.build()
        compressed = self.base / "compressed.zip"
        with zipfile.ZipFile(self.output) as source, zipfile.ZipFile(compressed, "w", compression=zipfile.ZIP_DEFLATED) as target:
            for entry in source.infolist():
                target.writestr(entry.filename, source.read(entry), compress_type=zipfile.ZIP_DEFLATED)
        with zipfile.ZipFile(compressed) as archive:
            member = archive.getinfo("agi-super-power/SKILL.md")
        raw = bytearray(compressed.read_bytes())
        filename_bytes, extra_bytes = struct.unpack_from("<HH", raw, member.header_offset + 26)
        start = member.header_offset + 30 + filename_bytes + extra_bytes
        raw[start] = 0xFF  # Invalid DEFLATE block type.
        compressed.write_bytes(raw)
        process = subprocess.run([sys.executable, "-B", str(SCRIPT), "verify", str(compressed)], capture_output=True, text=True)
        self.assertEqual(process.returncode, 1)
        self.assertFalse(json.loads(process.stdout)["valid"])
        self.assertNotIn("Traceback", process.stderr)

    def test_cli_build_and_verify(self) -> None:
        for arguments in (["build", "--root", str(self.root), "--output", str(self.output)], ["verify", str(self.output)]):
            process = subprocess.run([sys.executable, "-B", str(SCRIPT), *arguments], capture_output=True, text=True)
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            self.assertTrue(json.loads(process.stdout)["valid"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
