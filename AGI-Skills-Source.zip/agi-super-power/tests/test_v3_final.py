"""Final integration regressions. Local fixtures only; ZERO real model/native calls."""
from __future__ import annotations
import copy
import hashlib
import json
import multiprocessing
import os
import queue
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import time
import traceback
import unittest
from fs_test_support import make_symlink_or_skip
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from kernel import load_json
from team_runtime import TeamStore,TeamError,compile_plan,digest,write_json
from model_worker import run_packet,CallBudget,WorkerError,ModelTimeout,CommandClient,read_envelope
from model_semaphore import ConcurrencyGate,SemaphoreError
from host_adapters.claude_code import ClaudeCodeAdapter,agent_definition
from install_claude_agents import install
from verifier_registry import evaluate
from v3_protocol import strict_loads
from package_release import build_archive,verify_archive,PackageError
from host_bridge_export_evidence import export

DEMO=ROOT/'examples/team-demo'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def envelope(data,aid='facts-data'):
    return json.dumps({'outputs':[{'id':aid,'content':json.dumps(data,ensure_ascii=False)}],'concerns':[]})
def good_facts():
    raw=(DEMO/'brief.txt').read_bytes();text=raw.decode()
    return {'lines':len(text.splitlines()),'characters':len(text),'brief_sha256':hashlib.sha256(raw).hexdigest()}

class Fake:
    provider='fixture-model';model='NOT_A_REAL_MODEL';secret=''
    def __init__(self,*values):self.values=list(values);self.calls=0
    def complete(self,system,prompt):
        self.calls+=1;v=self.values.pop(0)
        if isinstance(v,BaseException):raise v
        return {'text':v,'seconds':0.001,'meta':{'fixture':True}}

class Case(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.base=Path(self.temp.name);self.job=self.base/'job'
        self.plan=load_json(DEMO/'plan.model-v3.json')
    def create(self):
        TeamStore.create(self.job,self.plan,DEMO)
        self.store=TeamStore(self.job);self.addCleanup(self.store.close)
        self.packet=self.store.claim('facts','facts-worker')
        return self.packet
    def produce(self, data=None):
        self.create()
        self.result=run_packet(self.packet,Fake(envelope(data or good_facts())),CallBudget(3),retries=0)
        self.bind_submit()
        return self.result
    def bind_submit(self):
        token=self.packet['lease_token'];host='test-only-'+token
        self.store.bind('facts',token,'command',host)
        receipt={'host_run_id':host,'mode':'command','finished':True,'task_id':'facts','lease_token':token,'exit_code':0}
        p=Path(self.packet['workspace'])/'evidence/host.json';write_json(p,receipt)
        self.result['host_run_id']=host;self.result['host_receipt']={'path':'evidence/host.json','sha256':sha(p)}
        self.store.submit(self.result)
    def review(self):
        p=self.job/'reviews/controller.json'
        if not p.exists():write_json(p,{'note':'Fixture coordinator requesting independent execution, not a business PASS assertion'})
        return self.store.review({'task_id':'facts','result_id':self.result['result_id'],'result_digest':digest(self.result),
                'goal_digest':self.packet['goal_digest'],'reviewer':'coordinator','decision':'accept','reason':'Run independent verifier',
                'evidence_path':'reviews/controller.json','evidence_sha256':sha(p)})

class AcceptanceTests(Case):
    def test_structure_pass_is_not_requirement_pass(self):
        self.produce({'lines':999,'characters':999,'brief_sha256':'0'*64})
        self.assertEqual(self.result['technical_validation']['outcome'],'PASS')
        self.assertEqual(self.result['checks'][0]['outcome'],'UNVERIFIED')
        with self.assertRaisesRegex(TeamError,'Independent requirement'):self.review()
        self.assertEqual(self.store.row('facts')['status'],'submitted')
    def test_independent_exact_facts_accept(self):
        self.produce();self.assertEqual(self.review()['status'],'accepted')
        reports=list((self.job/'reviews').glob('acceptance-*.json'));self.assertEqual(len(reports),1)
        r=load_json(reports[0]);self.assertTrue(r['passed']);self.assertEqual(r['kind'],'contract_acceptance')
        self.assertEqual(self.result['checks'][0]['execution'],'NOT_EXECUTED')
    def test_json_array_is_a_failed_requirement_not_a_verifier_crash(self):
        self.create();self.result=run_packet(self.packet,Fake(envelope([1,2,3])),CallBudget(1),retries=0);self.bind_submit()
        with self.assertRaises(TeamError):self.review()
    def test_model_transport_requires_explicit_authorization(self):
        self.plan['tasks'][0]['executor']['transport_network']=False
        with self.assertRaises(ValueError):compile_plan(self.plan)
    def test_static_page_cannot_use_digit_inside_hash_as_line_count(self):
        self.create();packet=copy.deepcopy(self.packet);workspace=Path(packet['workspace'])
        facts=workspace/'inputs/page-facts.json';outline=workspace/'inputs/page-outline.json'
        write_json(facts,good_facts());write_json(outline,{'title':'Title','sections':['Body']})
        packet['contract']['reads']=['facts-data','outline-data'];packet['contract']['outputs']=[{'id':'page-html','path':'page.html'}]
        packet['contract']['acceptance']=[{'id':'page-check','requirement':'R1','method':'demo-page-v3','evidence_kind':'RUNTIME_FACT','subject':{'scope':'artifact','artifact_id':'page-html'}}]
        packet['input_snapshots']=[{'id':'facts-data','path':str(facts),'sha256':sha(facts)},{'id':'outline-data','path':str(outline),'sha256':sha(outline)}]
        page=Path(packet['output_root'])/'page.html';page.write_text('<!doctype html><html><body><h1>Title</h1>Body '+good_facts()['brief_sha256']+'</body></html>')
        result={'artifacts':[{'id':'page-html','path':'page.html','sha256':sha(page)}]}
        assessment=evaluate(packet,result);self.assertFalse(assessment['passed'])
        page.write_text(page.read_text().replace('</body>',' lines=3</body>'));result['artifacts'][0]['sha256']=sha(page)
        self.assertTrue(evaluate(packet,result)['passed'])
    def test_unknown_verifier_cannot_pass(self):
        self.plan['tasks'][0]['acceptance'][0]['method']='imagined-web-research'
        self.produce()
        with self.assertRaises(TeamError):self.review()
        r=load_json(next((self.job/'reviews').glob('acceptance-*.json')))
        self.assertEqual(r['checks'][0]['execution'],'NOT_EXECUTED')
    def test_unimplemented_source_fact_does_not_masquerade_as_runtime(self):
        self.plan['tasks'][0]['acceptance'][0]['evidence_kind']='SOURCE_FACT'
        self.produce()
        with self.assertRaises(TeamError):self.review()
    def test_character_count_now_has_an_exact_gating_definition(self):
        data=good_facts();data['characters']-=1;self.produce(data)
        with self.assertRaises(TeamError):self.review()
    def test_wrong_statistic_hidden_in_an_unrelated_field_does_not_pass(self):
        data=good_facts();data['noise']=data['lines'];data['lines']=999;self.produce(data)
        with self.assertRaises(TeamError):self.review()
    def test_boolean_is_not_an_integer_statistic(self):
        data=good_facts();data['lines']=True;self.produce(data)
        with self.assertRaises(TeamError):self.review()
    def test_producer_cannot_submit_requirement_pass(self):
        self.create();r=run_packet(self.packet,Fake(envelope(good_facts())),CallBudget(2))
        r['checks'][0]['execution']='EXECUTED';r['checks'][0]['outcome']='PASS';self.result=r
        with self.assertRaisesRegex(TeamError,'Producer acceptance'):self.bind_submit()
    def test_mutated_acceptance_report_blocks_downstream(self):
        self.produce();self.review()
        p=next((self.job/'reviews').glob('acceptance-*.json'));p.write_text('{}')
        self.assertTrue(self.store.status()['changed_evidence'])
    def test_mismatched_subject_hash_rejected(self):
        self.create();self.result=run_packet(self.packet,Fake(envelope(good_facts())),CallBudget(2))
        self.result['checks'][0]['subject_hashes']['facts-data']='0'*64
        with self.assertRaises(TeamError):self.bind_submit()
    def test_legacy_offline_plan_cannot_bind_model_host(self):
        self.plan=load_json(DEMO/'plan.json');self.create()
        with self.assertRaisesRegex(TeamError,'Migrate'):self.store.bind('facts',self.packet['lease_token'],'command','cli')
    def test_legacy_packet_cannot_silently_run_a_model(self):
        self.plan=load_json(DEMO/'plan.json');self.create();f=Fake(envelope(good_facts()))
        with self.assertRaises(WorkerError):run_packet(self.packet,f,CallBudget(2))
        self.assertEqual(f.calls,0)
    def test_exact_runtime_host_required(self):
        self.create()
        with self.assertRaises(TeamError):self.store.bind('facts',self.packet['lease_token'],'native','host')
    def test_multi_output_check_is_bound_to_second_artifact(self):
        t=self.plan['tasks'][0];t['outputs'].append({'id':'second','path':'second.json'})
        t['acceptance'][0].update(method='json-values-v1',subject={'scope':'artifact','artifact_id':'second'},params={'equals':{'ok':True}})
        self.create();raw=json.dumps({'outputs':[{'id':'facts-data','content':'{"ok":true}'},{'id':'second','content':'{"ok":false}'}]})
        self.result=run_packet(self.packet,Fake(raw),CallBudget(2));self.bind_submit()
        self.assertEqual(set(self.result['checks'][0]['subject_hashes']),{'second'})
        with self.assertRaises(TeamError):self.review()
    def test_cross_artifact_hash_binding(self):
        t=self.plan['tasks'][0];t['outputs'].append({'id':'second','path':'second.json'})
        t['acceptance'][0].update(method='equal-bytes-v1',subject={'scope':'cross-artifact','artifact_ids':['facts-data','second']})
        self.create();raw=json.dumps({'outputs':[{'id':aid,'content':'{"ok":true}'} for aid in ('facts-data','second')]})
        self.result=run_packet(self.packet,Fake(raw),CallBudget(2));self.bind_submit();self.assertEqual(self.review()['status'],'accepted')
    def test_missing_subject_never_defaults_to_first_output(self):
        del self.plan['tasks'][0]['acceptance'][0]['subject']
        with self.assertRaises(ValueError):compile_plan(self.plan)
    def test_unknown_subject_scope_is_rejected(self):
        self.plan['tasks'][0]['acceptance'][0]['subject']={'scope':'workflow'}
        with self.assertRaises(ValueError):compile_plan(self.plan)
    def test_tool_capability_and_substrate_are_distinct(self):
        self.assertTrue(compile_plan(self.plan)['valid'])
        self.plan['tasks'][0]['capabilities']['network']=True
        with self.assertRaises(ValueError):compile_plan(self.plan)
    def test_recursion_permission_is_rejected(self):
        self.plan['tasks'][0]['capabilities']['model_delegation']=True
        with self.assertRaises(ValueError):compile_plan(self.plan)
    def test_cross_agent_external_writes_are_not_implicitly_enabled(self):
        self.plan['tasks'][0]['capabilities']['external_write']=True
        with self.assertRaises(ValueError):compile_plan(self.plan)

class JournalAndBoundaryTests(Case):
    def events(self):return [json.loads(x) for x in (Path(self.packet['workspace'])/'evidence/model-events.jsonl').read_text().splitlines()]
    def test_all_parse_failures_leave_raw_journal(self):
        self.create()
        with self.assertRaises(WorkerError):run_packet(self.packet,Fake('bad one','bad two'),CallBudget(2),retries=1)
        es=self.events();self.assertEqual(sum(x['event']=='CALL_RETURNED' for x in es),2)
        self.assertIn('bad two',json.dumps(es));self.assertEqual(es[-1]['event'],'WORKER_ABORTED')
    def test_parse_failure_then_timeout_is_preserved(self):
        self.create()
        with self.assertRaises(ModelTimeout):run_packet(self.packet,Fake('bad',ModelTimeout('timeout')),CallBudget(2),retries=1)
        es=self.events();self.assertIn('CALL_PARSE_FAILED',[x['event'] for x in es]);self.assertIn('CALL_FAILED_OR_UNKNOWN',[x['event'] for x in es])
    def test_budget_exhaustion_records_abort_without_extra_call(self):
        self.create();f=Fake('bad','never')
        with self.assertRaises(WorkerError):run_packet(self.packet,f,CallBudget(1),retries=1)
        self.assertEqual(f.calls,1);self.assertEqual(self.events()[-1]['event'],'WORKER_ABORTED')
    def test_journal_chain_matches_every_previous_line(self):
        self.create();run_packet(self.packet,Fake(envelope(good_facts())),CallBudget(2))
        lines=(Path(self.packet['workspace'])/'evidence/model-events.jsonl').read_bytes().splitlines(keepends=True)
        previous='0'*64
        for line in lines:
            self.assertEqual(json.loads(line)['previous_sha256'],previous);previous=hashlib.sha256(line).hexdigest()
    def test_journal_redacts_key_even_on_failure(self):
        self.create();f=Fake('SECRET-test');f.secret='SECRET-test'
        with self.assertRaises(WorkerError):run_packet(self.packet,f,CallBudget(1),retries=0)
        raw=(Path(self.packet['workspace'])/'evidence/model-events.jsonl').read_text();self.assertNotIn(f.secret,raw)
    def test_is_error_true_with_exit_zero_is_failure(self):
        client=CommandClient([sys.executable,'-c','import json;print(json.dumps({"is_error":True,"result":"{}"}))'],'test',10)
        with self.assertRaisesRegex(WorkerError,'is_error'):client.complete('','')
    def test_duplicate_json_keys_are_rejected(self):
        with self.assertRaises(WorkerError):read_envelope('{"outputs":[],"outputs":[]}',{'x':'x'},1000)
    def test_nonfinite_json_is_rejected(self):
        with self.assertRaises(WorkerError):read_envelope('{"outputs":[],"extra":NaN}',{'x':'x'},1000)
    def test_parent_escape_preflight_prevents_model_call(self):
        self.create();self.packet['contract']['outputs'][0]['path']='../escape.json';f=Fake('bad')
        with self.assertRaises(WorkerError):run_packet(self.packet,f,CallBudget(1))
        self.assertEqual(f.calls,0);self.assertFalse((self.base/'escape.json').exists())
    def test_result_path_escape_preflight_prevents_model_call(self):
        self.create();self.packet['result_path']=str(self.base/'escape.json');f=Fake('bad')
        with self.assertRaises(WorkerError):run_packet(self.packet,f,CallBudget(1))
        self.assertEqual(f.calls,0)
    def test_input_outside_workspace_is_rejected(self):
        self.create();self.packet['input_snapshots'][0]['path']=str(DEMO/'brief.txt');f=Fake('bad')
        with self.assertRaises(WorkerError):run_packet(self.packet,f,CallBudget(1))
        self.assertEqual(f.calls,0)
    def test_symlink_output_parent_is_rejected(self):
        self.create();make_symlink_or_skip(self, Path(self.packet['output_root'])/'research', self.base, target_is_directory=True)
        f=Fake('bad')
        with self.assertRaises(WorkerError):run_packet(self.packet,f,CallBudget(1))
        self.assertEqual(f.calls,0)
    def test_goal_snapshot_tampering_is_rejected_before_call(self):
        self.create();self.packet['goal']['objective']='mutated';f=Fake('bad')
        with self.assertRaises(WorkerError):run_packet(self.packet,f,CallBudget(1))
        self.assertEqual(f.calls,0)


    def test_provider_nonzero_stdout_and_stderr_are_durable(self):
        self.create()
        client=CommandClient([sys.executable,'-c','import sys;print("OUTPUT-before-failure");sys.stderr.write("ERROR-details");sys.exit(2)'],'fixture',10)
        with self.assertRaises(WorkerError):run_packet(self.packet,client,CallBudget(1),retries=0)
        event=next(e for e in self.events() if e['event']=='CALL_FAILED_OR_UNKNOWN')
        self.assertIn('OUTPUT-before-failure',event['observation']['stdout']['text'])
        self.assertEqual(event['observation']['stderr']['text'],'ERROR-details')
        self.assertFalse(event['observation']['stdout']['truncated'])
    def test_failed_calls_are_in_aggregate_without_result_json(self):
        from host_bridge_model_demo import call_records
        self.create()
        with self.assertRaises(WorkerError):run_packet(self.packet,Fake('wrong','wrong-again'),CallBudget(2),retries=1)
        self.assertFalse(Path(self.packet['result_path']).exists())
        calls=call_records(self.job);self.assertEqual(len(calls),2)
        self.assertTrue(all(c['parsed'] is False for c in calls))
    def test_timeout_partial_stdout_has_explicit_partial_flag(self):
        self.create();client=CommandClient([sys.executable,'-c','pass'],'fixture',10)
        err=subprocess.TimeoutExpired(client.argv,10,output=b'partial-message',stderr=b'partial-error')
        with patch('model_worker.subprocess.run',side_effect=err):
            with self.assertRaises(ModelTimeout):run_packet(self.packet,client,CallBudget(1),retries=0)
        observation=next(e for e in self.events() if e['event']=='CALL_FAILED_OR_UNKNOWN')['observation']
        self.assertTrue(observation['partial']);self.assertEqual(observation['stdout']['text'],'partial-message')
    def test_failure_observation_limit_is_not_claimed_complete(self):
        from model_worker import observed_bytes
        observation=observed_bytes(b'x'*20,limit=5)
        self.assertTrue(observation['truncated']);self.assertEqual(observation['captured_bytes'],5)
        self.assertEqual(observation['total_bytes'],20)
    def test_command_credentials_are_scrubbed_on_failure(self):
        self.create();key='TEST-secret-command-env'
        client=CommandClient([sys.executable,'-c','import os,sys;print(os.environ["ANTHROPIC_API_KEY"]);sys.exit(1)'],'fixture',10)
        with patch.dict(os.environ,{'ANTHROPIC_API_KEY':key}):
            with self.assertRaises(WorkerError):run_packet(self.packet,client,CallBudget(1),retries=0)
        self.assertNotIn(key,(Path(self.packet['workspace'])/'evidence/model-events.jsonl').read_text())

class DispatchPreflightTests(Case):
    def config(self,mode):
        return {'schema_version':1,'adapters':{t['role']:{'argv':[sys.executable,'-c','raise RuntimeError("must not execute")'],'mode':mode,'timeout_seconds':10} for t in self.plan['tasks']}}
    def test_wrong_mode_is_blocked_before_any_process_or_lease(self):
        from team_runner import run_batch
        TeamStore.create(self.job,self.plan,DEMO)
        with patch('team_runner.subprocess.Popen') as popen:
            with self.assertRaises(TeamError):run_batch(self.job,self.config('fixture'),allow_commands=True)
            popen.assert_not_called()
        with TeamStore(self.job) as store:self.assertEqual(store.row('facts')['attempt'],0)
    def test_legacy_fixture_contract_cannot_launch_command_wrapper(self):
        from team_runner import run_batch
        self.plan=load_json(DEMO/'plan.json');TeamStore.create(self.job,self.plan,DEMO)
        with patch('team_runner.subprocess.Popen') as popen:
            with self.assertRaises(TeamError):run_batch(self.job,self.config('command'),allow_commands=True)
            popen.assert_not_called()
    def test_direct_execute_also_checks_before_process(self):
        from team_runner import execute
        TeamStore.create(self.job,self.plan,DEMO)
        with patch('team_runner.subprocess.Popen') as popen:
            answer=execute(self.job,'facts',next(iter(self.config('fixture')['adapters'].values())))
            popen.assert_not_called();self.assertEqual(answer['status'],'not_started')


def _stress_gate(directory, limit, active, maximum, errors):
    try:
        for _ in range(5):
            with ConcurrencyGate(limit,Path(directory),20):
                with active.get_lock():
                    active.value+=1
                    maximum.value=max(maximum.value,active.value)
                time.sleep(.012)
                with active.get_lock():active.value-=1
    except BaseException:errors.put(traceback.format_exc())

def _crash_gate(directory):
    gate=ConcurrencyGate(1,Path(directory),5);gate.__enter__();os._exit(7)

class SemaphoreTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.base=Path(self.temp.name)
    def stress(self,limit,cold=False):
        ctx=multiprocessing.get_context('spawn');active=ctx.Value('i',0);maximum=ctx.Value('i',0);errors=ctx.Queue()
        # Initialize schema before workers; their constructors still race safely on config.
        if not cold: ConcurrencyGate(limit,self.base)
        workers=[ctx.Process(target=_stress_gate,args=(str(self.base),limit,active,maximum,errors)) for _ in range(8)]
        for p in workers:p.start()
        for p in workers:
            p.join(30)
            if p.is_alive():p.terminate();p.join();self.fail('Semaphore deadlock')
            self.assertEqual(p.exitcode,0)
        recorded_errors=[]
        while True:
            try:recorded_errors.append(errors.get_nowait())
            except queue.Empty:break
        errors.close();errors.join_thread()
        self.assertEqual(recorded_errors,[], 'Semaphore worker errors: '+repr(recorded_errors))
        self.assertEqual(active.value,0)
        self.assertGreaterEqual(maximum.value,1);self.assertLessEqual(maximum.value,limit)
    def test_eight_process_limit_one_never_overlaps(self):self.stress(1)
    def test_cold_start_eight_processes_initialize_atomically(self):self.stress(1,cold=True)
    def test_eight_process_limit_two_respects_capacity(self):self.stress(2)
    def test_empty_old_slot_file_cannot_break_sqlite_capacity(self):
        (self.base/'slot-01.json').write_text('')
        with ConcurrencyGate(1,self.base):
            with self.assertRaises(SemaphoreError):
                with ConcurrencyGate(1,self.base,0):pass
    def test_positive_limit_requires_shared_directory(self):
        with self.assertRaises(SemaphoreError):ConcurrencyGate(1,None)
    def test_mixed_capacity_is_rejected(self):
        ConcurrencyGate(1,self.base)
        with self.assertRaises(SemaphoreError):ConcurrencyGate(2,self.base)
    def test_negative_limit_is_rejected(self):
        with self.assertRaises(SemaphoreError):ConcurrencyGate(-1,self.base)
    def test_exception_keeps_uncertain_slot(self):
        with self.assertRaises(ModelTimeout):
            with ConcurrencyGate(1,self.base):raise ModelTimeout('unknown remote job')
        with self.assertRaises(SemaphoreError):
            with ConcurrencyGate(1,self.base,0):pass
    def test_crashed_pid_does_not_authorize_reclamation(self):
        ctx=multiprocessing.get_context('spawn');p=ctx.Process(target=_crash_gate,args=(str(self.base),))
        p.start();p.join(10);self.assertEqual(p.exitcode,7)
        with self.assertRaises(SemaphoreError):
            with ConcurrencyGate(1,self.base,0):pass
    def test_bound_termination_receipt_releases_exact_owner(self):
        gate=ConcurrencyGate(1,self.base)
        with self.assertRaises(RuntimeError):
            with gate:
                token=gate.held;raise RuntimeError('unknown')
        p=self.base/'receipt.json';write_json(p,{'owner_token':token,'termination':'confirmed_stopped','reason':'test-only confirmed stop'})
        gate.reconcile(token,p)
        with ConcurrencyGate(1,self.base,0):pass
    def test_wrong_token_cannot_release_owner(self):
        gate=ConcurrencyGate(1,self.base)
        with gate:
            p=self.base/'receipt.json';write_json(p,{'owner_token':'wrong','termination':'confirmed_stopped','reason':'test'})
            with self.assertRaises(SemaphoreError):gate.reconcile(gate.held,p)
    def test_unlimited_gate_is_explicit(self):
        with ConcurrencyGate(0,None) as gate:self.assertIsNone(gate.held)
    def test_reentrant_same_instance_is_rejected(self):
        gate=ConcurrencyGate(1,self.base)
        with gate:
            with self.assertRaises(SemaphoreError):gate.__enter__()

class NativeContractTests(Case):
    """SIMULATED host observation tests, not actual Claude Code execution."""
    def prepare(self):
        self.plan=load_json(DEMO/'plan.native-v3.json');TeamStore.create(self.job,self.plan,DEMO)
        self.adapter=ClaudeCodeAdapter(self.job);self.descriptor=self.adapter.prepare('facts','native-test-worker')
        self.packet=load_json(self.descriptor['packet_path'])
        return self.descriptor
    def event(self,kind='started'):
        path=Path(self.packet['workspace'])/'evidence'/('fixture-native-'+kind+'.json')
        write_json(path,{'fixture':True,'host_run_id':'simulated-host-test','event':kind,'NOT_REAL_NATIVE':True})
        return {'schema_version':1,'host':'claude_code_native','event':kind,'host_run_id':'simulated-host-test',
                'task_id':'facts','lease_token':self.packet['lease_token'],'native_tool':'Agent (SIMULATED TEST)',
                'raw_evidence_path':path.relative_to(Path(self.packet['workspace'])).as_posix(),
                'raw_evidence_sha256':sha(path),'observed_by':'coordinator'}
    def test_prepare_does_not_execute_and_disallows_recursion(self):
        d=self.prepare();self.assertEqual(d['execution'],'NOT_EXECUTED')
        definition=Path(d['definition_path']).read_text();self.assertIn('disallowedTools: Agent',definition)
        self.assertIn('permissionMode: default',definition);self.assertNotIn('bypassPermissions',definition)
    def test_second_prepare_cannot_duplicate_same_work(self):
        self.prepare()
        with self.assertRaises(TeamError):self.adapter.prepare('facts','second-worker')
    def test_model_plan_cannot_be_presented_as_native(self):
        TeamStore.create(self.job,self.plan,DEMO)
        with self.assertRaises(TeamError):ClaudeCodeAdapter(self.job).prepare('facts','worker')
    def test_native_rework_uses_a_new_definition_name(self):
        self.prepare();before=agent_definition(self.packet)
        after=copy.deepcopy(self.packet);after['lease_token']='new-attempt-token'
        self.assertNotEqual(before.splitlines()[1],agent_definition(after).splitlines()[1])
    def test_raw_observation_is_required(self):
        self.prepare();e=self.event();e['raw_evidence_sha256']='0'*64
        with self.assertRaises(TeamError):self.adapter.bind_observed(e)
    def test_partial_event_is_not_completion(self):
        self.prepare();self.adapter.bind_observed(self.event());e=self.event('finished');e['event']='partial'
        with self.assertRaises(TeamError):self.adapter.collect_observed(e)
    def test_collect_before_bind_is_rejected(self):
        self.prepare()
        with self.assertRaises(TeamError):self.adapter.collect_observed(self.event('finished'))
    def test_simulated_native_file_collection_stays_unverified(self):
        self.prepare();self.adapter.bind_observed(self.event())
        p=Path(self.packet['output_root'])/'research/facts.json';p.parent.mkdir();write_json(p,good_facts())
        answer=self.adapter.collect_observed(self.event('finished'));self.assertTrue(answer['submitted'])
        with TeamStore(self.job) as store:
            result=json.loads(store.row('facts')['result']);self.assertEqual(result['checks'][0]['outcome'],'UNVERIFIED')
            self.assertEqual(store.row('facts')['status'],'submitted')
    def test_simulated_native_collection_supports_binary_artifact_bytes(self):
        self.plan=load_json(DEMO/'plan.native-v3.json');task=self.plan['tasks'][0]
        data=b'\x00\xff\xfeBINARY-FIXTURE'
        task['outputs'][0]['path']='research/facts.bin';task['acceptance'][0]['method']='file-sha256-v1'
        task['acceptance'][0]['params']={'sha256':hashlib.sha256(data).hexdigest()}
        TeamStore.create(self.job,self.plan,DEMO);self.adapter=ClaudeCodeAdapter(self.job)
        self.descriptor=self.adapter.prepare('facts','native-test-worker');self.packet=load_json(self.descriptor['packet_path'])
        self.adapter.bind_observed(self.event());p=Path(self.packet['output_root'])/'research/facts.bin';p.parent.mkdir();p.write_bytes(data)
        self.adapter.collect_observed(self.event('finished'))
        with TeamStore(self.job) as store:result=json.loads(store.row('facts')['result'])
        self.assertTrue(evaluate(self.packet,result)['passed']);self.assertEqual(p.read_bytes(),data)
    def test_native_definition_requires_explicit_tool_permissions(self):
        self.prepare();packet=copy.deepcopy(self.packet);packet['contract']['tools'].append('Bash')
        with self.assertRaises(TeamError):agent_definition(packet)
    def test_install_is_dry_run_by_default(self):
        d=self.prepare();project=self.base/'project';project.mkdir()
        info=install(project,Path(d['definition_path']));self.assertFalse(info['installed']);self.assertFalse((project/'.claude').exists())
    def test_install_cannot_overwrite_an_existing_agent(self):
        d=self.prepare();project=self.base/'project';project.mkdir()
        install(project,Path(d['definition_path']),apply=True)
        with self.assertRaises(ValueError):install(project,Path(d['definition_path']),apply=True)
    def test_installer_rejects_symlink_directory(self):
        d=self.prepare();project=self.base/'project';project.mkdir();make_symlink_or_skip(self, project/'.claude', self.base, target_is_directory=True)
        with self.assertRaises(ValueError):install(project,Path(d['definition_path']),apply=True)

class PrivacyTests(Case):
    def test_default_export_does_not_copy_sources_prompts_or_paths(self):
        self.create();secret='USER-BUSINESS-TEXT-MUST-STAY-PRIVATE'
        (Path(self.packet['workspace'])/'evidence/model-transcript.json').write_text(secret)
        target=self.base/'release';export(self.job,target)
        self.assertEqual(sorted(p.name for p in target.iterdir()),['MANIFEST.json','summary.json'])
        text=''.join(p.read_text() for p in target.iterdir());self.assertNotIn(secret,text);self.assertNotIn(str(self.job),text)
    def test_private_export_preserves_empty_stderr_log(self):
        self.create();p=Path(self.packet['workspace'])/'evidence/stderr.log';p.write_bytes(b'')
        target=self.base/'private';export(self.job,target,private=True,acknowledge_sensitive=True)
        logs=list(target.rglob('stderr.log'));self.assertEqual(len(logs),1);self.assertEqual(logs[0].read_bytes(),b'')
    def test_private_export_requires_explicit_acknowledgment(self):
        self.create()
        with self.assertRaises(ValueError):export(self.job,self.base/'private',private=True)
    def test_private_export_has_a_release_blocking_marker(self):
        self.create();target=self.base/'private';export(self.job,target,private=True,acknowledge_sensitive=True)
        self.assertTrue((target/'PRIVATE_EVIDENCE.json').is_file())
    def test_export_cannot_recurse_into_own_job(self):
        self.create()
        with self.assertRaises(ValueError):export(self.job,self.job/'release')
    def package_root(self):
        p=self.base/'skill';p.mkdir();(p/'SKILL.md').write_text('---\nname: skill\ndescription: test\n---\nTest')
        return p
    def test_release_blocks_unknown_raw_transcript(self):
        p=self.package_root();(p/'model-transcript.json').write_text('{}')
        with self.assertRaises(PackageError):build_archive(p,self.base/'out.zip')
    def test_release_blocks_private_directory(self):
        p=self.package_root();(p/'.private').mkdir();(p/'.private/x.txt').write_text('private')
        with self.assertRaises(PackageError):build_archive(p,self.base/'out.zip')
    def test_release_blocks_unreviewed_provenance(self):
        p=self.package_root();(p/'provenance').mkdir();(p/'provenance/evidence.json').write_text('{}')
        with self.assertRaises(PackageError):build_archive(p,self.base/'out.zip')
    def test_reviewed_fixture_hash_is_allowed_but_mutation_is_not(self):
        p=self.package_root();(p/'provenance').mkdir();f=p/'provenance/evidence.json';f.write_text('{}')
        write_json(p/'release-evidence-allowlist.json',{'files':{'provenance/evidence.json':sha(f)}})
        self.assertTrue(build_archive(p,self.base/'ok.zip')['valid'])
        f.write_text('{"new_private_input":true}')
        with self.assertRaises(PackageError):build_archive(p,self.base/'bad.zip')

if __name__=='__main__':unittest.main()
