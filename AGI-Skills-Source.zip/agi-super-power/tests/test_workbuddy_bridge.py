"""Offline regression fixtures for the WorkBuddy Mobile Cloud adapter v0.1.

These tests do not create real agents. The raw returns used here are fixtures
modeled on the WB-01/WB-01B/WB-02 live evidence; real returns must be saved by
the coordinator and normalized via workbuddy_bridge.py.
"""
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from kernel import load_json
from team_runtime import TeamStore, TeamError, digest, write_json
from delivery_state import begin_submission
from host_adapters.workbuddy_mobile_cloud import WorkBuddyMobileCloudAdapter, parse_agent_ids
from host_adapters.workbuddy_contract import validate_sync_terminal_observation
from host_registry import host_info, preflight, execution_mode
from host_contract34 import blank_probe, ADAPTERS, TARGET_PRODUCTS
import v3_protocol
from workbuddy_bridge import normalize, contract as bridge_contract

RAW_OK = ('任务完成：result.json 已写入。\n\n'
          '[Agent ID: agent-670eea937b1a42ed]')


class WorkBuddyBridgeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.job=Path(self.temp.name)/'job'
        self.inputs=ROOT/'examples/workbuddy-mc'
        self.plan=load_json(self.inputs/'plan.workbuddy-v3.json')
    def prepare(self):
        TeamStore.create(self.job,self.plan,self.inputs,offline_fixture=True)
        from workbuddy_test_support import seed_capabilities
        seed_capabilities(self.job)
        self.adapter=WorkBuddyMobileCloudAdapter(self.job)
        self.desc=self.adapter.prepare('impl','wbmc-worker')
        self.packet=load_json(self.desc['packet_path'])
        return self.desc
    def begin_submit(self):
        with TeamStore(self.job) as s:return begin_submission(s,'impl',self.packet['lease_token'])
    def raw_evidence(self,text=RAW_OK):
        path=Path(self.packet['workspace'])/'evidence'/'workbuddy-raw-return.txt'
        path.write_text(text,encoding='utf-8')
        return path
    def event(self,event='finished',ident='agent-670eea937b1a42ed',text=RAW_OK):
        path=self.raw_evidence(text)
        from workbuddy_test_support import attach_call_evidence
        attach_call_evidence(self.job,Path(self.desc['packet_path']),path)
        return {'schema_version':1,'host':'workbuddy_mobile_cloud','event':event,
                'host_run_id':ident,'task_id':'impl','lease_token':self.packet['lease_token'],
                'native_tool':'Agent',
                'raw_evidence_path':path.relative_to(Path(self.packet['workspace'])).as_posix(),
                'raw_evidence_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                'observed_by':'coordinator'}
    def output(self,wrong=False):
        expected=(self.inputs/'expected-result.json').read_bytes()
        p=Path(self.packet['output_root'])/'result.json';p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(expected if not wrong else expected+b' ')  # one extra byte = wrong
    def review(self,task='impl',artifact=None):
        with TeamStore(self.job) as s:
            r=json.loads(s.row(task)['result'])
            name={'impl':'impl-check.json','audit':'audit-check.json'}[task]
            p=self.job/'reviews'/name
            write_json(p,{'method':'coordinator strict recheck on accept','sha256':artifact} if artifact
                       else {'method':'coordinator strict recheck on accept'})
            return s.review({'task_id':task,'result_id':r['result_id'],'result_digest':digest(r),
                'goal_digest':r['goal_digest'],'reviewer':'coordinator','decision':'accept',
                'reason':'Verify frozen bytes/values independently',
                'evidence_path':'reviews/'+name,'evidence_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    def guarded_happy_path(self):
        self.prepare();self.begin_submit()
        self.adapter.bind_observed(self.event());self.output()
        return self.adapter.collect_observed(self.event('finished'))

    # --- registration surface -------------------------------------------------
    def test_registry_marks_mobile_cloud_implemented_and_desktop_handoff(self):
        self.assertEqual(execution_mode('workbuddy_mobile_cloud'),'native')
        self.assertTrue(host_info('workbuddy_mobile_cloud')['implemented'])
        self.assertFalse(host_info('workbuddy')['implemented'])            # desktop alias untouched
        self.assertEqual(preflight('workbuddy',[],[])['status'],'HANDOFF_ONLY')
        self.assertEqual(preflight('workbuddy_mobile_cloud',['file.read'],['file.read'])['status'],'READY_FOR_HOST_PROBE')
    def test_v3_wire_accepts_new_host_only_with_transport(self):
        t=self.plan['tasks'][0];v3_protocol.validate_task(t)
        bad=copy.deepcopy(t);bad['executor']['transport_network']=False
        with self.assertRaises(ValueError):v3_protocol.validate_task(bad)
        bad2=copy.deepcopy(t);bad2['executor']['type']='workbuddy_candidate'
        with self.assertRaises(ValueError):v3_protocol.validate_task(bad2)
    def test_adapter_registered_in_host_contract(self):
        self.assertIn('workbuddy_mobile_cloud',ADAPTERS)
        self.assertEqual(TARGET_PRODUCTS['workbuddy_mobile_cloud'],'WorkBuddy Mobile Cloud')
        self.assertEqual(TARGET_PRODUCTS['workbuddy_candidate'],'WorkBuddy Desktop')
    def test_version_claims_stay_scoped(self):
        v=load_json(ROOT/'VERSION.json')
        self.assertIn('HANDOFF_ONLY',v['workbuddy'])                        # desktop statement preserved
        self.assertEqual(v['workbuddy_mobile_cloud'],'ADAPTER_CANDIDATE_INTEGRATION_NOT_EXECUTED')
        self.assertEqual(v['package_version'],'3.4.0-rc.7')
        catalog=load_json(ROOT/'assets/hosts/catalog.json')
        self.assertEqual(catalog['hosts']['workbuddy_mobile_cloud']['integration_status'],'NOT_EXECUTED')
        self.assertEqual(catalog['hosts']['workbuddy_candidate']['status'],'handoff_contract_only')

    # --- guarded lifecycle ----------------------------------------------------
    def test_prepare_is_not_launch(self):
        d=self.prepare();self.assertEqual(d['execution'],'NOT_EXECUTED')
        self.assertEqual(d['execution_mode'],'synchronous_terminal')
        self.assertFalse(d['query_supported'])
        self.assertEqual(d['task_id'],'impl')  # ledger task id; the HOST task_id stays nonexistent
    def test_bind_blocked_without_begin_submit(self):
        self.prepare()
        with self.assertRaises(TeamError):self.adapter.bind_observed(self.event())
    def test_sync_terminal_happy_path(self):
        out=self.guarded_happy_path();self.assertTrue(out['submitted'])
        with TeamStore(self.job) as s:
            row=s.row('impl');self.assertEqual(row['host_run_id'],'agent-670eea937b1a42ed')
            self.assertEqual(row['mode'],'native')
    def test_started_observation_never_binds(self):
        self.prepare();self.begin_submit()
        with self.assertRaises(TeamError):self.adapter.bind_observed(self.event(event='started'))
    def test_agent_id_mismatch_rejected(self):
        self.prepare();self.begin_submit()
        with self.assertRaises(TeamError):self.adapter.bind_observed(self.event(ident='agent-different'))
    def test_missing_agent_id_never_binds(self):
        self.prepare();self.begin_submit()
        with self.assertRaises(TeamError):self.adapter.bind_observed(self.event(text='任务完成，无尾注。'))
    def test_double_agent_id_rejected(self):
        self.prepare();self.begin_submit()
        text=RAW_OK+'\n[Agent ID: agent-second-one]'
        with self.assertRaises(TeamError):self.adapter.bind_observed(self.event(ident='agent-670eea937b1a42ed',text=text))
    def test_wrong_output_bytes_fail_acceptance(self):
        self.prepare();self.begin_submit()
        self.adapter.bind_observed(self.event());self.output(wrong=True)
        self.adapter.collect_observed(self.event('finished'))
        with self.assertRaises(TeamError):self.review()
    def test_correct_output_accepts_and_publishes(self):
        self.guarded_happy_path();self.review()
        with TeamStore(self.job) as s:
            self.assertEqual(s.row('impl')['status'],'accepted')
        published=self.job/'published'/'result.json'
        self.assertTrue(published.is_file())
        self.assertEqual(hashlib.sha256(published.read_bytes()).hexdigest(),
                         hashlib.sha256((self.inputs/'expected-result.json').read_bytes()).hexdigest())

    # --- parser + normalizer --------------------------------------------------
    def test_parser_requires_exactly_one_footer(self):
        self.assertEqual(parse_agent_ids(RAW_OK),['agent-670eea937b1a42ed'])
        self.assertEqual(parse_agent_ids('no footer'),[])
        self.assertEqual(validate_sync_terminal_observation(RAW_OK,'agent-670eea937b1a42ed'),
                         'agent-670eea937b1a42ed')
        with self.assertRaises(TeamError):validate_sync_terminal_observation('no footer','x')
        with self.assertRaises(TeamError):validate_sync_terminal_observation(RAW_OK,'agent-other')
    def test_normalize_state_rules(self):
        n=normalize(RAW_OK,'completed')
        self.assertEqual(n['status'],'COMPLETED_SYNC');self.assertEqual(n['agent_id'],'agent-670eea937b1a42ed')
        self.assertEqual(n['agent_id_status'],'PARSED');self.assertTrue(n['bind_eligible'])
        n2=normalize('完成但无尾注','completed')
        self.assertEqual(n2['agent_id_status'],'ID_UNKNOWN');self.assertIsNone(n2['agent_id'])
        self.assertFalse(n2['bind_eligible'])
        n3=normalize('boom: tool call exploded','failed')
        self.assertEqual(n3['status'],'FAILED');self.assertIsNone(n3['agent_id'])
        n4=normalize('', 'outcome_unknown')
        self.assertEqual(n4['status'],'EXECUTION_OUTCOME_UNKNOWN')
        self.assertIn('No auto-recreate',n4['next_action'])
    def test_normalized_result_matches_frozen_spec(self):
        n=normalize(RAW_OK,'completed')
        self.assertEqual(n['host'],'workbuddy_mobile_cloud')
        self.assertEqual(n['execution_mode'],'synchronous_terminal')
        self.assertIsNone(n['task_id']);self.assertFalse(n['query_supported'])
        self.assertEqual(n['cancel_supported'],'unknown')
        self.assertEqual(n['live_resume_supported'],'unknown')
        self.assertEqual(n['terminal_result'],RAW_OK)
        self.assertEqual(n['terminal_result_sha256'],hashlib.sha256(RAW_OK.encode()).hexdigest())
    def test_bridge_contract_lists_forbidden_assumptions(self):
        c=bridge_contract()
        self.assertTrue(any('task_id' in x for x in c['forbidden_assumptions']))
        self.assertFalse(c['query_supported'])

if __name__=='__main__':unittest.main()
