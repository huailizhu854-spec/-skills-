import copy
import hashlib
from pathlib import Path
import sys
import tempfile
import unittest
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "scripts"))
from evolution_gate import compare
from team_runtime import TeamError


class EvolutionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup); self.root = Path(self.tmp.name)
        (self.root / "log.txt").write_text("actual fixture log", encoding="utf-8")
        evidence_sha = hashlib.sha256((self.root / "log.txt").read_bytes()).hexdigest()
        case = dict(id="case-one", input_digest="1"*64, passed=False, required=True, hard_violation=False, cost_units=10, evidence_path="log.txt", evidence_sha256=evidence_sha)
        self.before = dict(schema_version=1, suite_id="suite", suite_digest="2"*64, environment_digest="3"*64, candidate_digest="4"*64, mode="software-runtime", cases=[case])
        self.after = copy.deepcopy(self.before); self.after["candidate_digest"] = "5"*64; self.after["cases"][0]["passed"] = True

    def test_improved_paired_evidence_only_becomes_eligible(self):
        result = compare(self.before, self.after, self.root)
        self.assertEqual(result["decision"], "ELIGIBLE_FOR_REVIEW")
        self.assertFalse(result["installed_skill_changed"])

    def test_fixture_quality_cannot_promote_real_behavior(self):
        self.before["mode"] = self.after["mode"] = "fixture"
        self.assertEqual(compare(self.before, self.after, self.root)["decision"], "HOLD")

    def test_missing_cost_measurement_holds(self):
        self.after["cases"][0]["cost_units"] = None
        self.assertEqual(compare(self.before, self.after, self.root)["decision"], "HOLD")

    def test_regression_or_hard_boundary_violation_rejects(self):
        self.before["cases"][0]["passed"] = True; self.after["cases"][0]["passed"] = False
        self.assertEqual(compare(self.before, self.after, self.root)["decision"], "REJECT")
        self.after["cases"][0]["passed"] = True; self.after["cases"][0]["hard_violation"] = True
        self.assertEqual(compare(self.before, self.after, self.root)["decision"], "REJECT")

    def test_cost_regression_rejects(self):
        self.after["cases"][0]["cost_units"] = 12
        self.assertEqual(compare(self.before, self.after, self.root)["decision"], "REJECT")

    def test_unchanged_score_and_cost_holds(self):
        self.before["cases"][0]["passed"] = True
        self.assertEqual(compare(self.before, self.after, self.root)["decision"], "HOLD")

    def test_unequal_suite_environment_or_inputs_rejects(self):
        for field in ("suite_digest", "environment_digest", "mode"):
            changed = copy.deepcopy(self.after); changed[field] = "fixture" if field == "mode" else "9"*64
            with self.subTest(field=field), self.assertRaises(TeamError): compare(self.before, changed, self.root)
        changed = copy.deepcopy(self.after); changed["cases"][0]["input_digest"] = "9"*64
        with self.assertRaises(TeamError): compare(self.before, changed, self.root)

    def test_dropping_cases_or_relaxing_requirements_rejects(self):
        changed = copy.deepcopy(self.after); changed["cases"][0]["id"] = "different"
        with self.assertRaises(TeamError): compare(self.before, changed, self.root)
        changed = copy.deepcopy(self.after); changed["cases"][0]["required"] = False
        with self.assertRaises(TeamError): compare(self.before, changed, self.root)

    def test_forged_evidence_hash_is_rejected(self):
        self.after["cases"][0]["evidence_sha256"] = "0"*64
        with self.assertRaises(TeamError): compare(self.before, self.after, self.root)

    def test_nonfinite_or_negative_cost_rejected(self):
        for value in (float("nan"), float("inf"), -1, True):
            changed = copy.deepcopy(self.after); changed["cases"][0]["cost_units"] = value
            with self.subTest(value=value), self.assertRaises(TeamError): compare(self.before, changed, self.root)

if __name__ == '__main__': unittest.main()
