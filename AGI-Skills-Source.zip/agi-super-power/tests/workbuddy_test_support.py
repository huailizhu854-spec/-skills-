"""Synthetic WorkBuddy fixtures, explicitly separate from a live job."""
import hashlib
import json
import time
from pathlib import Path
from team_runtime import TeamStore, write_json
from workbuddy_policy import template, freeze, REQUIRED

def seed_capabilities(job):
    with TeamStore(job) as store:
        v=template(store)
        raw=job/'reviews/offline-capabilities.txt'
        raw.write_bytes(b'OFFLINE SYNTHETIC tools fixture; not a real WorkBuddy observation.\n')
        pin={'path':raw.relative_to(job).as_posix(),'sha256':hashlib.sha256(raw.read_bytes()).hexdigest()}
        p=v['probe'];p.update(evidence_kind='OFFLINE_FIXTURE',os='Offline test OS',client_version='UNKNOWN',observed_at=time.time()-1,expires_at=time.time()+3600)
        for c in REQUIRED:p['capabilities'][c]={'status':'supported','evidence':pin}
        v['native_tool']='Agent'
        for key in v['file_tools']:
            v['file_tools'][key]={'status':'supported','native_tool':'fixture_'+key,'evidence':pin}
        path=job/'reviews/offline-capabilities.json';write_json(path,v)
        freeze(store,path)
        return path

def attach_call_evidence(job, packet_path, raw_path, *, outcome='completed'):
    from workbuddy_evidence import record_intent, record_return, INTENT, RECORD
    from delivery_state import dispatch
    packet=json.loads(Path(packet_path).read_bytes());folder=Path(packet['workspace'])/'evidence'
    with TeamStore(job) as store:
        d=dict(dispatch(store,packet['lease_token']))
    if not d['guarded']:return
    if not (folder/INTENT).exists():
        auth=folder/'fixture-authorization.json';args=folder/'fixture-arguments.json';sub=folder/'fixture-submission.json'
        write_json(auth,{'schema_version':1,'job':str(job),'plan_digest':packet['plan_digest'],
            'instruction':'OFFLINE synthetic fixture only. No host invocation.', 'source_kind':'coordinator_transcription',
            'source_ref':None,'message_time':None,'previous_job':None,'source_file':None})
        write_json(args,{'prompt':(folder/'workbuddy-delegation.md').read_bytes().decode('utf-8')})
        write_json(sub,{'request_key':d['request_key'],'state':'SUBMITTING','execution':'NOT_EXECUTED'})
        record_intent(job,Path(packet_path),auth,args,sub)
    if not (folder/RECORD).exists():
        record_return(job,Path(packet_path),raw_path,outcome)
