# 来源与再分发说明

本包的入口、中文 SOP、岗位配置、验证内核、生成器和发行工具是本次任务为用户编写的整合成果。外部项目的通用思想通过独立实现吸收；没有把各框架运行时或所有插件复制进来。

## 随包保留的第三方材料

`provenance/licensed-reference/superpowers/implementer-prompt.source.txt` 为 obra/superpowers 的未修改实施者模板，固定提交 `5bf4e78011075bcfc0dc295f0724994cd123ee71`，原路径 `skills/subagent-driven-development/implementer-prompt.md`。其完整 MIT 许可证随同保存在 `provenance/licensed-reference/superpowers/LICENSE.txt`。

此源文件为惰性核对资料。里面的模型指定、提交、询问等指令不属于本包执行入口；本包已按用户目标重新设计对应派发协议。精确文件哈希由最终发行清单记录。

其余 GitHub 源码只保留永久链接、版本与独立概述，不随包分发其运行时。AgentSkills 文档采用 CC-BY-4.0、其代码采用 Apache-2.0；Anthropic skill-creator 子目录采用 Apache-2.0，不据此推定该仓库所有技能同许可。AutoGen 的文档与代码许可也分别记录。

## 用户原包与本机插件

用户提供的原包用于审计和提炼流程。新包不包含旧嵌套来源仓、疑似个人数据、历史授权声明或商业插件资源。对应取舍见 provenance/archive-audit.md 与 plugin-audit.md。

本包不会自动改变第三方材料的许可证或给出新的再分发授权。若后续引入新的第三方源文件，需检查实际文件许可、保留通知并更新来源台账。
