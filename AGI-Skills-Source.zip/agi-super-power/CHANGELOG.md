# 3.4.0-rc.7 — External Bridge 接通验收候选（2026-09-27）

- 新增 provider-neutral HTTP 推理适配器、18份隔离的应用上下文、2×8派单与交叉审阅。不是ChatGPT原生子Agent。
- 固定问候的云端三阶段执行（PLAN / WORK / REVIEW）、持久化意图与回执、租约和幂等键；未完成通用代码/研究任务自动执行。
- 新增专用令牌鉴权、仅service_role可执行的数据库RPC、费用确认与模型传输授权前置、无付费回退。
- 外部模型调用或回执不确定就阻塞；允许原执行者最多两次确定性返工；不重跑已通过的15人。
- 新增原始HTTP回执哈希、主控决策与最终问候内容核对；版本号/上下文ID均不能证明真实执行。
- 原生模块除版本元数据外保留原实现；两处旧测试仅更新版本字面量，没有放宽断言。
- 真实模型验收仍须服务端配置后的实际证据；离线HTTP fixture不得改记为模型通过。

---

# 3.4.0-rc.6 — Dual16（2026-09-27）

- 新增严格2主控/16执行者拓扑，2×8唯一分组；新用户任务入口不采用最小团队策略。
- 将会话登记、两主控决策、一次性派单许可与交叉审阅接入原 TeamStore 数据库。
- 主控/执行者真实宿主ID唯一，18人存活barrier；原生派单改为复用已登记会话，禁止重复创建。
- 原 claim/bind/review/status 增加硬检查；错误批准仍受独立验收器阻止；目标更新前须核实全部18会话停止。
- 缺能力/额度、宿主身份不明、控制回执丢失时阻塞，不用角色扮演或低人数串行冒充。
- 增加纯标准库的18进程离线端到端测试、故障注入、专项回归、使用与实机验收文件。
- 原所有历史证据保留，不继承为rc.6原生成功。两处旧测试仅更新版本字面量，未放宽业务断言。

---

# 3.4.0-rc.5 — 第二轮修复候选（2026-09-23）

修复Windows派单换行；新增WorkBuddy能力冻结、执行入口证据检查、离线profile、历史作业只读；完善文件系统环境诊断；修复SQLite并发槽位释放的锁争用问题。全量737项，723通过、14环境阻塞，0失败错误。手机云端和桌面实机仍未验证。详见references/release-report.md与references/workbuddy-rc5-handoff.md。

# WorkBuddy Mobile Cloud Adapter v0.1（基于 3.4.0-rc.1 的接入补丁，2026-09-23）

- 新增 `workbuddy_mobile_cloud` 原生观察适配器（`scripts/host_adapters/workbuddy_mobile_cloud.py` + `workbuddy_contract.py`）：仅建模 **synchronous_terminal** 执行模式——总控一次真实 Agent 调用阻塞至终态，返回尾部由宿主附加 `[Agent ID: ...]`；bind 前强制校验恰一个 Agent ID 尾注、`begin-submit` 已执行（`LIFECYCLE_NOT_ENABLED` 闸门）。
- 新增 `scripts/workbuddy_bridge.py normalize/contract`：把真实原始返回归一化为 COMPLETED_SYNC / FAILED / EXECUTION_OUTCOME_UNKNOWN，`task_id` 恒为 null，解析失败记 `ID_UNKNOWN`，不伪造任何标识或能力。
- 注册面最小变更：`host_registry.IMPLEMENTED`、`v3_protocol.HOSTS` 与原生传输集合、`host_contract34.ADAPTERS/TARGET_PRODUCTS`、`native_host_bridge.py --host` 各加入 `workbuddy_mobile_cloud`；`assets/hosts/catalog.json` 新增实测条目。裸别名 `workbuddy` 与桌面候选 `workbuddy_candidate` 仍为 HANDOFF_ONLY。
- 新增离线测试 `tests/test_workbuddy_bridge.py` 与集成计划样例 `examples/workbuddy-mc/`（串行 impl→audit，冻结逐字节验收）。
- 依据：WB-01 / WB-01B / WB-02 实测报告（2026-09-23，WorkBuddy 云端沙箱）。未支持能力（query/cancel/resume/后台注册表）保持 unknown/false，不假装兼容。WorkBuddy 桌面端不在本补丁范围。

# 3.4.0-rc.1 — Reliable delivery candidate

- Reuse the existing TeamStore ledger; add transactional dispatch metadata and minimal checkpoints for NEW jobs only.
- Add explicit guarded submission, terminal observation reconciliation, cancellation-pending semantics, and no-blind-retry recovery.
- Add canonical path containment without resolving away links/reparse points; Windows native verification remains outstanding.
- Add evidence-bound host capability contracts. WorkBuddy remains handoff-only; no desktop transport is fabricated.
- Add frozen manual quality gates, explicit memory invalidation, beginner briefs, conservative impact analysis, and honest usage summaries.
- One existing version test now checks exact VERSION.json consistency rather than the obsolete 3.3.0 substring; other legacy tests are retained.
- Original wire schemas, bounded-model adapter and native observation adapter semantic versions are not mechanically bumped.
- See references/delivery-v34.md for limitations and release-report.md for measured results.

# 3.3.0 — Intelligence Layer（离线验证候选）

- 新增有限意图编译、工具/职责硬筛选、可复算路由和绑定候选集的宿主语义判断入口。
- 新增显式许可的项目记忆、来源与时效、冲突保留、替代关系、字节预算上下文胶囊；接入 compile/claim/模型 prompt。
- 新增 L0–L3 工作流深度；每任务尝试上限在 claim 与返工状态转移中执行。
- 新增终态路由成绩单及幂等去重；不自动调整策略，不把失败直接当路由错误。
- schema 3 新增 blockers/warnings/environment_notes；旧 concerns 保持阻塞语义。
- 新增 WorkBuddy 候选宿主与非执行交接入口；没有 WorkBuddy 原生执行适配器。
- 保留旧 SQLite 账本结构、所有权、版本栅栏、租约、独立验证及恢复协议。新计划使用可选 intelligence 扩展。
- 分开发布版本与协议/验证器语义版本；加强私有记忆与成绩单数据库的发布拦截。
- 新增小白指南、离线端到端示例、合成路由回归与机器可读测试报告。

详细实测及开发中修复记录见 `reports/v3.3/`；不能将合成回归结果解释为真实宿主成功率。

---

# 版本记录

## 3.2.0 — 2026-09-21

第一次真实派发 Claude Code 原生子 Agent。`examples/team-demo/plan.native-v3.json` 四个任务全部由宿主 `Agent` 工具执行并通过总控独立验证器验收；facts 与 outline 在同一条消息里派发，事件日志区间重叠 68.25 秒。原始工具返回原文保存在 `provenance/v4/native-run/raw-observations/`。

重要限制：per-attempt 定义写入 `.claude/agents/` 成功，但本会话在启动后不再重新发现定义，宿主按名字拒绝了它们。派发改用内置通用子 Agent，把定义正文当任务说明传入，因此 `tools` / `disallowedTools` 本轮**没有被宿主强制执行**，只是指令级约束。证据见 `provenance/v4/discovery/definition-visibility-probe.json`。

新增简历体检流水线 `examples/resume-clinic/`（schema 3，六任务，executor 为 bounded_model），以及 `scripts/verifiers_resume.py` 的六个确定性验证器。它们只证明「没有编造、没有遗漏」：取值必须逐字来自原文、引文必须落在所声称的行、JD 编号要求必须逐条有结论、建议与诊断一一对应、报告不得漏项、QA 自报覆盖率必须与事实一致。它们**不评价建议质量**。`scripts/verifier_registry.py` 只新增六个键，现有八个函数与键零改动。

五个造假桩各自在对应任务被拦截，下游始终未解锁；诚实桩六任务全部 accepted。本轮未提供模型，**没有真模型调用**，全部为确定性桩。

`max_concurrent_model_calls` 历史低报的根因查明：该字段是 `AGI_MODEL_MAX_CONCURRENT` 的回显，默认 0 表示「不限并发」，从来不是观测值。本轮用事件日志时间戳独立计算并发度，结果为 2。

新增打包隐私测试：模拟客户作业目录放进包目录后 `package_release.py build` 拒绝出包。

第 2 节冻结清单十个文件哈希全部未变；`tests/` 与 `provenance/` 既有文件字节未变。`scripts/team_runtime.py` 的 `VERSION` 常量因冻结仍为 3.1.0，与本包 3.2.0 不一致，见迭代报告。

## 3.0.0 — 2026-09-20

在 Claude host-bridge-v3 候选上最终整合，不推倒重写。主宿主固定为 Claude Code 原生子 Agent；新增只负责 prepare/bind/collect 的接线层和默认 dry-run 的定义安装器，不自建模型执行器。

团队协议升级到 schema 3：执行底座与任务权限分离、验收显式 subject、生产者只能报告产物完整性，总控独立运行注册验证器。未知方法拒绝晋级。旧 schema 2 仅保留离线 fixture/inline，不允许隐式改成模型任务。

替换文件槽位为 SQLite 事务并发门；异常和进程消失不释放未知远端任务。每次模型尝试即时 fsync journal，全失败也有记录；错误响应有有界捕获与截断标记。修正 CLI is_error、严格 JSON、路径和派发前宿主校验。

默认导出最小发布证据；完整运行原文需显式私有导出，发布器拒绝未审阅 provenance。动态适配路径，统一入口/指南/派生 Skill 版本。历史 provenance/v3 原字节保留，不冒充新版模型实测。

测试与发行清单见 provenance/v3-final；本轮没有真实 native/HTTP/模型稳定性/浏览器渲染结果。旧 2.0.0 条目描述历史版本，不是现版边界。

## 2.0.0 — 2026-09-20

在用户提供的 1.0.0 上增量迭代。共同目标、真实派发、唯一任务与产物、已验收成果复用优先于增加 Agent 数量。

新增 team_runtime.py：目标与计划摘要、任务责任去重、需求验收覆盖、DAG、唯一产物路径、SQLite 原子领单、租约与运行绑定、输入快照、证据复核、先验收后解锁、去重回执、定向返工、确认停止后恢复、迟到成果接纳和版本切换。

新增 team_runner.py：经明确授权的前台命令适配器，以实际子进程执行一批任务；不自带模型密钥，不执行计划中的任意 shell，不自动批准成果。

新增 evolution_gate.py：失败观察候选、冻结评测条件的成对比较、回归/成本/硬约束门禁。候选需审阅，不自行安装；测试桩不能证明模型能力提升。

更新 SKILL.md 与 build_specialist.py：总控保留总目标；被委派岗位直接进入叶节点协议，禁止再组队和重复全局工作。原有六个岗位不删除，新增验收与交付整合两种职责模板。

新增四任务离线演示、74 项回归/反例测试、实际测试日志、使用指南、启动指令和宿主桥接手册。新版共 151 项测试通过，8 个岗位 ZIP 构建通过；真实模型宿主端到端验证仍为 NOT_EXECUTED。

原 kernel.py、package_release.py 与历史 provenance 保持原字节；打包清单重建。安装不会由本包自动发生；保留原版 ZIP 即可回退安装版本，尚在运行的作业不能直接跨版本改账本。
