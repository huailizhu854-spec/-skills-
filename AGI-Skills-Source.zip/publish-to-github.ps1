# Publish after inspecting the extracted files. Never asks for or stores credentials.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = $PSScriptRoot
$dest = Join-Path (Split-Path $root -Parent) 'agi-skills-github-checkout'
if (Test-Path $dest) { throw "Directory already exists: $dest. Move it first; nothing overwritten." }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git for Windows is required: https://git-scm.com/downloads/win' }
& git clone https://github.com/huailizhu854-spec/-skills-.git $dest
if ($LASTEXITCODE -ne 0) { throw 'Git clone failed.' }
foreach ($item in Get-ChildItem -LiteralPath $root -Force) {
  if ($item.Name -eq '.git') { continue }
  Copy-Item -LiteralPath $item.FullName -Destination $dest -Recurse -Force
}
Write-Host "`n--- Changed files (first review the list carefully) ---" -ForegroundColor Cyan
& git -C $dest status --short
if ($LASTEXITCODE -ne 0) { throw 'git status failed' }
Write-Host "`nExamine the files in $dest before publishing." -ForegroundColor Yellow
$choice = Read-Host 'Type PUBLISH to commit and push this PUBLIC SOURCE to GitHub (anything else cancels)'
if ($choice -cne 'PUBLISH') { Write-Host 'Cancelled. Checkout saved locally.'; exit 0 }
& git -C $dest add --all
if ($LASTEXITCODE -ne 0) { throw 'git add failed' }
& git -C $dest commit -m 'feat: publish sanitized AGI Skills Dual16 and Agent Harness source'
if ($LASTEXITCODE -ne 0) { throw 'git commit failed (configure git name/email or check repo status).' }
& git -C $dest push origin HEAD:main
if ($LASTEXITCODE -ne 0) { throw 'git push failed. Check GitHub login and write permission.' }
Write-Host 'Published. Verify live contents at https://github.com/huailizhu854-spec/-skills-'
